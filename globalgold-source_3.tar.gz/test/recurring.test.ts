/**
 * Customers, reports and recurring payments.
 *
 * The subscription tests are the important ones. A recurring charge happens
 * with nobody watching, so a double charge is not noticed until a chargeback
 * and a charge after cancellation is not noticed until a complaint. Both are
 * tested directly, including two workers racing for the same due subscription.
 *
 * Runs on the simulated network, which is the only one that can complete a
 * payment without a real processor. The scheduling, claiming, counting and
 * stopping are all provider-independent, which is what is under test here.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-recurring';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'off';
process.env.CARD_RATE_LIMIT = '1000';
process.env.AUTH_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { runDueSubscriptions } = await import('../src/payments/subscriptions.js');

let base = '';
let server: http.Server;

async function api(method: string, path: string, key?: string, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: {
      'content-type': 'application/json',
      ...(key ? { authorization: `Bearer ${key}` } : {}),
      ...(method === 'POST' ? { 'idempotency-key': crypto.randomUUID() } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json, text };
}

async function business() {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await api('POST', '/v1/business/signup', undefined, {
    business_name: `Sub Seller ${who}`, name: 'Owner', email: `sub-${who}@test.com`,
    password: 'a-long-password-123', country: 'US', business_type: 'company',
  });
  await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [r.body.merchant_id]);
  return { key: r.body.token as string, id: r.body.merchant_id as string };
}

/**
 * A fresh, valid test card every time.
 *
 * Not a constant like 4242…: the risk engine blocks a card seen more than ten
 * times in an hour across all merchants, which is correct behaviour and would
 * otherwise make these tests fail each other depending on the order they ran
 * in. A distinct fingerprint per card keeps each test independent.
 */
let cardSeq = 0;
function testCard() {
  const body = ('4000' + String(100000000000 + (cardSeq += 7))).slice(0, 15);
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    let d = Number(body[body.length - 1 - i]);
    if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return {
    number: body + String((10 - (sum % 10)) % 10),
    exp_month: 12, exp_year: 2040, cvc: '123',
  };
}

/** A customer with a card on file, ready to be billed. */
async function customerWithCard(key: string, email: string) {
  const cus = await api('POST', '/v1/customers', key, { email, name: 'Ada Lovelace' });
  assert.equal(cus.status, 201, cus.text);
  const tok = await api('POST', '/v1/tokens', key, {
    card: testCard(),
  });
  assert.equal(tok.status, 201, tok.text);
  const pm = await api('POST', `/v1/customers/${cus.body.id}/payment_methods`, key,
    { payment_token: tok.body.id });
  assert.equal(pm.status, 201, pm.text);
  return { customer: cus.body.id as string, method: pm.body.id as string };
}

/**
 * Make a subscription due right now, without waiting for a real interval.
 * Only touches an active one: re-arming a subscription that has finished or
 * gone unpaid would be the test putting back what the code correctly removed.
 */
async function makeDue(id: string) {
  await pool.query(
    `UPDATE subscriptions SET next_charge_at = now() - interval '1 minute'
      WHERE id=$1 AND status='active'`, [id]);
}

let seller: { key: string; id: string };

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  seller = await business();
});

after(async () => { server?.close(); await pool.end(); });

describe('customers', () => {
  it('creates, finds and updates one', async () => {
    const c = await api('POST', '/v1/customers', seller.key, { email: 'Grace@Example.com', name: 'Grace' });
    assert.equal(c.status, 201, c.text);
    assert.equal(c.body.email, 'grace@example.com', 'email is normalised');

    const found = await api('GET', '/v1/customers?query=grace', seller.key);
    assert.equal(found.body.data.length, 1);

    const up = await api('POST', `/v1/customers/${c.body.id}`, seller.key, { phone: '+15551234567' });
    assert.equal(up.body.phone, '+15551234567');
    assert.equal(up.body.name, 'Grace', 'an unsent field is left alone');
  });

  it('keeps one record per email, whatever the case', async () => {
    await api('POST', '/v1/customers', seller.key, { email: 'dup@example.com', name: 'First' });
    const again = await api('POST', '/v1/customers', seller.key, { email: 'DUP@example.com', name: 'Second' });
    assert.equal(again.status, 409);
  });

  it('does not leak another merchant’s customers', async () => {
    const mine = await api('POST', '/v1/customers', seller.key, { email: 'private@example.com' });
    const stranger = await business();
    assert.equal((await api('GET', `/v1/customers/${mine.body.id}`, stranger.key)).status, 404);
    assert.equal((await api('POST', `/v1/customers/${mine.body.id}`, stranger.key, { name: 'x' })).status, 404);
    const list = await api('GET', '/v1/customers', stranger.key);
    assert.equal(list.body.data.length, 0);
  });
});

describe('recurring payments', () => {
  it('charges on schedule and moves the date forward by exactly one interval', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'monthly@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 9_900, currency: 'usd',
      interval: 'month', description: 'Pro plan',
    });
    assert.equal(sub.status, 201, sub.text);
    assert.equal(sub.body.status, 'active');
    assert.equal(sub.body.cycles_billed, 0);

    const before = new Date((await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key)).body.next_charge_at);
    await makeDue(sub.body.id);
    assert.deepEqual(await runDueSubscriptions(), { charged: 1, failed: 0 });

    const after = await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key);
    assert.equal(after.body.cycles_billed, 1);
    assert.equal(after.body.charges.length, 1);
    assert.equal(after.body.charges[0].status, 'succeeded');
    assert.equal(after.body.charges[0].amount, 9_900);
    assert.equal(after.body.charges[0].subscription_cycle, 1);

    void before;
  });

  it('bills from the scheduled date, so the billing day never drifts', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'drift@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 1_500, currency: 'usd', interval: 'day',
    });

    // Three days behind, as if the worker had been down. The next date must
    // come from the date that was DUE, not from when the worker finally ran:
    // advancing from now() is how a billing day creeps later every cycle, and
    // how a backlog silently collapses into one charge instead of three.
    await pool.query(
      `UPDATE subscriptions SET next_charge_at = now() - interval '3 days' WHERE id=$1`,
      [sub.body.id]);
    await runDueSubscriptions();

    const next = new Date((await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key)).body.next_charge_at);
    const hoursFromNow = (next.getTime() - Date.now()) / 3_600_000;
    assert.ok(hoursFromNow < -36,
      `expected the next charge still ~2 days overdue, got ${hoursFromNow.toFixed(1)}h from now`);

    // And the backlog drains one cycle per run rather than being lost.
    await runDueSubscriptions();
    await runDueSubscriptions();
    const done = await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key);
    assert.equal(done.body.cycles_billed, 3, 'each missed day is billed once');
  });

  it('cannot write two payments for one cycle, even bypassing the worker', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'index@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 1_000, currency: 'usd', interval: 'month',
    });
    await makeDue(sub.body.id);
    await runDueSubscriptions();

    // The last line of defence, tested directly: if every check in the worker
    // were removed, the database itself still refuses a second payment for a
    // cycle it has already billed.
    await assert.rejects(
      () => pool.query(
        `INSERT INTO payment_intents
           (id, merchant_id, customer_id, amount, currency, status, capture_method,
            client_secret, subscription_id, subscription_cycle)
         VALUES ('pi_dupe_test', $1, $2, 1000, 'usd', 'requires_payment_method',
                 'automatic', 'secret_dupe', $3, 1)`,
        [seller.id, customer, sub.body.id]),
      (e: any) => e.code === '23505',
      'the unique index on (subscription_id, subscription_cycle) must reject it');
  });

  it('does not bill twice when two workers run at the same moment', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'race@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 2_500, currency: 'usd', interval: 'week',
    });
    await makeDue(sub.body.id);

    // Two passes at once, as two containers of the same service would.
    const [a, b] = await Promise.all([runDueSubscriptions(), runDueSubscriptions()]);
    assert.equal(a.charged + b.charged, 1, 'exactly one of the two workers may bill it');

    const after = await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key);
    assert.equal(after.body.cycles_billed, 1);
    assert.equal(after.body.charges.length, 1);

    const rows = await pool.query(
      `SELECT count(*)::int AS n FROM payment_intents WHERE subscription_id=$1`, [sub.body.id]);
    assert.equal(rows.rows[0].n, 1, 'one payment row, not two');
  });

  it('bills each cycle exactly once over several runs', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'many@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 1_000, currency: 'usd', interval: 'day',
    });

    for (let i = 0; i < 3; i++) {
      await makeDue(sub.body.id);
      await runDueSubscriptions();
    }
    // A run with nothing due must charge nothing.
    assert.deepEqual(await runDueSubscriptions(), { charged: 0, failed: 0 });

    const after = await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key);
    assert.equal(after.body.cycles_billed, 3);
    assert.equal(after.body.charges.length, 3);
    assert.deepEqual(
      after.body.charges.map((c: any) => c.subscription_cycle).sort((x: number, y: number) => x - y),
      [1, 2, 3], 'one payment per cycle, no gaps and no repeats');
  });

  it('stops for good when cancelled, even if it was due', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'cancel@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 5_000, currency: 'usd', interval: 'month',
    });

    const c = await api('POST', `/v1/subscriptions/${sub.body.id}/cancel`, seller.key);
    assert.equal(c.body.status, 'canceled');
    assert.equal(c.body.next_charge_at, null, 'the worker must not even see it');

    // Due date forced back on, the way a stray update might. Status alone has
    // to be enough to keep it out, so this deliberately ignores the status.
    await pool.query(
      `UPDATE subscriptions SET next_charge_at = now() - interval '1 minute' WHERE id=$1`,
      [sub.body.id]);
    assert.deepEqual(await runDueSubscriptions(), { charged: 0, failed: 0 });
    assert.equal((await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key)).body.cycles_billed, 0);

    // And it cannot be quietly restarted.
    assert.equal((await api('POST', `/v1/subscriptions/${sub.body.id}/resume`, seller.key)).status, 400);
  });

  it('pauses without billing, then resumes', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'pause@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 3_000, currency: 'usd', interval: 'month',
    });

    await api('POST', `/v1/subscriptions/${sub.body.id}/pause`, seller.key);
    await makeDue(sub.body.id);
    assert.deepEqual(await runDueSubscriptions(), { charged: 0, failed: 0 });

    await api('POST', `/v1/subscriptions/${sub.body.id}/resume`, seller.key);
    await makeDue(sub.body.id);
    assert.deepEqual(await runDueSubscriptions(), { charged: 1, failed: 0 });
  });

  it('finishes by itself after the agreed number of cycles', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'installments@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 20_000, currency: 'usd',
      interval: 'month', max_cycles: 2, description: 'Two instalments',
    });

    for (let i = 0; i < 3; i++) { await makeDue(sub.body.id); await runDueSubscriptions(); }

    const after = await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key);
    assert.equal(after.body.cycles_billed, 2, 'never more than the agreed number');
    assert.equal(after.body.status, 'canceled');
    assert.equal(after.body.next_charge_at, null);
  });

  it('gives up on a card that keeps failing, instead of retrying forever', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'declines@example.com');
    const sub = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 4_000, currency: 'usd', interval: 'month',
    });
    // Over the merchant's per-transaction limit, so every attempt is refused.
    await pool.query('UPDATE subscriptions SET amount=$2 WHERE id=$1', [sub.body.id, 99_000_000]);

    for (let i = 0; i < 5; i++) { await makeDue(sub.body.id); await runDueSubscriptions(); }

    const after = await api('GET', `/v1/subscriptions/${sub.body.id}`, seller.key);
    assert.equal(after.body.status, 'unpaid');
    assert.equal(after.body.next_charge_at, null, 'stops being retried');
  });

  it('refuses a payment method belonging to someone else', async () => {
    const mine = await customerWithCard(seller.key, 'mine@example.com');
    const other = await customerWithCard(seller.key, 'other@example.com');
    const r = await api('POST', '/v1/subscriptions', seller.key, {
      customer: other.customer, payment_method: mine.method,
      amount: 1_000, currency: 'usd', interval: 'month',
    });
    assert.equal(r.status, 404);
  });

  it('refuses a start date in the past, which would bill every period since', async () => {
    const { customer, method } = await customerWithCard(seller.key, 'past@example.com');
    const r = await api('POST', '/v1/subscriptions', seller.key, {
      customer, payment_method: method, amount: 1_000, currency: 'usd',
      interval: 'month', start_at: new Date(Date.now() - 400 * 86_400_000).toISOString(),
    });
    assert.equal(r.status, 400);
  });
});

describe('reports', () => {
  it('adds up what was taken, and nets refunds off the right day', async () => {
    const shop = await business();
    const mk = async (amount: number) => {
      const pi = await api('POST', '/v1/payment_intents', shop.key, { amount, currency: 'usd' });
      const tok = await api('POST', '/v1/tokens', shop.key, {
        card: testCard(),
      });
      await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, shop.key, { payment_token: tok.body.id });
      return pi.body.id as string;
    };
    const a = await mk(10_000);
    await mk(5_000);
    await api('POST', '/v1/refunds', shop.key, { payment_intent: a, amount: 2_500 });

    const s = await api('GET', '/v1/reports/summary', shop.key);
    const usd = s.body.data.find((x: any) => x.currency === 'usd');
    assert.equal(usd.payments, 2);
    assert.equal(usd.gross, 15_000);
    assert.equal(usd.refunded, 2_500);
    assert.equal(usd.net, usd.gross - usd.refunded - usd.fees, 'net is its parts, not a stored number');
    assert.equal(usd.average_payment, 7_500);
  });

  it('never mixes currencies into one meaningless total', async () => {
    const shop = await business();
    for (const [amount, ccy] of [[10_000, 'usd'], [20_000, 'eur']] as const) {
      const pi = await api('POST', '/v1/payment_intents', shop.key, { amount, currency: ccy });
      const tok = await api('POST', '/v1/tokens', shop.key, {
        card: testCard(),
      });
      await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, shop.key, { payment_token: tok.body.id });
    }
    const s = await api('GET', '/v1/reports/summary', shop.key);
    assert.equal(s.body.data.length, 2);
    assert.equal(s.body.data.find((x: any) => x.currency === 'usd').gross, 10_000);
    assert.equal(s.body.data.find((x: any) => x.currency === 'eur').gross, 20_000);
  });

  it('shows quiet days as zero rather than leaving them out', async () => {
    const shop = await business();
    const pi = await api('POST', '/v1/payment_intents', shop.key, { amount: 1_000, currency: 'usd' });
    const tok = await api('POST', '/v1/tokens', shop.key, {
      card: testCard(),
    });
    await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, shop.key, { payment_token: tok.body.id });

    const from = new Date(Date.now() - 6 * 86_400_000).toISOString();
    const d = await api('GET', `/v1/reports/daily?from=${encodeURIComponent(from)}`, shop.key);
    assert.equal(d.body.data.length, 7, 'a week is seven rows, however little happened');
    assert.equal(d.body.data.filter((x: any) => x.gross > 0).length, 1);
  });

  it('exports CSV in real currency, not minor units', async () => {
    const shop = await business();
    const pi = await api('POST', '/v1/payment_intents', shop.key, { amount: 123_456, currency: 'usd' });
    const tok = await api('POST', '/v1/tokens', shop.key, {
      card: testCard(),
    });
    await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, shop.key, { payment_token: tok.body.id });

    const r = await fetch(`${base}/v1/reports/daily.csv`, { headers: { authorization: `Bearer ${shop.key}` } });
    const csv = await r.text();
    assert.match(r.headers.get('content-type') ?? '', /text\/csv/);
    assert.match(r.headers.get('content-disposition') ?? '', /attachment; filename=/);
    // 123456 minor units is 1,234.56 — a spreadsheet reading "123456" here
    // would file it as a hundred times the money.
    assert.match(csv, /"1234\.56"/);
    assert.match(csv, /^"Date","Currency"/);
  });

  it('refuses a range it cannot answer', async () => {
    assert.equal((await api('GET', '/v1/reports/summary?from=not-a-date', seller.key)).status, 400);
    const from = new Date(Date.now() - 500 * 86_400_000).toISOString();
    assert.equal((await api('GET', `/v1/reports/summary?from=${encodeURIComponent(from)}`, seller.key)).status, 400);
  });

  it('shows one merchant nothing of another’s takings', async () => {
    const stranger = await business();
    const s = await api('GET', '/v1/reports/summary', stranger.key);
    assert.equal(s.body.data.length, 0);
  });
});
