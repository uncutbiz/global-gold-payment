# Global Gold Payment — translation files

469 strings. Every one of them is already wired up in the app: the language
picker works, the fallback works, and the moment a translation lands in one of
these files it appears on the page. Nothing here is machine-translated, on
purpose — a payments screen that says the wrong thing about money is worse than
one in English.

## Two formats, same content — use whichever suits the translator

**CSV** (`es-spanish.csv`, `ht-haitian-creole.csv`, `sw-swahili.csv`,
`zh-chinese.csv`) — opens in Excel or Google Sheets. Three columns:

| key | english | es_translation |
|---|---|---|
| `sign_in_4b21` | Sign in | ← type here |

Fill the third column. Leave a row blank if you're unsure; a blank row shows
English, which is safe. Don't edit the `key` column — that's what the app
matches on.

**JSON** (`es.json`, `ht.json`, `sw.json`, `zh.json`) — for a developer or a
translation service that wants the file directly. Same keys, empty values.

`en.json` is the English reference. Don't translate it.

## Putting a finished translation back into the app

One command, from the project folder:

```bash
npm run i18n:import -- es ~/Downloads/es-spanish.csv
```

It prints how many translations it read and how many rows were left blank. Then
reload the page and pick the language — no rebuild, no restart, the catalogues
are fetched at runtime.

It is safe to run on a half-finished sheet, and safe to run twice: a blank row
keeps whatever the catalogue already had, so a second import can only add.

To send a fresh sheet out later — after the copy changes, or to show a
translator what's left — `npm run i18n:export`, which pre-fills everything
already translated.

(If the translator returns JSON instead, just drop their file straight into
`public/i18n/` — no import step needed.)

## Notes for whoever translates this

- **Money and dates are not in here.** Amounts, currency symbols and dates are
  formatted by the browser from the chosen language, so they're already right.
- **Keep it short.** Several of these are buttons in a narrow sidebar. If a
  translation is much longer than the English it will wrap awkwardly. Prefer the
  shorter phrasing.
- **`•••• •••• •••• 4748` style text isn't here** — masked card numbers,
  reference codes and IDs are deliberately left untranslated.
- **Tone:** plain and direct, the way a bank statement is. This is somebody's
  money; clarity beats warmth.
- 46 sentences are assembled at runtime (`"Sent $20.00 to Wanjiru"`) and are
  **not** in these files yet. They need a placeholder convention before they
  can be translated, which is a developer job — flagged, not forgotten.

## Which languages

| File | Language |
|---|---|
| `es.json` / `es-spanish.csv` | Spanish — Español |
| `ht.json` / `ht-haitian-creole.csv` | Haitian Creole — Kreyòl Ayisyen |
| `sw.json` / `sw-swahili.csv` | Swahili — Kiswahili |
| `zh.json` / `zh-chinese.csv` | Chinese — 中文 (Simplified; Traditional would need a separate `zh-Hant` file) |
