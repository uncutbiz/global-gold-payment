#!/usr/bin/env bash
#
#  package.sh — build the tarball the server installs.
#
#      bash scripts/package.sh [outfile]
#
#  Writes BUILD_STAMP first, because globalgold-update compares that value to
#  the one already on the machine and refuses to go backwards. A tarball built
#  without it installs fine but cannot participate in that check.
#
#  The output is named globalgold-build.tar.gz, matching DEFAULT_URL in
#  globalgold-update. The old name, globalgold-source.tar.gz, is deliberately
#  not reused: six numbered siblings of it exist in the repo, two byte-identical,
#  and one was pinned as a machine's update source for three deploys running.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-globalgold-build.tar.gz}"
date -u +%Y-%m-%dT%H:%M:%SZ > BUILD_STAMP
echo "build stamp: $(cat BUILD_STAMP)"
tar --exclude=node_modules --exclude=dist --exclude=.git \
    --exclude='.env' --exclude='.env.production' \
    --exclude='certs/*.pem' --exclude='*.pem' --exclude='*.ppk' \
    --exclude='.sandbox-ca.crt' --exclude='infra/aws/terraform.tfvars' \
    --exclude='*.tfstate*' --exclude='.deploy-logs' \
    --exclude='*.tgz' --exclude='*.tar.gz' --exclude='i18n-sheets' \
    -czf "$OUT" .
echo "$OUT  $(stat -c %s "$OUT") bytes"
echo "sha256: $(sha256sum "$OUT" | cut -d' ' -f1)"
