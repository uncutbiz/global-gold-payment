/**
 * The partner API — another platform (KobPaw) operating wallets for its users.
 *
 * A partner key can move other people's money, so most of this file is about
 * what a partner must NOT be able to do. The single rule being defended:
 *
 *     a partner may only touch a wallet it created.
 *
 * If that scoping is ever lost, one partner key becomes a key to every wallet
 * on the platform — including wallets belonging to people who signed up
 * directly and never heard of the partner. Each test below is one way that
 * could happen.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-partner';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.INVOICE_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'full';
process.env.PARTNER_RATE_LIMIT = '5000';
process.env.AUTH_RATE_LIMIT = '5000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { createPartner, issueKey, revokeKey, setPartnerStatus } = await import('../src/partners/partners.js');
const { acct, postJournal } = await import('../src/ledger/ledger.js');

let base = '';
let server: http.Server;

async function call(method: string, path: string, key?: string | null, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json: any = null;
  try { json = await r.json(); } catch { /* no body */ }
  return { status: r.status, body: json };
}

/** Put money in a wallet straight through the ledger, so transfers have funds. */
async function fund(walletId: string, minor = 500_00, currency = 'usd') {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await postJournal(c as any, currency, { type: 'test_fund', id: walletId }, 'test funding', [
      { account: acct.bankCash, debit: minor },
      { account: acct.wallet(walletId), credit: minor },
    ]);
    await c.query('COMMIT');
  } finally { c.release(); }
}

/** A wallet that signed up directly, with no partner. */
async function directWallet() {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await call('POST', '/v1/wallet/signup', null, {
    email: `direct-${who}@test.com`, name: 'Direct Person',
    password: 'correct horse battery', country: 'US',
  });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return { id: r.body.user.id as string, email: r.body.user.email as string, token: r.body.token as string };
}

let kobpaw: { id: string; key: string };
let rival: { id: string; key: string };

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  const a = await createPartner('KobPaw');
  kobpaw = { id: a.partner.id, key: a.key.key };
  const b = await createPartner('Rival Platform');
  rival = { id: b.partner.id, key: b.key.key };
});
after(async () => { server?.close(); await pool.end(); });

describe('authenticating as a partner', () => {
  it('identifies the partner behind the key', async () => {
    const r = await call('GET', '/v1/partner/me', kobpaw.key);
    assert.equal(r.status, 200);
    assert.equal(r.body.name, 'KobPaw');
  });

  it('refuses no key, a junk key, a revoked key and a suspended partner', async () => {
    assert.equal((await call('GET', '/v1/partner/me', null)).status, 401);
    assert.equal((await call('GET', '/v1/partner/me', 'pt_live_nonsense')).status, 401);

    const extra = await issueKey(kobpaw.id, 'to-be-revoked');
    assert.equal((await call('GET', '/v1/partner/me', extra.key)).status, 200);
    await revokeKey(kobpaw.id, extra.id);
    assert.equal((await call('GET', '/v1/partner/me', extra.key)).status, 401, 'a revoked key is dead');

    const temp = await createPartner('Temporarily Bad');
    await setPartnerStatus(temp.partner.id, 'suspended');
    assert.equal((await call('GET', '/v1/partner/me', temp.key.key)).status, 401,
      'a suspended partner cannot act even with a valid key');
  });

  it('a partner key is not a merchant key and cannot reach merchant endpoints', async () => {
    assert.equal((await call('GET', '/v1/items', kobpaw.key)).status, 401);
    assert.equal((await call('GET', '/v1/balance', kobpaw.key)).status, 401);
  });
});

describe('creating wallets for its users', () => {
  it('creates a wallet addressed by the partner\'s own reference', async () => {
    const r = await call('POST', '/v1/partner/wallets', kobpaw.key, {
      ref: 'kp-user-1', email: `kp1-${crypto.randomBytes(3).toString('hex')}@test.com`,
      name: 'Marie Joseph', country: 'US',
    });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    assert.equal(r.body.ref, 'kp-user-1');
    assert.equal(r.body.created, true);
    assert.ok(r.body.wallet_id);
    assert.equal(r.body.kyc_status, 'unverified');
    // No session or password leaks back to the partner.
    assert.equal(r.body.token, undefined);
    assert.equal(r.body.password, undefined);
  });

  it('the same reference twice returns the same wallet, not a second one', async () => {
    const email = `kp-dup-${crypto.randomBytes(3).toString('hex')}@test.com`;
    const a = await call('POST', '/v1/partner/wallets', kobpaw.key, { ref: 'kp-dup', email, name: 'Dup', country: 'US' });
    assert.equal(a.status, 201);
    const b = await call('POST', '/v1/partner/wallets', kobpaw.key, { ref: 'kp-dup', email, name: 'Dup', country: 'US' });
    assert.equal(b.status, 200, 'the retry is not a new wallet');
    assert.equal(b.body.created, false);
    assert.equal(b.body.wallet_id, a.body.wallet_id);
  });

  it('CANNOT adopt a wallet that signed up directly', async () => {
    // The takeover case. Knowing somebody's email must not hand a partner
    // control of their existing account.
    const victim = await directWallet();
    const r = await call('POST', '/v1/partner/wallets', kobpaw.key, {
      ref: 'stolen', email: victim.email, name: 'Not Me', country: 'US',
    });
    assert.equal(r.status, 409);
    assert.equal(r.body.error.code, 'email_belongs_to_another_account');

    // And the victim's wallet is still unowned by any partner.
    const owner = (await pool.query('SELECT partner_id FROM users WHERE id=$1', [victim.id])).rows[0];
    assert.equal(owner.partner_id, null);
  });

  it('CANNOT adopt another partner\'s wallet', async () => {
    const email = `rv-${crypto.randomBytes(3).toString('hex')}@test.com`;
    assert.equal((await call('POST', '/v1/partner/wallets', rival.key,
      { ref: 'rival-1', email, name: 'Theirs', country: 'US' })).status, 201);

    const r = await call('POST', '/v1/partner/wallets', kobpaw.key,
      { ref: 'poach', email, name: 'Mine Now', country: 'US' });
    assert.equal(r.status, 409);
    assert.equal(r.body.error.code, 'email_belongs_to_another_account');
  });

  it('refuses a bad email or an unsupported country', async () => {
    assert.equal((await call('POST', '/v1/partner/wallets', kobpaw.key,
      { ref: 'bad-1', email: 'not-an-email', name: 'X', country: 'US' })).status, 400);
    assert.equal((await call('POST', '/v1/partner/wallets', kobpaw.key,
      { ref: 'bad-2', email: `ok-${crypto.randomBytes(3).toString('hex')}@test.com`, name: 'X', country: 'ZZ' })).status, 400);
  });
});

describe('reading a wallet', () => {
  it('reads its own wallet\'s balance and KYC state', async () => {
    const email = `kp-read-${crypto.randomBytes(3).toString('hex')}@test.com`;
    const made = await call('POST', '/v1/partner/wallets', kobpaw.key, { ref: 'kp-read', email, name: 'Reader', country: 'US' });
    await fund(made.body.wallet_id, 250_00);

    const r = await call('GET', '/v1/partner/wallets/kp-read', kobpaw.key);
    assert.equal(r.status, 200);
    assert.equal(r.body.ref, 'kp-read');
    const usd = (r.body.balances ?? []).find((b: any) => b.currency === 'usd');
    assert.ok(usd, 'a balance is reported');
    assert.equal(usd.amount, 250_00);
  });

  it('another partner\'s reference is NOT FOUND, not forbidden', async () => {
    // 404 rather than 403: confirming the ref exists would itself leak.
    const r = await call('GET', '/v1/partner/wallets/kp-read', rival.key);
    assert.equal(r.status, 404);
  });

  it('a reference that was never created is not found', async () => {
    assert.equal((await call('GET', '/v1/partner/wallets/no-such-ref', kobpaw.key)).status, 404);
  });
});

describe('moving money', () => {
  async function wallet(ref: string, funded = 500_00) {
    const email = `kp-${ref}-${crypto.randomBytes(3).toString('hex')}@test.com`;
    const r = await call('POST', '/v1/partner/wallets', kobpaw.key, { ref, email, name: `User ${ref}`, country: 'US' });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    if (funded) await fund(r.body.wallet_id, funded);
    return { ref, email, id: r.body.wallet_id as string };
  }

  it('quotes a transfer before sending it', async () => {
    const from = await wallet('q-from');
    const to = await wallet('q-to', 0);
    const r = await call('POST', '/v1/partner/transfer_quotes', kobpaw.key,
      { from_ref: from.ref, to_email: to.email, amount: 50_00 });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.ok(r.body.fee !== undefined || r.body.total !== undefined, 'a quote carries the cost');
  });

  it('sends money between two of its own wallets', async () => {
    const from = await wallet('t-from');
    const to = await wallet('t-to', 0);
    const r = await call('POST', '/v1/partner/transfers', kobpaw.key,
      { from_ref: from.ref, to_email: to.email, amount: 40_00, note: 'rent' });
    assert.equal(r.status, 201, JSON.stringify(r.body));

    const after = await call('GET', `/v1/partner/wallets/${to.ref}`, kobpaw.key);
    const usd = (after.body.balances ?? []).find((b: any) => b.currency === 'usd');
    assert.ok(usd && usd.amount > 0, 'the recipient was credited');
  });

  it('can send TO a wallet it does not own — sending to someone is not acting on them', async () => {
    const from = await wallet('x-from');
    const outsider = await directWallet();
    const r = await call('POST', '/v1/partner/transfers', kobpaw.key,
      { from_ref: from.ref, to_email: outsider.email, amount: 20_00 });
    assert.equal(r.status, 201, JSON.stringify(r.body));
  });

  it('CANNOT send FROM a wallet it does not own', async () => {
    // The whole point. A partner may not spend other people's money.
    const mine = await wallet('victim-src');
    const r = await call('POST', '/v1/partner/transfers', rival.key,
      { from_ref: 'victim-src', to_email: 'anywhere@test.com', amount: 10_00 });
    assert.equal(r.status, 404, 'the other partner cannot even address that wallet');

    // The balance is untouched.
    const still = await call('GET', `/v1/partner/wallets/${mine.ref}`, kobpaw.key);
    const usd = (still.body.balances ?? []).find((b: any) => b.currency === 'usd');
    assert.equal(usd.amount, 500_00);
  });

  it('CANNOT withdraw from a wallet it does not own', async () => {
    await wallet('wd-src');
    assert.equal((await call('POST', '/v1/partner/wallets/wd-src/withdrawals', rival.key, { amount: 10_00 })).status, 404);
  });

  it('respects the ordinary wallet limits — a partner key is not a bypass', async () => {
    const from = await wallet('limit-src', 50_000_00);
    const to = await wallet('limit-dst', 0);
    // Unverified wallets are capped; a huge send must be refused the same way
    // it would be for a person using the app directly.
    const r = await call('POST', '/v1/partner/transfers', kobpaw.key,
      { from_ref: from.ref, to_email: to.email, amount: 40_000_00 });
    assert.ok(r.status >= 400, `expected a refusal, got ${r.status}`);
    // Whichever cap bites first — the per-send maximum or the unverified-KYC
    // ceiling — the point is that the partner key did not lift it.
    assert.match(JSON.stringify(r.body), /kyc|limit|verif|maximum|too_large/i);
  });

  it('refuses to overdraw', async () => {
    const from = await wallet('poor-src', 5_00);
    const to = await wallet('poor-dst', 0);
    const r = await call('POST', '/v1/partner/transfers', kobpaw.key,
      { from_ref: from.ref, to_email: to.email, amount: 100_00 });
    assert.ok(r.status >= 400);
  });
});

describe('the audit trail', () => {
  it('records what the partner did, including refusals', async () => {
    const email = `kp-audit-${crypto.randomBytes(3).toString('hex')}@test.com`;
    await call('POST', '/v1/partner/wallets', kobpaw.key, { ref: 'kp-audit', email, name: 'Audited', country: 'US' });
    // A refusal: adopting a direct wallet.
    const victim = await directWallet();
    await call('POST', '/v1/partner/wallets', kobpaw.key, { ref: 'kp-audit-fail', email: victim.email, name: 'X', country: 'US' });

    const rows = (await pool.query(
      `SELECT action, subject_ref, ok FROM partner_actions
        WHERE partner_id = $1 ORDER BY created_at DESC LIMIT 20`, [kobpaw.id])).rows;
    assert.ok(rows.some((r) => r.subject_ref === 'kp-audit' && r.ok === true), 'the success is recorded');
    assert.ok(rows.some((r) => r.subject_ref === 'kp-audit-fail' && r.ok === false), 'the refusal is recorded too');
  });
});
