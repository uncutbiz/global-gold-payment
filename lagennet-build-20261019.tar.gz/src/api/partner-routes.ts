/**
 * The partner API: another platform operating wallets for its own users.
 *
 *   POST /v1/partner/wallets                  create (or fetch) a wallet
 *   GET  /v1/partner/wallets/:ref             balance and KYC state
 *   GET  /v1/partner/wallets/:ref/activity    that wallet's history
 *   POST /v1/partner/wallets/:ref/kyc         submit identity documents
 *   POST /v1/partner/transfer_quotes          what a transfer would cost
 *   POST /v1/partner/transfers                send money
 *   POST /v1/partner/wallets/:ref/withdrawals cash out to a bank
 *   GET  /v1/partner/me                       which partner this key is
 *
 * Everything here reuses the same wallet engine the first-party app uses — the
 * same limits, the same fees, the same KYC gates, the same ledger. A partner
 * route that reimplemented any of that would drift, and the drift would be in
 * money. The only thing these routes add is WHO is asking: a partner key
 * instead of an end user's session, scoped so a partner can only ever reach
 * the wallets it created.
 *
 * The wallet-mode gates are applied here too. If this deployment has P2P
 * switched off, a partner key does not get to bypass that.
 */
import { Router, json } from 'express';
import { z } from 'zod';
import { config } from '../config.js';
import { SUPPORTED_CURRENCIES } from '../util/common.js';
import { rateLimit } from './middleware.js';
import {
  createPartnerWallet, logPartnerAction, partnerUser, presentPartnerWallet, requirePartner,
} from '../partners/partners.js';
import {
  getActivity, getWallet, quoteTransfer, sendMoney, withdraw,
} from '../wallet/wallet.js';
import { submitKyc, latestKyc } from '../wallet/kyc.js';

export const partnerApi = Router();

/*
 * Mounted before the global JSON parser (its body limit is small and KYC
 * documents arrive as base64), so this router parses its own bodies.
 */
const body = json({ limit: '8mb' });
const smallBody = json({ limit: '32kb' });
const pk = requirePartner;
const limit = rateLimit(Number(process.env.PARTNER_RATE_LIMIT ?? 300), 60_000);

const currency = z.string().toLowerCase().pipe(z.enum(SUPPORTED_CURRENCIES));
const cents = z.number().int().positive().max(1_000_000_000_00);

function needsWallet(_req: any, res: any, next: any) {
  if (config.walletMode === 'off') {
    return res.status(403).json({ error: {
      type: 'invalid_request_error', code: 'wallet_disabled',
      message: 'Wallet balances are not enabled on this platform.',
    }});
  }
  next();
}
function needsP2P(_req: any, res: any, next: any) {
  if (config.walletMode !== 'full') {
    return res.status(403).json({ error: {
      type: 'invalid_request_error', code: 'transfers_disabled',
      message: 'Person-to-person transfers are not enabled on this platform.',
    }});
  }
  next();
}

partnerApi.get('/v1/partner/me', pk, limit, async (req, res) => {
  res.json({ object: 'partner', id: req.partner!.id, name: req.partner!.name, status: req.partner!.status });
});

// ───────────────────────────────────────────── wallets
partnerApi.post('/v1/partner/wallets', pk, limit, needsWallet, smallBody, async (req, res) => {
  const input = z.object({
    ref: z.string().min(1).max(200),
    email: z.string().max(254),
    name: z.string().trim().min(1).max(100),
    country: z.string().length(2),
  }).parse(req.body ?? {});

  try {
    const { wallet, created } = await createPartnerWallet(req.partner!.id, input);
    await logPartnerAction(req.partner!.id, req.partnerKeyId, 'wallet.create', input.ref, true, { created });
    res.status(created ? 201 : 200).json(presentPartnerWallet(wallet, input.ref, { created }));
  } catch (e: any) {
    await logPartnerAction(req.partner!.id, req.partnerKeyId, 'wallet.create', input.ref, false,
      { code: e?.code ?? null });
    throw e;
  }
});

partnerApi.get('/v1/partner/wallets/:ref', pk, limit, needsWallet, async (req, res) => {
  const ref = req.params.ref as string;
  const u = await partnerUser(req.partner!.id, ref);
  const w = await getWallet(u);
  const kyc = await latestKyc(u.id).catch(() => null);
  res.json(presentPartnerWallet(u, ref, { balances: (w as any).balances ?? [], kyc: kyc ?? null }));
});

partnerApi.get('/v1/partner/wallets/:ref/activity', pk, limit, needsWallet, async (req, res) => {
  const u = await partnerUser(req.partner!.id, req.params.ref as string);
  const q = z.object({ limit: z.coerce.number().int().min(1).max(200).optional() }).parse(req.query ?? {});
  res.json({ object: 'list', data: await getActivity(u.id, q.limit ?? 50) });
});

/*
 * KYC on behalf of the user. The documents are the person's, so the partner is
 * passing them through rather than vouching for them — the same review queue
 * and the same decision apply, and an unverified wallet keeps the same limits
 * it would have anywhere else.
 */
partnerApi.post('/v1/partner/wallets/:ref/kyc', pk, limit, needsWallet, body, async (req, res) => {
  const ref = req.params.ref as string;
  const u = await partnerUser(req.partner!.id, ref);
  const input = z.object({
    legal_name: z.string().min(1).max(200),
    date_of_birth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    address_line: z.string().min(1).max(300),
    city: z.string().min(1).max(120),
    postal_code: z.string().min(1).max(40),
    country: z.string().length(2),
    id_type: z.enum(['passport', 'national_id', 'drivers_license']),
    id_number: z.string().min(1).max(100),
    document: z.string().min(1),
  }).parse(req.body ?? {});

  const r = await submitKyc(u.id, input);
  await logPartnerAction(req.partner!.id, req.partnerKeyId, 'wallet.kyc', ref, true, {});
  res.status(201).json(r);
});

// ───────────────────────────────────────────── moving money
/** What a transfer would cost, before committing to it. */
partnerApi.post('/v1/partner/transfer_quotes', pk, limit, needsP2P, smallBody, async (req, res) => {
  const input = z.object({
    from_ref: z.string().min(1).max(200),
    to_email: z.string().max(254),
    amount: cents,
    currency: currency.optional(),
  }).parse(req.body ?? {});
  const from = await partnerUser(req.partner!.id, input.from_ref);
  res.json(await quoteTransfer(from, { to: input.to_email, amount: input.amount, currency: input.currency }));
});

/**
 * Send money from one of the partner's wallets.
 *
 * The recipient is addressed by email, exactly as in the first-party app, and
 * may be any Lagennet wallet — the partner's own user or anybody else's.
 * That asymmetry is deliberate: sending TO someone is not acting ON their
 * account, so it needs no claim over them. Sending FROM a wallet does, and
 * `partnerUser` enforces it.
 */
partnerApi.post('/v1/partner/transfers', pk, limit, needsP2P, smallBody, async (req, res) => {
  const input = z.object({
    from_ref: z.string().min(1).max(200),
    to_email: z.string().max(254),
    amount: cents,
    currency: currency.optional(),
    note: z.string().max(200).optional(),
    quote: z.string().optional(),
  }).parse(req.body ?? {});

  const from = await partnerUser(req.partner!.id, input.from_ref);
  try {
    const r = await sendMoney(from, {
      to: input.to_email, amount: input.amount,
      currency: input.currency, note: input.note, quote: input.quote,
    });
    await logPartnerAction(req.partner!.id, req.partnerKeyId, 'transfer.send', input.from_ref, true,
      { amount: input.amount, currency: input.currency ?? null });
    res.status(201).json(r);
  } catch (e: any) {
    await logPartnerAction(req.partner!.id, req.partnerKeyId, 'transfer.send', input.from_ref, false,
      { amount: input.amount, code: e?.code ?? null });
    throw e;
  }
});

partnerApi.post('/v1/partner/wallets/:ref/withdrawals', pk, limit, needsP2P, smallBody, async (req, res) => {
  const ref = req.params.ref as string;
  const u = await partnerUser(req.partner!.id, ref);
  const input = z.object({ amount: cents, currency: currency.optional() }).parse(req.body ?? {});
  const r = await withdraw(u, input.amount, input.currency);
  await logPartnerAction(req.partner!.id, req.partnerKeyId, 'wallet.withdraw', ref, true, { amount: input.amount });
  res.status(201).json(r);
});
