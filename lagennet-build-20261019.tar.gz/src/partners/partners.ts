/**
 * Partners: another platform operating Lagennet wallets for its own users.
 *
 * See migrations/024 for why this exists. The security model is the whole
 * point of this file, so it is stated here rather than left implicit:
 *
 *   1. A partner key authenticates a PLATFORM, not a person. It can move
 *      money, so it is stored hashed and can be revoked.
 *
 *   2. A partner may only act on wallets it created. Every lookup goes through
 *      `partnerUser`, which filters on partner_id. A wallet belonging to
 *      someone who signed up directly, or to a different partner, resolves to
 *      "not found" — not "forbidden", because confirming the id exists is
 *      itself a disclosure.
 *
 *   3. A partner cannot adopt an existing wallet. If the email is already on
 *      the platform and is not already this partner's, creation is refused.
 *      Allowing it would be account takeover by whoever knows an email
 *      address.
 *
 *   4. Partner-created wallets get a random password nobody holds. The partner
 *      authenticates on the user's behalf; the person can claim the wallet
 *      later through the ordinary forgotten-password flow. A predictable or
 *      shared password would make every partner wallet openable by anyone who
 *      guessed the scheme.
 */
import type { NextFunction, Request, Response } from 'express';
import crypto from 'node:crypto';
import { Db, one, pool, tx } from '../db.js';
import { ApiError, newId, sha256 } from '../util/common.js';
import type { WalletUser } from '../wallet/wallet.js';

export interface Partner {
  id: string;
  name: string;
  status: 'active' | 'suspended';
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      partner?: Partner;
      partnerKeyId?: string;
    }
  }
}

const USER_COLS = 'id, email, name, country, currency, kyc_status';

/** A partner and its first key. The key is returned once and never again. */
export async function createPartner(name: string, label = 'initial') {
  if (!name?.trim()) throw new ApiError(400, 'name_required', 'A partner needs a name.');
  return tx(async (c) => {
    const p = await one<Partner>(c,
      `INSERT INTO partners (id, name) VALUES ($1,$2) RETURNING id, name, status`,
      [newId('ptr'), name.trim()]);
    const key = await issueKey(p!.id, label, c);
    return { partner: p!, key };
  });
}

/**
 * Issue a key. Returns the plaintext, which is the only time it exists in a
 * readable form — only its hash is stored.
 */
export async function issueKey(partnerId: string, label = 'additional', db: Db = pool) {
  const exists = await one(db, 'SELECT 1 FROM partners WHERE id = $1', [partnerId]);
  if (!exists) throw new ApiError(404, 'resource_missing', 'Partner not found.');
  const raw = `pt_live_${crypto.randomBytes(24).toString('base64url')}`;
  const id = newId('ptk');
  await db.query(
    `INSERT INTO partner_keys (id, partner_id, key_hash, last_four, label)
     VALUES ($1,$2,$3,$4,$5)`,
    [id, partnerId, sha256(raw), raw.slice(-4), label]);
  return { id, key: raw, last_four: raw.slice(-4) };
}

export async function revokeKey(partnerId: string, keyId: string) {
  const r = await pool.query(
    `UPDATE partner_keys SET revoked_at = now()
      WHERE id = $1 AND partner_id = $2 AND revoked_at IS NULL`, [keyId, partnerId]);
  if (!r.rowCount) throw new ApiError(404, 'resource_missing', 'No active key with that id.');
  return { ok: true };
}

export async function listKeys(partnerId: string) {
  const r = await pool.query(
    `SELECT id, last_four, label, revoked_at, created_at
       FROM partner_keys WHERE partner_id = $1 ORDER BY created_at DESC`, [partnerId]);
  return r.rows;
}

export async function setPartnerStatus(partnerId: string, status: 'active' | 'suspended') {
  const p = await one<Partner>(pool,
    `UPDATE partners SET status = $2, updated_at = now() WHERE id = $1
     RETURNING id, name, status`, [partnerId, status]);
  if (!p) throw new ApiError(404, 'resource_missing', 'Partner not found.');
  return p;
}

export async function listPartners() {
  const r = await pool.query(
    `SELECT p.id, p.name, p.status, p.created_at,
            (SELECT COUNT(*)::int FROM users u WHERE u.partner_id = p.id) AS wallets,
            (SELECT COUNT(*)::int FROM partner_keys k WHERE k.partner_id = p.id AND k.revoked_at IS NULL) AS active_keys
       FROM partners p ORDER BY p.created_at DESC`);
  return r.rows;
}

/** Resolve a key to its partner. Null for unknown, revoked or suspended. */
export async function partnerForKey(raw: string): Promise<{ partner: Partner; keyId: string } | null> {
  if (!raw) return null;
  const row = await one<any>(pool,
    `SELECT k.id AS key_id, p.id, p.name, p.status
       FROM partner_keys k JOIN partners p ON p.id = k.partner_id
      WHERE k.key_hash = $1 AND k.revoked_at IS NULL`, [sha256(raw)]);
  if (!row) return null;
  if (row.status !== 'active') return null;
  return { partner: { id: row.id, name: row.name, status: row.status }, keyId: row.key_id };
}

export async function requirePartner(req: Request, _res: Response, next: NextFunction) {
  const h = req.header('authorization');
  const key = h?.startsWith('Bearer ') ? h.slice(7).trim() : undefined;
  if (!key) {
    throw new ApiError(401, 'unauthorized', 'Provide your partner key as "Authorization: Bearer <key>".');
  }
  const found = await partnerForKey(key);
  if (!found) throw new ApiError(401, 'invalid_partner_key', 'That partner key is not valid.');
  req.partner = found.partner;
  req.partnerKeyId = found.keyId;
  next();
}

/** Record what a partner did. Never throws — an audit failure must not eat the action. */
export async function logPartnerAction(
  partnerId: string, keyId: string | undefined, action: string,
  subjectRef: string | null, ok: boolean, detail: Record<string, unknown> = {},
) {
  await pool.query(
    `INSERT INTO partner_actions (partner_id, key_id, action, subject_ref, ok, detail)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [partnerId, keyId ?? null, action, subjectRef, ok, JSON.stringify(detail)],
  ).catch((e) => console.error(JSON.stringify({
    level: 'error', msg: 'partner_audit_failed', partner: partnerId, action, error: String(e) })));
}

/**
 * The partner's own user, by the partner's own reference.
 *
 * This is the scoping chokepoint. Everything a partner does to a wallet goes
 * through here, and it filters on partner_id — so a ref belonging to another
 * partner, or a wallet that signed up directly, is simply not found.
 */
export async function partnerUser(partnerId: string, ref: string): Promise<WalletUser> {
  const u = await one<WalletUser>(pool,
    `SELECT ${USER_COLS} FROM users WHERE partner_id = $1 AND partner_ref = $2`,
    [partnerId, ref]);
  if (!u) throw new ApiError(404, 'resource_missing', 'No wallet with that reference.');
  return u;
}

export interface CreateWalletInput {
  ref: string;
  email: string;
  name: string;
  country: string;
}

/**
 * Create (or return) a wallet for one of the partner's users.
 *
 * Idempotent on the partner's ref, so a retry does not make a second wallet.
 * Refuses to attach to an email that already belongs to somebody else — see
 * rule 3 at the top of this file.
 */
export async function createPartnerWallet(partnerId: string, input: CreateWalletInput) {
  const ref = String(input.ref ?? '').trim();
  if (!ref) throw new ApiError(400, 'ref_required', 'A partner reference is required.');
  if (ref.length > 200) throw new ApiError(400, 'ref_too_long', 'A partner reference must be 200 characters or fewer.');

  // Already ours under this ref: hand the same wallet back.
  const mine = await one<WalletUser>(pool,
    `SELECT ${USER_COLS} FROM users WHERE partner_id = $1 AND partner_ref = $2`, [partnerId, ref]);
  if (mine) return { wallet: mine, created: false };

  const email = String(input.email ?? '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    throw new ApiError(400, 'invalid_email', 'A valid email address is required.');
  }

  // Someone already holds this email. Only continue if it is this partner's
  // own wallet under a different ref — otherwise this would be a takeover.
  const existing = await one<any>(pool,
    'SELECT id, partner_id, partner_ref FROM users WHERE email = $1', [email]);
  if (existing) {
    if (existing.partner_id !== partnerId) {
      throw new ApiError(409, 'email_belongs_to_another_account',
        'That email already has a Lagennet account that this partner does not operate. '
        + 'The person can connect it themselves by signing in.');
    }
    throw new ApiError(409, 'email_already_linked',
      `That email is already linked to your reference "${existing.partner_ref}".`);
  }

  // A password nobody holds. The partner acts for the user; the person claims
  // the wallet later through forgotten-password if they want direct access.
  const { signUp } = await import('../wallet/wallet.js');
  const throwaway = crypto.randomBytes(32).toString('base64url');
  const created = await signUp({ email, name: input.name, password: throwaway, country: input.country });

  await pool.query(
    'UPDATE users SET partner_id = $2, partner_ref = $3 WHERE id = $1',
    [created.user.id, partnerId, ref]);

  return { wallet: { ...created.user }, created: true };
}

/** Shape a wallet for a partner response. Never includes a session or secret. */
export function presentPartnerWallet(u: WalletUser, ref: string, extra: Record<string, unknown> = {}) {
  return {
    object: 'partner_wallet',
    ref,
    wallet_id: u.id,
    email: u.email,
    name: u.name,
    country: u.country,
    currency: u.currency,
    kyc_status: u.kyc_status,
    ...extra,
  };
}
