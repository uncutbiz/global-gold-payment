/**
 * Load the OFAC Specially Designated Nationals list into watchlist_entries.
 *
 * On a server:   sudo ggp load-ofac
 * In this repo:  npx tsx scripts/load-ofac.ts [./sdn.csv]
 *
 * WHY THIS LIVES IN src/ AND NOT scripts/
 *
 * The production image contains only `dist/`, `migrations/` and `public/` —
 * `scripts/` is not copied and tsx is pruned with the dev dependencies. A
 * loader that only existed in scripts/ could therefore never be run on the
 * machine that actually needs the list, which is how screening ended up
 * configured everywhere except production. Compiled into dist/ it is reachable
 * from `ggp load-ofac` like every other operational command.
 *
 * WHY OFAC SDN, AND WHY IT IS NOT ENOUGH ON ITS OWN
 *
 * The SDN list is published by the US Treasury, free, and is the one list
 * almost every US programme is expected to screen against. Starting here means
 * screening works on day one instead of waiting on a vendor contract. It is
 * also narrow: a real programme screens the OFAC consolidated list, EU and UN
 * lists, the local jurisdiction's list, and PEP data, which is commercial. The
 * `source` column exists so those arrive beside this rather than replacing it.
 *
 * THE FILE FORMAT
 *
 * SDN.CSV is positional, quoted, and uses the literal string "-0-" where a
 * field is absent — not an empty field. Treating "-0-" as a value puts the
 * string "-0-" in thousands of rows, so it is mapped to null here rather than
 * at every read site.
 */
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { pool } from './db.js';
import { normalize, resetWatchlistCache } from './compliance/screening.js';

export const SDN_URL = 'https://www.treasury.gov/ofac/downloads/sdn.csv';

/** RFC4180 parse. The remarks field contains commas, quotes and newlines. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], field = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else quoted = false;
      } else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  return rows;
}

/** OFAC writes "-0-" for an absent field. It is not a value. */
export const val = (s: string | undefined): string | null => {
  const t = (s ?? '').trim();
  return !t || t === '-0-' ? null : t;
};

const TYPE: Record<string, string> = {
  individual: 'individual', 'individual.': 'individual',
  entity: 'entity', vessel: 'vessel', aircraft: 'aircraft',
};

/**
 * The version is the hash of the file itself. Two loads of the same list
 * produce the same version, so a screening record stays reproducible, and a
 * changed list shows up as a changed version without trusting a date.
 */
export function ofacVersion(csv: string): string {
  return 'ofac_sdn:' + crypto.createHash('sha256').update(csv).digest('hex').slice(0, 12);
}

export interface LoadResult {
  version: string;
  loaded: number;
  skipped: number;
  delisted: number;
  total: number;
}

/** Load a parsed SDN csv into the watchlist, replacing the previous snapshot. */
export async function loadOfac(csv: string): Promise<LoadResult> {
  const rows = parseCsv(csv).filter((r) => r.length >= 2 && r[0]?.trim());
  if (!rows.length) throw new Error('No rows parsed — is this the SDN.CSV file?');

  const version = ofacVersion(csv);
  let loaded = 0, skipped = 0, delisted = 0;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const r of rows) {
      // ent_num, SDN_Name, SDN_Type, Program, Title, Call_Sign, Vess_type,
      // Tonnage, GRT, Vess_flag, Vess_owner, Remarks
      const [entNum, name, sdnType, program, , , , , , , , remarks] = r;
      const clean = val(name);
      if (!clean) { skipped++; continue; }

      await client.query(
        `INSERT INTO watchlist_entries
           (id, source, external_id, name, normalized_name, entity_type, program, remarks, list_version)
         VALUES ($1,'ofac_sdn',$2,$3,$4,$5,$6,$7,$8)
         ON CONFLICT (source, external_id) WHERE external_id IS NOT NULL
         DO UPDATE SET name = EXCLUDED.name,
                       normalized_name = EXCLUDED.normalized_name,
                       entity_type = EXCLUDED.entity_type,
                       program = EXCLUDED.program,
                       remarks = EXCLUDED.remarks,
                       list_version = EXCLUDED.list_version,
                       loaded_at = now()`,
        ['wl_' + crypto.randomBytes(9).toString('base64url'), val(entNum) ?? name,
         clean, normalize(clean),
         TYPE[(sdnType ?? '').trim().toLowerCase()] ?? 'unknown',
         val(program), val(remarks), version]);
      loaded++;
    }

    /*
     * Entries on the previous list and not on this one have been delisted.
     * They are removed rather than kept, because screening against a stale
     * list is how you block a customer who was cleared months ago. The
     * screening_checks rows that cited them stay, so past decisions remain
     * explicable.
     *
     * Scoped to this source: a different list's entries are not ours to drop.
     */
    const gone = await client.query(
      `DELETE FROM watchlist_entries
        WHERE source = 'ofac_sdn' AND list_version <> $1`, [version]);
    delisted = gone.rowCount ?? 0;
    await client.query('COMMIT');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }

  // The in-process cache would otherwise keep serving the previous snapshot.
  resetWatchlistCache();

  const n = await pool.query(
    `SELECT count(*)::int AS n FROM watchlist_entries WHERE source='ofac_sdn'`);
  return { version, loaded, skipped, delisted, total: n.rows[0].n };
}

/** Fetch the list from Treasury, or read a local copy. */
export async function fetchSdn(path?: string): Promise<string> {
  if (path) return fs.readFile(path, 'utf8');
  const r = await fetch(SDN_URL);
  if (!r.ok) {
    throw new Error(`Could not fetch the list: HTTP ${r.status}. `
      + 'Download sdn.csv in a browser and pass the path instead.');
  }
  return r.text();
}

async function main(): Promise<void> {
  const path = process.argv[2];
  console.log(path ? `  reading ${path}` : `  fetching ${SDN_URL}`);
  const csv = await fetchSdn(path);
  const r = await loadOfac(csv);
  console.log(`  version ${r.version}`);
  console.log(`  loaded ${r.loaded}, skipped ${r.skipped}, delisted ${r.delisted}`);
  console.log(`  watchlist now holds ${r.total} OFAC entries`);
  await pool.end();
}

// Run only when invoked directly, so importing the loader does not load a list.
const invokedDirectly = process.argv[1]
  && (() => { try { return fileURLToPath(import.meta.url) === process.argv[1]; } catch { return false; } })();
if (invokedDirectly) {
  main().catch((e) => { console.error(`\n  ${e instanceof Error ? e.message : String(e)}\n`); process.exit(1); });
}
