/**
 * Invoices.
 *
 * A document with line items, sent to a customer, that gets paid.
 *
 * Paying it is not reimplemented here. Sending an invoice creates a payment
 * link, and the customer pays that — so an invoice payment runs down exactly
 * the same road as every other payment: same provider routing, same browser
 * tokenisation, same platform fee, same ledger entries. There is one charge
 * path on this platform and this is not a second one.
 *
 * Money rules worth stating, because each is a way invoices go wrong:
 *
 *   - Totals are computed from the lines, in SQL, every time a line changes.
 *     They are never accepted from the caller. A client-supplied total is a
 *     client-supplied price.
 *   - Tax is worked out per line and rounded per line, then summed. Summing
 *     first and taxing the total gives a different, wrong number, and it is
 *     the number an accountant will query.
 *   - Quantity is thousandths of a unit, as an integer. "0.1 + 0.2 hours" in
 *     floating point is 0.30000000000000004, and that ends up on a bill.
 *   - A draft is not payable. The link is created when it is sent, so an
 *     unfinished invoice cannot be paid by someone who guessed the URL.
 */
import type { PoolClient } from 'pg';
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { createLink, setLinkActive } from './links.js';
import { emitEvent } from '../webhooks/webhooks.js';
import type { Merchant } from './service.js';

/** Quantities are thousandths, so this is the divisor, not a magic number. */
const QTY_SCALE = 1000;

export interface LineInput {
  description: string;
  quantity?: number;      // whole units; 1.5 is allowed and becomes 1500
  unit_amount: number;    // minor units
  tax_bps?: number;
}

/**
 * Recompute and store the totals from the lines.
 *
 * Runs inside the caller's transaction and is the ONLY thing that writes
 * subtotal, tax_total or total. Every mutation of a line calls it, so the
 * stored totals cannot drift from the lines that justify them.
 */
async function recalcInvoice(c: PoolClient, invoiceId: string) {
  // Rounded per line, then summed: rounding the sum instead produces a total
  // that does not equal the column of numbers printed above it.
  await c.query(
    `WITH totals AS (
       SELECT
         coalesce(sum( (quantity * unit_amount) / ${QTY_SCALE} ), 0)::bigint AS subtotal,
         coalesce(sum( round( ((quantity * unit_amount) / ${QTY_SCALE}::numeric) * tax_bps / 10000 ) ), 0)::bigint AS tax_total
         FROM invoice_lines WHERE invoice_id = $1
     )
     UPDATE invoices SET
       subtotal = totals.subtotal,
       tax_total = totals.tax_total,
       total = totals.subtotal + totals.tax_total,
       updated_at = now()
     FROM totals WHERE invoices.id = $1`, [invoiceId]);
}

/** The next invoice number for this merchant, counted per merchant. */
async function nextNumber(c: PoolClient, merchantId: string): Promise<string> {
  const row = await one<{ next_number: string }>(c,
    `INSERT INTO invoice_counters (merchant_id, next_number) VALUES ($1, 2)
     ON CONFLICT (merchant_id) DO UPDATE SET next_number = invoice_counters.next_number + 1
     RETURNING invoice_counters.next_number - 1 AS next_number`, [merchantId]);
  return `INV-${String(row!.next_number).padStart(4, '0')}`;
}

function toQty(q?: number): number {
  if (q === undefined) return QTY_SCALE;
  if (!Number.isFinite(q) || q <= 0) {
    throw new ApiError(400, 'parameter_invalid', 'Quantity must be greater than zero.');
  }
  return Math.round(q * QTY_SCALE);
}

export async function createInvoice(m: Merchant, input: {
  customer: string;
  currency: string;
  title?: string;
  note?: string;
  due_at?: Date;
  lines?: LineInput[];
  metadata?: Record<string, string>;
}) {
  if (m.status !== 'active') {
    throw new ApiError(403, 'account_inactive', 'This account cannot accept payments yet.');
  }
  return tx(async (c) => {
    const cus = await one(c, 'SELECT * FROM customers WHERE id=$1 AND merchant_id=$2', [input.customer, m.id]);
    if (!cus) throw new ApiError(404, 'resource_missing', 'Customer not found.');

    const inv = await one<any>(c,
      `INSERT INTO invoices (id, merchant_id, customer_id, number, currency, title, note, due_at, metadata)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [newId('inv'), m.id, cus.id, await nextNumber(c, m.id), input.currency,
       input.title ?? null, input.note ?? null, input.due_at ?? null,
       JSON.stringify(input.metadata ?? {})]);

    let pos = 0;
    for (const l of input.lines ?? []) {
      await c.query(
        `INSERT INTO invoice_lines (id, invoice_id, position, description, quantity, unit_amount, tax_bps)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [newId('il'), inv.id, pos++, l.description, toQty(l.quantity), l.unit_amount, l.tax_bps ?? 0]);
    }
    await recalcInvoice(c, inv.id);
    return loadInvoice(c, m.id, inv.id);
  });
}

export async function addLine(m: Merchant, invoiceId: string, line: LineInput) {
  return tx(async (c) => {
    const inv = await mutableInvoice(c, m.id, invoiceId);
    const pos = await one<{ n: number }>(c,
      'SELECT coalesce(max(position), -1) + 1 AS n FROM invoice_lines WHERE invoice_id=$1', [inv.id]);
    await c.query(
      `INSERT INTO invoice_lines (id, invoice_id, position, description, quantity, unit_amount, tax_bps)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [newId('il'), inv.id, pos!.n, line.description, toQty(line.quantity), line.unit_amount, line.tax_bps ?? 0]);
    await recalcInvoice(c, inv.id);
    return loadInvoice(c, m.id, inv.id);
  });
}

export async function removeLine(m: Merchant, invoiceId: string, lineId: string) {
  return tx(async (c) => {
    const inv = await mutableInvoice(c, m.id, invoiceId);
    const r = await c.query('DELETE FROM invoice_lines WHERE id=$1 AND invoice_id=$2', [lineId, inv.id]);
    if (!r.rowCount) throw new ApiError(404, 'resource_missing', 'That line is not on this invoice.');
    await recalcInvoice(c, inv.id);
    return loadInvoice(c, m.id, inv.id);
  });
}

/**
 * An invoice that may still be edited.
 *
 * Only a draft. Once it is sent the customer has a copy, and changing the
 * amount underneath them is how a dispute starts — the line items they agreed
 * to have to be the line items they are charged for.
 */
async function mutableInvoice(c: PoolClient, merchantId: string, id: string) {
  const inv = await one<any>(c,
    'SELECT * FROM invoices WHERE id=$1 AND merchant_id=$2 FOR UPDATE', [id, merchantId]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  if (inv.status !== 'draft') {
    throw new ApiError(400, 'invoice_not_editable',
      `This invoice is ${inv.status}. Only a draft can be changed — void it and raise a new one.`);
  }
  return inv;
}

/**
 * Send it: the invoice becomes payable and gets its link.
 *
 * The link's amount is the stored total, which came from the lines. Nothing
 * the caller sends decides what the customer pays.
 */
export async function sendInvoice(m: Merchant, id: string) {
  const inv = await one<any>(pool, 'SELECT * FROM invoices WHERE id=$1 AND merchant_id=$2', [id, m.id]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  if (inv.status === 'open') return loadInvoice(pool, m.id, id);   // already sent; idempotent
  if (inv.status !== 'draft') {
    throw new ApiError(400, 'invoice_not_sendable', `This invoice is ${inv.status}.`);
  }
  if (Number(inv.total) <= 0) {
    throw new ApiError(400, 'invoice_empty', 'Add at least one line before sending.');
  }

  // createLink enforces its own minimum and the merchant's active status.
  const link = await createLink(m, {
    title: inv.title || `Invoice ${inv.number}`,
    currency: inv.currency,
    amount: Number(inv.total),
    description: inv.note ?? undefined,
    max_uses: 1,                       // an invoice is paid once
    expires_at: null,
  });

  const row = await one<any>(pool,
    `UPDATE invoices SET status='open', sent_at=now(), payment_link_id=$2, updated_at=now()
      WHERE id=$1 AND status='draft' RETURNING *`, [id, link.id]);
  if (!row) return loadInvoice(pool, m.id, id);   // someone else sent it first

  await tx(async (c) => {
    await emitEvent(c, m.id, 'invoice.sent', { id: row.id, number: row.number, total: Number(row.total) });
    // A recurring invoice starts its clock when it is sent, not when the
    // cadence is set — a draft must never bill anybody.
    await startScheduleIfRecurring(c, row.id);
  });
  return loadInvoice(pool, m.id, id);
}

/**
 * Cancel an unpaid invoice.
 *
 * Voided, never deleted: an invoice number that vanishes is a gap in a
 * sequence an auditor will ask about. The payment link is switched off in the
 * same breath, or the customer could still pay a bill that no longer exists.
 */
export async function voidInvoice(m: Merchant, id: string) {
  const inv = await one<any>(pool, 'SELECT * FROM invoices WHERE id=$1 AND merchant_id=$2', [id, m.id]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  if (inv.status === 'paid') {
    throw new ApiError(400, 'invoice_paid', 'This invoice has been paid. Refund the payment instead of voiding it.');
  }
  if (inv.status === 'void') return loadInvoice(pool, m.id, id);

  if (inv.payment_link_id) await setLinkActive(m, inv.payment_link_id, false);
  const row = await one<any>(pool,
    `UPDATE invoices SET status='void', voided_at=now(), updated_at=now() WHERE id=$1 RETURNING *`, [id]);
  await tx((c) => emitEvent(c, m.id, 'invoice.voided', { id: row.id, number: row.number }));
  return loadInvoice(pool, m.id, id);
}

/**
 * Credit a successful payment to the invoice it settled.
 *
 * Called from the payment success path, inside its transaction, so an invoice
 * cannot be marked paid by a payment that later failed to commit.
 */
export async function creditInvoicePayment(c: PoolClient, pi: {
  id: string; payment_link_id?: string | null; amount_captured?: number | string | null;
}) {
  if (!pi.payment_link_id) return;
  const inv = await one<any>(c,
    'SELECT * FROM invoices WHERE payment_link_id = $1 FOR UPDATE', [pi.payment_link_id]);
  if (!inv) return;

  const paid = Number(pi.amount_captured ?? 0);
  if (paid <= 0) return;

  await c.query('UPDATE payment_intents SET invoice_id = $2 WHERE id = $1', [pi.id, inv.id]);
  const row = await one<any>(c,
    `UPDATE invoices SET
       amount_paid = amount_paid + $2,
       status = CASE WHEN amount_paid + $2 >= total THEN 'paid' ELSE status END,
       paid_at = CASE WHEN amount_paid + $2 >= total THEN coalesce(paid_at, now()) ELSE paid_at END,
       updated_at = now()
     WHERE id = $1 RETURNING *`, [inv.id, paid]);
  if (row?.status === 'paid') {
    await emitEvent(c, inv.merchant_id, 'invoice.paid',
      { id: row.id, number: row.number, total: Number(row.total) });
  }
}

export async function listInvoices(m: Merchant, opts: { status?: string; customer?: string } = {}) {
  const r = await pool.query(
    `SELECT i.*, c.email AS customer_email, c.name AS customer_name,
            l.code AS link_code
       FROM invoices i
       JOIN customers c ON c.id = i.customer_id
       LEFT JOIN payment_links l ON l.id = i.payment_link_id
      WHERE i.merchant_id = $1
        AND ($2::text IS NULL OR i.status = $2)
        AND ($3::text IS NULL OR i.customer_id = $3)
      ORDER BY i.created_at DESC LIMIT 200`,
    [m.id, opts.status ?? null, opts.customer ?? null]);
  return r.rows.map(present);
}

export async function getInvoice(m: Merchant, id: string) {
  return loadInvoice(pool, m.id, id);
}

/** Sent, unpaid and past its due date. */
export async function overdueInvoices(m: Merchant) {
  const r = await pool.query(
    `SELECT i.*, c.email AS customer_email, c.name AS customer_name, l.code AS link_code
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       LEFT JOIN payment_links l ON l.id = i.payment_link_id
      WHERE i.merchant_id=$1 AND i.status='open' AND i.due_at IS NOT NULL AND i.due_at < now()
      ORDER BY i.due_at`, [m.id]);
  return r.rows.map(present);
}

async function loadInvoice(db: PoolClient | typeof pool, merchantId: string, id: string) {
  const inv = await one<any>(db,
    `SELECT i.*, c.email AS customer_email, c.name AS customer_name, l.code AS link_code
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       LEFT JOIN payment_links l ON l.id = i.payment_link_id
      WHERE i.id=$1 AND i.merchant_id=$2`, [id, merchantId]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  const lines = await db.query(
    'SELECT * FROM invoice_lines WHERE invoice_id=$1 ORDER BY position', [id]);
  return { ...present(inv), lines: lines.rows.map(presentLine) };
}

function presentLine(l: any) {
  const amount = Math.trunc((Number(l.quantity) * Number(l.unit_amount)) / QTY_SCALE);
  return {
    id: l.id,
    description: l.description,
    quantity: Number(l.quantity) / QTY_SCALE,
    unit_amount: Number(l.unit_amount),
    tax_bps: l.tax_bps,
    amount,
    tax: Math.round((amount * Number(l.tax_bps)) / 10000),
  };
}

function present(i: any) {
  return {
    id: i.id,
    object: 'invoice',
    number: i.number,
    customer: i.customer_id,
    customer_email: i.customer_email,
    customer_name: i.customer_name,
    currency: i.currency,
    subtotal: Number(i.subtotal),
    tax_total: Number(i.tax_total),
    total: Number(i.total),
    amount_paid: Number(i.amount_paid),
    amount_due: Math.max(0, Number(i.total) - Number(i.amount_paid)),
    status: i.status,
    title: i.title,
    note: i.note,
    due_at: i.due_at,
    overdue: i.status === 'open' && i.due_at != null && new Date(i.due_at).getTime() < Date.now(),
    payment_url: i.link_code ? `/pay/${i.link_code}` : null,
    sent_at: i.sent_at,
    paid_at: i.paid_at,
    created_at: i.created_at,
    // One-time or subscription. `recurs_from_id` is set on the invoices a
    // schedule mints, so a client can tell a bill apart from the schedule
    // that produced it.
    billing_type: i.billing_type ?? 'one_time',
    recur_interval: i.recur_interval ?? null,
    recur_interval_count: i.recur_interval_count ?? 1,
    recur_active: Boolean(i.recur_active),
    recur_next_at: i.recur_next_at ?? null,
    recur_end_at: i.recur_end_at ?? null,
    recur_max_cycles: i.recur_max_cycles ?? null,
    recur_cycles_done: i.recur_cycles_done ?? 0,
    recurs_from_id: i.recurs_from_id ?? null,
  };
}

// ─────────────────────────────────────────────── recurring invoices
/*
 * "One time" or "subscription" on an invoice. See migrations/023 for why a
 * repeating invoice reissues itself rather than starting a card-on-file
 * subscription: the person being invoiced has no stored card to charge.
 */
export type RecurInterval = 'day' | 'week' | 'month' | 'year';

/**
 * When does the next one fall due?
 *
 * Pure, and the month arithmetic is the reason. Adding a month to the 31st
 * with naive date maths overflows: Jan 31 + 1 month becomes Mar 2 or Mar 3,
 * so a customer billed on the 31st silently drifts into the following month
 * and eventually gets billed twice in one month. The day is clamped to the
 * length of the target month instead, which is what every billing system
 * means by "monthly on the 31st".
 */
export function nextRecurrence(from: Date, interval: RecurInterval, count = 1): Date {
  if (!Number.isInteger(count) || count < 1) {
    throw new ApiError(400, 'parameter_invalid', 'The interval count must be a whole number, one or more.');
  }
  const d = new Date(from.getTime());
  if (interval === 'day')  { d.setUTCDate(d.getUTCDate() + count); return d; }
  if (interval === 'week') { d.setUTCDate(d.getUTCDate() + 7 * count); return d; }

  const months = interval === 'month' ? count : count * 12;
  const day = d.getUTCDate();
  // Land on the 1st of the target month, then clamp the day to that month's
  // length. Date.UTC rolls a month index past 11 into the next year for us.
  const target = new Date(Date.UTC(
    d.getUTCFullYear(), d.getUTCMonth() + months, 1,
    d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds(), d.getUTCMilliseconds()));
  const daysInTarget = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(day, daysInTarget));
  return target;
}

/** Has this schedule run out of road? Pure. */
export function scheduleFinished(
  s: { recur_max_cycles?: number | null; recur_cycles_done?: number | null; recur_end_at?: Date | string | null },
  nextAt: Date,
): boolean {
  const done = s.recur_cycles_done ?? 0;
  if (s.recur_max_cycles != null && done >= s.recur_max_cycles) return true;
  if (s.recur_end_at) {
    const end = typeof s.recur_end_at === 'string' ? new Date(s.recur_end_at) : s.recur_end_at;
    if (nextAt.getTime() > end.getTime()) return true;
  }
  return false;
}

/**
 * Make an invoice recurring (or put it back to one-off).
 *
 * Allowed on a draft or an already-sent invoice: a merchant who sent a bill
 * and then agreed to put the customer on a monthly plan should not have to
 * void and rebuild it. Setting it on a sent invoice starts the clock from now.
 */
export async function setInvoiceRecurrence(m: Merchant, id: string, input: {
  billing_type: 'one_time' | 'recurring';
  interval?: RecurInterval;
  interval_count?: number;
  end_at?: Date | null;
  max_cycles?: number | null;
}) {
  return tx(async (c) => {
    const inv = await one<any>(c,
      'SELECT * FROM invoices WHERE id=$1 AND merchant_id=$2 FOR UPDATE', [id, m.id]);
    if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
    if (inv.recurs_from_id) {
      throw new ApiError(400, 'invoice_is_a_cycle',
        'This invoice was issued by a schedule. Change the schedule on the original invoice instead.');
    }
    if (inv.status === 'void' || inv.status === 'paid') {
      throw new ApiError(400, 'invoice_not_editable', `This invoice is ${inv.status}.`);
    }

    if (input.billing_type === 'one_time') {
      await c.query(
        `UPDATE invoices SET billing_type='one_time', recur_interval=NULL, recur_interval_count=1,
                recur_next_at=NULL, recur_end_at=NULL, recur_max_cycles=NULL,
                recur_active=false, updated_at=now()
          WHERE id=$1`, [id]);
      return loadInvoice(c, m.id, id);
    }

    if (!input.interval) {
      throw new ApiError(400, 'parameter_required', 'A recurring invoice needs an interval.');
    }
    const count = input.interval_count ?? 1;
    // Validate the cadence by computing one step; nextRecurrence throws on a
    // bad count, so a broken schedule can never be stored.
    const firstNext = nextRecurrence(new Date(), input.interval, count);
    if (input.max_cycles != null && (!Number.isInteger(input.max_cycles) || input.max_cycles < 1)) {
      throw new ApiError(400, 'parameter_invalid', 'max_cycles must be a whole number, one or more.');
    }
    if (input.end_at && input.end_at.getTime() <= Date.now()) {
      throw new ApiError(400, 'parameter_invalid', 'The end date is in the past.');
    }

    // A sent invoice starts billing from now; a draft starts when it is sent.
    const active = inv.status === 'open';
    await c.query(
      `UPDATE invoices
          SET billing_type='recurring', recur_interval=$2, recur_interval_count=$3,
              recur_end_at=$4, recur_max_cycles=$5,
              recur_active=$6, recur_next_at=$7, updated_at=now()
        WHERE id=$1`,
      [id, input.interval, count, input.end_at ?? null, input.max_cycles ?? null,
       active, active ? firstNext : null]);
    return loadInvoice(c, m.id, id);
  });
}

/** Stop a running schedule. The invoices it already issued are untouched. */
export async function stopInvoiceRecurrence(m: Merchant, id: string) {
  const r = await pool.query(
    `UPDATE invoices SET recur_active=false, recur_next_at=NULL, updated_at=now()
      WHERE id=$1 AND merchant_id=$2 AND billing_type='recurring'`, [id, m.id]);
  if (!r.rowCount) throw new ApiError(404, 'resource_missing', 'No recurring invoice with that id.');
  return loadInvoice(pool, m.id, id);
}

/**
 * Start the clock on a recurring invoice that has just been sent.
 * Called by sendInvoice; separate so the rule lives in one place.
 */
async function startScheduleIfRecurring(c: PoolClient, id: string) {
  const inv = await one<any>(c, 'SELECT * FROM invoices WHERE id=$1', [id]);
  if (!inv || inv.billing_type !== 'recurring' || inv.recur_active) return;
  const next = nextRecurrence(new Date(), inv.recur_interval, inv.recur_interval_count);
  await c.query('UPDATE invoices SET recur_active=true, recur_next_at=$2 WHERE id=$1', [id, next]);
}

/** The schedules a merchant is running. */
export async function listSchedules(m: Merchant) {
  const r = await pool.query(
    `SELECT i.*, c.name AS customer_name, c.email AS customer_email,
            (SELECT COUNT(*)::int FROM invoices k WHERE k.recurs_from_id = i.id) AS issued
       FROM invoices i JOIN customers c ON c.id = i.customer_id
      WHERE i.merchant_id = $1 AND i.billing_type = 'recurring'
      ORDER BY i.recur_active DESC, i.created_at DESC`, [m.id]);
  return r.rows.map((i) => ({
    id: i.id, number: i.number, title: i.title, currency: i.currency,
    total: Number(i.total), customer_id: i.customer_id,
    customer_name: i.customer_name, customer_email: i.customer_email,
    interval: i.recur_interval, interval_count: i.recur_interval_count,
    active: i.recur_active, next_at: i.recur_next_at, end_at: i.recur_end_at,
    max_cycles: i.recur_max_cycles, cycles_done: i.recur_cycles_done, issued: i.issued,
  }));
}

/**
 * Mint the invoices that have come due, and send them.
 *
 * The due row is claimed with a conditional UPDATE before anything is created,
 * so two workers running at once cannot both mint the same period. Whoever
 * loses the race updates zero rows and moves on.
 */
export async function issueDueRecurringInvoices(limit = 25, now = new Date()):
  Promise<{ issued: number; ended: number; failed: number }> {
  const due = (await pool.query(
    `SELECT id, merchant_id FROM invoices
      WHERE recur_active AND recur_next_at IS NOT NULL AND recur_next_at <= $1
      ORDER BY recur_next_at
      LIMIT $2`, [now, Math.min(Math.max(limit, 1), 200)])).rows;

  let issued = 0, ended = 0, failed = 0;

  for (const row of due) {
    try {
      const claimed = await tx(async (c) => {
        const s = await one<any>(c,
          `SELECT * FROM invoices WHERE id=$1 AND recur_active AND recur_next_at <= $2 FOR UPDATE`,
          [row.id, now]);
        if (!s) return null;                       // another worker took it

        const next = nextRecurrence(
          new Date(s.recur_next_at), s.recur_interval, s.recur_interval_count);
        const finished = scheduleFinished(
          { recur_max_cycles: s.recur_max_cycles, recur_cycles_done: (s.recur_cycles_done ?? 0) + 1, recur_end_at: s.recur_end_at },
          next);

        await c.query(
          `UPDATE invoices
              SET recur_cycles_done = recur_cycles_done + 1,
                  recur_next_at = $2, recur_active = $3, updated_at = now()
            WHERE id = $1`,
          [s.id, finished ? null : next, !finished]);
        return s;
      });
      if (!claimed) continue;

      // Mint the period's invoice, copying the original's lines.
      const child = await tx(async (c) => {
        const inv = await one<any>(c,
          `INSERT INTO invoices
             (id, merchant_id, customer_id, number, currency, title, note, metadata, recurs_from_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
          [newId('inv'), claimed.merchant_id, claimed.customer_id,
           await nextNumber(c, claimed.merchant_id), claimed.currency,
           claimed.title, claimed.note, claimed.metadata, claimed.id]);

        await c.query(
          `INSERT INTO invoice_lines (id, invoice_id, position, description, quantity, unit_amount, tax_bps)
           SELECT 'il_' || substr(md5(random()::text), 1, 20), $2, position, description, quantity, unit_amount, tax_bps
             FROM invoice_lines WHERE invoice_id = $1 ORDER BY position`,
          [claimed.id, inv.id]);
        await recalcInvoice(c, inv.id);
        return inv;
      });

      // Sending needs the merchant row, and creates the payment link.
      const merchant = await one<any>(pool, 'SELECT * FROM merchants WHERE id=$1', [claimed.merchant_id]);
      if (merchant) await sendInvoice(merchant as Merchant, child.id);
      issued++;
      const after = await one<any>(pool, 'SELECT recur_active FROM invoices WHERE id=$1', [claimed.id]);
      if (after && !after.recur_active) ended++;
    } catch (e) {
      failed++;
      console.error(JSON.stringify({
        level: 'error', msg: 'recurring_invoice_failed', invoice: row.id, error: String(e) }));
    }
  }
  return { issued, ended, failed };
}

/** Background scheduler, mirroring the subscriptions worker. */
export function startRecurringInvoiceWorker(everyMs = 60_000) {
  if (process.env.INVOICE_WORKER === 'off') return;
  const tick = () => issueDueRecurringInvoices().catch((e) => console.error(
    JSON.stringify({ level: 'error', msg: 'recurring_invoice_worker', error: String(e) })));
  setInterval(tick, everyMs).unref();
  tick();
}

export { startScheduleIfRecurring };
