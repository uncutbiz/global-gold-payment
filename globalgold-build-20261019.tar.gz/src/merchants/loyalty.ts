/**
 * Loyalty points: earned on spend, redeemed for credit.
 *
 * The three sums that matter — how many points an amount earns, what a number
 * of points is worth, and the most a customer may redeem against a given bill
 * — are pure functions. A loyalty balance is money by another name, and the
 * same reasoning as the ledger applies: the arithmetic is separated from the
 * storage so it can be tested exhaustively and cannot quietly round in the
 * house's favour (or the customer's).
 */
import { Db, one, pool, tx } from '../db.js';
import { ApiError, newId, SUPPORTED_CURRENCIES } from '../util/common.js';

export interface Program {
  merchant_id: string;
  enabled: boolean;
  currency: string;
  earn_points_per_unit: number;
  redeem_minor_per_point: number;
  min_redeem_points: number;
}

/**
 * Points earned on an amount. Points accrue per WHOLE unit spent — a $4.99
 * coffee at 1 point per dollar earns 4, not 4.99 — so the minor-unit remainder
 * is dropped. Pure.
 */
export function pointsForAmount(amountMinor: number, program: Pick<Program, 'earn_points_per_unit'>): number {
  if (!Number.isInteger(amountMinor) || amountMinor < 0) return 0;
  return Math.floor(amountMinor / 100) * program.earn_points_per_unit;
}

/** What a number of points is worth, in minor units. Pure. */
export function redemptionValue(points: number, program: Pick<Program, 'redeem_minor_per_point'>): number {
  if (!Number.isInteger(points) || points < 0) return 0;
  return points * program.redeem_minor_per_point;
}

/**
 * The most points a customer may redeem against a bill, in points.
 *
 * Bounded by three things at once: their balance, the minimum redemption, and
 * the bill itself — you cannot take more credit than the amount owed. Returns
 * 0 when they cannot meet the minimum, so the caller never offers a redemption
 * that would then be refused. Pure.
 */
export function maxRedeemable(balance: number, capMinor: number, program: Program): number {
  if (program.redeem_minor_per_point <= 0) return 0;
  const byCap = Math.floor(Math.max(0, capMinor) / program.redeem_minor_per_point);
  const usable = Math.min(balance, byCap);
  return usable >= program.min_redeem_points ? usable : 0;
}

function presentProgram(p: any): Program & { object: 'loyalty_program' } {
  return {
    object: 'loyalty_program', merchant_id: p.merchant_id, enabled: p.enabled, currency: p.currency,
    earn_points_per_unit: p.earn_points_per_unit, redeem_minor_per_point: p.redeem_minor_per_point,
    min_redeem_points: p.min_redeem_points,
  };
}

/** The program, defaulting to a disabled one so callers never see null. */
export async function getProgram(merchantId: string, db: Db = pool) {
  const p = await one<any>(db, 'SELECT * FROM loyalty_programs WHERE merchant_id = $1', [merchantId]);
  if (!p) {
    const m = await one<any>(db, 'SELECT country FROM merchants WHERE id = $1', [merchantId]);
    if (!m) throw new ApiError(404, 'resource_missing', 'Business not found.');
    return presentProgram({ merchant_id: merchantId, enabled: false, currency: 'usd', earn_points_per_unit: 1, redeem_minor_per_point: 1, min_redeem_points: 0 });
  }
  return presentProgram(p);
}

export async function setProgram(merchantId: string, patch: {
  enabled?: boolean; currency?: string;
  earn_points_per_unit?: number; redeem_minor_per_point?: number; min_redeem_points?: number;
}, db: Db = pool) {
  const cur = await getProgram(merchantId, db);
  const currency = (patch.currency ?? cur.currency).toLowerCase();
  if (!SUPPORTED_CURRENCIES.includes(currency as any)) {
    throw new ApiError(400, 'unsupported_currency', `${patch.currency} is not a supported currency.`);
  }
  const nn = (v: number | undefined, name: string) => {
    if (v === undefined) return undefined;
    if (!Number.isInteger(v) || v < 0) throw new ApiError(400, 'invalid_value', `${name} must be a whole number, zero or more.`);
    return v;
  };
  const earn = nn(patch.earn_points_per_unit, 'earn rate') ?? cur.earn_points_per_unit;
  const redeem = nn(patch.redeem_minor_per_point, 'redemption rate') ?? cur.redeem_minor_per_point;
  const minr = nn(patch.min_redeem_points, 'minimum redemption') ?? cur.min_redeem_points;
  const enabled = patch.enabled ?? cur.enabled;

  const p = await one(db,
    `INSERT INTO loyalty_programs (merchant_id, enabled, currency, earn_points_per_unit, redeem_minor_per_point, min_redeem_points)
       VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (merchant_id) DO UPDATE SET
       enabled = EXCLUDED.enabled, currency = EXCLUDED.currency,
       earn_points_per_unit = EXCLUDED.earn_points_per_unit,
       redeem_minor_per_point = EXCLUDED.redeem_minor_per_point,
       min_redeem_points = EXCLUDED.min_redeem_points, updated_at = now()
     RETURNING *`,
    [merchantId, enabled, currency, earn, redeem, minr]);
  return presentProgram(p);
}

async function accountRow(c: Db, merchantId: string, customerId: string) {
  const cust = await one(c, 'SELECT 1 FROM customers WHERE id = $1 AND merchant_id = $2', [customerId, merchantId]);
  if (!cust) throw new ApiError(404, 'resource_missing', 'Customer not found.');
  let acc = await one<any>(c, 'SELECT * FROM loyalty_accounts WHERE merchant_id = $1 AND customer_id = $2', [merchantId, customerId]);
  if (!acc) {
    acc = await one<any>(c,
      `INSERT INTO loyalty_accounts (id, merchant_id, customer_id) VALUES ($1,$2,$3)
       ON CONFLICT (merchant_id, customer_id) DO UPDATE SET updated_at = now() RETURNING *`,
      [newId('loy'), merchantId, customerId]);
  }
  return acc;
}

export async function getAccount(merchantId: string, customerId: string, db: Db = pool) {
  const acc = await accountRow(db, merchantId, customerId);
  return { object: 'loyalty_account', id: acc.id, customer_id: customerId, balance: acc.balance, lifetime_earned: acc.lifetime_earned };
}

/**
 * Earn points for an amount spent. `source` makes it idempotent: the same
 * source string can only earn once, so a retried payment webhook is harmless.
 * Returns the points earned (0 if the program is off or the amount too small).
 */
export async function earn(merchantId: string, customerId: string, amountMinor: number, source?: string) {
  return tx(async (c) => {
    const program = await getProgram(merchantId, c);
    if (!program.enabled) return { object: 'loyalty_earn', points: 0, balance: (await accountRow(c, merchantId, customerId)).balance, skipped: 'program_disabled' };
    const points = pointsForAmount(amountMinor, program);
    const acc = await accountRow(c, merchantId, customerId);
    if (points <= 0) return { object: 'loyalty_earn', points: 0, balance: acc.balance };

    try {
      await c.query(
        `INSERT INTO loyalty_transactions (id, account_id, type, points, source) VALUES ($1,$2,'earn',$3,$4)`,
        [newId('ltx'), acc.id, points, source ?? null]);
    } catch (e: any) {
      if (e?.code === '23505') {
        // Already earned for this source — return the balance unchanged.
        return { object: 'loyalty_earn', points: 0, balance: acc.balance, skipped: 'already_earned' };
      }
      throw e;
    }
    const upd = await one<any>(c,
      `UPDATE loyalty_accounts SET balance = balance + $2, lifetime_earned = lifetime_earned + $2, updated_at = now()
       WHERE id = $1 RETURNING balance`, [acc.id, points]);
    return { object: 'loyalty_earn', points, balance: upd.balance };
  });
}

/**
 * Redeem points for credit. Refuses below the minimum and refuses more than
 * the balance; returns the credit value in minor units. The balance check and
 * the decrement are in one transaction, so two redemptions racing cannot take
 * the balance negative.
 */
export async function redeem(merchantId: string, customerId: string, points: number, note?: string) {
  if (!Number.isInteger(points) || points <= 0) {
    throw new ApiError(400, 'invalid_points', 'Redeem a whole number of points, greater than zero.');
  }
  return tx(async (c) => {
    /*
     * Ownership first, before anything else is considered.
     *
     * Checking the program before the customer meant a business pointing at
     * someone else's customer got "your program is disabled" — a different
     * answer from "no such customer", which is a small disclosure and a
     * confusing one. Whose customer it is decides the answer.
     */
    const owns = await one(c, 'SELECT 1 FROM customers WHERE id = $1 AND merchant_id = $2',
      [customerId, merchantId]);
    if (!owns) throw new ApiError(404, 'resource_missing', 'Customer not found.');

    const program = await getProgram(merchantId, c);
    if (!program.enabled) throw new ApiError(409, 'program_disabled', 'This business is not running a loyalty program.');
    if (points < program.min_redeem_points) {
      throw new ApiError(400, 'below_minimum', `The minimum redemption is ${program.min_redeem_points} points.`);
    }
    // Lock the row so a concurrent redeem sees the decremented balance.
    const acc = await one<any>(c,
      `SELECT * FROM loyalty_accounts WHERE merchant_id = $1 AND customer_id = $2 FOR UPDATE`, [merchantId, customerId]);
    if (!acc) throw new ApiError(400, 'no_points', 'This customer has no points to redeem.');
    if (acc.balance < points) throw new ApiError(400, 'insufficient_points', `This customer has ${acc.balance} points, not ${points}.`);

    await c.query(`INSERT INTO loyalty_transactions (id, account_id, type, points, note) VALUES ($1,$2,'redeem',$3,$4)`,
      [newId('ltx'), acc.id, -points, note ?? null]);
    const upd = await one<any>(c, `UPDATE loyalty_accounts SET balance = balance - $2, updated_at = now() WHERE id = $1 RETURNING balance`, [acc.id, points]);
    return { object: 'loyalty_redeem', points, value: redemptionValue(points, program), currency: program.currency, balance: upd.balance };
  });
}

export async function listTransactions(merchantId: string, customerId: string, db: Db = pool) {
  const acc = await one<any>(db, 'SELECT id FROM loyalty_accounts WHERE merchant_id = $1 AND customer_id = $2', [merchantId, customerId]);
  if (!acc) return [];
  const rows = (await db.query('SELECT * FROM loyalty_transactions WHERE account_id = $1 ORDER BY created_at DESC LIMIT 100', [acc.id])).rows;
  return rows.map((t) => ({ id: t.id, type: t.type, points: t.points, note: t.note ?? null, created_at: t.created_at }));
}
