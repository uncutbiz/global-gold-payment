/**
 * Dev shim. The loader itself lives in src/load-ofac.ts so that it compiles
 * into the production image and can be run there as `ggp load-ofac` — the
 * image contains only dist/, so a loader that lived only here could never be
 * run on the machine that needs the list.
 *
 *   npx tsx scripts/load-ofac.ts              # fetch from treasury.gov
 *   npx tsx scripts/load-ofac.ts ./sdn.csv    # from a local copy
 */
import { pool } from '../src/db.js';
import { fetchSdn, loadOfac, SDN_URL } from '../src/load-ofac.js';

const path = process.argv[2];
console.log(path ? `  reading ${path}` : `  fetching ${SDN_URL}`);
try {
  const csv = await fetchSdn(path);
  const r = await loadOfac(csv);
  console.log(`  version ${r.version}`);
  console.log(`  loaded ${r.loaded}, skipped ${r.skipped}, delisted ${r.delisted}`);
  console.log(`  watchlist now holds ${r.total} OFAC entries`);
} catch (e) {
  console.error(`\n  ${e instanceof Error ? e.message : String(e)}\n`);
  process.exitCode = 1;
}
await pool.end();
