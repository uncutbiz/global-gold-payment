-- Invoices that repeat: "one time" or "subscription".
--
-- WHY A REPEATING INVOICE RATHER THAN A SUBSCRIPTION
--
-- There is already a subscriptions engine, and it is the right thing when the
-- customer's card is on file: it charges that card every period with nobody
-- present. But an invoice is sent to someone who has not paid yet and has no
-- card stored, so it cannot start a card-on-file subscription — there is
-- nothing to charge. Requiring a saved card before an invoice could repeat
-- would mean the feature only worked for customers who had already bought
-- something, which is the opposite of who gets invoiced.
--
-- So a recurring invoice reissues ITSELF. Each period the schedule mints a new
-- invoice from the original, with its own number and its own payment link, and
-- the customer pays it the same way they paid the first one. No stored card,
-- no consent problem, and every period leaves a real invoice in the books
-- instead of a bare charge.
--
-- THE ORIGINAL IS THE SCHEDULE
--
-- The invoice the merchant marked recurring holds the cadence and the cursor
-- (recur_next_at). The invoices it mints each period point back at it through
-- recurs_from_id and are ordinary one-time invoices themselves. That keeps
-- "when is the next one due" in exactly one row, so two workers cannot both
-- decide a period is due, and a paid child never changes the schedule.

ALTER TABLE invoices ADD COLUMN billing_type TEXT NOT NULL DEFAULT 'one_time'
  CHECK (billing_type IN ('one_time', 'recurring'));

ALTER TABLE invoices ADD COLUMN recur_interval TEXT
  CHECK (recur_interval IN ('day', 'week', 'month', 'year'));
ALTER TABLE invoices ADD COLUMN recur_interval_count INTEGER NOT NULL DEFAULT 1
  CHECK (recur_interval_count > 0 AND recur_interval_count <= 365);

-- When the next invoice should be minted. NULL once the schedule has ended.
ALTER TABLE invoices ADD COLUMN recur_next_at   TIMESTAMPTZ;
-- Optional stopping conditions. Either, both, or neither.
ALTER TABLE invoices ADD COLUMN recur_end_at    TIMESTAMPTZ;
ALTER TABLE invoices ADD COLUMN recur_max_cycles INTEGER CHECK (recur_max_cycles > 0);
ALTER TABLE invoices ADD COLUMN recur_cycles_done INTEGER NOT NULL DEFAULT 0
  CHECK (recur_cycles_done >= 0);
-- Only true between being sent and the schedule ending. A draft never bills.
ALTER TABLE invoices ADD COLUMN recur_active    BOOLEAN NOT NULL DEFAULT false;
-- Set on each minted child, pointing at the invoice that is the schedule.
ALTER TABLE invoices ADD COLUMN recurs_from_id  TEXT REFERENCES invoices(id);

-- A recurring invoice must say how often. A one-time one must not.
ALTER TABLE invoices ADD CONSTRAINT invoices_recurrence_shape CHECK (
  (billing_type = 'recurring' AND recur_interval IS NOT NULL) OR
  (billing_type = 'one_time'  AND recur_interval IS NULL)
);

-- Only a schedule that is active and due is ever scanned.
CREATE INDEX invoices_recur_due_idx ON invoices (recur_next_at)
  WHERE recur_active AND recur_next_at IS NOT NULL;
CREATE INDEX invoices_recurs_from_idx ON invoices (recurs_from_id)
  WHERE recurs_from_id IS NOT NULL;
