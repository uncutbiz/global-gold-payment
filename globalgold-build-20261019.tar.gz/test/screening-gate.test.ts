/**
 * The approval gate, and screening businesses that are already on the books.
 *
 * Two failures are pinned here, and the second is the dangerous one:
 *
 *   1. A business that registered before screening existed has no check, so it
 *      cannot be approved and there was no way to fix that. The backfill is
 *      the fix, and it must actually clear the gate.
 *
 *   2. With no watchlist loaded, screening compares a name against zero
 *      entries and writes "clear". That row is indistinguishable from a real
 *      clearance. Approving on the strength of it means approving a payments
 *      merchant with no sanctions screening at all, while the records say
 *      otherwise. The gate must refuse it.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-screengate';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const {
  approvalBlocked, screenedAgainstNothing, resetWatchlistCache, watchlistSummary, normalize,
} = await import('../src/compliance/screening.js');
const {
  rescreenMerchant, backfillScreening, merchantScreening, setMerchantStatus,
} = await import('../src/admin/service.js');

const STAFF = { id: 'stf_test', name: 'Compliance Person', email: 'c@globalgold.test', role: 'compliance' } as any;

let n = 0;
async function merchant(status = 'pending_review') {
  const id = `acct_sg_${n++}_${crypto.randomBytes(3).toString('hex')}`;
  await pool.query(
    `INSERT INTO merchants (id, name, email, status, webhook_secret, country)
     VALUES ($1,$2,$3,$4,'whsec_x','US')`,
    [id, `Biz ${n}`, `${id}@test.local`, status]);
  await pool.query(
    `INSERT INTO merchant_users (id, merchant_id, email, name, password_hash)
     VALUES ($1,$2,$3,'Owner Person','x')`,
    [`mu_${crypto.randomBytes(4).toString('hex')}`, id, `o-${id}@test.local`]);
  return id;
}

/** Put one real-looking entry on the watchlist so screening has something to compare. */
async function loadOneEntry(name = 'SOMEBODY SANCTIONED') {
  await pool.query(
    `INSERT INTO watchlist_entries
       (id, source, external_id, name, normalized_name, entity_type, program, list_version)
     VALUES ($1,'ofac_sdn',$2,$3,$4,'individual','TEST','v-test')`,
    [`wl_${crypto.randomBytes(4).toString('hex')}`, String(n++), name, normalize(name)]);
  resetWatchlistCache();
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  resetWatchlistCache();
});
after(async () => { await pool.end(); });

// ───────────────────────────────────────────── the gate (pure)
describe('the approval gate', () => {
  it('refuses a subject with no screening record at all', () => {
    const g = approvalBlocked(null);
    assert.equal(g.blocked, true);
    assert.match((g as any).reason, /has not been screened/);
  });

  it('refuses a potential or confirmed match', () => {
    assert.equal(approvalBlocked({ status: 'potential_match', sources_checked: ['ofac_sdn'], list_version: 'v:10' }).blocked, true);
    assert.equal(approvalBlocked({ status: 'confirmed_match', sources_checked: ['ofac_sdn'], list_version: 'v:10' }).blocked, true);
  });

  it('allows a real clearance — checked against a list that had entries', () => {
    assert.equal(approvalBlocked({ status: 'clear', sources_checked: ['ofac_sdn'], list_version: 'v1:1200' }).blocked, false);
  });

  it('REFUSES a "clear" that compared the name against nothing', () => {
    // The dangerous case. No sources, zero entries: the row says clear but
    // nothing was examined.
    const g = approvalBlocked({ status: 'clear', sources_checked: [], list_version: 'none:0' });
    assert.equal(g.blocked, true);
    assert.match((g as any).reason, /No sanctions list is loaded/);
  });

  it('spots an empty comparison from either signal', () => {
    assert.equal(screenedAgainstNothing({ status: 'clear', sources_checked: [], list_version: 'none:0' }), true);
    assert.equal(screenedAgainstNothing({ status: 'clear', sources_checked: [], list_version: 'v1:0' }), true,
      'a version with a zero count is still an empty list');
    assert.equal(screenedAgainstNothing({ status: 'clear', sources_checked: ['ofac_sdn'], list_version: 'v1:5' }), false);
    assert.equal(screenedAgainstNothing({ status: 'clear' }), true, 'missing fields are not evidence of a check');
  });
});

// ───────────────────────────────────────────── screening on demand
describe('screening a business already on the books', () => {
  it('an unscreened business cannot be activated, and says why', async () => {
    const id = await merchant();
    await assert.rejects(() => setMerchantStatus(STAFF, id, 'active'), /has not been screened/);
  });

  it('with no watchlist loaded, screening does NOT make it approvable', async () => {
    await pool.query('DELETE FROM watchlist_entries');
    resetWatchlistCache();
    const id = await merchant();
    const r = await rescreenMerchant(STAFF, id);
    assert.equal(r.merchant.status, 'clear', 'nothing to match against, so the raw verdict is clear');
    assert.equal(r.approvable, false, 'but it must not be approvable');
    assert.match(r.blocked_reason!, /No sanctions list is loaded/);
    assert.equal(r.watchlist.loaded, false);
    // And the gate still refuses the activation itself.
    await assert.rejects(() => setMerchantStatus(STAFF, id, 'active'), /No sanctions list is loaded/);
  });

  it('with a watchlist loaded, screening a clean name makes it approvable', async () => {
    await loadOneEntry('TOTALLY DIFFERENT PERSON');
    const id = await merchant();
    const r = await rescreenMerchant(STAFF, id);
    assert.equal(r.approvable, true, r.blocked_reason ?? '');
    assert.equal(r.watchlist.loaded, true);
    const m = await setMerchantStatus(STAFF, id, 'active');
    assert.equal((m as any).status, 'active');
  });

  it('screens the people on the account, not just the company', async () => {
    await loadOneEntry('UNRELATED NAME');
    const id = await merchant();
    const r = await rescreenMerchant(STAFF, id);
    assert.equal(r.owners.length, 1, 'the owner is screened too');
    assert.equal(r.owners[0].name, 'Owner Person');
  });

  it('backfill screens every unscreened business and leaves screened ones alone', async () => {
    await loadOneEntry('NOBODY RELEVANT');
    const a = await merchant(); const b = await merchant(); const c = await merchant();
    await rescreenMerchant(STAFF, c);           // c already done

    const before = (await pool.query('SELECT COUNT(*)::int AS n FROM screening_checks')).rows[0].n;
    const r = await backfillScreening(STAFF, 100);
    const ids = r.results.map((x: any) => x.merchant_id);
    assert.ok(ids.includes(a), 'a was unscreened and must be picked up');
    assert.ok(ids.includes(b), 'b was unscreened and must be picked up');
    assert.ok(!ids.includes(c), 'an already-screened business is skipped');
    assert.ok((await pool.query('SELECT COUNT(*)::int AS n FROM screening_checks')).rows[0].n > before);

    // Nothing is left unscreened afterwards — that is the point of a backfill.
    const stillUnscreened = (await pool.query(
      `SELECT COUNT(*)::int AS n FROM merchants m WHERE NOT EXISTS (
         SELECT 1 FROM screening_checks s WHERE s.subject_type='merchant' AND s.subject_id=m.id)`)).rows[0].n;
    assert.equal(stillUnscreened, 0);

    // Both are now approvable.
    assert.equal((await merchantScreening(a)).approvable, true);
    assert.equal((await merchantScreening(b)).approvable, true);
  });

  it('reports screening state for the admin drawer', async () => {
    await loadOneEntry('SOMEONE ELSE');
    const id = await merchant();
    let s = await merchantScreening(id);
    assert.equal(s.check, null);
    assert.equal(s.approvable, false);
    await rescreenMerchant(STAFF, id);
    s = await merchantScreening(id);
    assert.ok(s.check);
    assert.equal(s.approvable, true);
  });

  it('a watchlist summary says whether screening is configured', async () => {
    await pool.query('DELETE FROM watchlist_entries');
    resetWatchlistCache();
    assert.equal((await watchlistSummary()).loaded, false);
    await loadOneEntry();
    const w = await watchlistSummary();
    assert.equal(w.loaded, true);
    assert.ok(w.entries >= 1);
    assert.deepEqual(w.sources, ['ofac_sdn']);
  });
});
