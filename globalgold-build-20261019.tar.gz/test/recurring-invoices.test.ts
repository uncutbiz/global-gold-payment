/**
 * Invoices that repeat: "one time" or "subscription".
 *
 * The date arithmetic gets the hardest tests. Monthly billing on the 31st is
 * where every billing system goes wrong: naive maths turns Jan 31 + 1 month
 * into Mar 2, so the customer drifts a month forward and eventually gets
 * billed twice in one calendar month. The rest pins the operational
 * guarantees — a draft never bills, a period is minted exactly once, and the
 * schedule stops when it is told to.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-recur';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.INVOICE_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const {
  createInvoice, sendInvoice, setInvoiceRecurrence, stopInvoiceRecurrence,
  listSchedules, issueDueRecurringInvoices, nextRecurrence, scheduleFinished, getInvoice,
} = await import('../src/payments/invoices.js');

let n = 0;
async function merchant() {
  const id = `acct_ri_${n++}_${crypto.randomBytes(3).toString('hex')}`;
  await pool.query(
    `INSERT INTO merchants (id, name, email, status, webhook_secret)
     VALUES ($1,$2,$3,'active','whsec_x')`, [id, 'Biller', `${id}@test.local`]);
  return (await pool.query('SELECT * FROM merchants WHERE id=$1', [id])).rows[0];
}
async function customer(merchantId: string) {
  const id = `cus_${crypto.randomBytes(4).toString('hex')}`;
  await pool.query(
    `INSERT INTO customers (id, merchant_id, name, email) VALUES ($1,$2,'Buyer',$3)`,
    [id, merchantId, `${id}@buyer.test`]);
  return id;
}
async function invoiceFor(m: any, cust: string) {
  return createInvoice(m, {
    customer: cust, currency: 'usd', title: 'Monthly service',
    lines: [{ description: 'Service', quantity: 1, unit_amount: 5000 }],
  });
}
const d = (s: string) => new Date(s);

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
});
after(async () => { await pool.end(); });

// ───────────────────────────────────────────── date maths (pure)
describe('when the next one falls due', () => {
  it('adds days and weeks', () => {
    assert.equal(nextRecurrence(d('2026-01-01T09:00:00Z'), 'day', 1).toISOString(), '2026-01-02T09:00:00.000Z');
    assert.equal(nextRecurrence(d('2026-01-01T09:00:00Z'), 'week', 2).toISOString(), '2026-01-15T09:00:00.000Z');
  });

  it('keeps the time of day', () => {
    assert.equal(nextRecurrence(d('2026-03-10T14:30:45Z'), 'month', 1).toISOString(), '2026-04-10T14:30:45.000Z');
  });

  it('clamps the 31st to the length of a short month instead of overflowing', () => {
    // The bug this prevents: Jan 31 + 1 month must not become Mar 2/3.
    assert.equal(nextRecurrence(d('2026-01-31T00:00:00Z'), 'month', 1).toISOString(), '2026-02-28T00:00:00.000Z');
    assert.equal(nextRecurrence(d('2026-03-31T00:00:00Z'), 'month', 1).toISOString(), '2026-04-30T00:00:00.000Z');
    assert.equal(nextRecurrence(d('2026-05-31T00:00:00Z'), 'month', 1).toISOString(), '2026-06-30T00:00:00.000Z');
  });

  it('gets February right in a leap year', () => {
    // 2028 is a leap year; 2026 is not.
    assert.equal(nextRecurrence(d('2028-01-31T00:00:00Z'), 'month', 1).toISOString(), '2028-02-29T00:00:00.000Z');
  });

  it('rolls the year over', () => {
    assert.equal(nextRecurrence(d('2026-12-15T00:00:00Z'), 'month', 1).toISOString(), '2027-01-15T00:00:00.000Z');
    assert.equal(nextRecurrence(d('2026-11-30T00:00:00Z'), 'month', 3).toISOString(), '2027-02-28T00:00:00.000Z');
  });

  it('handles yearly, including Feb 29 landing on a non-leap year', () => {
    assert.equal(nextRecurrence(d('2026-06-01T00:00:00Z'), 'year', 1).toISOString(), '2027-06-01T00:00:00.000Z');
    assert.equal(nextRecurrence(d('2028-02-29T00:00:00Z'), 'year', 1).toISOString(), '2029-02-28T00:00:00.000Z');
  });

  it('refuses a nonsense interval count', () => {
    assert.throws(() => nextRecurrence(new Date(), 'month', 0), /one or more/);
    assert.throws(() => nextRecurrence(new Date(), 'month', 1.5), /whole number/);
  });
});

describe('when a schedule has run out', () => {
  const soon = d('2026-06-01T00:00:00Z');
  it('stops at the cycle cap', () => {
    assert.equal(scheduleFinished({ recur_max_cycles: 3, recur_cycles_done: 3 }, soon), true);
    assert.equal(scheduleFinished({ recur_max_cycles: 3, recur_cycles_done: 2 }, soon), false);
  });
  it('stops when the next one would fall after the end date', () => {
    assert.equal(scheduleFinished({ recur_end_at: d('2026-05-01T00:00:00Z') }, soon), true);
    assert.equal(scheduleFinished({ recur_end_at: d('2026-07-01T00:00:00Z') }, soon), false);
  });
  it('runs forever with neither set', () => {
    assert.equal(scheduleFinished({}, soon), false);
  });
});

// ───────────────────────────────────────────── the feature
describe('making an invoice recurring', () => {
  it('defaults to one-time', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    assert.equal(inv.billing_type, 'one_time');
  });

  it('a recurring DRAFT does not bill — the clock starts when it is sent', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    const set = await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'month' });
    assert.equal(set.billing_type, 'recurring');
    assert.equal(set.recur_active, false, 'a draft must never be active');
    assert.equal(set.recur_next_at, null);

    // Nothing is due, because nothing has been sent.
    assert.equal((await issueDueRecurringInvoices(10, d('2027-01-01T00:00:00Z'))).issued, 0);

    await sendInvoice(m, inv.id);
    const after = await getInvoice(m, inv.id);
    assert.equal(after.recur_active, true, 'sending starts the schedule');
    assert.ok(after.recur_next_at, 'and sets the next date');
  });

  it('issues the next invoice when the period comes due, copying the lines', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'month' });
    await sendInvoice(m, inv.id);

    // Jump past the next due date. The issuer is platform-wide, so assert the
    // effect on THIS schedule rather than the global count.
    const r = await issueDueRecurringInvoices(50, d('2099-01-01T00:00:00Z'));
    assert.ok(r.issued >= 1);

    const kids = (await pool.query(
      'SELECT * FROM invoices WHERE recurs_from_id=$1', [inv.id])).rows;
    assert.equal(kids.length, 1);
    const child = kids[0];
    assert.equal(child.status, 'open', 'the minted invoice is sent, so it is payable');
    assert.equal(Number(child.total), Number(inv.total), 'same amount as the original');
    assert.notEqual(child.number, inv.number, 'its own invoice number');
    assert.ok(child.payment_link_id, 'and its own payment link');
    const lines = (await pool.query('SELECT * FROM invoice_lines WHERE invoice_id=$1', [child.id])).rows;
    assert.equal(lines.length, 1);
    assert.equal(lines[0].description, 'Service');
  });

  it('a period is minted once, even if the issuer runs twice', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'month' });
    await sendInvoice(m, inv.id);

    const now = d('2026-12-01T00:00:00Z');
    const a = await issueDueRecurringInvoices(10, now);
    const b = await issueDueRecurringInvoices(10, now);
    assert.equal(a.issued + b.issued, 1, 'the same period must not be billed twice');
  });

  it('stops after max_cycles and marks the schedule finished', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'day', max_cycles: 2 });
    await sendInvoice(m, inv.id);

    // Run far enough ahead that each call finds one period due.
    for (let i = 0; i < 5; i++) await issueDueRecurringInvoices(10, d('2099-01-01T00:00:00Z'));

    const s = await getInvoice(m, inv.id);
    assert.equal(s.recur_cycles_done, 2, 'exactly the cap');
    assert.equal(s.recur_active, false, 'and the schedule is closed');
    assert.equal(s.recur_next_at, null);
  });

  it('a merchant can stop a schedule, and already-issued invoices stay', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'month' });
    await sendInvoice(m, inv.id);
    await issueDueRecurringInvoices(10, d('2099-01-01T00:00:00Z'));

    const countKids = async () => (await pool.query(
      'SELECT COUNT(*)::int AS n FROM invoices WHERE recurs_from_id=$1', [inv.id])).rows[0].n;
    const beforeStop = await countKids();

    const stopped = await stopInvoiceRecurrence(m, inv.id);
    assert.equal(stopped.recur_active, false);

    // Run the issuer far into the future: this schedule must mint nothing more.
    await issueDueRecurringInvoices(50, d('2099-06-01T00:00:00Z'));
    assert.equal(await countKids(), beforeStop,
      'a stopped schedule issues nothing further, and what it already issued stays');
    assert.ok(beforeStop >= 1, 'it had issued at least one before being stopped');
  });

  it('switching back to one-time clears the cadence', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'week' });
    const back = await setInvoiceRecurrence(m, inv.id, { billing_type: 'one_time' });
    assert.equal(back.billing_type, 'one_time');
    assert.equal(back.recur_interval, null);
    assert.equal(back.recur_active, false);
  });

  it('refuses a recurring invoice with no interval, and a past end date', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await assert.rejects(() => setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring' } as any), /needs an interval/);
    await assert.rejects(
      () => setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'month', end_at: d('2020-01-01T00:00:00Z') }),
      /in the past/);
  });

  it('a minted invoice cannot itself be made into a schedule', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'month' });
    await sendInvoice(m, inv.id);
    await issueDueRecurringInvoices(10, d('2099-01-01T00:00:00Z'));
    const child = (await pool.query('SELECT id FROM invoices WHERE recurs_from_id=$1', [inv.id])).rows[0];
    await assert.rejects(
      () => setInvoiceRecurrence(m, child.id, { billing_type: 'recurring', interval: 'month' }),
      /issued by a schedule/);
  });

  it('lists a merchant\'s schedules with how many have gone out', async () => {
    const m = await merchant(); const c = await customer(m.id);
    const inv = await invoiceFor(m, c);
    await setInvoiceRecurrence(m, inv.id, { billing_type: 'recurring', interval: 'month', interval_count: 2 });
    await sendInvoice(m, inv.id);
    await issueDueRecurringInvoices(10, d('2099-01-01T00:00:00Z'));

    const list = await listSchedules(m);
    assert.equal(list.length, 1);
    assert.equal(list[0].interval, 'month');
    assert.equal(list[0].interval_count, 2);
    assert.equal(list[0].issued, 1);
    assert.equal(list[0].customer_name, 'Buyer');
  });

  it('one merchant cannot touch another\'s schedule', async () => {
    const a = await merchant(); const b = await merchant();
    const c = await customer(a.id);
    const inv = await invoiceFor(a, c);
    await assert.rejects(
      () => setInvoiceRecurrence(b, inv.id, { billing_type: 'recurring', interval: 'month' }),
      /not found/);
  });
});
