/**
 * Two businesses, two logins, no overlap.
 *
 * This is the test that answers "can another business see my data". It signs
 * up two real accounts through the HTTP API and then, for every resource the
 * dashboard exposes, checks three things:
 *
 *   1. A list shows only your own rows.
 *   2. Fetching another account's object by its id is a 404, not a 200 — and
 *      404 rather than 403, because "this id exists but is not yours" is
 *      itself a disclosure.
 *   3. Acting on another account's object changes nothing.
 *
 * It also pins the two cases that look like overlap but are not: two accounts
 * with nearly identical names, and one person's email on a second account.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-isolation';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.INVOICE_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'off';
process.env.AUTH_RATE_LIMIT = '1000';
process.env.CARD_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

let base = '';
let server: http.Server;

async function call(method: string, path: string, key?: string | null, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json: any = null;
  try { json = await r.json(); } catch { /* empty body */ }
  return { status: r.status, body: json };
}

interface Biz { key: string; id: string; email: string }

async function signup(name: string, emailLocal?: string): Promise<Biz> {
  const who = emailLocal ?? `b-${crypto.randomBytes(4).toString('hex')}`;
  const email = `${who}@test.com`;
  const r = await call('POST', '/v1/business/signup', null, {
    business_name: name, name: 'Owner', email,
    password: 'a-long-password-123', country: 'US', business_type: 'company',
  });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  // Activate so payment-bearing endpoints are usable.
  await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [r.body.merchant_id]);
  return { key: r.body.token, id: r.body.merchant_id, email };
}

/** Everything one business owns, so the other can be pointed at all of it. */
async function furnish(b: Biz) {
  const customer = (await call('POST', '/v1/customers', b.key, { name: 'Buyer', email: `cus-${crypto.randomBytes(3).toString('hex')}@x.com` })).body;
  const item = (await call('POST', '/v1/items', b.key, { name: 'Widget', price: 2500, currency: 'usd' })).body;
  const order = (await call('POST', '/v1/orders', b.key, { items: [{ item_id: item.id, quantity: 1 }] })).body;
  const invoice = (await call('POST', '/v1/invoices', b.key, {
    customer: customer.id, currency: 'usd',
    lines: [{ description: 'Work', quantity: 1, unit_amount: 5000 }],
  })).body;
  const intent = (await call('POST', '/v1/payment_intents', b.key, { amount: 1000, currency: 'usd' })).body;
  const link = (await call('POST', '/v1/payment_links', b.key, { title: 'Pay me', amount: 1000, currency: 'usd' })).body;
  const card = (await call('POST', '/v1/business_cards', b.key, { currency: 'usd', nickname: 'Ops' })).body;
  return { customer, item, order, invoice, intent, link, card };
}

let A: Biz, B: Biz, ownA: Awaited<ReturnType<typeof furnish>>;

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  A = await signup('Alpha Trading');
  B = await signup('Beta Supply');
  ownA = await furnish(A);
  await furnish(B);
});
after(async () => { server?.close(); await pool.end(); });

describe('each business sees only its own data', () => {
  const lists: Array<[string, string]> = [
    ['customers', '/v1/customers'],
    ['items', '/v1/items'],
    ['orders', '/v1/orders'],
    ['invoices', '/v1/invoices'],
    ['payments', '/v1/payment_intents'],
    ['payment links', '/v1/payment_links'],
    ['expense cards', '/v1/business_cards'],
  ];

  for (const [label, path] of lists) {
    it(`${label}: a list never contains another account's rows`, async () => {
      const mine = await call('GET', path, A.key);
      assert.equal(mine.status, 200, JSON.stringify(mine.body));
      const rows = mine.body.data ?? mine.body;
      assert.ok(Array.isArray(rows), `${path} should return a list`);

      const theirs = await call('GET', path, B.key);
      const theirIds = new Set((theirs.body.data ?? theirs.body).map((r: any) => r.id));
      for (const row of rows) {
        assert.ok(!theirIds.has(row.id), `${path} leaked a row across accounts`);
      }
      // Both accounts were furnished identically, so each must see its own.
      assert.ok(rows.length >= 1, `${path} returned nothing for its owner`);
    });
  }
});

describe('one business cannot reach another\'s objects by id', () => {
  it('reading another account\'s object is a 404, not a 200', async () => {
    const probes: Array<[string, string]> = [
      ['customer', `/v1/customers/${ownA.customer.id}`],
      ['item', `/v1/items/${ownA.item.id}`],
      ['order', `/v1/orders/${ownA.order.id}`],
      ['invoice', `/v1/invoices/${ownA.invoice.id}`],
      ['payment intent', `/v1/payment_intents/${ownA.intent.id}`],
    ];
    for (const [label, path] of probes) {
      const mine = await call('GET', path, A.key);
      assert.equal(mine.status, 200, `${label}: the owner must be able to read it`);
      const theirs = await call('GET', path, B.key);
      assert.equal(theirs.status, 404, `${label}: another account got ${theirs.status} instead of 404`);
    }
  });

  it('acting on another account\'s object is refused and changes nothing', async () => {
    // Send A's invoice as B.
    const send = await call('POST', `/v1/invoices/${ownA.invoice.id}/send`, B.key);
    assert.equal(send.status, 404);
    assert.equal((await call('GET', `/v1/invoices/${ownA.invoice.id}`, A.key)).body.status, 'draft',
      'A\'s invoice must still be a draft');

    // Archive A's item as B.
    assert.equal((await call('POST', `/v1/items/${ownA.item.id}`, B.key, { active: false })).status, 404);
    assert.equal((await call('GET', `/v1/items/${ownA.item.id}`, A.key)).body.active, true);

    // Cancel A's order as B.
    assert.equal((await call('POST', `/v1/orders/${ownA.order.id}/status`, B.key, { status: 'canceled' })).status, 404);
    assert.equal((await call('GET', `/v1/orders/${ownA.order.id}`, A.key)).body.status, 'open');

    // Freeze A's expense card as B.
    assert.equal((await call('POST', `/v1/business_cards/${ownA.card.id}/freeze`, B.key)).status, 404);

    // Refund A's payment as B.
    const refund = await call('POST', '/v1/refunds', B.key, { payment_intent: ownA.intent.id });
    assert.ok(refund.status === 404 || refund.status === 400, `got ${refund.status}`);
  });

  it('another account cannot read or change A\'s brand, and its logo stays A\'s', async () => {
    await call('PATCH', '/v1/brand', A.key, { display_name: 'Alpha Public' });
    assert.equal((await call('GET', '/v1/brand', A.key)).body.display_name, 'Alpha Public');
    // B's own brand is untouched by A's change.
    assert.equal((await call('GET', '/v1/brand', B.key)).body.display_name, null);
    // And B writing its brand does not touch A's.
    await call('PATCH', '/v1/brand', B.key, { display_name: 'Beta Public' });
    assert.equal((await call('GET', '/v1/brand', A.key)).body.display_name, 'Alpha Public');
  });

  it('loyalty points belong to the business that granted them', async () => {
    await call('POST', '/v1/loyalty/program', A.key, { enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 1 });
    await call('POST', '/v1/loyalty/earn', A.key, { customer_id: ownA.customer.id, amount: 5000, source: 'iso-1' });
    assert.equal((await call('GET', `/v1/loyalty/accounts/${ownA.customer.id}`, A.key)).body.balance, 50);
    // B does not own that customer, so the account is not reachable.
    assert.equal((await call('GET', `/v1/loyalty/accounts/${ownA.customer.id}`, B.key)).status, 404);
    // And B cannot spend A's customer's points.
    assert.equal((await call('POST', '/v1/loyalty/redeem', B.key, { customer_id: ownA.customer.id, points: 10 })).status, 404);
    assert.equal((await call('GET', `/v1/loyalty/accounts/${ownA.customer.id}`, A.key)).body.balance, 50,
      'the balance is unchanged');
  });
});

describe('sessions and credentials do not cross', () => {
  it('signing out of one account leaves the other signed in', async () => {
    const a2 = await signup('Gamma Co');
    const b2 = await signup('Delta Co');
    assert.equal((await call('POST', '/v1/business/logout', a2.key)).status, 200);
    assert.equal((await call('GET', '/v1/brand', a2.key)).status, 401, 'the signed-out session is dead');
    assert.equal((await call('GET', '/v1/brand', b2.key)).status, 200, 'the other session still works');
  });

  it('a session only ever resolves to the account it was issued for', async () => {
    const mineA = (await call('GET', '/v1/account', A.key)).body;
    const mineB = (await call('GET', '/v1/account', B.key)).body;
    assert.notEqual(mineA.id, mineB.id);
    assert.equal(mineA.id, A.id);
    assert.equal(mineB.id, B.id);
  });

  it('the same email cannot open a second business account', async () => {
    const dup = await call('POST', '/v1/business/signup', null, {
      business_name: 'Impostor Ltd', name: 'Owner', email: A.email,
      password: 'a-long-password-123', country: 'US', business_type: 'company',
    });
    assert.equal(dup.status, 409, 'one email, one login');
  });

  it('two businesses with nearly the same name are still separate accounts', async () => {
    // This is what "overlap" usually turns out to be: two real, distinct
    // accounts whose names look alike in a list.
    const one = await signup('OpenDoor');
    const two = await signup('Opendoor');
    assert.notEqual(one.id, two.id);
    await call('POST', '/v1/items', one.key, { name: 'Only mine', price: 100, currency: 'usd' });
    const theirItems = (await call('GET', '/v1/items', two.key)).body.data;
    assert.equal(theirItems.length, 0, 'a similar name shares nothing');
  });

  it('a wrong password does not get in, and a right one does', async () => {
    const biz = await signup('Epsilon Co');
    assert.equal((await call('POST', '/v1/business/login', null, { email: biz.email, password: 'wrong-password-here' })).status, 401);
    const ok = await call('POST', '/v1/business/login', null, { email: biz.email, password: 'a-long-password-123' });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.merchant_id, biz.id, 'and lands on its own account');
  });
});
