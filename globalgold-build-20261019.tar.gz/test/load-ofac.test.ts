/**
 * The OFAC SDN loader.
 *
 * The parsing tests are here because SDN.CSV is a hostile little format: it is
 * positional, its remarks field contains commas, quotes and newlines, and it
 * writes the literal string "-0-" where a field is absent. Getting any of that
 * wrong silently corrupts the list every name is screened against.
 *
 * The load test pins the behaviour that matters operationally: loading a new
 * snapshot removes the previous one (a delisted person must stop matching),
 * and once a list is present the approval gate stops refusing.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-ofac';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { parseCsv, val, ofacVersion, loadOfac } = await import('../src/load-ofac.js');
const { watchlistSummary, evaluate, loadWatchlist, resetWatchlistCache } =
  await import('../src/compliance/screening.js');

/** Two rows in the real column order: ent_num, name, type, program, …, remarks. */
const SDN_A = [
  '1,"BADGUY, Ivan","individual","SDN-PROGRAM",-0-,-0-,-0-,-0-,-0-,-0-,-0-,"Linked to X, Y and Z."',
  '2,"SHELL COMPANY LTD","entity","SDN-PROGRAM",-0-,-0-,-0-,-0-,-0-,-0-,-0-,-0-',
].join('\n') + '\n';

/** A later snapshot where Ivan has been delisted and someone else added. */
const SDN_B = [
  '2,"SHELL COMPANY LTD","entity","SDN-PROGRAM",-0-,-0-,-0-,-0-,-0-,-0-,-0-,-0-',
  '3,"NEWLY LISTED PERSON","individual","SDN-PROGRAM",-0-,-0-,-0-,-0-,-0-,-0-,-0-,-0-',
].join('\n') + '\n';

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  resetWatchlistCache();
});
after(async () => { await pool.end(); });

// ───────────────────────────────────────────── parsing (pure)
describe('parsing SDN.CSV', () => {
  it('keeps a quoted field that contains commas as one field', () => {
    const rows = parseCsv('1,"BADGUY, Ivan","individual"\n');
    assert.equal(rows[0]!.length, 3);
    assert.equal(rows[0]![1], 'BADGUY, Ivan');
  });

  it('handles an escaped quote inside a quoted field', () => {
    const rows = parseCsv('1,"He said ""no""",x\n');
    assert.equal(rows[0]![1], 'He said "no"');
  });

  it('keeps a newline inside a quoted field in the same row', () => {
    const rows = parseCsv('1,"line one\nline two",x\n');
    assert.equal(rows.length, 1, 'a quoted newline must not split the row');
    assert.equal(rows[0]![1], 'line one\nline two');
  });

  it('reads a final row with no trailing newline', () => {
    const rows = parseCsv('1,a,b');
    assert.equal(rows.length, 1);
    assert.equal(rows[0]![2], 'b');
  });

  it('treats "-0-" as absent, not as a value', () => {
    assert.equal(val('-0-'), null);
    assert.equal(val('  -0-  '), null);
    assert.equal(val(''), null);
    assert.equal(val(undefined), null);
    assert.equal(val(' Tehran '), 'Tehran');
  });
});

// ───────────────────────────────────────────── version (pure)
describe('the list version', () => {
  it('is the same for the same file and different for a changed one', () => {
    assert.equal(ofacVersion(SDN_A), ofacVersion(SDN_A), 'reproducible');
    assert.notEqual(ofacVersion(SDN_A), ofacVersion(SDN_B));
    assert.match(ofacVersion(SDN_A), /^ofac_sdn:[0-9a-f]{12}$/);
  });
});

// ───────────────────────────────────────────── loading
describe('loading the list', () => {
  it('loads entries, maps types, and nulls the "-0-" fields', async () => {
    const r = await loadOfac(SDN_A);
    assert.equal(r.loaded, 2);
    assert.equal(r.total, 2);

    const ivan = (await pool.query(
      `SELECT * FROM watchlist_entries WHERE name LIKE 'BADGUY%'`)).rows[0];
    assert.equal(ivan.entity_type, 'individual');
    assert.equal(ivan.program, 'SDN-PROGRAM');
    assert.equal(ivan.country, null, '"-0-" must not become the string "-0-"');
    assert.match(ivan.remarks, /Linked to X, Y and Z/);
    assert.ok(ivan.normalized_name, 'the match column is populated at load time');
  });

  it('a loaded list makes screening meaningful — the name actually matches', async () => {
    await loadOfac(SDN_A);
    const { entries } = await loadWatchlist();
    const v = evaluate({ name: 'Ivan Badguy' }, entries);
    assert.notEqual(v.status, 'clear', 'a listed person must not come back clear');
    assert.ok(v.topScore >= 85, `expected a strong score, got ${v.topScore}`);
  });

  it('a clean name still comes back clear against a loaded list', async () => {
    await loadOfac(SDN_A);
    const { entries } = await loadWatchlist();
    assert.equal(evaluate({ name: 'Marie Joseph' }, entries).status, 'clear');
  });

  it('a new snapshot delists whoever is no longer on it', async () => {
    await loadOfac(SDN_A);
    assert.equal((await watchlistSummary()).entries, 2);

    const r = await loadOfac(SDN_B);
    assert.equal(r.total, 2, 'two entries on the new snapshot');
    assert.ok(r.delisted >= 1, 'the dropped entry is removed');

    // Ivan is gone, so he no longer matches.
    const { entries } = await loadWatchlist();
    assert.equal(evaluate({ name: 'Ivan Badguy' }, entries).status, 'clear',
      'a delisted person must stop matching');
    assert.ok(entries.some((e) => e.name === 'NEWLY LISTED PERSON'));
  });

  it('refuses a file that is not the SDN list', async () => {
    await assert.rejects(() => loadOfac('\n\n'), /No rows parsed/);
  });

  it('the summary reports a loaded list', async () => {
    await loadOfac(SDN_A);
    const w = await watchlistSummary();
    assert.equal(w.loaded, true);
    assert.deepEqual(w.sources, ['ofac_sdn']);
    assert.match(w.version, /^ofac_sdn:[0-9a-f]{12}:2$/);
  });
});
