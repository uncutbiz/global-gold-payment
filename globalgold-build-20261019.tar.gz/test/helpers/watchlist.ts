/**
 * Seed a minimal sanctions watchlist for tests.
 *
 * WHY TESTS NEED THIS NOW
 *
 * Approving a merchant or a customer's identity check requires a screening
 * record that was compared against a list with entries in it. A "clear"
 * verdict produced against an empty list is not a clearance — it means nothing
 * was examined — and the approval gate refuses it. That is the correct
 * production rule: a real deployment runs `ggp load-ofac` before approving
 * anybody.
 *
 * So a test that approves someone has to look like a configured deployment.
 * This seeds one entry whose name matches nobody, which is enough to make
 * screening meaningful without creating false positives.
 */
import { pool } from '../../src/db.js';
import { normalize, resetWatchlistCache } from '../../src/compliance/screening.js';

/** One harmless entry, so screening compares against something. */
export async function seedWatchlist(name = 'ZZZ NOBODY MATCHES THIS NAME'): Promise<void> {
  await pool.query(
    `INSERT INTO watchlist_entries
       (id, source, external_id, name, normalized_name, entity_type, program, list_version)
     VALUES ($1,'ofac_sdn',$2,$3,$4,'individual','TEST','test:seed')
     ON CONFLICT (source, external_id) WHERE external_id IS NOT NULL DO NOTHING`,
    [`wl_seed_${Math.random().toString(36).slice(2, 10)}`, `seed-${Math.random().toString(36).slice(2, 10)}`,
     name, normalize(name)]);
  resetWatchlistCache();
}
