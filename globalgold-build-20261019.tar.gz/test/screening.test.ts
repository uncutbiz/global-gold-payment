/**
 * Sanctions screening.
 *
 * The matching is pure, so the first half of this file hands it the cases that
 * actually decide whether a screening programme works: the same person written
 * two ways, a common name that is not the listed person, a company with a
 * suffix, a transliteration. These are the ones a false-positive rate is made
 * of, and none of them needs a database.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'scr-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const {
  approvalBlocked, dobContradicts, evaluate, MATCH_THRESHOLD, normalize, score,
} = await import('../src/compliance/screening.js');

// ────────────────────────────────────────────────────────────── normalisation
test('surname-first and natural order normalise to the same string', () => {
  // Every published list writes names surname-first. No customer does.
  assert.equal(normalize('SMITH, JOHN'), normalize('John Smith'));
  assert.equal(normalize('AL-ASSAD, Bashar'), normalize('bashar al assad'));
});

test('accents, punctuation and case fold away', () => {
  assert.equal(normalize('José MARTÍNEZ'), normalize('jose martinez'));
  assert.equal(normalize("O'Brien, Patrick"), normalize('patrick obrien'));
});

test('corporate suffixes and titles are dropped, real names are not', () => {
  assert.equal(normalize('Acme Ltd'), normalize('ACME Limited'));
  assert.equal(normalize('Dr. Ana Pereira'), normalize('ana pereira'));
  // "Co" is noise; "Cole" is a name and must survive.
  assert.ok(normalize('Jordan Cole').includes('cole'));
});

test('normalising an empty or junk name does not throw', () => {
  assert.equal(normalize(''), '');
  assert.equal(normalize('   '), '');
  assert.equal(normalize('...'), '');
});

// ──────────────────────────────────────────────────────────────── the scoring
test('identical names score 100 however they are written', () => {
  assert.equal(score('John Smith', 'SMITH, JOHN'), 100);
  assert.equal(score('Acme Ltd', 'ACME LIMITED'), 100);
});

test('a middle name costs a little, not everything', () => {
  // Same person. Must stay well above threshold, or every customer with a
  // middle name on one side becomes a miss.
  const s = score('John Smith', 'John Michael Smith');
  assert.ok(s >= MATCH_THRESHOLD, `middle-name case scored ${s}, below threshold`);
  assert.ok(s < 100, 'but it is not a perfect match either');
});

test('common transliterations still match', () => {
  for (const [a, b] of [
    ['Mohammed Ali', 'Muhammad Ali'],
    ['Yusef Hassan', 'Yousef Hassan'],
    ['Sergei Ivanov', 'Sergey Ivanov'],
  ] as const) {
    const s = score(a, b);
    assert.ok(s >= MATCH_THRESHOLD, `"${a}" vs "${b}" scored ${s}, below threshold`);
  }
});

test('different people with one shared name score low', () => {
  // This is the false-positive case. If these clear the threshold, reviewers
  // drown and stop reading, which is worse than not screening.
  for (const [a, b] of [
    ['John Smith', 'Jane Smith'],
    ['Ana Pereira', 'Luis Pereira'],
    ['Wei Chen', 'Wei Zhang'],
  ] as const) {
    const s = score(a, b);
    assert.ok(s < MATCH_THRESHOLD, `"${a}" vs "${b}" scored ${s} — a false positive`);
  }
});

test('unrelated names score near zero', () => {
  assert.ok(score('John Smith', 'Vladimir Petrov') < 40);
});

test('scoring is symmetric', () => {
  // Asymmetry would mean the result depended on argument order, which is the
  // kind of bug that shows up as "it matched last week".
  for (const [a, b] of [
    ['John Smith', 'John Michael Smith'],
    ['Acme Ltd', 'Acme Holdings Limited'],
    ['Mohammed Ali', 'Ali'],
  ] as const) {
    assert.equal(score(a, b), score(b, a), `${a} / ${b}`);
  }
});

test('an empty name never matches anything', () => {
  assert.equal(score('', 'John Smith'), 0);
  assert.equal(score('   ', 'John Smith'), 0);
});

// ────────────────────────────────────────────────────────── date of birth
test('a different date of birth rules a name match out', () => {
  assert.equal(dobContradicts('1980-01-01', '1975-06-12'), true);
  assert.equal(dobContradicts('1980-01-01', '1980-01-01'), false);
});

test('a missing date of birth rules nothing out', () => {
  // Treating "unknown" as "different" would clear real matches, which is the
  // expensive direction to be wrong in.
  assert.equal(dobContradicts(null, '1975-06-12'), false);
  assert.equal(dobContradicts('1980-01-01', null), false);
  assert.equal(dobContradicts(undefined, undefined), false);
});

// ─────────────────────────────────────────────────────────────── the verdict
const LIST = [
  { id: 'w1', source: 'ofac_sdn', name: 'IVANOV, Vladimir', program: 'SDN', country: 'RU', date_of_birth: '1975-06-12' },
  { id: 'w2', source: 'ofac_sdn', name: 'ACME TRADING LIMITED', program: 'SDN', country: 'IR', date_of_birth: null },
  { id: 'w3', source: 'eu', name: 'Bashar AL-ASSAD', program: 'PEP', country: 'SY', date_of_birth: null },
];

test('a listed name comes back as a potential match, with its source named', () => {
  const v = evaluate({ name: 'Vladimir Ivanov' }, LIST);
  assert.equal(v.status, 'potential_match');
  assert.equal(v.matches.length, 1);
  assert.equal(v.matches[0].source, 'ofac_sdn');
  assert.equal(v.matches[0].program, 'SDN');
  assert.match(v.matches[0].reason, /exact name match/);
});

test('an unlisted name comes back clear, and still reports its top score', () => {
  const v = evaluate({ name: 'Marguerite Okonjo' }, LIST);
  assert.equal(v.status, 'clear');
  assert.equal(v.matches.length, 0);
  // The score is kept even when clear: a run of near-misses on one name is a
  // signal in itself.
  assert.equal(typeof v.topScore, 'number');
});

test('a matching name with a contradicting date of birth is not a match', () => {
  const v = evaluate({ name: 'Vladimir Ivanov', dateOfBirth: '1990-02-02' }, LIST);
  assert.equal(v.status, 'clear', 'a different DOB should rule this out');
  // But the name similarity is still recorded.
  assert.equal(v.topScore, 100);
});

test('the same name with the right date of birth is still a match', () => {
  const v = evaluate({ name: 'Vladimir Ivanov', dateOfBirth: '1975-06-12' }, LIST);
  assert.equal(v.status, 'potential_match');
});

test('matches come back highest score first', () => {
  const list = [
    { id: 'a', source: 's', name: 'John Michael Smith', date_of_birth: null },
    { id: 'b', source: 's', name: 'John Smith', date_of_birth: null },
  ];
  const v = evaluate({ name: 'John Smith' }, list);
  assert.equal(v.matches[0].entry_id, 'b', 'the exact match must be first');
  assert.equal(v.matches.length, 2);
  assert.ok(v.matches[0].score >= v.matches[1].score);
});

test('an empty watchlist clears everyone — and that is the dangerous case', () => {
  // Documented deliberately: if the list fails to load, everything looks
  // clear. The gate below is what stops that becoming an open door.
  const v = evaluate({ name: 'Vladimir Ivanov' }, []);
  assert.equal(v.status, 'clear');
});

// ───────────────────────────────────────────────────────────────── the gate
test('an unscreened subject cannot be approved', () => {
  const r = approvalBlocked(null);
  assert.equal(r.blocked, true);
  assert.match((r as any).reason, /not been screened/);
});

test('a subject awaiting review cannot be approved', () => {
  assert.equal(approvalBlocked({ status: 'potential_match' }).blocked, true);
});

test('a confirmed match cannot be approved', () => {
  assert.equal(approvalBlocked({ status: 'confirmed_match' }).blocked, true);
});

test('a clear subject, and one a reviewer cleared, can be approved', () => {
  // A clearance counts only if the name was compared against a list that had
  // entries in it. The sources and the version are part of the evidence, not
  // decoration — see approvalBlocked and screenedAgainstNothing.
  const checked = { sources_checked: ['ofac_sdn'], list_version: 'ofac_sdn:abc123:1200' };
  assert.equal(approvalBlocked({ status: 'clear', ...checked }).blocked, false);
  assert.equal(approvalBlocked({ status: 'false_positive', ...checked }).blocked, false);
});

test('a clear verdict against an empty list is NOT an approval', () => {
  // With no watchlist loaded, screening compares a name against nothing and
  // records "clear". That row must not open the gate.
  assert.equal(approvalBlocked({ status: 'clear', sources_checked: [], list_version: 'none:0' }).blocked, true);
  assert.equal(approvalBlocked({ status: 'clear' }).blocked, true, 'no evidence of a check at all');
});

// ───────────────────────────────────────────── recording, against a database
const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { resetWatchlistCache, review, screen, latestFor, reviewQueue } =
  await import('../src/compliance/screening.js');

await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
await migrate();

async function seedList() {
  for (const e of LIST) {
    await pool.query(
      `INSERT INTO watchlist_entries
         (id, source, external_id, name, normalized_name, program, country, date_of_birth, list_version)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'test-v1')`,
      [e.id, e.source, e.id, e.name, normalize(e.name), e.program, e.country, e.date_of_birth]);
  }
  resetWatchlistCache();
}
await seedList();

test('a clear screen is recorded, not just the hits', async () => {
  const r = await screen({ subjectType: 'user', subjectId: 'usr_clear', name: 'Marguerite Okonjo' });
  assert.equal(r.status, 'clear');
  const row = await latestFor('user', 'usr_clear') as any;
  assert.ok(row, 'a clear screen must still leave a record — it is the proof anyone was screened');
  assert.equal(row.status, 'clear');
  // Reproducibility: the row names which lists, and which snapshot.
  assert.ok(row.sources_checked.length > 0);
  assert.match(row.list_version, /test-v1/);
});

test('a hit is recorded with the matches that caused it', async () => {
  const r = await screen({ subjectType: 'merchant', subjectId: 'acct_hit', name: 'Acme Trading Ltd' });
  assert.equal(r.status, 'potential_match');
  const row = await latestFor('merchant', 'acct_hit') as any;
  assert.equal(row.status, 'potential_match');
  assert.equal(row.matches.length, 1);
  assert.equal(row.matches[0].source, 'ofac_sdn');
});

test('hits land in the review queue', async () => {
  const q = await reviewQueue();
  assert.ok(q.data.some((c: any) => c.subject_id === 'acct_hit'));
  assert.ok(!q.data.some((c: any) => c.subject_id === 'usr_clear'), 'clear screens are not work');
});

test('a review needs a written reason', async () => {
  const r = await screen({ subjectType: 'user', subjectId: 'usr_rev', name: 'Vladimir Ivanov' });
  await assert.rejects(
    () => review(r.id, 'false_positive', 'staff_1', 'nope'),
    /written reason/);
});

test('a reviewed check keeps its findings — the decision is added, not substituted', async () => {
  const r = await screen({ subjectType: 'user', subjectId: 'usr_rev2', name: 'Vladimir Ivanov' });
  const done = await review(r.id, 'false_positive', 'staff_1',
    'Date of birth and nationality both differ; customer provided a passport.') as any;
  assert.equal(done.status, 'false_positive');
  assert.equal(done.reviewed_by, 'staff_1');
  assert.ok(done.reviewed_at);
  assert.equal(done.matches.length, 1, 'the original finding must survive the review');
});

test('a check cannot be reviewed twice', async () => {
  const r = await screen({ subjectType: 'user', subjectId: 'usr_rev3', name: 'Vladimir Ivanov' });
  await review(r.id, 'confirmed_match', 'staff_1', 'Confirmed against the published listing.');
  await assert.rejects(
    () => review(r.id, 'false_positive', 'staff_2', 'Changed my mind about this one.'),
    /already confirmed_match/);
});

test('the watchlist cache refreshes when the list changes', async () => {
  // A stale cache here is a correctness bug: a name added this morning would
  // not be screened against until the process restarted.
  const before = await screen({ subjectType: 'user', subjectId: 'usr_new', name: 'Dmitri Volkov' });
  assert.equal(before.status, 'clear');

  await pool.query(
    `INSERT INTO watchlist_entries (id, source, external_id, name, normalized_name, list_version)
     VALUES ('w9','ofac_sdn','w9','VOLKOV, Dmitri',$1,'test-v2')`, [normalize('VOLKOV, Dmitri')]);

  const after = await screen({ subjectType: 'user', subjectId: 'usr_new2', name: 'Dmitri Volkov' });
  assert.equal(after.status, 'potential_match', 'a newly listed name must be caught without a restart');
});

// ──────────────────────────────────────────── enforcement, end to end
//
// The gate is only worth anything if it actually stops an approval. These
// drive the real admin paths rather than the pure function, because the
// question is whether the control is WIRED, not whether the rule is right.

const { createApp } = await import('../src/server.js');
const { businessSignUp } = await import('../src/merchants/accounts.js');
const { setMerchantStatus, decideKyc } = await import('../src/admin/service.js');
const { reportDueBy, recommendAction, daysUntilDue, recordAction, reportingQueue,
        markEscalated, markReported, blockedPropertyReport } =
  await import('../src/compliance/sanctions-actions.js');

const staff = { id: 'stf_1', name: 'Reviewer', email: 'rev@gg.test', role: 'compliance' } as any;

test('a business whose name is on the list cannot be activated', async () => {
  await pool.query(
    `INSERT INTO watchlist_entries (id, source, external_id, name, normalized_name, program, list_version)
     VALUES ('w20','ofac_sdn','w20','ACME TRADING LIMITED',$1,'SDN','test-v3')
     ON CONFLICT DO NOTHING`, [normalize('ACME TRADING LIMITED')]);
  resetWatchlistCache();

  const su = await businessSignUp({
    business_name: 'Acme Trading Ltd', name: 'Someone Ordinary',
    email: `acme-${crypto.randomBytes(3).toString('hex')}@t.test`,
    password: 'correct horse battery staple', country: 'US', business_type: 'company',
  });

  // Signing up is allowed. Being approved is not.
  const check = await latestFor('merchant', su.merchant_id) as any;
  assert.ok(check, 'signup must leave a screening record');
  assert.equal(check.status, 'potential_match');

  await assert.rejects(
    () => setMerchantStatus(staff, su.merchant_id, 'active'),
    /sanctions match is waiting for review/);
});

test('suspending is never gated — a control must not stop you stopping a business', async () => {
  const su = await businessSignUp({
    business_name: 'Acme Trading Ltd', name: 'Someone Else',
    email: `acme2-${crypto.randomBytes(3).toString('hex')}@t.test`,
    password: 'correct horse battery staple', country: 'US', business_type: 'company',
  });
  const r = await setMerchantStatus(staff, su.merchant_id, 'suspended', 'Testing') as any;
  assert.equal(r.status, 'suspended');
});

test('a clean business activates normally', async () => {
  const su = await businessSignUp({
    business_name: 'Fieldnotes Coffee Co', name: 'Marguerite Okonjo',
    email: `fn-${crypto.randomBytes(3).toString('hex')}@t.test`,
    password: 'correct horse battery staple', country: 'US', business_type: 'company',
  });
  const r = await setMerchantStatus(staff, su.merchant_id, 'active') as any;
  assert.equal(r.status, 'active', 'screening must not block ordinary businesses');
});

test('once a reviewer clears the hit, activation goes through', async () => {
  const su = await businessSignUp({
    business_name: 'Acme Trading Ltd', name: 'Third Person',
    email: `acme3-${crypto.randomBytes(3).toString('hex')}@t.test`,
    password: 'correct horse battery staple', country: 'US', business_type: 'company',
  });
  const check = await latestFor('merchant', su.merchant_id) as any;
  await review(check.id, 'false_positive', 'stf_1',
    'Different company: incorporated in Delaware 2019, no connection to the listed entity.');
  const r = await setMerchantStatus(staff, su.merchant_id, 'active') as any;
  assert.equal(r.status, 'active');
});

test('an unscreened merchant cannot be activated at all', async () => {
  // The failure mode that matters: screening did not run, for any reason.
  await pool.query(
    `INSERT INTO merchants (id, name, email, status, webhook_secret, country, business_type)
     VALUES ('acct_unscreened','Ghost Co','ghost@t.test','pending_review','whsec_x','US','company')`);
  await assert.rejects(
    () => setMerchantStatus(staff, 'acct_unscreened', 'active'),
    /not been screened/);
});

// ───────────────────────────────────────────── the reporting clock
test('ten business days skips weekends', () => {
  // Fri 16 Oct 2026 → Fri 30 Oct. Two weekends, no federal holiday inside the
  // window, so this isolates the weekend skipping on its own.
  const due = reportDueBy(new Date('2026-10-16T12:00:00Z'));
  assert.equal(due.toISOString().slice(0, 10), '2026-10-30');
});

test('a holiday inside the window pushes the deadline out by a day', () => {
  // The same count from Thu 1 Oct lands on 16 Oct, not 15 Oct, because
  // Columbus Day (Mon 12 Oct) is not a business day. Getting this wrong makes
  // a filing one day late, which is indistinguishable from on time until
  // somebody checks.
  const due = reportDueBy(new Date('2026-10-01T12:00:00Z'));
  assert.equal(due.toISOString().slice(0, 10), '2026-10-16');
});

test('ten business days skips federal holidays too', () => {
  // From Mon 16 Nov 2026, Thanksgiving (26 Nov) falls inside the window, so
  // the deadline is pushed a day beyond the weekends-only answer.
  const due = reportDueBy(new Date('2026-11-16T12:00:00Z'));
  assert.equal(due.toISOString().slice(0, 10), '2026-12-01');
});

test('the action date itself does not count', () => {
  const due = reportDueBy(new Date('2026-10-01T23:59:00Z'), 1);
  assert.equal(due.toISOString().slice(0, 10), '2026-10-02');
});

test('the deadline refuses to be computed past the holiday table', () => {
  // Silently counting weekends only, once the table expires, is how a filing
  // becomes late without anybody noticing.
  assert.throws(() => reportDueBy(new Date('2099-01-01T00:00:00Z')), /holiday table/);
});

test('days until due goes negative when overdue', () => {
  assert.ok(daysUntilDue('2020-01-01') < 0);
  assert.ok(daysUntilDue(new Date(Date.now() + 5 * 86400000)) > 0);
});

// ──────────────────────────────────────── block versus reject
test('an OFAC SDN hit is a block, and says why', () => {
  const r = recommendAction({ source: 'ofac_sdn', program: 'SDGT' });
  assert.equal(r.action, 'blocked');
  assert.equal(r.certain, true);
  assert.match(r.why, /frozen and held, not returned/);
});

test('a PEP is not a block and is not treated as one', () => {
  const r = recommendAction({ source: 'eu', program: 'PEP' });
  assert.equal(r.action, 'rejected');
  assert.equal(r.certain, false, 'a PEP needs a human, not an automatic block');
});

test('a non-OFAC prohibition is a reject pending a human', () => {
  const r = recommendAction({ source: 'un', program: 'UN-LIST' });
  assert.equal(r.action, 'rejected');
  assert.equal(r.certain, false);
});

// ──────────────────────────────────────── who files, and the record
test('blocking money with nowhere to hold it is refused', async () => {
  await assert.rejects(
    () => recordAction({
      action: 'blocked', subjectType: 'user', subjectId: 'u1',
      nameMatched: 'Vladimir Ivanov', amount: 50_000, currency: 'usd',
      responsibility: 'self',
    }),
    /cannot be unblocked with interest later/);
});

test('an action records its deadline and who has to file', async () => {
  const a = await recordAction({
    action: 'rejected', subjectType: 'user', subjectId: 'u2',
    nameMatched: 'Vladimir Ivanov', amount: 25_000, currency: 'usd',
    counterparty: 'Some Bank', responsibility: 'processor',
  }) as any;
  assert.equal(a.responsibility, 'processor');
  assert.ok(a.report_due_by, 'every action carries a deadline');
});

test('an action we do not own cannot be marked as filed by us', async () => {
  const a = await recordAction({
    action: 'rejected', subjectType: 'user', subjectId: 'u3',
    nameMatched: 'Vladimir Ivanov', responsibility: 'processor',
  }) as any;
  await assert.rejects(() => markReported(a.id, 'OFAC-123', 'stf_1'), /processor's to file/);
  // Escalation is the right verb for it.
  const esc = await markEscalated(a.id, 'Stripe compliance', 'TICKET-9', 'stf_1') as any;
  assert.ok(esc.escalated_at);
});

test('an action we DO own cannot be escalated instead of filed', async () => {
  const a = await recordAction({
    action: 'rejected', subjectType: 'user', subjectId: 'u4',
    nameMatched: 'Vladimir Ivanov', responsibility: 'self',
  }) as any;
  await assert.rejects(() => markEscalated(a.id, 'Someone', 'X', 'stf_1'), /ours to file/);
  await assert.rejects(() => markReported(a.id, '', 'stf_1'), /reference/);
  const done = await markReported(a.id, 'OFAC-2026-0001', 'stf_1') as any;
  assert.equal(done.report_reference, 'OFAC-2026-0001');
});

test('the queue holds what is still owed, and flags what is overdue', async () => {
  const q = await reportingQueue();
  assert.ok(q.data.length > 0);
  for (const a of q.data) {
    assert.equal(typeof a.days_until_due, 'number');
    assert.equal(a.reported_at, null);
    assert.equal(a.escalated_at, null);
  }
});

test('the annual blocked-property report counts holds, not rejections', async () => {
  await recordAction({
    action: 'blocked', subjectType: 'user', subjectId: 'u5',
    nameMatched: 'Vladimir Ivanov', amount: 10_000, currency: 'usd',
    heldAccount: 'blocked:ofac:u5', responsibility: 'self',
  });
  const rep = await blockedPropertyReport();
  assert.ok((rep.count ?? 0) >= 1);
  assert.ok(rep.data.every((a: any) => a.action === 'blocked'), 'rejections hold nothing');
  assert.match(rep.due_by, /-09-30$/);
});

test.after(async () => { await pool.end(); });

// ───────────────────────────────────────────────────────── the legal pages
//
// A processor reviewing your application opens these URLs directly. A 404 on
// /privacy during underwriting is a delay measured in weeks.

test('every legal page serves on its own URL', async () => {
  const app = createApp();
  const srv = app.listen(0);
  await new Promise((r) => srv.once('listening', r));
  const base = `http://127.0.0.1:${(srv.address() as any).port}`;
  try {
    for (const p of ['/terms', '/privacy', '/merchant-agreement', '/acceptable-use']) {
      const r = await fetch(base + p);
      assert.equal(r.status, 200, `${p} must serve`);
      const html = await r.text();
      assert.match(html, /<article id="privacy"/, `${p} must carry the documents`);
    }
  } finally { srv.close(); }
});

test('the draft banner is present — these must not look binding yet', async () => {
  const app = createApp();
  const srv = app.listen(0);
  await new Promise((r) => srv.once('listening', r));
  const base = `http://127.0.0.1:${(srv.address() as any).port}`;
  try {
    const html = await (await fetch(base + '/terms')).text();
    assert.match(html, /Draft — not yet in force/);
    // The placeholders a lawyer and the owner still have to fill.
    assert.match(html, /\[LEGAL ENTITY NAME\]/);
    assert.match(html, /\[FOR COUNSEL\]/);
  } finally { srv.close(); }
});

test('the fee terms match what the code actually charges', async () => {
  // A merchant agreement that misstates the fee is a contract you lose.
  const app = createApp();
  const srv = app.listen(0);
  await new Promise((r) => srv.once('listening', r));
  const base = `http://127.0.0.1:${(srv.address() as any).port}`;
  try {
    const html = await (await fetch(base + '/merchant-agreement')).text();
    const { config } = await import('../src/config.js');
    const pct = (config.platformFeeBps / 100).toString();
    const cap = (config.platformFeeCapMonthly / 100).toFixed(0);
    assert.ok(html.includes(`${pct}% of processed volume`), `agreement must state ${pct}%`);
    assert.ok(html.includes(`$${cap} per calendar`), `agreement must state the $${cap} cap`);
    // And the refund behaviour, which the code does proportionally.
    assert.match(html, /returned to you\s*\n?\s*in proportion to the amount refunded/);
  } finally { srv.close(); }
});

// ─────────────────────────────────── a business can connect itself
//
// The question this answers: can someone who is not us sign up, get approved,
// and reach the point of taking payments without anyone touching a database?
// The OAuth flow existed in the API for a long time with no way in from the
// product, which is the same as not existing.

test('the connect API tells a business what it must do before it can take payments', async () => {
  const su = await businessSignUp({
    business_name: 'Harbour Books', name: 'Ada Okafor',
    email: `harbour-${crypto.randomBytes(3).toString('hex')}@t.test`,
    password: 'correct horse battery staple', country: 'US', business_type: 'company',
  });
  const { connectionStatus } = await import('../src/merchants/connect.js');
  const st = await connectionStatus(su.merchant_id) as any;

  // Every field the dashboard banner renders from must be present, or the
  // merchant sees an empty box where the instructions should be.
  assert.equal(typeof st.connected, 'boolean');
  assert.equal(st.connected, false, 'a new business starts unconnected');
  assert.equal(typeof st.required, 'boolean');
  assert.equal(st.country, 'US');
  assert.equal(st.country_supported, true, 'US must be servable or nobody can onboard');
  assert.ok(Array.isArray(st.available_providers));
  for (const p of st.available_providers) {
    assert.ok(p.name, 'each option needs a name to label its button');
    assert.match(p.connect_url_path, /^\/v1\/connect\/start\?provider=/);
  }
});

test('an unsupported country is reported rather than silently offering nothing', async () => {
  // A merchant in a country no processor serves must be told, not shown an
  // empty list and left to guess.
  const { connectionStatus } = await import('../src/merchants/connect.js');
  const id = 'acct_unsupported_' + crypto.randomBytes(3).toString('hex');
  await pool.query(
    `INSERT INTO merchants (id, name, email, status, webhook_secret, country, business_type)
     VALUES ($1,'Faraway Co',$2,'active','whsec_y','AQ','company')`, [id, id + '@t.test']);
  const st = await connectionStatus(id) as any;
  assert.equal(st.country_supported, false);
  assert.equal(st.available_providers.length, 0);
});

test('the dashboard actually renders the connect call to action', async () => {
  // The bug this guards: the whole OAuth flow existing in the API with no
  // button anywhere in the product.
  const app = createApp();
  const srv = app.listen(0);
  await new Promise((r) => srv.once('listening', r));
  const base = `http://127.0.0.1:${(srv.address() as any).port}`;
  try {
    const html = await (await fetch(base + '/dashboard')).text();
    assert.match(html, /id="connectPanel"/, 'the home banner must exist');
    assert.match(html, /id="connSettingsActions"/, 'settings must offer it too');
    assert.match(html, /loadConnection/, 'and something must populate them');
    assert.match(html, /\/v1\/connect\/start/, 'the button must reach the real endpoint');
  } finally { srv.close(); }
});
