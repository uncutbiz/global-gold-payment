/**
 * Every in-page link points at something that exists.
 *
 * The bug this catches: index.html carried two "Pricing" links to #pricing
 * while the pricing section had no id at all, so clicking Pricing silently did
 * nothing. Nothing failed, nothing logged, and the only way to find it was for
 * someone to click it. A dead anchor is invisible to every other kind of test,
 * so it gets its own.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';

const dir = path.join(process.cwd(), 'public');

/** Hrefs that are deliberately not navigation targets. */
const IGNORE = new Set(['#', '#!']);

describe('in-page links', () => {
  it('every href="#target" has a matching id in the same page', async () => {
    const pages = (await fs.readdir(dir)).filter((f) => f.endsWith('.html'));
    assert.ok(pages.length > 0, 'no pages found to check');

    const dead: string[] = [];
    for (const page of pages) {
      const html = await fs.readFile(path.join(dir, page), 'utf8');
      const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]!));
      /*
       * Route names of a hash-routed page. The admin panel resolves #overview,
       * #merchants and so on through its own hashchange router, and its logo
       * links to #overview without carrying data-nav, so the route NAMES are
       * collected and treated as valid targets rather than matching on the
       * attribute alone.
       */
      const routes = new Set([...html.matchAll(/\bdata-nav="([^"]+)"/g)].map((m) => m[1]!));

      /*
       * Match the whole <a> tag, because a hash is not always an anchor: the
       * admin panel is a hash-routed app whose nav links carry data-nav and
       * are resolved by its own router, not by scrolling to an element. Those
       * are skipped; a plain anchor must still land somewhere.
       */
      for (const m of html.matchAll(/<a\b([^>]*)\bhref="(#[^"]*)"([^>]*)>/g)) {
        const tag = `${m[1]}${m[3]}`;
        const href = m[2]!;
        if (IGNORE.has(href)) continue;
        if (/\bdata-nav=/.test(tag)) continue;        // router link, not an anchor
        const target = href.slice(1);
        if (!target) continue;
        if (routes.has(target)) continue;             // a route this page's router owns
        if (!ids.has(target)) dead.push(`${page}: href="${href}" has no element with id="${target}"`);
      }
    }
    assert.deepEqual(dead, [], `dead in-page links:\n  ${dead.join('\n  ')}`);
  });

  it('the pricing link specifically resolves', async () => {
    // Named explicitly because this is the one that shipped broken.
    const html = await fs.readFile(path.join(dir, 'index.html'), 'utf8');
    assert.ok(/href="#pricing"/.test(html), 'the Pricing link should still be there');
    assert.ok(/\bid="pricing"/.test(html), 'and it must have somewhere to land');
  });
});
