/**
 * Telnyx as the SMS provider for password-reset codes.
 *
 * No database and no network: the provider takes its fetch by injection, so
 * every branch that matters can be exercised directly. What matters is the
 * failure paths — a reset code that silently fails to send locks a person out
 * of their account, and the only thing that makes that debuggable is the
 * provider reporting WHY rather than just "failed".
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

const { TelnyxSms, toE164, maskPhone } = await import('../src/notify/sms.js');

/** A fetch stub that records the call and replies with whatever is queued. */
function stub(reply: { status: number; body: unknown } | { throws: string }) {
  const calls: Array<{ url: string; init: any }> = [];
  const impl = (async (url: any, init: any) => {
    calls.push({ url: String(url), init });
    if ('throws' in reply) {
      const e: any = new Error(reply.throws); e.name = reply.throws; throw e;
    }
    return new Response(JSON.stringify(reply.body), {
      status: reply.status, headers: { 'content-type': 'application/json' },
    });
  }) as unknown as typeof fetch;
  return { impl, calls };
}

describe('sending through Telnyx', () => {
  it('posts the message and returns the Telnyx id', async () => {
    const s = stub({ status: 200, body: { data: { id: 'msg_abc123' } } });
    const p = new TelnyxSms({ apiKey: 'KEY123', from: '+15555550142', fetchImpl: s.impl });

    const r = await p.send('+15125551234', 'Your code is 123456');
    assert.equal(r.sent, true);
    assert.equal(r.id, 'msg_abc123');

    assert.equal(s.calls.length, 1);
    const call = s.calls[0]!;
    assert.equal(call.url, 'https://api.telnyx.com/v2/messages');
    assert.equal(call.init.method, 'POST');
    assert.equal(call.init.headers.Authorization, 'Bearer KEY123');
    const body = JSON.parse(call.init.body);
    assert.equal(body.to, '+15125551234');
    assert.equal(body.from, '+15555550142');
    assert.equal(body.text, 'Your code is 123456');
  });

  it('uses a messaging profile when no from-number is set', async () => {
    const s = stub({ status: 200, body: { data: { id: 'm1' } } });
    const p = new TelnyxSms({ apiKey: 'K', messagingProfileId: 'prof_1', fetchImpl: s.impl });
    await p.send('+15125551234', 'hi');
    const body = JSON.parse(s.calls[0]!.init.body);
    assert.equal(body.messaging_profile_id, 'prof_1');
    assert.equal(body.from, undefined);
  });

  it('passes through the reason Telnyx rejected it', async () => {
    // The real-world case: a number that was bought but never enabled for
    // messaging. "Send failed" would send someone hunting for hours.
    const s = stub({
      status: 422,
      body: { errors: [{ title: 'Invalid from', detail: 'The from number is not provisioned for messaging.' }] },
    });
    const p = new TelnyxSms({ apiKey: 'K', from: '+1555', fetchImpl: s.impl });
    const r = await p.send('+15125551234', 'hi');
    assert.equal(r.sent, false);
    assert.match(r.error!, /not provisioned for messaging/);
  });

  it('falls back to the title, then the status, when no detail is given', async () => {
    let r = await new TelnyxSms({ apiKey: 'K', from: '+1', fetchImpl: stub({ status: 400, body: { errors: [{ title: 'Bad request' }] } }).impl })
      .send('+1', 'x');
    assert.match(r.error!, /Bad request/);

    r = await new TelnyxSms({ apiKey: 'K', from: '+1', fetchImpl: stub({ status: 500, body: {} }).impl })
      .send('+1', 'x');
    assert.match(r.error!, /Telnyx returned 500/);
  });

  it('an unauthorized key is reported, not swallowed', async () => {
    const s = stub({ status: 401, body: { errors: [{ detail: 'Invalid API key.' }] } });
    const r = await new TelnyxSms({ apiKey: 'wrong', from: '+1', fetchImpl: s.impl }).send('+1', 'x');
    assert.equal(r.sent, false);
    assert.match(r.error!, /Invalid API key/);
  });

  it('a timeout says so rather than looking like a rejection', async () => {
    const s = stub({ throws: 'AbortError' });
    const r = await new TelnyxSms({ apiKey: 'K', from: '+1', fetchImpl: s.impl, timeoutMs: 5 }).send('+1', 'x');
    assert.equal(r.sent, false);
    assert.match(r.error!, /did not respond in time/);
  });

  it('a network failure is reported as unreachable', async () => {
    const s = stub({ throws: 'TypeError' });
    const r = await new TelnyxSms({ apiKey: 'K', from: '+1', fetchImpl: s.impl }).send('+1', 'x');
    assert.equal(r.sent, false);
    assert.match(r.error!, /Could not reach Telnyx/);
  });

  it('never puts the API key in the error it returns', async () => {
    const s = stub({ status: 401, body: { errors: [{ detail: 'Invalid API key.' }] } });
    const r = await new TelnyxSms({ apiKey: 'SUPERSECRETKEY', from: '+1', fetchImpl: s.impl }).send('+1', 'x');
    assert.ok(!JSON.stringify(r).includes('SUPERSECRETKEY'),
      'a provider error can be surfaced to a user; it must not carry the credential');
  });
});

describe('the phone number a code goes to', () => {
  it('normalises what people actually type', () => {
    assert.equal(toE164('(512) 555-1234'), '+15125551234');
    assert.equal(toE164('512-555-1234'), '+15125551234');
    assert.equal(toE164('+1 512 555 1234'), '+15125551234');
    assert.equal(toE164('00447700900123'), '+447700900123');
  });
  it('refuses something that is not a phone number', () => {
    assert.equal(toE164(''), null);
    assert.equal(toE164('12345'), null);
    assert.equal(toE164('not a phone'), null);
  });
  it('masks a number in logs and replies', () => {
    assert.equal(maskPhone('+15125551234'), '+15••••34');
  });
});
