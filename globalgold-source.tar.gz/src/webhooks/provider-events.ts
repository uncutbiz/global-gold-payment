/**
 * Turning a processor's webhook into something that happened here.
 *
 * Until now provider webhooks were verified, stored and then ignored — which
 * is fine for an audit trail and useless for a chargeback, because the money
 * has already moved by the time the event arrives and nothing was writing that
 * down.
 *
 * Square and Stripe describe the same event with different words and different
 * shapes, so each provider gets a small translator and everything below works
 * on one normalised form. Amounts are minor units on both, which is the one
 * mercy.
 *
 * Every handler here must be safe to run twice. Processors retry, events
 * arrive out of order, and a replay of the stored payload is the recovery path
 * when something fails — so "safe to repeat" is a requirement, not a nicety.
 */
import { upsertDispute, normaliseStatus, type IncomingDispute } from '../payments/disputes.js';

/** A date from either provider, or null if it is missing or nonsense. */
function when(v: unknown): Date | null {
  if (!v) return null;
  // Stripe sends seconds since the epoch; Square sends RFC 3339.
  const d = typeof v === 'number' ? new Date(v * 1000) : new Date(String(v));
  return Number.isNaN(d.getTime()) ? null : d;
}

function squareDispute(body: any): IncomingDispute | null {
  const d = body?.data?.object?.dispute;
  if (!d?.dispute_id && !d?.id) return null;
  return {
    provider: 'square',
    providerDisputeId: String(d.dispute_id ?? d.id),
    providerPaymentId: d.disputed_payment?.payment_id ?? null,
    amount: Number(d.amount_money?.amount ?? 0),
    currency: String(d.amount_money?.currency ?? 'USD').toLowerCase(),
    status: normaliseStatus('square', d.state),
    reason: d.reason ?? null,
    evidenceDueBy: when(d.due_at),
  };
}

function stripeDispute(body: any): IncomingDispute | null {
  const d = body?.data?.object;
  if (!d?.id) return null;
  return {
    provider: 'stripe',
    providerDisputeId: String(d.id),
    providerPaymentId: d.payment_intent ?? d.charge ?? null,
    amount: Number(d.amount ?? 0),
    currency: String(d.currency ?? 'usd').toLowerCase(),
    // Stripe reports the dispute fee as a negative balance transaction; the
    // fee amount, when present, is the one marked as such.
    fee: Math.abs(Number(
      (d.balance_transactions ?? []).find((b: any) => b.reporting_category === 'dispute')?.fee ?? 0)),
    status: normaliseStatus('stripe', d.status),
    reason: d.reason ?? null,
    evidenceDueBy: when(d.evidence_details?.due_by),
  };
}

/**
 * Dispatch one verified provider event.
 *
 * Returns what it did, so a caller replaying stored events can report rather
 * than guess. An event type nobody handles is not an error — both providers
 * send far more than this platform cares about, and treating the rest as
 * failures would bury the ones that matter.
 */
export async function handleProviderEvent(
  provider: string, type: string, body: any,
): Promise<{ handled: boolean; what?: string }> {
  const t = String(type).toLowerCase();

  // Square:  dispute.state.updated, dispute.created, dispute.evidence.added
  // Stripe:  charge.dispute.created, .updated, .closed, .funds_withdrawn, …
  if (t.includes('dispute')) {
    const incoming = provider === 'square' ? squareDispute(body) : stripeDispute(body);
    if (!incoming) return { handled: false };
    if (!incoming.amount || incoming.amount <= 0) return { handled: false };
    const d = await upsertDispute(incoming);
    return { handled: true, what: `dispute ${d.id} ${d.status}` };
  }

  return { handled: false };
}
