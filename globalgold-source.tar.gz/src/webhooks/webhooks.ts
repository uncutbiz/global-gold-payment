/**
 * Events + signed webhook delivery (transactional outbox pattern: the event row
 * is written in the same DB transaction as the state change, then delivered
 * asynchronously with retries).
 *
 * Signature header:  GlobalGold-Signature: t=<unix>,v1=<hex hmac-sha256(secret, `${t}.${body}`)>
 */
import crypto from 'node:crypto';
import type { PoolClient } from 'pg';
import { pool } from '../db.js';
import { newId } from '../util/common.js';

const MAX_ATTEMPTS = 8;

export async function emitEvent(c: PoolClient, merchantId: string, type: string, data: unknown): Promise<string> {
  const id = newId('evt');
  await c.query('INSERT INTO events (id, merchant_id, type, data) VALUES ($1,$2,$3,$4)', [id, merchantId, type, JSON.stringify(data)]);
  await c.query(
    `INSERT INTO webhook_deliveries (event_id, merchant_id, url)
     SELECT $1, id, webhook_url FROM merchants WHERE id = $2 AND webhook_url IS NOT NULL`,
    [id, merchantId]);
  return id;
}

export function sign(secret: string, body: string, t = Math.floor(Date.now() / 1000)): string {
  const v1 = crypto.createHmac('sha256', secret).update(`${t}.${body}`).digest('hex');
  return `t=${t},v1=${v1}`;
}

/** For merchants: verify a received webhook (tolerance in seconds). */
export function verify(secret: string, body: string, header: string, toleranceSec = 300): boolean {
  const parts = Object.fromEntries(header.split(',').map((kv) => kv.split('=') as [string, string]));
  const t = Number(parts.t);
  if (!t || Math.abs(Date.now() / 1000 - t) > toleranceSec) return false;
  const expected = sign(secret, body, t).split('v1=')[1];
  const got = parts.v1 ?? '';
  return got.length === expected.length && crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expected));
}

export async function deliverDue(limit = 20): Promise<number> {
  const client = await pool.connect();
  let jobs: any[];
  try {
    await client.query('BEGIN');
    const r = await client.query(
      `SELECT d.id, d.url, d.attempts, e.id AS event_id, e.type, e.data, e.created_at, m.webhook_secret
         FROM webhook_deliveries d
         JOIN events e ON e.id = d.event_id
         JOIN merchants m ON m.id = d.merchant_id
        WHERE d.status = 'pending' AND d.next_attempt_at <= now()
        ORDER BY d.next_attempt_at
        LIMIT $1
        FOR UPDATE OF d SKIP LOCKED`, [limit]);
    jobs = r.rows;
    // Lease the rows so parallel workers skip them while we deliver.
    if (jobs.length) {
      await client.query(
        `UPDATE webhook_deliveries SET next_attempt_at = now() + interval '2 minutes' WHERE id = ANY($1)`,
        [jobs.map((j) => j.id)]);
    }
    await client.query('COMMIT');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }

  await Promise.all(jobs.map(async (j) => {
    const body = JSON.stringify({ id: j.event_id, object: 'event', type: j.type, created: j.created_at, data: { object: j.data } });
    let error: string | null = null;
    try {
      const res = await fetch(j.url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'globalgold-signature': sign(j.webhook_secret, body) },
        body,
        signal: AbortSignal.timeout(10_000),
      });
      if (!res.ok) error = `HTTP ${res.status}`;
    } catch (e: any) {
      error = e?.message ?? String(e);
    }
    const attempts = j.attempts + 1;
    if (!error) {
      await pool.query(`UPDATE webhook_deliveries SET status='delivered', attempts=$2, last_error=NULL WHERE id=$1`, [j.id, attempts]);
    } else {
      const status = attempts >= MAX_ATTEMPTS ? 'failed' : 'pending';
      const backoffSec = Math.min(2 ** attempts * 30, 6 * 3600); // 1m, 2m, 4m ... capped at 6h
      await pool.query(
        `UPDATE webhook_deliveries SET status=$2, attempts=$3, last_error=$4, next_attempt_at = now() + make_interval(secs => $5) WHERE id=$1`,
        [j.id, status, attempts, error, backoffSec]);
    }
  }));
  return jobs.length;
}

export function startWebhookWorker(intervalMs = 2000): () => void {
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;
    running = true;
    try { await deliverDue(); } catch (e) { console.error('webhook worker', e); } finally { running = false; }
  }, intervalMs);
  return () => clearInterval(timer);
}
