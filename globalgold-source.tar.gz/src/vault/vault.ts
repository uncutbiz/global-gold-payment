/**
 * Card token vault.
 *
 * The ONLY module (besides the acquirer connector) allowed to see a full PAN.
 * Production: run as a separate service inside the PCI cardholder data environment,
 * encrypt with keys held in an HSM/KMS (envelope encryption), and never log PANs.
 * CVC is validated for format and then discarded. PCI DSS forbids storing it after authorization.
 */
import crypto from 'node:crypto';
import { config } from '../config.js';
import { Db, one } from '../db.js';
import { ApiError, cardBrand, luhnValid, newId } from '../util/common.js';

export interface CardInput {
  number: string;
  exp_month: number;
  exp_year: number;
  cvc: string;
}

export interface CardToken {
  id: string;
  brand: string;
  last4: string;
  bin: string;
  exp_month: number;
  exp_year: number;
  fingerprint: string;
}

export function fingerprint(pan: string): string {
  return crypto.createHmac('sha256', config.fingerprintKey).update(pan).digest('base64url').slice(0, 24);
}

export type TokenOwner = { merchantId: string } | { userId: string };

export async function tokenize(db: Db, owner: TokenOwner, card: CardInput): Promise<CardToken> {
  const pan = card.number.replace(/[\s-]/g, '');
  if (!luhnValid(pan)) throw new ApiError(402, 'invalid_number', 'The card number is not valid.');
  if (!/^\d{3,4}$/.test(card.cvc)) throw new ApiError(402, 'invalid_cvc', 'The security code is not valid.');
  const now = new Date();
  const year = card.exp_year < 100 ? 2000 + card.exp_year : card.exp_year;
  if (card.exp_month < 1 || card.exp_month > 12) throw new ApiError(402, 'invalid_expiry_month', 'The expiration month is not valid.');
  if (year < now.getUTCFullYear() || (year === now.getUTCFullYear() && card.exp_month < now.getUTCMonth() + 1)) {
    throw new ApiError(402, 'expired_card', 'The card has expired.');
  }

  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', config.vaultKey, iv);
  const id = newId('tok');
  cipher.setAAD(Buffer.from(id)); // bind ciphertext to its token id
  const ciphertext = Buffer.concat([cipher.update(pan, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();

  const row = await one<CardToken>(db,
    `INSERT INTO card_tokens (id, merchant_id, user_id, key_id, iv, ciphertext, auth_tag, fingerprint, brand, last4, bin, exp_month, exp_year)
     VALUES ($1,$2,$13,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
     RETURNING id, brand, last4, bin, exp_month, exp_year, fingerprint`,
    [id, 'merchantId' in owner ? owner.merchantId : null, config.vaultKeyId, iv, ciphertext, tag, fingerprint(pan), cardBrand(pan), pan.slice(-4), pan.slice(0, 6), card.exp_month, year, 'userId' in owner ? owner.userId : null]);
  return row!;
}

/** Internal only. Never expose via the API. */
export async function detokenize(db: Db, tokenId: string): Promise<{ pan: string; exp_month: number; exp_year: number }> {
  const row = await one<any>(db, 'SELECT * FROM card_tokens WHERE id = $1', [tokenId]);
  if (!row) throw new ApiError(404, 'token_not_found', 'Payment token not found.');
  if (row.key_id !== config.vaultKeyId) throw new Error(`vault key ${row.key_id} not loaded`);
  const decipher = crypto.createDecipheriv('aes-256-gcm', config.vaultKey, row.iv);
  decipher.setAAD(Buffer.from(row.id));
  decipher.setAuthTag(row.auth_tag);
  const pan = Buffer.concat([decipher.update(row.ciphertext), decipher.final()]).toString('utf8');
  return { pan, exp_month: row.exp_month, exp_year: row.exp_year };
}

export async function getToken(db: Db, tokenId: string, merchantId: string): Promise<CardToken | undefined> {
  return one<CardToken>(db,
    'SELECT id, brand, last4, bin, exp_month, exp_year, fingerprint FROM card_tokens WHERE id = $1 AND merchant_id = $2',
    [tokenId, merchantId]);
}

export async function getUserCard(db: Db, tokenId: string, userId: string): Promise<CardToken | undefined> {
  return one<CardToken>(db,
    'SELECT id, brand, last4, bin, exp_month, exp_year, fingerprint FROM card_tokens WHERE id = $1 AND user_id = $2 AND removed_at IS NULL',
    [tokenId, userId]);
}
