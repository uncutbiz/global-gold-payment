/**
 * Acquirer connector: turns payment operations into ISO 8583 messages and
 * sends them to the sponsor bank's processor over a Transport.
 *
 *   SimulatedNetwork: deterministic test issuer (default, for development)
 *   TcpTransport:     length-prefixed TCP/TLS link, the shape most host-to-host links use
 */
import net from 'node:net';
import tls from 'node:tls';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { CURRENCY_NUMERIC } from '../util/common.js';
import { decode, encode, IsoMessage, MTI, redact, RESPONSE_CODES } from './iso8583.js';

export interface Transport {
  send(raw: string): Promise<string>;
}

export interface AuthRequest {
  pan: string;
  exp_month: number;
  exp_year: number;
  amount: number;
  currency: string;
}

export interface NetworkResult {
  approved: boolean;
  responseCode: string;
  declineCode?: string;
  declineMessage?: string;
  authCode?: string;
  rrn: string;
}

let stanCounter = crypto.randomInt(1, 999999);
function nextStan(): string {
  stanCounter = (stanCounter % 999999) + 1;
  return String(stanCounter).padStart(6, '0');
}

function timeFields(d = new Date()) {
  const p = (n: number, l = 2) => String(n).padStart(l, '0');
  const MM = p(d.getUTCMonth() + 1), DD = p(d.getUTCDate());
  const hh = p(d.getUTCHours()), mm = p(d.getUTCMinutes()), ss = p(d.getUTCSeconds());
  return { 7: `${MM}${DD}${hh}${mm}${ss}`, 12: `${hh}${mm}${ss}`, 13: `${MM}${DD}` };
}

function makeRrn(): string {
  return crypto.randomBytes(6).toString('hex').toUpperCase(); // 12 chars
}

export class AcquirerConnector {
  constructor(private transport: Transport, private log: (m: IsoMessage, dir: '>>' | '<<') => void = () => {}) {}

  private async roundTrip(msg: IsoMessage): Promise<IsoMessage> {
    this.log(redact(msg), '>>');
    const res = decode(await this.transport.send(encode(msg)));
    this.log(redact(res), '<<');
    const expected = msg.mti.slice(0, 2) + String(Number(msg.mti[2]) + 1) + msg.mti[3];
    if (res.mti !== expected) throw new Error(`unexpected MTI ${res.mti}, wanted ${expected}`);
    if (res.fields[11] !== msg.fields[11]) throw new Error('STAN mismatch');
    return res;
  }

  private base(req: Pick<AuthRequest, 'pan' | 'exp_month' | 'exp_year' | 'amount' | 'currency'>, processingCode: string, rrn: string) {
    const cur = CURRENCY_NUMERIC[req.currency];
    if (!cur) throw new Error(`no ISO 4217 code for ${req.currency}`);
    return {
      2: req.pan,
      3: processingCode,
      4: String(req.amount),
      ...timeFields(),
      11: nextStan(),
      14: String(req.exp_year % 100).padStart(2, '0') + String(req.exp_month).padStart(2, '0'),
      22: '010',   // manual key entry / e-commerce
      25: '59',    // e-commerce
      37: rrn,
      41: config.terminalId,
      42: config.acceptorId,
      49: cur,
    };
  }

  private toResult(res: IsoMessage, rrn: string): NetworkResult {
    const rc = res.fields[39] ?? '96';
    const mapped = RESPONSE_CODES[rc] ?? { code: 'card_declined', message: 'The card was declined.' };
    return rc === '00'
      ? { approved: true, responseCode: rc, authCode: res.fields[38], rrn }
      : { approved: false, responseCode: rc, declineCode: mapped.code, declineMessage: mapped.message, rrn };
  }

  async authorize(req: AuthRequest): Promise<NetworkResult> {
    const rrn = makeRrn();
    const res = await this.roundTrip({ mti: MTI.AUTH_REQUEST, fields: this.base(req, '000000', rrn) });
    return this.toResult(res, rrn);
  }

  /** Reverse (void) a previous authorization. */
  async reverse(req: AuthRequest & { originalRrn: string }): Promise<NetworkResult> {
    const res = await this.roundTrip({ mti: MTI.REVERSAL_REQUEST, fields: this.base(req, '000000', req.originalRrn) });
    return this.toResult(res, req.originalRrn);
  }

  /** Online refund (processing code 20). Many processors take refunds via the clearing file instead. */
  async refund(req: AuthRequest): Promise<NetworkResult> {
    const rrn = makeRrn();
    const res = await this.roundTrip({ mti: MTI.FINANCIAL_REQUEST, fields: this.base(req, '200000', rrn) });
    return this.toResult(res, rrn);
  }

  // Capture in a dual-message system is NOT an online message: captured
  // authorizations are written to the daily clearing file (see settlement/).
}

// ---------------------------------------------------------------------------
// Simulated issuer. Test cards (any future expiry, any CVC):
//   4242 4242 4242 4242   approved
//   5555 5555 5555 4444   approved (Mastercard)
//   4000 0000 0000 0002   do_not_honor (05)
//   4000 0000 0000 9995   insufficient_funds (51)
//   4000 0000 0000 0069   expired_card (54)
//   4100 0000 0000 0019   suspected_fraud (59)
//   4000 0000 0000 0119   processing_error (96)
// Also: amounts ending in 51 cents decline with insufficient_funds.
// ---------------------------------------------------------------------------
const TEST_DECLINES: Record<string, string> = {
  '4000000000000002': '05',
  '4000000000009995': '51',
  '4000000000000069': '54',
  '4100000000000019': '59',
  '4000000000000119': '96',
};

export class SimulatedNetwork implements Transport {
  async send(raw: string): Promise<string> {
    const req = decode(raw);
    const f = req.fields;
    let rc = '00';
    if (req.mti === MTI.AUTH_REQUEST) {
      rc = TEST_DECLINES[f[2]] ?? (f[4].endsWith('51') ? '51' : '00');
    }
    const respMti = req.mti.slice(0, 2) + String(Number(req.mti[2]) + 1) + req.mti[3];
    const fields: Record<number, string> = {
      3: f[3], 4: f[4], 7: f[7], 11: f[11], 37: f[37], 39: rc, 41: f[41], 42: f[42], 49: f[49],
    };
    if (rc === '00' && req.mti === MTI.AUTH_REQUEST) fields[38] = crypto.randomBytes(3).toString('hex').toUpperCase();
    return encode({ mti: respMti, fields });
  }
}

/**
 * Host-to-host transport with a 2-byte big-endian length header.
 * Serialized request/response (one in-flight message). Production links
 * multiplex by STAN, keep persistent connections, send 0800 echo messages, and use mutual TLS.
 */
export class TcpTransport implements Transport {
  constructor(private opts: { host: string; port: number; tls?: tls.ConnectionOptions; timeoutMs?: number }) {}

  send(raw: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const payload = Buffer.from(raw, 'ascii');
      const header = Buffer.alloc(2);
      header.writeUInt16BE(payload.length);
      const sock: net.Socket = this.opts.tls
        ? tls.connect({ host: this.opts.host, port: this.opts.port, ...this.opts.tls })
        : net.connect({ host: this.opts.host, port: this.opts.port });
      let buf = Buffer.alloc(0);
      sock.setTimeout(this.opts.timeoutMs ?? 15000, () => { sock.destroy(); reject(new Error('acquirer timeout')); });
      sock.once(this.opts.tls ? 'secureConnect' : 'connect', () => sock.write(Buffer.concat([header, payload])));
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (buf.length >= 2 && buf.length >= 2 + buf.readUInt16BE(0)) {
          resolve(buf.subarray(2, 2 + buf.readUInt16BE(0)).toString('ascii'));
          sock.end();
        }
      });
      sock.on('error', reject);
    });
  }
}

export const connector = new AcquirerConnector(
  new SimulatedNetwork(),
  process.env.ISO_LOG === 'on' ? (m, dir) => console.log(`[iso8583] ${dir} ${m.mti}`, JSON.stringify(m.fields)) : undefined,
);
