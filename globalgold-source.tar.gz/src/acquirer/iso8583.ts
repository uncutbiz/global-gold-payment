/**
 * Minimal ISO 8583:1987 codec (ASCII encoding, primary bitmap only).
 *
 * Real processors each publish their own spec (field subsets, binary vs ASCII,
 * header formats, private-use fields 48/60-63). Treat this as the skeleton you
 * adapt to your sponsor processor's message specification.
 */

type FieldSpec = { name: string; type: 'n' | 'an' | 'ans'; len: number; variable?: 'LL' | 'LLL' };

export const FIELDS: Record<number, FieldSpec> = {
  2:  { name: 'pan', type: 'n', len: 19, variable: 'LL' },
  3:  { name: 'processing_code', type: 'n', len: 6 },
  4:  { name: 'amount', type: 'n', len: 12 },
  7:  { name: 'transmission_datetime', type: 'n', len: 10 },
  11: { name: 'stan', type: 'n', len: 6 },
  12: { name: 'local_time', type: 'n', len: 6 },
  13: { name: 'local_date', type: 'n', len: 4 },
  14: { name: 'expiry', type: 'n', len: 4 },
  22: { name: 'pos_entry_mode', type: 'n', len: 3 },
  25: { name: 'pos_condition_code', type: 'n', len: 2 },
  37: { name: 'rrn', type: 'an', len: 12 },
  38: { name: 'auth_id', type: 'an', len: 6 },
  39: { name: 'response_code', type: 'an', len: 2 },
  41: { name: 'terminal_id', type: 'ans', len: 8 },
  42: { name: 'acceptor_id', type: 'ans', len: 15 },
  49: { name: 'currency', type: 'n', len: 3 },
};

export const MTI = {
  AUTH_REQUEST: '0100', AUTH_RESPONSE: '0110',
  FINANCIAL_REQUEST: '0200', FINANCIAL_RESPONSE: '0210',
  REVERSAL_REQUEST: '0400', REVERSAL_RESPONSE: '0410',
} as const;

export type IsoMessage = { mti: string; fields: Record<number, string> };

function pad(spec: FieldSpec, value: string, field: number): string {
  if (spec.variable) {
    const lenDigits = spec.variable === 'LL' ? 2 : 3;
    if (value.length > spec.len) throw new Error(`field ${field} too long`);
    return String(value.length).padStart(lenDigits, '0') + value;
  }
  if (value.length > spec.len) throw new Error(`field ${field} too long`);
  return spec.type === 'n' ? value.padStart(spec.len, '0') : value.padEnd(spec.len, ' ');
}

export function encode(msg: IsoMessage): string {
  if (!/^\d{4}$/.test(msg.mti)) throw new Error('bad MTI');
  const nums = Object.keys(msg.fields).map(Number).sort((a, b) => a - b);
  let bitmap = 0n;
  let body = '';
  for (const n of nums) {
    const spec = FIELDS[n];
    if (!spec) throw new Error(`unsupported field ${n}`);
    if (n > 64 || n < 2) throw new Error(`field ${n} outside primary bitmap`);
    bitmap |= 1n << BigInt(64 - n);
    body += pad(spec, msg.fields[n], n);
  }
  return msg.mti + bitmap.toString(16).toUpperCase().padStart(16, '0') + body;
}

export function decode(raw: string): IsoMessage {
  const mti = raw.slice(0, 4);
  const bitmap = BigInt('0x' + raw.slice(4, 20));
  if (bitmap & (1n << 63n)) throw new Error('secondary bitmap not supported');
  let pos = 20;
  const fields: Record<number, string> = {};
  for (let n = 2; n <= 64; n++) {
    if (!(bitmap & (1n << BigInt(64 - n)))) continue;
    const spec = FIELDS[n];
    if (!spec) throw new Error(`unsupported field ${n} in message`);
    let len = spec.len;
    if (spec.variable) {
      const d = spec.variable === 'LL' ? 2 : 3;
      len = Number(raw.slice(pos, pos + d));
      pos += d;
    }
    const v = raw.slice(pos, pos + len);
    pos += len;
    fields[n] = spec.type === 'n' || spec.variable ? v : v.trimEnd();
  }
  if (pos !== raw.length) throw new Error('trailing bytes in message');
  return { mti, fields };
}

/** Copy of a message safe for logs: PAN masked (PCI DSS Req. 3.4). */
export function redact(msg: IsoMessage): IsoMessage {
  const f = { ...msg.fields };
  if (f[2]) f[2] = f[2].slice(0, 6) + '*'.repeat(f[2].length - 10) + f[2].slice(-4);
  return { mti: msg.mti, fields: f };
}

/** Common ISO 8583 response codes (field 39). */
export const RESPONSE_CODES: Record<string, { code: string; message: string }> = {
  '00': { code: 'approved', message: 'Approved' },
  '05': { code: 'do_not_honor', message: 'The card was declined.' },
  '14': { code: 'invalid_number', message: 'The card number is not valid.' },
  '51': { code: 'insufficient_funds', message: 'The card has insufficient funds.' },
  '54': { code: 'expired_card', message: 'The card has expired.' },
  '59': { code: 'suspected_fraud', message: 'The card was declined.' },
  '91': { code: 'issuer_unavailable', message: 'The card issuer could not be reached. Try again.' },
  '96': { code: 'processing_error', message: 'An error occurred while processing the card. Try again.' },
};
