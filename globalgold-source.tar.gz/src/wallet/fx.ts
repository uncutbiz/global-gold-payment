/**
 * Currencies, countries and foreign exchange for Global Gold wallets.
 *
 * SAMPLE RATES ONLY. In production, pull live mid-market rates from an FX
 * provider (and hedge the resulting position with your FX/banking partner).
 */
import type { PoolClient } from 'pg';
import { Db, one } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { postJournal } from '../ledger/ledger.js';

export const CURRENCIES: Record<string, { name: string; symbol: string; perUsd: number }> = {
  usd: { name: 'US dollar', symbol: '$', perUsd: 1 },
  eur: { name: 'Euro', symbol: '€', perUsd: 0.92 },
  gbp: { name: 'British pound', symbol: '£', perUsd: 0.78 },
  cad: { name: 'Canadian dollar', symbol: 'CA$', perUsd: 1.37 },
  aud: { name: 'Australian dollar', symbol: 'A$', perUsd: 1.52 },
  mxn: { name: 'Mexican peso', symbol: 'MX$', perUsd: 18.5 },
  brl: { name: 'Brazilian real', symbol: 'R$', perUsd: 5.5 },
  ngn: { name: 'Nigerian naira', symbol: '₦', perUsd: 1550 },
  ghs: { name: 'Ghanaian cedi', symbol: 'GH₵', perUsd: 15.5 },
  kes: { name: 'Kenyan shilling', symbol: 'KSh', perUsd: 129 },
  zar: { name: 'South African rand', symbol: 'R', perUsd: 18 },
  inr: { name: 'Indian rupee', symbol: '₹', perUsd: 84 },
  php: { name: 'Philippine peso', symbol: '₱', perUsd: 57 },
};

export const COUNTRIES: Record<string, { name: string; currency: string }> = {
  US: { name: 'United States', currency: 'usd' },
  GB: { name: 'United Kingdom', currency: 'gbp' },
  CA: { name: 'Canada', currency: 'cad' },
  AU: { name: 'Australia', currency: 'aud' },
  DE: { name: 'Germany', currency: 'eur' },
  FR: { name: 'France', currency: 'eur' },
  ES: { name: 'Spain', currency: 'eur' },
  IT: { name: 'Italy', currency: 'eur' },
  NL: { name: 'Netherlands', currency: 'eur' },
  IE: { name: 'Ireland', currency: 'eur' },
  MX: { name: 'Mexico', currency: 'mxn' },
  BR: { name: 'Brazil', currency: 'brl' },
  NG: { name: 'Nigeria', currency: 'ngn' },
  GH: { name: 'Ghana', currency: 'ghs' },
  KE: { name: 'Kenya', currency: 'kes' },
  ZA: { name: 'South Africa', currency: 'zar' },
  IN: { name: 'India', currency: 'inr' },
  PH: { name: 'Philippines', currency: 'php' },
};

/** Our margin on the mid-market rate for conversions. */
export const FX_SPREAD = 0.015;
const QUOTE_MINUTES = 10;

export const FX_POSITION = 'platform:fx_position';

export function assertCurrency(cur: string) {
  if (!CURRENCIES[cur]) throw new ApiError(400, 'currency_not_supported', `Currency ${cur.toUpperCase()} is not supported.`);
}

/** Customer rate: units of `to` per unit of `from`, after our spread. */
export function customerRate(from: string, to: string) {
  assertCurrency(from); assertCurrency(to);
  if (from === to) return { mid: 1, rate: 1 };
  const mid = CURRENCIES[to].perUsd / CURRENCIES[from].perUsd;
  return { mid, rate: mid * (1 - FX_SPREAD) };
}

export function convert(amountFrom: number, from: string, to: string) {
  const { mid, rate } = customerRate(from, to);
  const amountTo = Math.floor(amountFrom * rate + 1e-6);
  // What the customer would have received at the mid-market rate, minus what they get = our FX fee (in `to`).
  return { mid, rate, amountTo, fxFee: Math.floor(amountFrom * mid) - amountTo };
}

/** Smallest source amount that yields at least `amountTo` after conversion. */
export function sourceNeeded(amountTo: number, from: string, to: string) {
  const { rate } = customerRate(from, to);
  let src = Math.ceil(amountTo / rate);
  while (Math.floor(src * rate + 1e-6) < amountTo) src++;
  return src;
}

function assertConvertible(amountTo: number) {
  if (amountTo < 1) throw new ApiError(400, 'amount_too_small', 'This amount is too small to convert.');
}

export async function createQuote(db: Db, userId: string, from: string, to: string, amountFrom: number) {
  const c = convert(amountFrom, from, to);
  assertConvertible(c.amountTo);
  const q = await one(db,
    `INSERT INTO fx_quotes (id, user_id, from_currency, to_currency, amount_from, amount_to, rate, expires_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7, now() + make_interval(mins => $8)) RETURNING *`,
    [newId('qt'), userId, from, to, amountFrom, c.amountTo, c.rate, QUOTE_MINUTES]);
  return { ...q, mid_rate: c.mid, fx_fee: c.fxFee };
}

/** Uses a locked quote if given and still valid; otherwise converts at the current rate. */
export async function resolveConversion(c: PoolClient, userId: string, from: string, to: string, amountFrom: number, quoteId?: string) {
  if (!quoteId || from === to) {
    const conv = convert(amountFrom, from, to);
    assertConvertible(conv.amountTo);
    return { ...conv, quoteId: null as string | null };
  }
  const q = await one(c, 'SELECT * FROM fx_quotes WHERE id = $1 AND user_id = $2 FOR UPDATE', [quoteId, userId]);
  if (!q || q.used_at) throw new ApiError(400, 'quote_invalid', 'This quote is no longer valid. Get a new one.');
  if (new Date(q.expires_at) < new Date()) throw new ApiError(400, 'quote_expired', 'This quote has expired. Get a new one.');
  if (q.from_currency !== from || q.to_currency !== to || q.amount_from !== amountFrom) {
    throw new ApiError(400, 'quote_mismatch', 'The quote does not match this transfer.');
  }
  await c.query('UPDATE fx_quotes SET used_at = now() WHERE id = $1', [quoteId]);
  const mid = customerRate(from, to).mid;
  return { mid, rate: Number(q.rate), amountTo: q.amount_to, fxFee: Math.floor(amountFrom * mid) - q.amount_to, quoteId };
}

/**
 * Moves value between currencies through the platform FX position account.
 * Balances per currency within one journal (enforced by the database).
 */
export async function postCrossCurrency(
  c: PoolClient, ref: { type: string; id: string }, description: string,
  debit: { account: string; currency: string; amount: number },
  credits: { account: string; amount: number }[], creditCurrency: string,
) {
  if (debit.currency === creditCurrency) {
    await postJournal(c, debit.currency, ref, description, [
      { account: debit.account, debit: debit.amount },
      ...credits.map((x) => ({ account: x.account, credit: x.amount })),
    ]);
    return;
  }
  const total = credits.reduce((s, x) => s + x.amount, 0);
  // One journal id, two currencies: write the two legs through a shared journal.
  const jid = await postJournal(c, debit.currency, ref, description, [
    { account: debit.account, debit: debit.amount },
    { account: FX_POSITION, credit: debit.amount },
  ]);
  for (const line of [{ account: FX_POSITION, debit: total }, ...credits.filter((x) => x.amount > 0).map((x) => ({ account: x.account, credit: x.amount }))]) {
    await c.query('INSERT INTO ledger_lines (journal_id, account, currency, debit, credit) VALUES ($1,$2,$3,$4,$5)',
      [jid, line.account, creditCurrency, (line as any).debit ?? 0, (line as any).credit ?? 0]);
  }
}
