/**
 * Global Gold wallet (PayPal-style): consumer accounts that hold balances in
 * one or more currencies and move money nationally and internationally.
 *
 *   top up     card ──▶ wallet          Dr settlement_receivable / Cr wallet:<user>
 *   send       wallet ──▶ wallet        Dr wallet:<from> / Cr wallet:<to>   (via FX position if currencies differ)
 *   convert    wallet ccy A ──▶ ccy B   Dr wallet (A) / Cr fx_position (A); Dr fx_position (B) / Cr wallet (B)
 *   pay        wallet ──▶ merchant      Dr wallet / Cr merchant pending + fee revenue
 *   withdraw   wallet ──▶ bank          Dr wallet / Cr bank_cash
 *
 * Balances can never go negative: every debit locks the user row, re-reads the
 * ledger balance, and aborts if it is insufficient.
 */
import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import type { PoolClient } from 'pg';
import { Db, one, pool, tx } from '../db.js';
import { connector } from '../acquirer/connector.js';
import { acct, balance, postJournal } from '../ledger/ledger.js';
import { assessRisk } from '../payments/risk.js';
import { present, type Merchant } from '../payments/service.js';
import { ApiError, computeFee, newId, sha256 } from '../util/common.js';
import { checkPassword, dummyHash, hashPassword } from '../util/passwords.js';
import { CardInput, detokenize, getUserCard, tokenize } from '../vault/vault.js';
import { emitEvent } from '../webhooks/webhooks.js';
import { checkDeclinedTopUps, checkTransfer } from '../admin/monitoring.js';
import { assertKyc, latestKyc, UNVERIFIED_LIMITS_USD, type KycStatus } from './kyc.js';
import {
  assertCurrency, COUNTRIES, createQuote, CURRENCIES, customerRate, postCrossCurrency,
  resolveConversion, sourceNeeded,
} from './fx.js';

/** Limits are expressed in USD cents and converted to each currency. */
export const LIMITS_USD = { topUp: 2_000_00, send: 10_000_00, min: 1_00 };
const SESSION_HOURS = 12;

/**
 * Pricing (configurable). Same structure consumer wallets commonly use:
 * free domestic transfers, a percentage fee (with min/max) on international
 * transfers, plus a spread on currency conversion (see fx.ts).
 */
export const PRICING = {
  internationalPct: Number(process.env.INTL_FEE_PCT ?? 1),   // 1%
  internationalMinUsd: 99,                                    // $0.99
  internationalMaxUsd: 4_99,                                  // $4.99
};

export function transferFee(amount: number, currency: string, international: boolean) {
  if (!international) return 0;
  const pct = Math.round(amount * PRICING.internationalPct / 100);
  return Math.min(Math.max(pct, limitIn(currency, PRICING.internationalMinUsd)), limitIn(currency, PRICING.internationalMaxUsd));
}

export interface WalletUser { id: string; email: string; name: string; country: string; currency: string; kyc_status: KycStatus }

declare global {
  namespace Express { interface Request { user?: WalletUser } }
}

function limitIn(currency: string, usdCents: number) {
  return Math.round(usdCents * CURRENCIES[currency].perUsd);
}

export function fmt(amount: number, currency: string) {
  return `${CURRENCIES[currency]?.symbol ?? ''}${(amount / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency.toUpperCase()}`;
}

// ------------------------------------------------------------------ accounts
async function newSession(userId: string) {
  const token = 'ggs_' + crypto.randomBytes(32).toString('base64url');
  await pool.query(
    `INSERT INTO user_sessions (token_hash, user_id, expires_at) VALUES ($1,$2, now() + make_interval(hours => $3))`,
    [sha256(token), userId, SESSION_HOURS]);
  return token;
}

const USER_COLS = 'id, email, name, country, currency, kyc_status';

export async function signUp(input: { email: string; name: string; password: string; country: string }) {
  const country = COUNTRIES[input.country.toUpperCase()];
  if (!country) throw new ApiError(400, 'country_not_supported', 'Global Gold is not available in this country yet.');
  const email = input.email.trim().toLowerCase();
  const hash = await hashPassword(input.password);
  const user = await one<WalletUser>(pool,
    `INSERT INTO users (id, email, name, password_hash, country, currency) VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (email) DO NOTHING RETURNING ${USER_COLS}`,
    [newId('usr'), email, input.name.trim(), hash, input.country.toUpperCase(), country.currency]);
  if (!user) throw new ApiError(409, 'email_taken', 'An account with this email already exists. Sign in instead.');
  return { user, session: await newSession(user.id) };
}

export async function logIn(emailRaw: string, password: string) {
  const user = await one(pool, 'SELECT * FROM users WHERE email = $1', [emailRaw.trim().toLowerCase()]);
  const ok = await checkPassword(password, user?.password_hash ?? await dummyHash());
  if (!user || !ok) throw new ApiError(401, 'invalid_login', 'Email or password is incorrect.');
  if (user.status !== 'active') throw new ApiError(403, 'account_locked', 'This account is locked. Contact Global Gold support.');
  const { id, email, name, country, currency, kyc_status } = user;
  return { user: { id, email, name, country, currency, kyc_status } as WalletUser, session: await newSession(user.id) };
}

export async function logOut(token: string) {
  await pool.query('DELETE FROM user_sessions WHERE token_hash = $1', [sha256(token)]);
}

export async function requireUser(req: Request, _res: Response, next: NextFunction) {
  const h = req.header('authorization') ?? '';
  const token = h.startsWith('Bearer ggs_') ? h.slice(7) : undefined;
  if (!token) throw new ApiError(401, 'unauthorized', 'Sign in to your Global Gold wallet.');
  const u = await one(pool,
    `SELECT u.id, u.email, u.name, u.country, u.currency, u.kyc_status, u.status FROM user_sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = $1 AND s.expires_at > now()`, [sha256(token)]);
  if (!u) throw new ApiError(401, 'session_expired', 'Your session has expired. Sign in again.');
  if (u.status !== 'active') throw new ApiError(403, 'account_locked', 'This account is locked. Contact Global Gold support.');
  const { status, ...user } = u;
  req.user = user;
  next();
}

// ------------------------------------------------------------------ reads
async function balances(db: Db, userId: string, home: string) {
  const r = await db.query(
    `SELECT currency, (SUM(credit) - SUM(debit))::bigint AS amount FROM ledger_lines
      WHERE account = $1 GROUP BY currency`, [acct.wallet(userId)]);
  const map = new Map<string, number>(r.rows.map((x) => [x.currency, x.amount]));
  if (!map.has(home)) map.set(home, 0);
  return [...map].map(([currency, amount]) => ({ currency, amount }))
    .filter((b) => b.amount !== 0 || b.currency === home)
    .sort((a, b) => (a.currency === home ? -1 : b.currency === home ? 1 : a.currency.localeCompare(b.currency)));
}

export async function getWallet(user: WalletUser) {
  const [bals, cards, kyc] = await Promise.all([
    balances(pool, user.id, user.currency),
    pool.query(`SELECT id, brand, last4, exp_month, exp_year FROM card_tokens WHERE user_id = $1 AND removed_at IS NULL ORDER BY created_at`, [user.id]),
    latestKyc(user.id),
  ]);
  return {
    object: 'wallet',
    user: { ...user, country_name: COUNTRIES[user.country]?.name },
    home_currency: user.currency,
    balances: bals,
    cards: cards.rows,
    kyc: {
      status: user.kyc_status,
      rejection_reason: kyc?.status === 'rejected' ? kyc.review_note : null,
      submitted_at: kyc?.created_at ?? null,
    },
    limits: {
      top_up: limitIn(user.currency, user.kyc_status === 'approved' ? LIMITS_USD.topUp : UNVERIFIED_LIMITS_USD.topUp),
      send: limitIn(user.currency, user.kyc_status === 'approved' ? LIMITS_USD.send : UNVERIFIED_LIMITS_USD.sendDomestic),
      international: user.kyc_status === 'approved',
      withdrawals: user.kyc_status === 'approved',
      min: limitIn(user.currency, LIMITS_USD.min),
    },
  };
}

export async function getActivity(userId: string, limit = 50) {
  const r = await pool.query(
    `SELECT id, type, amount, currency, counter_amount, counter_currency, fx_rate, international,
            counterparty, note, status, failure_message, payment_intent_id, created_at
       FROM wallet_transactions WHERE user_id = $1 ORDER BY created_at DESC, id LIMIT $2`, [userId, limit]);
  return { object: 'list', data: r.rows.map((x) => ({ ...x, fx_rate: x.fx_rate == null ? null : Number(x.fx_rate) })) };
}

export function listSupported() {
  return {
    countries: Object.entries(COUNTRIES).map(([code, c]) => ({ code, ...c })),
    currencies: Object.entries(CURRENCIES).map(([code, c]) => ({ code, name: c.name, symbol: c.symbol })),
  };
}

/** Public lookup for "pay me" links: shows who you are paying before you send. */
export async function lookupRecipient(emailRaw: string) {
  const u = await one(pool, `SELECT name, country, currency FROM users WHERE email = $1 AND status = 'active'`, [emailRaw.trim().toLowerCase()]);
  if (!u) throw new ApiError(404, 'recipient_not_found', 'No Global Gold account uses this email.');
  return { name: u.name, country: u.country, country_name: COUNTRIES[u.country]?.name, currency: u.currency };
}

// ------------------------------------------------------------------ cards
export async function linkCard(userId: string, card: CardInput) {
  const t = await tokenize(pool, { userId }, card);
  return { id: t.id, brand: t.brand, last4: t.last4, exp_month: t.exp_month, exp_year: t.exp_year };
}

export async function unlinkCard(userId: string, cardId: string) {
  const r = await pool.query('UPDATE card_tokens SET removed_at = now() WHERE id = $1 AND user_id = $2 AND removed_at IS NULL', [cardId, userId]);
  if (!r.rowCount) throw new ApiError(404, 'resource_missing', 'Card not found.');
  return { id: cardId, deleted: true };
}

// ------------------------------------------------------------------ money movement
function checkAmount(amount: number, currency: string, maxUsd: number) {
  assertCurrency(currency);
  const min = limitIn(currency, LIMITS_USD.min), max = limitIn(currency, maxUsd);
  if (!Number.isInteger(amount) || amount < min) throw new ApiError(400, 'amount_too_small', `The minimum is ${fmt(min, currency)}.`);
  if (amount > max) throw new ApiError(400, 'amount_too_large', `The maximum is ${fmt(max, currency)}.`);
}

async function requireFunds(c: PoolClient, userId: string, amount: number, currency: string) {
  await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [userId]);
  const bal = await balance(c, acct.wallet(userId), currency);
  if (bal < amount) {
    throw new ApiError(402, 'insufficient_balance', `Your ${currency.toUpperCase()} balance (${fmt(bal, currency)}) is not enough. Add money or convert first.`);
  }
}

const walletBalance = (c: Db, userId: string, currency: string) => balance(c, acct.wallet(userId), currency);

export async function topUp(user: WalletUser, amount: number, cardId: string) {
  const currency = user.currency;
  checkAmount(amount, currency, LIMITS_USD.topUp);
  assertKyc(user, 'top_up', { amount, currency });
  const card = await getUserCard(pool, cardId, user.id);
  if (!card) throw new ApiError(400, 'invalid_card', 'Choose one of your linked cards.');
  const txId = newId('wtx');

  const fail = async (message: string): Promise<never> => {
    await pool.query(
      `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, status, failure_message, card_token_id, note)
       VALUES ($1,$2,'top_up',$3,$4,'failed',$5,$6,$7)`,
      [txId, user.id, amount, currency, message, cardId, `${card.brand} •••• ${card.last4}`]);
    await checkDeclinedTopUps(pool, user.id);
    throw new ApiError(402, 'card_declined', message);
  };

  const risk = await assessRisk(pool, { amount, maxAmount: limitIn(currency, LIMITS_USD.topUp), card });
  if (risk.action === 'block') return fail('This top-up was blocked by our risk checks.');

  const secret = await detokenize(pool, cardId);
  let result;
  try {
    result = await connector.authorize({ ...secret, amount, currency });
  } catch {
    return fail('The card network did not respond. Try again.');
  }
  if (!result.approved) return fail(result.declineMessage ?? 'The card was declined.');

  return tx(async (c) => {
    await postJournal(c, currency, { type: 'wallet_transaction', id: txId }, `top up ${txId}`, [
      { account: acct.receivable, debit: amount },
      { account: acct.wallet(user.id), credit: amount },
    ]);
    const row = await one(c,
      `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, card_token_id, network_ref, auth_code, note)
       VALUES ($1,$2,'top_up',$3,$4,$5,$6,$7,$8) RETURNING *`,
      [txId, user.id, amount, currency, cardId, result.rrn, result.authCode, `${card.brand} •••• ${card.last4}`]);
    return { ...row, balance: await walletBalance(c, user.id, currency) };
  });
}

async function findRecipient(from: WalletUser, toEmailRaw: string) {
  const toEmail = toEmailRaw.trim().toLowerCase();
  if (toEmail === from.email) throw new ApiError(400, 'invalid_recipient', 'You cannot send money to yourself.');
  const to = await one<WalletUser>(pool, `SELECT ${USER_COLS} FROM users WHERE email = $1 AND status = 'active'`, [toEmail]);
  if (!to) throw new ApiError(404, 'recipient_not_found', `No Global Gold account uses ${toEmail}. Ask them to sign up first.`);
  return to;
}

/** Shows exactly what the recipient gets. The rate is locked for 10 minutes. */
export async function quoteTransfer(from: WalletUser, input: { to: string; amount: number; currency?: string }) {
  const to = await findRecipient(from, input.to);
  const source = input.currency ?? from.currency;
  checkAmount(input.amount, source, LIMITS_USD.send);
  const international = from.country !== to.country;
  assertKyc(from, 'send', { amount: input.amount, currency: source, international });
  const q = await createQuote(pool, from.id, source, to.currency, input.amount);
  const fee = transferFee(input.amount, source, international);
  return {
    object: 'transfer_quote',
    quote: source === to.currency ? null : q.id,
    recipient: { name: to.name, country: to.country, country_name: COUNTRIES[to.country]?.name, currency: to.currency },
    send: { amount: input.amount, currency: source },
    receive: { amount: q.amount_to, currency: to.currency },
    rate: source === to.currency ? 1 : Number(q.rate),
    mid_market_rate: q.mid_rate,
    fx_fee: { amount: q.fx_fee, currency: to.currency },
    fee: { amount: fee, currency: source },
    total_debited: { amount: input.amount + fee, currency: source },
    international,
    expires_at: source === to.currency ? null : q.expires_at,
  };
}

export async function sendMoney(from: WalletUser, input: { to: string; amount: number; currency?: string; note?: string; quote?: string }) {
  const to = await findRecipient(from, input.to);
  const source = input.currency ?? from.currency;
  checkAmount(input.amount, source, LIMITS_USD.send);
  const international = from.country !== to.country;
  assertKyc(from, 'send', { amount: input.amount, currency: source, international });

  return tx(async (c) => {
    // Lock both users in a fixed order to avoid deadlocks.
    for (const id of [from.id, to.id].sort()) await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [id]);
    const fee = transferFee(input.amount, source, international);
    await requireFunds(c, from.id, input.amount + fee, source);
    const conv = await resolveConversion(c, from.id, source, to.currency, input.amount, input.quote);
    const outId = newId('wtx'), inId = newId('wtx');
    if (fee > 0) {
      await postJournal(c, source, { type: 'wallet_transaction', id: outId }, `international transfer fee ${outId}`, [
        { account: acct.wallet(from.id), debit: fee },
        { account: acct.fees, credit: fee },
      ]);
    }
    await postCrossCurrency(c, { type: 'wallet_transaction', id: outId }, `transfer ${from.id} -> ${to.id}`,
      { account: acct.wallet(from.id), currency: source, amount: input.amount },
      [{ account: acct.wallet(to.id), amount: conv.amountTo }], to.currency);
    const fx = source === to.currency ? [null, null, null] : [conv.amountTo, to.currency, conv.rate];
    const out = await one(c,
      `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, note, counter_amount, counter_currency, fx_rate, international, fee)
       VALUES ($1,$2,'transfer_out',$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [outId, from.id, -(input.amount + fee), source, `${to.name} · ${COUNTRIES[to.country]?.name ?? to.country}`, input.note ?? null, ...fx, international, fee]);
    await c.query(
      `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, note, counter_amount, counter_currency, fx_rate, international)
       VALUES ($1,$2,'transfer_in',$3,$4,$5,$6,$7,$8,$9,$10)`,
      [inId, to.id, conv.amountTo, to.currency, `${from.name} · ${COUNTRIES[from.country]?.name ?? from.country}`, input.note ?? null,
       ...(source === to.currency ? [null, null, null] : [-input.amount, source, conv.rate]), international]);
    await checkTransfer(c, { txId: outId, userId: from.id, amount: input.amount, currency: source, international, recipientName: to.name });
    return {
      ...out,
      fx_rate: out.fx_rate == null ? null : Number(out.fx_rate),
      recipient_received: { amount: conv.amountTo, currency: to.currency },
      balance: await walletBalance(c, from.id, source),
    };
  });
}

export async function convertBalance(user: WalletUser, input: { from: string; to: string; amount: number; quote?: string }) {
  if (input.from === input.to) throw new ApiError(400, 'invalid_conversion', 'Choose two different currencies.');
  checkAmount(input.amount, input.from, LIMITS_USD.send);
  assertCurrency(input.to);
  return tx(async (c) => {
    await requireFunds(c, user.id, input.amount, input.from);
    const conv = await resolveConversion(c, user.id, input.from, input.to, input.amount, input.quote);
    const outId = newId('wtx');
    await postCrossCurrency(c, { type: 'wallet_transaction', id: outId }, `conversion ${user.id}`,
      { account: acct.wallet(user.id), currency: input.from, amount: input.amount },
      [{ account: acct.wallet(user.id), amount: conv.amountTo }], input.to);
    await c.query(
      `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, counter_amount, counter_currency, fx_rate)
       VALUES ($1,$2,'conversion_out',$3,$4,'Currency conversion',$5,$6,$7), ($8,$2,'conversion_in',$5,$6,'Currency conversion',$3,$4,$7)`,
      [outId, user.id, -input.amount, input.from, conv.amountTo, input.to, conv.rate, newId('wtx')]);
    return { object: 'conversion', from: { amount: input.amount, currency: input.from }, to: { amount: conv.amountTo, currency: input.to }, rate: conv.rate };
  });
}

export async function quoteConversion(user: WalletUser, from: string, to: string, amount: number) {
  checkAmount(amount, from, LIMITS_USD.send);
  const q = await createQuote(pool, user.id, from, to, amount);
  return { object: 'conversion_quote', quote: q.id, from: { amount, currency: from }, to: { amount: q.amount_to, currency: to },
           rate: Number(q.rate), mid_market_rate: q.mid_rate, expires_at: q.expires_at };
}

export async function withdraw(user: WalletUser, amount: number, currency?: string) {
  const cur = currency ?? user.currency;
  checkAmount(amount, cur, LIMITS_USD.send);
  assertKyc(user, 'withdraw');
  return tx(async (c) => {
    await requireFunds(c, user.id, amount, cur);
    const id = newId('wtx');
    await postJournal(c, cur, { type: 'wallet_transaction', id }, `withdrawal ${id}`, [
      { account: acct.wallet(user.id), debit: amount },
      { account: acct.bankCash, credit: amount },
    ]);
    const bankName = `Bank account · ${COUNTRIES[user.country]?.name ?? user.country}`;
    const row = await one(c,
      `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, note)
       VALUES ($1,$2,'withdrawal',$3,$4,$5,'Arrives in 1–3 business days') RETURNING *`,
      [id, user.id, -amount, cur, bankName]);
    return { ...row, balance: await walletBalance(c, user.id, cur) };
  });
}

/** Shows how a wallet user would pay a merchant (same currency or converted). */
export async function walletPaymentPreview(user: WalletUser, pi: { amount: number; currency: string }) {
  const direct = await walletBalance(pool, user.id, pi.currency);
  if (direct >= pi.amount) return { pay_from: { amount: pi.amount, currency: pi.currency }, converted: false };
  if (user.currency === pi.currency) return { pay_from: { amount: pi.amount, currency: pi.currency }, converted: false, insufficient: true };
  const need = sourceNeeded(pi.amount, user.currency, pi.currency);
  const have = await walletBalance(pool, user.id, user.currency);
  return { pay_from: { amount: need, currency: user.currency }, converted: true, rate: customerRate(user.currency, pi.currency).rate, insufficient: have < need };
}

/** "Pay with Global Gold" at a merchant checkout. No card network involved. */
export async function payWithWallet(user: WalletUser, paymentIntentId: string) {
  return tx(async (c) => {
    const pi = await one(c, 'SELECT * FROM payment_intents WHERE id = $1 FOR UPDATE', [paymentIntentId]);
    if (!pi) throw new ApiError(404, 'resource_missing', 'Payment not found.');
    if (pi.status !== 'requires_payment_method') {
      throw new ApiError(400, 'payment_intent_unexpected_state', `This payment is ${pi.status.replace(/_/g, ' ')}.`);
    }
    const m = await one<Merchant>(c, 'SELECT * FROM merchants WHERE id = $1', [pi.merchant_id]);
    if (!m || m.status !== 'active') throw new ApiError(403, 'account_inactive', 'This merchant cannot accept payments.');

    await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [user.id]);
    // Pay from a balance in the merchant's currency if there is enough; otherwise convert from the home currency.
    let source = pi.currency, sourceAmount = pi.amount;
    if ((await walletBalance(c, user.id, pi.currency)) < pi.amount && user.currency !== pi.currency) {
      source = user.currency;
      sourceAmount = sourceNeeded(pi.amount, source, pi.currency);
    }
    await requireFunds(c, user.id, sourceAmount, source);

    // Wallet payments are captured immediately, whatever the intent's capture_method.
    const fee = computeFee(pi.amount, m.fee_bps, m.fee_fixed);
    await postCrossCurrency(c, { type: 'payment_intent', id: pi.id }, `wallet payment ${pi.id}`,
      { account: acct.wallet(user.id), currency: source, amount: sourceAmount },
      [
        { account: acct.pending(m.id), amount: pi.amount - fee },
        { account: acct.fees, amount: fee },
      ], pi.currency);
    const row = await one(c,
      `UPDATE payment_intents SET status='succeeded', wallet_user_id=$2, amount_captured=amount, fee=$3,
              decline_code=NULL, decline_message=NULL, updated_at=now()
        WHERE id=$1 RETURNING *`, [pi.id, user.id, fee]);
    const converted = source !== pi.currency;
    await c.query(
      `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, note, payment_intent_id,
                                        counter_amount, counter_currency, fx_rate)
       VALUES ($1,$2,'payment',$3,$4,$5,$6,$7,$8,$9,$10)`,
      [newId('wtx'), user.id, -sourceAmount, source, m.name, pi.description, pi.id,
       converted ? pi.amount : null, converted ? pi.currency : null, converted ? customerRate(source, pi.currency).rate : null]);
    const out = present(row);
    await emitEvent(c, m.id, 'payment_intent.succeeded', out);
    return { ...out, paid_from: { amount: sourceAmount, currency: source }, balance: await walletBalance(c, user.id, source) };
  });
}
