/**
 * Know Your Customer (identity verification) for wallet users.
 *
 * Tiers (USD equivalents, configurable):
 *   unverified / pending / rejected: add money up to $500 at a time, send up to $250
 *       within their own country, receive money, pay merchants. No international
 *       transfers and no withdrawals.
 *   approved: full limits.
 *
 * Production: use an identity-verification provider for document authenticity,
 * liveness/selfie matching and sanctions/PEP screening, and store documents in
 * encrypted object storage with a retention policy.
 */
import crypto from 'node:crypto';
import { config } from '../config.js';
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { raiseAlert } from '../admin/monitoring.js';
import { COUNTRIES, CURRENCIES } from './fx.js';

export type KycStatus = 'unverified' | 'pending' | 'approved' | 'rejected';

export const UNVERIFIED_LIMITS_USD = { topUp: 500_00, sendDomestic: 250_00 };
const MAX_DOC_BYTES = 5 * 1024 * 1024;
const DOC_TYPES = ['image/jpeg', 'image/png', 'application/pdf'];

const usd = (amount: number, currency: string) => Math.round(amount / (CURRENCIES[currency]?.perUsd ?? 1));

export function assertKyc(
  user: { kyc_status: KycStatus },
  action: 'top_up' | 'send' | 'withdraw',
  opts: { amount?: number; currency?: string; international?: boolean } = {},
) {
  if (user.kyc_status === 'approved') return;
  const verify = user.kyc_status === 'pending'
    ? 'Your identity check is under review. This will unlock once it is approved.'
    : 'Verify your identity to unlock this.';
  if (action === 'withdraw') throw new ApiError(403, 'kyc_required', `Withdrawals need a verified account. ${verify}`);
  if (action === 'send' && opts.international) throw new ApiError(403, 'kyc_required', `International transfers need a verified account. ${verify}`);
  const amt = usd(opts.amount ?? 0, opts.currency ?? 'usd');
  if (action === 'send' && amt > UNVERIFIED_LIMITS_USD.sendDomestic) {
    throw new ApiError(403, 'kyc_required', `Unverified accounts can send up to $250 (USD equivalent) at a time. ${verify}`);
  }
  if (action === 'top_up' && amt > UNVERIFIED_LIMITS_USD.topUp) {
    throw new ApiError(403, 'kyc_required', `Unverified accounts can add up to $500 (USD equivalent) at a time. ${verify}`);
  }
}

function parseDataUrl(dataUrl: string) {
  const m = /^data:([\w/+.-]+);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) throw new ApiError(400, 'document_invalid', 'Upload a photo or scan of your ID (JPEG, PNG or PDF).');
  const [, mime, b64] = m;
  if (!DOC_TYPES.includes(mime)) throw new ApiError(400, 'document_invalid', 'The document must be a JPEG, PNG or PDF.');
  const bytes = Buffer.from(b64, 'base64');
  if (bytes.length > MAX_DOC_BYTES) throw new ApiError(400, 'document_too_large', 'The document must be 5 MB or smaller.');
  if (bytes.length < 100) throw new ApiError(400, 'document_invalid', 'The document looks empty. Try another file.');
  return { mime, bytes };
}

export async function submitKyc(userId: string, input: {
  legal_name: string; date_of_birth: string; address_line: string; city: string; postal_code: string;
  country: string; id_type: 'passport' | 'national_id' | 'drivers_license'; id_number: string; document: string;
}) {
  const country = input.country.toUpperCase();
  if (!COUNTRIES[country]) throw new ApiError(400, 'country_not_supported', 'This country is not supported.');
  const dob = new Date(input.date_of_birth + 'T00:00:00Z');
  if (Number.isNaN(dob.getTime())) throw new ApiError(400, 'date_invalid', 'Enter your date of birth as YYYY-MM-DD.');
  const age = (Date.now() - dob.getTime()) / (365.25 * 24 * 3600 * 1000);
  if (age < 18) throw new ApiError(400, 'age_requirement', 'You must be 18 or older to verify an account.');
  if (age > 120) throw new ApiError(400, 'date_invalid', 'Check your date of birth.');
  const idNumber = input.id_number.replace(/[\s-]/g, '').toUpperCase();
  if (!/^[A-Z0-9]{5,20}$/.test(idNumber)) throw new ApiError(400, 'id_number_invalid', 'Enter the ID number exactly as shown on the document.');
  const doc = parseDataUrl(input.document);
  const idHash = crypto.createHmac('sha256', config.fingerprintKey).update(`${country}:${input.id_type}:${idNumber}`).digest('hex');

  return tx(async (c) => {
    const u = await one(c, 'SELECT kyc_status FROM users WHERE id = $1 FOR UPDATE', [userId]);
    if (u.kyc_status === 'approved') throw new ApiError(400, 'kyc_already_approved', 'Your identity is already verified.');
    if (u.kyc_status === 'pending') throw new ApiError(400, 'kyc_pending', 'Your documents are already under review.');
    const id = newId('kyc');
    await c.query(
      `INSERT INTO kyc_submissions (id, user_id, legal_name, date_of_birth, address_line, city, postal_code, country,
                                    id_type, id_number_last4, id_number_hash, document, document_mime)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
      [id, userId, input.legal_name.trim(), input.date_of_birth, input.address_line.trim(), input.city.trim(), input.postal_code.trim(),
       country, input.id_type, idNumber.slice(-4), idHash, doc.bytes, doc.mime]);
    await c.query(`UPDATE users SET kyc_status = 'pending' WHERE id = $1`, [userId]);

    const dup = await c.query(
      `SELECT DISTINCT user_id FROM kyc_submissions WHERE id_number_hash = $1 AND user_id <> $2`, [idHash, userId]);
    if (dup.rowCount) {
      await raiseAlert(c, { severity: 'high', rule: 'duplicate_identity',
        message: `The same ID document was used by ${dup.rowCount} other account(s)`,
        subjectType: 'kyc_submission', subjectId: id, userId });
    }
    return { object: 'kyc_submission', id, status: 'pending' };
  });
}

export async function latestKyc(userId: string) {
  return one(pool,
    `SELECT id, status, review_note, created_at, reviewed_at FROM kyc_submissions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
    [userId]);
}
