/**
 * Double-entry ledger. Every money movement is a journal whose lines balance
 * per currency (enforced again in Postgres by a deferred constraint trigger).
 *
 * Accounts:
 *   platform:settlement_receivable  money owed to us by the sponsor bank for captured sales
 *   platform:fee_revenue            our processing fees
 *   platform:bank_cash              our settlement (FBO) account at the sponsor bank (debit-normal)
 *   wallet:<user id>                a Global Gold wallet user's balance (we owe it to them)
 *   merchant:<id>:pending           captured but not yet settled
 *   merchant:<id>:available         settled, eligible for payout
 */
import type { PoolClient } from 'pg';
import { Db } from '../db.js';
import { newId } from '../util/common.js';

export const acct = {
  receivable: 'platform:settlement_receivable',
  /**
   * Platform fees a processor owes us. When a merchant is on their own Square
   * or Stripe account the buyer's money never passes through us — the processor
   * settles it to the merchant and pays us our cut separately — so the only
   * thing on our books is what the processor owes us.
   */
  providerReceivable: 'platform:provider_fee_receivable',
  fees: 'platform:fee_revenue',
  bankCash: 'platform:bank_cash',
  pending: (m: string) => `merchant:${m}:pending`,
  available: (m: string) => `merchant:${m}:available`,
  wallet: (u: string) => `wallet:${u}`,
};

export interface Line { account: string; debit?: number; credit?: number }

export async function postJournal(
  c: PoolClient, currency: string, ref: { type: string; id: string }, description: string, lines: Line[],
): Promise<string> {
  const debits = lines.reduce((s, l) => s + (l.debit ?? 0), 0);
  const credits = lines.reduce((s, l) => s + (l.credit ?? 0), 0);
  if (debits !== credits) throw new Error(`unbalanced journal: ${debits} != ${credits}`);
  const id = newId('jnl');
  await c.query('INSERT INTO journals (id, ref_type, ref_id, description) VALUES ($1,$2,$3,$4)', [id, ref.type, ref.id, description]);
  for (const l of lines) {
    if (!(l.debit ?? 0) && !(l.credit ?? 0)) continue; // skip zero lines
    await c.query(
      'INSERT INTO ledger_lines (journal_id, account, currency, debit, credit) VALUES ($1,$2,$3,$4,$5)',
      [id, l.account, currency, l.debit ?? 0, l.credit ?? 0]);
  }
  return id;
}

/** Balance in the account's natural direction: credit-normal for merchant and revenue accounts. */
export async function balance(db: Db, account: string, currency: string, creditNormal = true): Promise<number> {
  const r = await db.query(
    'SELECT COALESCE(SUM(credit),0) - COALESCE(SUM(debit),0) AS bal FROM ledger_lines WHERE account = $1 AND currency = $2',
    [account, currency]);
  const bal = Number(r.rows[0].bal);
  return creditNormal ? bal : -bal;
}

/** Trial balance: total debits must equal total credits per currency. */
export async function trialBalance(db: Db) {
  const r = await db.query(
    'SELECT currency, SUM(debit)::bigint AS debits, SUM(credit)::bigint AS credits FROM ledger_lines GROUP BY currency ORDER BY currency');
  return r.rows as { currency: string; debits: number; credits: number }[];
}
