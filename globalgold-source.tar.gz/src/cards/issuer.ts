/**
 * Card issuing, behind an interface.
 *
 * READ THIS BEFORE PLANNING A LAUNCH. Nobody issues their own cards. A card
 * that works in a shop needs three things we do not have and cannot write:
 *
 *   1. An issuer-processor — Lithic, Marqeta, Stripe Issuing, Highnote — that
 *      holds the network connection and asks us to approve each authorization.
 *   2. A sponsor bank, which owns the BIN the card numbers come from and
 *      carries the regulatory relationship with Visa or Mastercard.
 *   3. A compliance programme underneath both: BSA/AML, OFAC screening,
 *      Regulation E dispute handling, and for a prepaid programme in the US,
 *      money transmission licensing or a bank's shelter from it.
 *
 * That is a months-long, money-and-lawyers exercise. What this file does is
 * everything on OUR side of that boundary, so the day a sponsor bank says yes,
 * adopting them is writing one class rather than rebuilding the product.
 *
 * The simulated issuer below makes cards that behave correctly in every way
 * except being real: it mints a Luhn-valid PAN in a test BIN range, and it
 * cannot be used anywhere outside this system. That is deliberate. A number
 * that looked plausible to a real network would be the sort of thing that
 * gets an account closed.
 */
import crypto from 'node:crypto';

export interface IssuedCardDetails {
  issuerCardId: string;
  pan: string;
  expMonth: number;
  expYear: number;
  cvc: string;
  brand: string;
}

export interface CreateCardRequest {
  userId: string;
  kind: 'virtual' | 'physical';
  currency: string;
}

export interface ShippingAddress {
  name: string; line1: string; line2?: string;
  city: string; region?: string; postalCode: string; country: string;
}

export interface CardIssuer {
  readonly name: string;
  /** Mint a card. A physical card is produced later; a virtual one exists at once. */
  createCard(req: CreateCardRequest): Promise<IssuedCardDetails>;
  /** Tell the issuer a card is frozen, cancelled, or live again. */
  setStatus(issuerCardId: string, status: 'active' | 'frozen' | 'canceled'): Promise<void>;
  /** Hand a physical card to production. Returns the issuer's order handle. */
  shipCard(issuerCardId: string, to: ShippingAddress): Promise<{ orderId: string }>;
}

/**
 * A Luhn-valid number in a range reserved for testing.
 *
 * 4000 00 is the well-known test prefix every processor recognises as
 * non-routable. Using it means a number from here can never be mistaken for a
 * live card, by us or by anyone who finds one in a log.
 */
function testPan(): string {
  const body = ('400000' + crypto.randomInt(1e9, 1e10 - 1).toString().padStart(9, '0')).slice(0, 15);
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    let d = Number(body[body.length - 1 - i]);
    if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return body + String((10 - (sum % 10)) % 10);
}

export class SimulatedIssuer implements CardIssuer {
  readonly name = 'simulated';

  async createCard(req: CreateCardRequest): Promise<IssuedCardDetails> {
    const now = new Date();
    return {
      issuerCardId: `icard_sim_${crypto.randomBytes(8).toString('hex')}`,
      pan: testPan(),
      expMonth: now.getUTCMonth() + 1,
      // Three years out, which is what most issuers do for a first card.
      expYear: now.getUTCFullYear() + 3,
      cvc: String(crypto.randomInt(0, 1000)).padStart(3, '0'),
      brand: 'visa',
    };
  }

  async setStatus(): Promise<void> {
    // A real issuer call. Nothing to do locally — our own status is the record
    // that decides authorizations, and it is already written by the caller.
  }

  async shipCard(): Promise<{ orderId: string }> {
    return { orderId: `cord_sim_${crypto.randomBytes(6).toString('hex')}` };
  }
}

let issuer: CardIssuer | null = null;

/**
 * The configured issuer. Only the simulated one exists today; a real one is
 * added here, and nothing above this line changes.
 */
export function cardIssuer(): CardIssuer {
  if (issuer) return issuer;
  const want = (process.env.CARD_ISSUER ?? 'simulated').toLowerCase();
  if (want !== 'simulated') {
    throw new Error(
      `CARD_ISSUER=${want} is not implemented. Issuing real cards needs an issuer-processor `
      + `and a sponsor bank; see the comment at the top of src/cards/issuer.ts.`);
  }
  issuer = new SimulatedIssuer();
  return issuer;
}
