/**
 * Issued cards: creating them, ordering a physical one, and the controls a
 * cardholder sets on their own spending.
 *
 * A card here is a way to spend a Global Gold wallet balance. It is not credit
 * and it is not a bank account: every authorization is checked against the
 * wallet's ledger balance, so a card cannot go overdrawn. That makes this a
 * prepaid programme, which matters — prepaid and debit sit under different
 * rules, and the one we are building is the simpler of the two.
 *
 * The authorization decision lives next door in authorize.ts. This file is
 * lifecycle only.
 */
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { tokenize, detokenize } from '../vault/vault.js';
import { cardIssuer, type ShippingAddress } from './issuer.js';

export interface CardholderUser { id: string; name: string; currency?: string }

/** What is safe to show. No PAN, ever, unless it is explicitly asked for. */
export function presentCard(c: any) {
  return {
    id: c.id,
    object: 'card',
    kind: c.kind,
    status: c.status,
    brand: c.brand,
    last4: c.last4,
    exp_month: c.exp_month,
    exp_year: c.exp_year,
    currency: c.currency,
    nickname: c.nickname,
    cardholder_name: c.cardholder_name ?? null,
    single_use: c.single_use,
    controls: {
      per_auth_limit: c.per_auth_limit === null ? null : Number(c.per_auth_limit),
      daily_limit: c.daily_limit === null ? null : Number(c.daily_limit),
      monthly_limit: c.monthly_limit === null ? null : Number(c.monthly_limit),
      allowed_mcc: c.allowed_mcc ?? null,
      blocked_mcc: c.blocked_mcc ?? null,
    },
    created_at: c.created_at,
  };
}

export interface CardControls {
  per_auth_limit?: number | null;
  daily_limit?: number | null;
  monthly_limit?: number | null;
  allowed_mcc?: string[] | null;
  blocked_mcc?: string[] | null;
}

/**
 * A virtual card, usable the moment it is made.
 *
 * The PAN goes straight into the vault and is never returned by this
 * function. Showing the number is a separate, deliberate call — see
 * revealCard — so a card's digits cannot end up in a list response that
 * somebody logs.
 */
export async function createVirtualCard(
  user: CardholderUser,
  input: { currency: string; nickname?: string; single_use?: boolean } & CardControls,
) {
  const details = await cardIssuer().createCard({
    userId: user.id, kind: 'virtual', currency: input.currency,
  });

  return tx(async (c) => {
    const token = await tokenize(c, { userId: user.id }, {
      number: details.pan, exp_month: details.expMonth,
      exp_year: details.expYear, cvc: details.cvc,
    });
    const row = await one(c,
      `INSERT INTO issued_cards
         (id, user_id, kind, status, vault_token_id, issuer, issuer_card_id, brand,
          last4, exp_month, exp_year, currency, nickname, single_use,
          per_auth_limit, daily_limit, monthly_limit, allowed_mcc, blocked_mcc, activated_at)
       VALUES ($1,$2,'virtual','active',$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17, now())
       RETURNING *`,
      [newId('card'), user.id, token.id, cardIssuer().name, details.issuerCardId, details.brand,
       token.last4, details.expMonth, details.expYear, input.currency.toLowerCase(),
       input.nickname ?? null, input.single_use ?? false,
       input.per_auth_limit ?? null, input.daily_limit ?? null, input.monthly_limit ?? null,
       input.allowed_mcc ?? null, input.blocked_mcc ?? null]);
    return presentCard(row);
  });
}

/**
 * Order a physical card.
 *
 * It arrives as `ordered` with no number at all. A real programme mints the
 * PAN at production time, and pretending otherwise would mean a card number
 * existing — and being spendable — weeks before anybody could hold it.
 */
export async function orderPhysicalCard(
  user: CardholderUser,
  input: { currency: string; nickname?: string; address: ShippingAddress } & CardControls,
) {
  const a = input.address;
  for (const [field, value] of [['name', a?.name], ['line1', a?.line1], ['city', a?.city],
                                ['postal code', a?.postalCode], ['country', a?.country]] as const) {
    if (!value || !String(value).trim()) {
      throw new ApiError(400, 'address_incomplete', `A delivery address needs a ${field}.`);
    }
  }

  return tx(async (c) => {
    const cardId = newId('card');
    const row = await one(c,
      `INSERT INTO issued_cards
         (id, user_id, kind, status, issuer, currency, nickname, single_use,
          per_auth_limit, daily_limit, monthly_limit, allowed_mcc, blocked_mcc)
       VALUES ($1,$2,'physical','ordered',$3,$4,$5,false,$6,$7,$8,$9,$10) RETURNING *`,
      [cardId, user.id, cardIssuer().name, input.currency.toLowerCase(), input.nickname ?? null,
       input.per_auth_limit ?? null, input.daily_limit ?? null, input.monthly_limit ?? null,
       input.allowed_mcc ?? null, input.blocked_mcc ?? null]);

    await c.query(
      `INSERT INTO card_orders (id, card_id, user_id, name, line1, line2, city, region, postal_code, country, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'ordered')`,
      [newId('cord'), cardId, user.id, a.name, a.line1, a.line2 ?? null,
       a.city, a.region ?? null, a.postalCode, a.country.toUpperCase()]);

    return presentCard(row);
  });
}

/**
 * Production has made the card: it now has a number, and can be activated.
 *
 * Split from ordering because in a real programme this is driven by the
 * issuer's webhook days later, not by the customer.
 */
export async function producePhysicalCard(cardId: string) {
  const card = await one(pool, `SELECT * FROM issued_cards WHERE id = $1`, [cardId]);
  if (!card) throw new ApiError(404, 'resource_missing', 'No such card.');
  if (card.kind !== 'physical') throw new ApiError(400, 'not_physical', 'Only a physical card is produced.');
  if (card.vault_token_id) throw new ApiError(409, 'already_produced', 'This card already has a number.');

  const details = await cardIssuer().createCard({
    userId: card.user_id, kind: 'physical', currency: card.currency,
  });
  return tx(async (c) => {
    const token = await tokenize(c, { userId: card.user_id }, {
      number: details.pan, exp_month: details.expMonth,
      exp_year: details.expYear, cvc: details.cvc,
    });
    const row = await one(c,
      `UPDATE issued_cards SET vault_token_id=$2, issuer_card_id=$3, brand=$4, last4=$5,
              exp_month=$6, exp_year=$7, status='shipped', updated_at=now()
        WHERE id=$1 RETURNING *`,
      [cardId, token.id, details.issuerCardId, details.brand, token.last4, details.expMonth, details.expYear]);
    await c.query(
      `UPDATE card_orders SET status='shipped', shipped_at=now(), carrier='simulated post', tracking=$2
        WHERE card_id=$1`,
      [cardId, `SIM${Math.floor(Math.random() * 1e9)}`]);
    return presentCard(row);
  });
}

/**
 * A physical card arrives dead and the cardholder activates it.
 *
 * This is not ceremony: a card that is live in transit is a card anyone who
 * opens the envelope can spend.
 */
export async function activateCard(user: CardholderUser, cardId: string) {
  const row = await one(pool,
    `UPDATE issued_cards SET status='active', activated_at=now(), updated_at=now()
      WHERE id=$1 AND user_id=$2 AND status='shipped' RETURNING *`,
    [cardId, user.id]);
  if (!row) {
    const exists = await one(pool, `SELECT status FROM issued_cards WHERE id=$1 AND user_id=$2`, [cardId, user.id]);
    if (!exists) throw new ApiError(404, 'resource_missing', 'No such card.');
    throw new ApiError(400, 'cannot_activate', `A card that is ${exists.status} cannot be activated.`);
  }
  return presentCard(row);
}

/** Freeze, unfreeze, or cancel. Cancelling is final. */
export async function setCardStatus(user: CardholderUser, cardId: string, want: 'active' | 'frozen' | 'canceled') {
  const card = await one(pool, `SELECT * FROM issued_cards WHERE id=$1 AND user_id=$2`, [cardId, user.id]);
  if (!card) throw new ApiError(404, 'resource_missing', 'No such card.');
  if (card.status === 'canceled') {
    throw new ApiError(400, 'card_canceled', 'This card was cancelled and cannot be changed.');
  }
  if (want === 'active' && card.status === 'ordered') {
    throw new ApiError(400, 'not_yet_issued', 'This card has not been made yet.');
  }
  await cardIssuer().setStatus(card.issuer_card_id ?? '', want);
  const row = await one(pool,
    `UPDATE issued_cards SET status=$2, canceled_at = CASE WHEN $2='canceled' THEN now() ELSE canceled_at END,
            updated_at=now() WHERE id=$1 RETURNING *`,
    [cardId, want]);
  return presentCard(row);
}

/** Change the spend rules on a card. Only the fields sent are touched. */
export async function setCardControls(user: CardholderUser, cardId: string, controls: CardControls) {
  const card = await one(pool, `SELECT * FROM issued_cards WHERE id=$1 AND user_id=$2`, [cardId, user.id]);
  if (!card) throw new ApiError(404, 'resource_missing', 'No such card.');
  for (const k of ['per_auth_limit', 'daily_limit', 'monthly_limit'] as const) {
    const v = controls[k];
    if (v !== undefined && v !== null && (!Number.isInteger(v) || v < 0)) {
      throw new ApiError(400, 'parameter_invalid', `${k} must be a whole number of minor units, or null for no limit.`);
    }
  }
  const row = await one(pool,
    `UPDATE issued_cards SET
       per_auth_limit = CASE WHEN $3 THEN $4 ELSE per_auth_limit END,
       daily_limit    = CASE WHEN $5 THEN $6 ELSE daily_limit END,
       monthly_limit  = CASE WHEN $7 THEN $8 ELSE monthly_limit END,
       allowed_mcc    = CASE WHEN $9 THEN $10 ELSE allowed_mcc END,
       blocked_mcc    = CASE WHEN $11 THEN $12 ELSE blocked_mcc END,
       updated_at = now()
     WHERE id=$1 AND user_id=$2 RETURNING *`,
    [cardId, user.id,
     controls.per_auth_limit !== undefined, controls.per_auth_limit ?? null,
     controls.daily_limit !== undefined, controls.daily_limit ?? null,
     controls.monthly_limit !== undefined, controls.monthly_limit ?? null,
     controls.allowed_mcc !== undefined, controls.allowed_mcc ?? null,
     controls.blocked_mcc !== undefined, controls.blocked_mcc ?? null]);
  return presentCard(row);
}

export async function listCards(user: CardholderUser) {
  const r = await pool.query(
    `SELECT * FROM issued_cards WHERE user_id=$1 ORDER BY created_at DESC`, [user.id]);
  return r.rows.map(presentCard);
}

/**
 * Show the number.
 *
 * Its own endpoint rather than a field on the card, because this is the one
 * call that hands back a PAN and it should be obvious in an access log that
 * somebody asked for it. A cancelled card never reveals — there is no honest
 * reason to need the digits of a dead card.
 */
export async function revealCard(user: CardholderUser, cardId: string) {
  const card = await one(pool, `SELECT * FROM issued_cards WHERE id=$1 AND user_id=$2`, [cardId, user.id]);
  if (!card) throw new ApiError(404, 'resource_missing', 'No such card.');
  if (!card.vault_token_id) throw new ApiError(400, 'not_yet_issued', 'This card has not been made yet.');
  if (card.status === 'canceled') throw new ApiError(400, 'card_canceled', 'This card was cancelled.');
  const pan = await detokenize(pool, card.vault_token_id);
  return {
    id: card.id,
    number: pan.pan,
    exp_month: pan.exp_month,
    exp_year: pan.exp_year,
    brand: card.brand,
  };
}

export async function cardOrder(user: CardholderUser, cardId: string) {
  const r = await one(pool,
    `SELECT * FROM card_orders WHERE card_id=$1 AND user_id=$2`, [cardId, user.id]);
  if (!r) throw new ApiError(404, 'resource_missing', 'No delivery for this card.');
  return {
    object: 'card_order', id: r.id, card: r.card_id, status: r.status,
    to: { name: r.name, line1: r.line1, line2: r.line2, city: r.city,
          region: r.region, postal_code: r.postal_code, country: r.country },
    carrier: r.carrier, tracking: r.tracking,
    created_at: r.created_at, shipped_at: r.shipped_at, delivered_at: r.delivered_at,
  };
}

// ══════════════════════════════════════════════════ business cards
/**
 * A card a business gives an employee, spending the business's own settled
 * balance.
 *
 * The same engine as a customer card. What differs is whose money it draws on
 * and one hard precondition, below.
 */
export interface CardMerchant { id: string; name: string; status: string }

/**
 * Refuse to issue a card that could never work.
 *
 * A business card spends `merchant:<id>:available` — money we hold. That only
 * exists where we are the acquirer. A merchant on their own connected Square
 * or Stripe account is settled to directly by the processor, so we hold
 * nothing of theirs and a card would decline every single payment for
 * insufficient funds.
 *
 * Saying so at creation is the whole point. A card that exists and always
 * declines is worse than no card: the merchant hands it to an employee, the
 * employee is embarrassed at a till, and nobody can see why.
 */
/**
 * The rule itself, separated from looking things up so it can be tested
 * directly. Faking a connected Square merchant in a test needs Square's whole
 * configuration enabled; the decision is what matters, and this is it.
 */
export function assertIssuable(status: string, providerName: string) {
  if (status !== 'active') {
    throw new ApiError(403, 'account_not_active',
      'This business account is not active yet, so it cannot be issued a card.');
  }
  if (providerName !== 'simulated') {
    throw new ApiError(400, 'no_platform_balance',
      `Payments for this business settle straight into its own ${providerName} account, `
      + `so there is no balance here for a card to spend. A business card needs either a funding `
      + `account held on this platform, or a card programme issued against the sponsor bank.`);
  }
}

async function assertCanIssue(m: CardMerchant) {
  // Status is checked before the lookup, so a pending business gets the
  // useful error rather than one about processors.
  if (m.status !== 'active') assertIssuable(m.status, 'simulated');
  const { providerMerchant } = await import('../merchants/connect.js');
  const pm = await providerMerchant(pool, m.id);
  assertIssuable(m.status, pm.provider.name);
}

export async function createBusinessVirtualCard(
  m: CardMerchant,
  input: { currency: string; nickname?: string; cardholder_name?: string; single_use?: boolean } & CardControls,
) {
  await assertCanIssue(m);
  const details = await cardIssuer().createCard({ userId: m.id, kind: 'virtual', currency: input.currency });
  return tx(async (c) => {
    const token = await tokenize(c, { merchantId: m.id }, {
      number: details.pan, exp_month: details.expMonth,
      exp_year: details.expYear, cvc: details.cvc,
    });
    const row = await one(c,
      `INSERT INTO issued_cards
         (id, merchant_id, kind, status, vault_token_id, issuer, issuer_card_id, brand,
          last4, exp_month, exp_year, currency, nickname, cardholder_name, single_use,
          per_auth_limit, daily_limit, monthly_limit, allowed_mcc, blocked_mcc, activated_at)
       VALUES ($1,$2,'virtual','active',$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18, now())
       RETURNING *`,
      [newId('card'), m.id, token.id, cardIssuer().name, details.issuerCardId, details.brand,
       token.last4, details.expMonth, details.expYear, input.currency.toLowerCase(),
       input.nickname ?? null, input.cardholder_name ?? null, input.single_use ?? false,
       input.per_auth_limit ?? null, input.daily_limit ?? null, input.monthly_limit ?? null,
       input.allowed_mcc ?? null, input.blocked_mcc ?? null]);
    return presentCard(row);
  });
}

export async function orderBusinessPhysicalCard(
  m: CardMerchant,
  input: { currency: string; nickname?: string; cardholder_name?: string; address: ShippingAddress } & CardControls,
) {
  await assertCanIssue(m);
  const a = input.address;
  for (const [field, value] of [['name', a?.name], ['line1', a?.line1], ['city', a?.city],
                                ['postal code', a?.postalCode], ['country', a?.country]] as const) {
    if (!value || !String(value).trim()) {
      throw new ApiError(400, 'address_incomplete', `A delivery address needs a ${field}.`);
    }
  }
  return tx(async (c) => {
    const cardId = newId('card');
    const row = await one(c,
      `INSERT INTO issued_cards
         (id, merchant_id, kind, status, issuer, currency, nickname, cardholder_name, single_use,
          per_auth_limit, daily_limit, monthly_limit, allowed_mcc, blocked_mcc)
       VALUES ($1,$2,'physical','ordered',$3,$4,$5,$6,false,$7,$8,$9,$10,$11) RETURNING *`,
      [cardId, m.id, cardIssuer().name, input.currency.toLowerCase(), input.nickname ?? null,
       input.cardholder_name ?? null,
       input.per_auth_limit ?? null, input.daily_limit ?? null, input.monthly_limit ?? null,
       input.allowed_mcc ?? null, input.blocked_mcc ?? null]);
    await c.query(
      `INSERT INTO card_orders (id, card_id, merchant_id, name, line1, line2, city, region, postal_code, country, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'ordered')`,
      [newId('cord'), cardId, m.id, a.name, a.line1, a.line2 ?? null,
       a.city, a.region ?? null, a.postalCode, a.country.toUpperCase()]);
    return presentCard(row);
  });
}

export async function listBusinessCards(m: CardMerchant) {
  const r = await pool.query(
    `SELECT * FROM issued_cards WHERE merchant_id=$1 ORDER BY created_at DESC`, [m.id]);
  return r.rows.map(presentCard);
}

/* The merchant-owned versions of the lifecycle calls. Same rules, different
   owner column — a business must not be able to touch a customer's card by id. */
export async function setBusinessCardStatus(m: CardMerchant, cardId: string, want: 'active' | 'frozen' | 'canceled') {
  const card = await one(pool, `SELECT * FROM issued_cards WHERE id=$1 AND merchant_id=$2`, [cardId, m.id]);
  if (!card) throw new ApiError(404, 'resource_missing', 'No such card.');
  if (card.status === 'canceled') throw new ApiError(400, 'card_canceled', 'This card was cancelled and cannot be changed.');
  if (want === 'active' && card.status === 'ordered') throw new ApiError(400, 'not_yet_issued', 'This card has not been made yet.');
  await cardIssuer().setStatus(card.issuer_card_id ?? '', want);
  const row = await one(pool,
    `UPDATE issued_cards SET status=$2, canceled_at = CASE WHEN $2='canceled' THEN now() ELSE canceled_at END,
            updated_at=now() WHERE id=$1 RETURNING *`, [cardId, want]);
  return presentCard(row);
}

export async function setBusinessCardControls(m: CardMerchant, cardId: string, controls: CardControls) {
  const owned = await one(pool, `SELECT 1 FROM issued_cards WHERE id=$1 AND merchant_id=$2`, [cardId, m.id]);
  if (!owned) throw new ApiError(404, 'resource_missing', 'No such card.');
  for (const k of ['per_auth_limit', 'daily_limit', 'monthly_limit'] as const) {
    const v = controls[k];
    if (v !== undefined && v !== null && (!Number.isInteger(v) || v < 0)) {
      throw new ApiError(400, 'parameter_invalid', `${k} must be a whole number of minor units, or null for no limit.`);
    }
  }
  const row = await one(pool,
    `UPDATE issued_cards SET
       per_auth_limit = CASE WHEN $3 THEN $4 ELSE per_auth_limit END,
       daily_limit    = CASE WHEN $5 THEN $6 ELSE daily_limit END,
       monthly_limit  = CASE WHEN $7 THEN $8 ELSE monthly_limit END,
       allowed_mcc    = CASE WHEN $9 THEN $10 ELSE allowed_mcc END,
       blocked_mcc    = CASE WHEN $11 THEN $12 ELSE blocked_mcc END,
       updated_at = now()
     WHERE id=$1 AND merchant_id=$2 RETURNING *`,
    [cardId, m.id,
     controls.per_auth_limit !== undefined, controls.per_auth_limit ?? null,
     controls.daily_limit !== undefined, controls.daily_limit ?? null,
     controls.monthly_limit !== undefined, controls.monthly_limit ?? null,
     controls.allowed_mcc !== undefined, controls.allowed_mcc ?? null,
     controls.blocked_mcc !== undefined, controls.blocked_mcc ?? null]);
  return presentCard(row);
}

export async function revealBusinessCard(m: CardMerchant, cardId: string) {
  const card = await one(pool, `SELECT * FROM issued_cards WHERE id=$1 AND merchant_id=$2`, [cardId, m.id]);
  if (!card) throw new ApiError(404, 'resource_missing', 'No such card.');
  if (!card.vault_token_id) throw new ApiError(400, 'not_yet_issued', 'This card has not been made yet.');
  if (card.status === 'canceled') throw new ApiError(400, 'card_canceled', 'This card was cancelled.');
  const pan = await detokenize(pool, card.vault_token_id);
  return { id: card.id, number: pan.pan, exp_month: pan.exp_month, exp_year: pan.exp_year, brand: card.brand };
}

export async function activateBusinessCard(m: CardMerchant, cardId: string) {
  const row = await one(pool,
    `UPDATE issued_cards SET status='active', activated_at=now(), updated_at=now()
      WHERE id=$1 AND merchant_id=$2 AND status='shipped' RETURNING *`, [cardId, m.id]);
  if (!row) {
    const exists = await one(pool, `SELECT status FROM issued_cards WHERE id=$1 AND merchant_id=$2`, [cardId, m.id]);
    if (!exists) throw new ApiError(404, 'resource_missing', 'No such card.');
    throw new ApiError(400, 'cannot_activate', `A card that is ${exists.status} cannot be activated.`);
  }
  return presentCard(row);
}
