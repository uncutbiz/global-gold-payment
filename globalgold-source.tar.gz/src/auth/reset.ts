/**
 * Adding a phone number, and resetting a forgotten password with it.
 *
 * A password reset is the softest part of any account system: it exists to let
 * someone in who cannot prove who they are the usual way. Everything below is
 * about making that as narrow as possible.
 *
 * The flow is three requests, on purpose:
 *
 *   1. start    "I forgot" + a phone number  → a code goes out by SMS
 *   2. verify   the code                     → a short-lived ticket
 *   3. finish   the ticket + a new password  → signed out everywhere
 *
 * Splitting 2 and 3 means the code is sent once and lives for seconds, rather
 * than being carried alongside the new password and sitting in a form.
 *
 * The rules, each of which exists because leaving it out is a known way in:
 *
 *   - The number must be VERIFIED first. Otherwise anyone could claim someone
 *     else's number and reset their password with it.
 *   - Step 1 ALWAYS answers the same way. If "no account with that number"
 *     looked different from "code sent", the endpoint would be a free tool for
 *     discovering which numbers bank here.
 *   - Codes are stored hashed and compared in constant time.
 *   - Six digits is one in a million only with few guesses, so guesses are
 *     capped and the code dies on the cap.
 *   - Everything is rate limited per number, because SMS costs real money and
 *     an unlimited endpoint is someone else's phone bill.
 *   - A successful reset ends every session. A password changed because it
 *     leaked achieves nothing if the session made with it keeps working.
 *
 * Worth saying plainly: SMS is not a strong second factor. A SIM swap defeats
 * it, and it is phishable. It is here because it is what people can actually
 * use. Anything that moves money should want more than this.
 */
import crypto from 'node:crypto';
import type { PoolClient } from 'pg';
import { one, pool, tx } from '../db.js';
import { ApiError, newId, sha256 } from '../util/common.js';
import { hashPassword } from '../util/passwords.js';
import { maskPhone, smsProvider, toE164 } from '../notify/sms.js';

const CODE_TTL_MINUTES = 10;
const TICKET_TTL_MINUTES = 15;
const MAX_ATTEMPTS = 5;
/** How many codes one number may be sent in an hour. */
const MAX_SENDS_PER_HOUR = 5;
/** How long between codes to the same number. */
const RESEND_SECONDS = 60;

export type Subject = 'merchant_user' | 'user';

/**
 * Hash a code before storing it.
 *
 * Peppered with the app's FINGERPRINT_KEY so that a stolen database alone does
 * not let someone precompute all million six-digit hashes — the pepper is in
 * the application's configuration, not the database.
 */
function hashCode(code: string, phone: string): string {
  const pepper = process.env.FINGERPRINT_KEY ?? '';
  return crypto.createHmac('sha256', pepper).update(`${phone}|${code}`).digest('hex');
}

function newCode(): string {
  // Uniform over 000000–999999. `% 1000000` on a random 32-bit value is very
  // slightly biased; rejection sampling is cheap enough to just do it right.
  while (true) {
    const n = crypto.randomBytes(4).readUInt32BE(0);
    if (n < 4_294_000_000) return String(n % 1_000_000).padStart(6, '0');
  }
}

function equal(a: string, b: string): boolean {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

const TABLE = { merchant_user: 'merchant_users', user: 'users' } as const;
const COLUMN = { merchant_user: 'merchant_user_id', user: 'user_id' } as const;
const SESSIONS = { merchant_user: 'merchant_sessions', user: 'user_sessions' } as const;
// The two session tables do NOT name their owner column the same way, and
// getting it wrong is a silent failure to sign anyone out.
const SESSION_COLUMN = { merchant_user: 'merchant_user_id', user: 'user_id' } as const;

/** Refuse to send if this number has had too many already. */
async function checkSendRate(c: PoolClient, phone: string, purpose: string) {
  const r = await one<{ recent: number; last: Date | null }>(c,
    `SELECT count(*)::int AS recent, max(created_at) AS last
       FROM otp_codes WHERE phone = $1 AND purpose = $2 AND created_at > now() - interval '1 hour'`,
    [phone, purpose]);
  if ((r?.recent ?? 0) >= MAX_SENDS_PER_HOUR) {
    throw new ApiError(429, 'too_many_codes',
      'Too many codes have been sent to that number. Try again in an hour.');
  }
  if (r?.last && Date.now() - new Date(r.last).getTime() < RESEND_SECONDS * 1000) {
    throw new ApiError(429, 'code_just_sent',
      `A code was just sent. Wait ${RESEND_SECONDS} seconds before asking for another.`);
  }
}

async function issueCode(
  c: PoolClient, subject: Subject, subjectId: string, phone: string,
  purpose: 'verify_phone' | 'reset_password', ip?: string,
) {
  const code = newCode();
  // Any earlier live code for this number and purpose stops working, so a
  // resend cannot leave two valid codes in the wild.
  await c.query(
    `UPDATE otp_codes SET consumed_at = now()
      WHERE phone = $1 AND purpose = $2 AND consumed_at IS NULL`, [phone, purpose]);
  await c.query(
    `INSERT INTO otp_codes (id, purpose, ${COLUMN[subject]}, phone, code_hash, expires_at, created_ip)
     VALUES ($1,$2,$3,$4,$5, now() + make_interval(mins => $6), $7)`,
    [newId('otp'), purpose, subjectId, phone, hashCode(code, phone), CODE_TTL_MINUTES, ip ?? null]);
  return code;
}

// ------------------------------------------------------- adding a phone number

/**
 * Attach a number to an account and send it a code.
 *
 * This one is called by someone already signed in, so it can afford to be
 * honest about failures — the caller has already proved who they are.
 */
export async function startPhoneVerification(
  subject: Subject, subjectId: string, rawPhone: string, ip?: string,
) {
  const phone = toE164(rawPhone, process.env.DEFAULT_COUNTRY_CODE ?? '1');
  if (!phone) {
    throw new ApiError(400, 'parameter_invalid',
      'That does not look like a phone number. Include the country code, for example +1 555 123 4567.');
  }

  // Refuse a number already verified on another account: the reset lookup is
  // by number, so two accounts sharing one would make it ambiguous.
  const taken = await one(pool,
    `SELECT id FROM ${TABLE[subject]} WHERE phone = $1 AND phone_verified_at IS NOT NULL AND id <> $2`,
    [phone, subjectId]);
  if (taken) {
    throw new ApiError(409, 'phone_taken', 'That number is already on another account.');
  }

  const code = await tx(async (c) => {
    await checkSendRate(c, phone, 'verify_phone');
    // Stored unverified now; verified only when the code comes back.
    await c.query(
      `UPDATE ${TABLE[subject]} SET phone = $2, phone_verified_at = NULL WHERE id = $1`,
      [subjectId, phone]);
    return issueCode(c, subject, subjectId, phone, 'verify_phone', ip);
  });

  const sent = await smsProvider().send(phone,
    `${code} is your Global Gold verification code. It expires in ${CODE_TTL_MINUTES} minutes.`);
  if (!sent.sent) {
    throw new ApiError(502, 'sms_failed', `Could not send the code: ${sent.error ?? 'unknown error'}`);
  }
  return { sent_to: maskPhone(phone), expires_in_minutes: CODE_TTL_MINUTES };
}

export async function confirmPhoneVerification(subject: Subject, subjectId: string, code: string) {
  // The transaction COMMITS whether the code was right or wrong, and the
  // failure is thrown afterwards. Throwing from inside it would roll back the
  // attempt counter along with everything else, which silently turns a
  // six-guess limit into no limit at all — and a six-digit code with
  // unlimited guesses is not a secret.
  const outcome = await tx(async (c) => {
    const row = await one<any>(c,
      `SELECT * FROM otp_codes
        WHERE ${COLUMN[subject]} = $1 AND purpose = 'verify_phone' AND consumed_at IS NULL
        ORDER BY created_at DESC LIMIT 1 FOR UPDATE`, [subjectId]);
    if (!row) return { fail: new ApiError(400, 'no_code', 'Ask for a code first.') };
    if (new Date(row.expires_at).getTime() < Date.now()) {
      return { fail: new ApiError(400, 'code_expired', 'That code has expired. Ask for a new one.') };
    }
    if (row.attempts >= MAX_ATTEMPTS) {
      return { fail: new ApiError(429, 'too_many_attempts', 'Too many wrong codes. Ask for a new one.') };
    }
    if (!equal(row.code_hash, hashCode(String(code).trim(), row.phone))) {
      await c.query('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1', [row.id]);
      return { fail: new ApiError(400, 'code_incorrect', 'That code is not correct.') };
    }
    await c.query('UPDATE otp_codes SET consumed_at = now() WHERE id = $1', [row.id]);
    await c.query(
      `UPDATE ${TABLE[subject]} SET phone_verified_at = now() WHERE id = $1 AND phone = $2`,
      [subjectId, row.phone]);
    return { ok: { verified: true, phone: maskPhone(row.phone) } };
  });
  if ('fail' in outcome && outcome.fail) throw outcome.fail;
  return (outcome as { ok: { verified: boolean; phone: string } }).ok;
}

// ------------------------------------------------------------ forgot password

/**
 * Step 1. Send a reset code to a number, if it belongs to a verified account.
 *
 * ALWAYS returns the same thing. Not a convenience — the difference between
 * "sent" and "no such account" is exactly what someone enumerating customers
 * would ask this endpoint for, one number at a time.
 *
 * The rate limit is applied to the number regardless of whether an account
 * exists, so timing and limits do not leak the answer either.
 */
export async function startPasswordReset(subject: Subject, rawPhone: string, ip?: string) {
  const same = { ok: true, message: 'If that number is on a verified account, a code has been sent to it.' };
  const phone = toE164(rawPhone, process.env.DEFAULT_COUNTRY_CODE ?? '1');
  if (!phone) return same;

  let code: string | null = null;
  try {
    code = await tx(async (c) => {
      await checkSendRate(c, phone, 'reset_password');
      const account = await one<{ id: string }>(c,
        `SELECT id FROM ${TABLE[subject]} WHERE phone = $1 AND phone_verified_at IS NOT NULL`, [phone]);
      if (!account) return null;
      return issueCode(c, subject, account.id, phone, 'reset_password', ip);
    });
  } catch (e: any) {
    // A rate limit is worth telling the caller about — it is about the number
    // they typed, not about whether an account exists.
    if (e instanceof ApiError && e.status === 429) throw e;
    throw e;
  }

  if (code) {
    const sent = await smsProvider().send(phone,
      `${code} is your Global Gold password reset code. It expires in ${CODE_TTL_MINUTES} minutes. `
      + 'If you did not ask for this, ignore it and your password stays the same.');
    if (!sent.sent) {
      console.error(JSON.stringify({ level: 'error', msg: 'reset SMS failed', error: sent.error }));
    }
  }
  return same;
}

/** Step 2. Trade a correct code for a short-lived ticket. */
export async function verifyResetCode(subject: Subject, rawPhone: string, code: string) {
  const phone = toE164(rawPhone, process.env.DEFAULT_COUNTRY_CODE ?? '1');
  if (!phone) throw new ApiError(400, 'code_incorrect', 'That code is not correct.');

  // As above: the transaction must COMMIT the attempt counter even when the
  // code was wrong, so the failure is returned and thrown afterwards.
  const outcome = await tx(async (c) => {
    const row = await one<any>(c,
      `SELECT * FROM otp_codes
        WHERE phone = $1 AND purpose = 'reset_password' AND consumed_at IS NULL
        ORDER BY created_at DESC LIMIT 1 FOR UPDATE`, [phone]);
    // Same error for "no code", "expired" and "wrong", beyond what the user
    // needs to act: none of them should confirm an account exists.
    const wrong = () => ({ fail: new ApiError(400, 'code_incorrect', 'That code is not correct or has expired.') });
    if (!row) return wrong();
    if (new Date(row.expires_at).getTime() < Date.now()) return wrong();
    if (row.attempts >= MAX_ATTEMPTS) {
      await c.query('UPDATE otp_codes SET consumed_at = now() WHERE id = $1', [row.id]);
      return { fail: new ApiError(429, 'too_many_attempts', 'Too many wrong codes. Ask for a new one.') };
    }
    if (!equal(row.code_hash, hashCode(String(code).trim(), phone))) {
      await c.query('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1', [row.id]);
      return wrong();
    }

    await c.query('UPDATE otp_codes SET consumed_at = now() WHERE id = $1', [row.id]);
    const ticket = 'rst_' + crypto.randomBytes(32).toString('base64url');
    await c.query(
      `INSERT INTO reset_tickets (token_hash, ${COLUMN[subject]}, expires_at)
       VALUES ($1,$2, now() + make_interval(mins => $3))`,
      [sha256(ticket), row[COLUMN[subject]], TICKET_TTL_MINUTES]);
    return { ok: { ticket, expires_in_minutes: TICKET_TTL_MINUTES } };
  });
  if ('fail' in outcome && outcome.fail) throw outcome.fail;
  return (outcome as { ok: { ticket: string; expires_in_minutes: number } }).ok;
}

/** Step 3. Set the new password and sign the account out everywhere. */
export async function finishPasswordReset(
  subject: Subject, ticket: string, newPassword: string, minLength = 10,
) {
  if (newPassword.length < minLength) {
    throw new ApiError(400, 'password_too_short', `Use at least ${minLength} characters.`);
  }
  return tx(async (c) => {
    const t = await one<any>(c,
      `SELECT * FROM reset_tickets WHERE token_hash = $1 FOR UPDATE`, [sha256(ticket)]);
    if (!t || t.used_at || new Date(t.expires_at).getTime() < Date.now() || !t[COLUMN[subject]]) {
      throw new ApiError(400, 'reset_expired', 'That reset has expired. Start again.');
    }
    const id = t[COLUMN[subject]];

    await c.query(`UPDATE reset_tickets SET used_at = now() WHERE token_hash = $1`, [sha256(ticket)]);
    await c.query(`UPDATE ${TABLE[subject]} SET password_hash = $2 WHERE id = $1`,
      [id, await hashPassword(newPassword)]);
    // Whoever was signed in as this account is not any more.
    const gone = await c.query(
      `DELETE FROM ${SESSIONS[subject]} WHERE ${SESSION_COLUMN[subject]} = $1`, [id]);
    // Any other live reset for this account dies too, so a second code that
    // was already in flight cannot be used afterwards.
    await c.query(
      `UPDATE otp_codes SET consumed_at = now()
        WHERE ${COLUMN[subject]} = $1 AND purpose = 'reset_password' AND consumed_at IS NULL`, [id]);
    return { ok: true, sessions_ended: gone.rowCount ?? 0 };
  });
}

/** Housekeeping: nothing here is useful once it has expired. */
export async function purgeExpiredCodes() {
  const a = await pool.query(`DELETE FROM otp_codes WHERE expires_at < now() - interval '1 day'`);
  const b = await pool.query(`DELETE FROM reset_tickets WHERE expires_at < now() - interval '1 day'`);
  return { codes: a.rowCount ?? 0, tickets: b.rowCount ?? 0 };
}
