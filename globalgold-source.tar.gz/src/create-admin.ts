/**
 * Creates a staff account for the admin panel.
 *   npm run create-admin -- --email you@company.com --name "Your Name" --role owner
 * The password is read from ADMIN_PASSWORD, or generated and printed once.
 */
import crypto from 'node:crypto';
import { parseArgs } from 'node:util';
import { pool } from './db.js';
import { migrate } from './migrate.js';
import { createStaff, type Role } from './admin/staff.js';

const { values } = parseArgs({ options: { email: { type: 'string' }, name: { type: 'string' }, role: { type: 'string', default: 'owner' } } });
if (!values.email || !values.name) {
  console.error('Usage: npm run create-admin -- --email you@company.com --name "Your Name" [--role owner|compliance|support|viewer]');
  process.exit(1);
}
const password = process.env.ADMIN_PASSWORD ?? crypto.randomBytes(12).toString('base64url');
await migrate();
const s = await createStaff({ email: values.email, name: values.name, password, role: values.role as Role });
console.log(`Created ${s.role} ${s.email}`);
if (!process.env.ADMIN_PASSWORD) console.log(`Temporary password: ${password}`);
console.log('Sign in at /admin');
await pool.end();
