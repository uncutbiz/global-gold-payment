/**
 * Fills a running server with demo data: an admin, a merchant, and wallet
 * customers in several countries (some verified, some waiting for review),
 * plus transfers that trip the monitoring rules.
 *
 *   npm run seed
 */
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { config } from './config.js';
import { pool } from './db.js';
import { createStaff } from './admin/staff.js';

const base = config.publicUrl;
const PASSWORD = 'correct horse battery';

async function call(method: string, path: string, key: string | null, body?: unknown) {
  const res = await fetch(base + path, {
    method,
    headers: { ...(key ? { authorization: `Bearer ${key}` } : {}), 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json: any = await res.json();
  if (!res.ok) throw new Error(`${method} ${path}: ${json.error?.message}`);
  return json;
}

/** Draws a simple placeholder "ID card" PNG so the KYC queue has something to show. */
function fakeIdPng(seed: number) {
  const w = 480, h = 300;
  const crc = (buf: Buffer) => { let c = ~0; for (const b of buf) { c ^= b; for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1)); } return ~c >>> 0; };
  const chunk = (type: string, data: Buffer) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const c = Buffer.alloc(4); c.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, c]);
  };
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    for (let x = 0; x < w; x++) {
      const i = y * (w * 3 + 1) + 1 + x * 3;
      let [r, g, b] = [236, 230, 214];                                        // card
      if (y < 56) [r, g, b] = [14, 26, 51];                                   // navy header
      if (y > 20 && y < 36 && x > 24 && x < 200) [r, g, b] = [201, 162, 39];  // gold title bar
      if (x > 28 && x < 148 && y > 80 && y < 240) [r, g, b] = [150 + (seed * 13) % 60, 140, 130]; // photo
      if (x > 172 && x < 440 && [96, 130, 164, 198].some((l) => y > l && y < l + 12)) [r, g, b] = [90, 96, 110]; // text lines
      raw[i] = r; raw[i + 1] = g; raw[i + 2] = b;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const png = Buffer.concat([
    Buffer.from('89504e470d0a1a0a', 'hex'), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0)),
  ]);
  return 'data:image/png;base64,' + png.toString('base64');
}

const suffix = crypto.randomBytes(2).toString('hex');
const people = [
  { key: 'yvon', name: 'Yvon Demo', country: 'US', kyc: 'approved', fund: 150000 },
  { key: 'emeka', name: 'Emeka Obi', country: 'NG', kyc: 'approved', fund: 0 },
  { key: 'fiona', name: 'Fiona Hart', country: 'GB', kyc: 'approved', fund: 120000 },
  { key: 'maria', name: 'María López', country: 'MX', kyc: 'pending', fund: 0 },
  { key: 'wanjiru', name: 'Wanjiru Kamau', country: 'KE', kyc: 'pending', fund: 0 },
  { key: 'priya', name: 'Priya Nair', country: 'IN', kyc: 'unverified', fund: 0 },
];

// 1. Admin (owner) account.
const adminEmail = `owner-${suffix}@globalgold.test`;
const adminPassword = crypto.randomBytes(9).toString('base64url');
await createStaff({ email: adminEmail, name: 'Demo Owner', password: adminPassword, role: 'owner' });

// 2. Businesses: one approved (with sample card payments), one waiting for review.
const BIZ_PASSWORD = 'business password';
const bizEmail = `owner-${suffix}@dripline.test`;
const b = await call('POST', '/v1/business/signup', null, {
  business_name: 'Dripline Mobile IV', name: 'Yvon Demo', email: bizEmail, password: BIZ_PASSWORD,
  country: 'US', business_type: 'company', website: 'https://dripline.live', description: 'Mobile IV hydration sessions',
});
await call('POST', `/v1/admin/merchants/${b.merchant_id}/status`, config.adminToken, { status: 'active' });
const keys = await call('POST', '/v1/account/keys/roll', b.token, {});
const card = { number: '4242424242424242', exp_month: 12, exp_year: new Date().getFullYear() + 3, cvc: '123' };
for (const [amount, description] of [[14900, 'Hydration package'], [8900, 'Recovery drip'], [22000, 'Group booking']] as const) {
  const tok = await call('POST', '/v1/tokens', keys.publishable, { card });
  await call('POST', '/v1/payment_intents', b.token, { amount, description, currency: 'usd', payment_token: tok.id, confirm: true });
}
await call('POST', '/v1/business/signup', null, {
  business_name: 'Accra Kente House', name: 'Kofi Mensah', email: `kofi-${suffix}@kente.test`, password: BIZ_PASSWORD,
  country: 'GH', business_type: 'individual', website: 'https://kente.example', description: 'Handwoven kente cloth, shipped worldwide',
});

// 3. Customers.
const u: Record<string, any> = {};
for (const [i, p] of people.entries()) {
  const email = `${p.key}-${suffix}@example.com`;
  const s = await call('POST', '/v1/wallet/signup', null, { email, name: p.name, password: PASSWORD, country: p.country });
  u[p.key] = { ...p, email, token: s.token, id: s.user.id };
  if (p.kyc !== 'unverified') {
    const k = await call('POST', '/v1/wallet/kyc', s.token, {
      legal_name: p.name, date_of_birth: `19${80 + i}-0${(i % 9) + 1}-1${i}`, address_line: `${10 + i} Market Street`,
      city: 'Capital City', postal_code: `${10000 + i}`, country: p.country, id_type: i % 2 ? 'national_id' : 'passport',
      id_number: `GG${suffix}${i}${1000 + i}`, document: fakeIdPng(i),
    });
    if (p.kyc === 'approved') await call('POST', `/v1/admin/kyc/${k.id}/approve`, config.adminToken, { note: 'Demo data' });
  }
  if (p.fund) {
    const c = await call('POST', '/v1/wallet/cards', s.token, { card });
    await call('POST', '/v1/wallet/top_ups', s.token, { amount: p.fund, card: c.id });
  }
}

// A wallet payment to the business, from a verified customer.
const walletPi = await call('POST', '/v1/payment_intents', b.token, { amount: 12500, currency: 'usd', description: 'Wellness drip' });
await call('POST', `/v1/checkout/${walletPi.id}/pay_with_wallet`, u.yvon.token, { client_secret: walletPi.client_secret });
// Business payouts go to Yvon's verified wallet.
await call('POST', '/v1/account', b.token, { payout_method: 'wallet', payout_wallet_email: u.yvon.email });

// 4. Transfers (the large one and the burst trip monitoring alerts).
await call('POST', '/v1/wallet/transfers', u.yvon.token, { to: u.emeka.email, amount: 20000, note: 'School fees' });
await call('POST', '/v1/wallet/transfers', u.fiona.token, { to: u.yvon.email, amount: 5000, note: 'Concert tickets' });
await call('POST', '/v1/wallet/transfers', u.yvon.token, { to: u.maria.email, amount: 110000, note: 'Family support' });
for (let i = 0; i < 5; i++) await call('POST', '/v1/wallet/transfers', u.fiona.token, { to: u.priya.email, amount: 1000 + i * 100, note: `Split ${i + 1}` });
await call('POST', '/v1/wallet/conversions', u.yvon.token, { from: 'usd', to: 'eur', amount: 10000 });

console.log(`
Demo data ready.

  Admin panel      ${base}/admin
    email          ${adminEmail}
    password       ${adminPassword}

  Home             ${base}/

  Business dash    ${base}/dashboard
    email          ${bizEmail}
    password       ${BIZ_PASSWORD}
    secret key     ${keys.secret}
    (a second business, Accra Kente House, is waiting for approval in the admin panel)

  Customer wallet  ${base}/wallet   (password for all: ${PASSWORD})
${Object.values(u).map((p: any) => `    ${p.email.padEnd(34)} ${p.country}  ${p.kyc}`).join('\n')}
`);
await pool.end();
