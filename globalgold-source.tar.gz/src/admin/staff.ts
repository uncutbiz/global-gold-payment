/**
 * Staff accounts for the admin panel, with roles and an audit trail.
 *
 *   owner       everything, including staff management, merchant approval and settlement
 *   compliance  KYC decisions, alerts, freezing accounts, merchant status
 *   support     read customers and transactions
 *   viewer      read-only dashboards
 *
 * The ADMIN_TOKEN env var acts as a bootstrap owner (to create the first staff
 * account). Production: remove it after setup, and require SSO + hardware-key MFA
 * and IP allow-listing for staff.
 */
import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { config } from '../config.js';
import { Db, one, pool } from '../db.js';
import { ApiError, newId, sha256 } from '../util/common.js';
import { checkPassword, dummyHash, hashPassword } from '../util/passwords.js';

export type Role = 'owner' | 'compliance' | 'support' | 'viewer';
export interface Staff { id: string | null; email: string; name: string; role: Role }

declare global {
  namespace Express { interface Request { staff?: Staff } }
}

const SESSION_HOURS = 8;
export const MIN_PASSWORD_LENGTH = 12;

export async function createStaff(input: { email: string; name: string; password: string; role: Role }) {
  const row = await one(pool,
    `INSERT INTO admin_users (id, email, name, password_hash, role) VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (email) DO NOTHING RETURNING id, email, name, role, created_at`,
    [newId('adm'), input.email.trim().toLowerCase(), input.name.trim(), await hashPassword(input.password), input.role]);
  if (!row) throw new ApiError(409, 'email_taken', 'A staff account with this email already exists.');
  return row;
}

/**
 * Changes a staff account's password and ends every session it had open.
 *
 * The session deletion is the security-relevant half. Someone rotating a
 * password is usually doing it because they think the old one leaked, and a
 * session token lives for SESSION_HOURS independently of the password that
 * created it — so without this, whoever holds a stolen token keeps their access
 * for the rest of the day and the rotation accomplishes nothing.
 */
export async function setStaffPassword(email: string, password: string) {
  if (password.length < MIN_PASSWORD_LENGTH) {
    throw new ApiError(400, 'password_too_short',
      `Use at least ${MIN_PASSWORD_LENGTH} characters.`);
  }
  const staff = await one<{ id: string; email: string; name: string; role: Role }>(pool,
    'UPDATE admin_users SET password_hash = $2 WHERE email = $1 RETURNING id, email, name, role',
    [email.trim().toLowerCase(), await hashPassword(password)]);
  if (!staff) throw new ApiError(404, 'resource_missing', 'Staff account not found.');
  const gone = await pool.query('DELETE FROM admin_sessions WHERE admin_id = $1', [staff.id]);
  return { staff, sessionsEnded: gone.rowCount ?? 0 };
}

/**
 * Change your own password. Requires the current one.
 *
 * Asking for the current password is not a formality: it is what stops a
 * borrowed, unlocked laptop or a stolen session token from becoming permanent
 * ownership of the account. Every other session is ended, so if someone else
 * was signed in as you, they are not any more.
 */
export async function changeOwnPassword(staffId: string, current: string, next: string) {
  const u = await one<any>(pool, 'SELECT * FROM admin_users WHERE id = $1', [staffId]);
  if (!u) throw new ApiError(404, 'resource_missing', 'Staff account not found.');
  if (!(await checkPassword(current, u.password_hash))) {
    throw new ApiError(401, 'invalid_login', 'Your current password is not correct.');
  }
  if (next === current) {
    throw new ApiError(400, 'password_unchanged', 'The new password is the same as the old one.');
  }
  return setStaffPassword(u.email, next);
}

/**
 * An owner resets someone else's password, for the person who is locked out.
 *
 * The generated password is returned ONCE and never stored in readable form.
 * The alternative — letting an owner choose it — means the owner knows a
 * password the other person will keep using, and every audit asks about that.
 */
export async function resetStaffPassword(actor: Staff, id: string) {
  const u = await one<any>(pool, 'SELECT * FROM admin_users WHERE id = $1', [id]);
  if (!u) throw new ApiError(404, 'resource_missing', 'Staff account not found.');
  const password = crypto.randomBytes(12).toString('base64url');
  const r = await setStaffPassword(u.email, password);
  await audit(pool, actor, 'staff.password_reset', 'admin_user', u.id, { email: u.email });
  return { ...r, temporary_password: password };
}

export async function listStaff() {
  const r = await pool.query('SELECT id, email, name, role, disabled_at, created_at FROM admin_users ORDER BY created_at');
  return r.rows;
}

export async function setStaffDisabled(id: string, disabled: boolean) {
  const row = await one(pool, 'UPDATE admin_users SET disabled_at = $2 WHERE id = $1 RETURNING id, email, role, disabled_at', [id, disabled ? new Date() : null]);
  if (!row) throw new ApiError(404, 'resource_missing', 'Staff account not found.');
  if (disabled) await pool.query('DELETE FROM admin_sessions WHERE admin_id = $1', [id]);
  return row;
}

export async function staffLogin(email: string, password: string) {
  const u = await one(pool, 'SELECT * FROM admin_users WHERE email = $1', [email.trim().toLowerCase()]);
  const ok = await checkPassword(password, u?.password_hash ?? await dummyHash());
  if (!u || !ok || u.disabled_at) throw new ApiError(401, 'invalid_login', 'Email or password is incorrect.');
  const token = 'gga_' + crypto.randomBytes(32).toString('base64url');
  await pool.query(
    `INSERT INTO admin_sessions (token_hash, admin_id, expires_at) VALUES ($1,$2, now() + make_interval(hours => $3))`,
    [sha256(token), u.id, SESSION_HOURS]);
  return { token, staff: { id: u.id, email: u.email, name: u.name, role: u.role } };
}

export async function staffLogout(token: string) {
  await pool.query('DELETE FROM admin_sessions WHERE token_hash = $1', [sha256(token)]);
}

function isBootstrapToken(t: string) {
  const a = Buffer.from(sha256(t)), b = Buffer.from(sha256(config.adminToken));
  return crypto.timingSafeEqual(a, b);
}

/** Allows the listed roles. Owners are always allowed. */
export function requireStaff(...roles: Role[]) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    const h = req.header('authorization') ?? '';
    const token = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
    let staff: Staff | undefined;
    if (token.startsWith('gga_')) {
      staff = await one<Staff>(pool,
        `SELECT a.id, a.email, a.name, a.role FROM admin_sessions s JOIN admin_users a ON a.id = s.admin_id
          WHERE s.token_hash = $1 AND s.expires_at > now() AND a.disabled_at IS NULL`, [sha256(token)]);
      if (!staff) throw new ApiError(401, 'session_expired', 'Your admin session has expired. Sign in again.');
    } else if (token && isBootstrapToken(token)) {
      staff = { id: null, email: 'bootstrap', name: 'Bootstrap token', role: 'owner' };
    }
    if (!staff) throw new ApiError(401, 'unauthorized', 'Sign in to the admin panel.');
    if (staff.role !== 'owner' && !roles.includes(staff.role)) {
      throw new ApiError(403, 'forbidden', `Your role (${staff.role}) cannot do this.`);
    }
    req.staff = staff;
    next();
  };
}

export const ALL_ROLES: Role[] = ['owner', 'compliance', 'support', 'viewer'];

export async function audit(db: Db, staff: Staff, action: string, targetType: string, targetId: string, details: Record<string, unknown> = {}) {
  await db.query(
    `INSERT INTO audit_log (admin_id, admin_label, action, target_type, target_id, details) VALUES ($1,$2,$3,$4,$5,$6)`,
    [staff.id, `${staff.name} (${staff.email})`, action, targetType, targetId, JSON.stringify(details)]);
}
