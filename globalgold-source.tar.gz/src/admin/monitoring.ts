/**
 * Transaction monitoring: rules that open alerts for the compliance team.
 * Thresholds are in USD cents and converted per currency.
 *
 * Production systems add: sanctions/PEP screening on names, structuring
 * detection (many transfers just under a threshold), network analysis between
 * accounts, and case management with SAR filing.
 */
import type { PoolClient } from 'pg';
import { Db } from '../db.js';
import { newId } from '../util/common.js';
import { CURRENCIES } from '../wallet/fx.js';

export const RULES = {
  largeTransferUsd: Number(process.env.ALERT_LARGE_TRANSFER_USD ?? 3_000_00),
  largeInternationalUsd: Number(process.env.ALERT_LARGE_INTL_USD ?? 1_000_00),
  velocityCount: 5,              // outbound transfers per hour
  newAccountLargeUsd: 500_00,    // large sends in the first 24 hours
};

export type Severity = 'low' | 'medium' | 'high';

export async function raiseAlert(db: Db, a: {
  severity: Severity; rule: string; message: string;
  subjectType: string; subjectId: string;
  userId?: string | null; merchantId?: string | null; amount?: number | null; currency?: string | null;
}) {
  const id = newId('alrt');
  await db.query(
    `INSERT INTO alerts (id, severity, rule, message, subject_type, subject_id, user_id, merchant_id, amount, currency)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [id, a.severity, a.rule, a.message, a.subjectType, a.subjectId, a.userId ?? null, a.merchantId ?? null, a.amount ?? null, a.currency ?? null]);
  return id;
}

const toUsd = (amount: number, currency: string) => Math.round(amount / (CURRENCIES[currency]?.perUsd ?? 1));

/** Runs inside the transfer's transaction so alerts and money move together. */
export async function checkTransfer(c: PoolClient, t: {
  txId: string; userId: string; amount: number; currency: string; international: boolean; recipientName: string;
}) {
  const usd = toUsd(t.amount, t.currency);
  const money = `${(t.amount / 100).toFixed(2)} ${t.currency.toUpperCase()}`;

  if (usd >= RULES.largeTransferUsd) {
    await raiseAlert(c, { severity: 'medium', rule: 'large_transfer', message: `Large transfer of ${money} to ${t.recipientName}`,
      subjectType: 'wallet_transaction', subjectId: t.txId, userId: t.userId, amount: t.amount, currency: t.currency });
  } else if (t.international && usd >= RULES.largeInternationalUsd) {
    await raiseAlert(c, { severity: 'medium', rule: 'large_international', message: `International transfer of ${money} to ${t.recipientName}`,
      subjectType: 'wallet_transaction', subjectId: t.txId, userId: t.userId, amount: t.amount, currency: t.currency });
  }

  const v = await c.query(
    `SELECT COUNT(*)::int AS n FROM wallet_transactions
      WHERE user_id = $1 AND type = 'transfer_out' AND created_at > now() - interval '1 hour'`, [t.userId]);
  if (v.rows[0].n + 1 === RULES.velocityCount) {
    await raiseAlert(c, { severity: 'high', rule: 'velocity', message: `${RULES.velocityCount} transfers sent within an hour`,
      subjectType: 'user', subjectId: t.userId, userId: t.userId });
  }

  if (usd >= RULES.newAccountLargeUsd) {
    const young = await c.query(`SELECT 1 FROM users WHERE id = $1 AND created_at > now() - interval '24 hours'`, [t.userId]);
    if (young.rowCount) {
      await raiseAlert(c, { severity: 'high', rule: 'new_account_large_send', message: `New account (under 24h) sent ${money}`,
        subjectType: 'wallet_transaction', subjectId: t.txId, userId: t.userId, amount: t.amount, currency: t.currency });
    }
  }
}

export async function checkDeclinedTopUps(db: Db, userId: string) {
  const r = await db.query(
    `SELECT COUNT(*)::int AS n FROM wallet_transactions
      WHERE user_id = $1 AND type = 'top_up' AND status = 'failed' AND created_at > now() - interval '1 hour'`, [userId]);
  if (r.rows[0].n === 3) {
    await raiseAlert(db, { severity: 'high', rule: 'card_testing', message: '3 declined card top-ups within an hour (possible stolen cards)',
      subjectType: 'user', subjectId: userId, userId });
  }
}
