/** Read models and actions behind the admin panel. */
import { one, pool, tx } from '../db.js';
import { acct, trialBalance } from '../ledger/ledger.js';
import { ApiError } from '../util/common.js';
import { COUNTRIES, CURRENCIES, FX_POSITION } from '../wallet/fx.js';
import { audit, type Staff } from './staff.js';

const toUsd = (amount: number, currency: string) => Math.round(Number(amount) / (CURRENCIES[currency]?.perUsd ?? 1));

// ------------------------------------------------------------------ overview
export async function overview() {
  const [users, merchants, alerts, volume, revenue, fx, daily, tb, pendingKyc] = await Promise.all([
    pool.query(`SELECT COUNT(*)::int AS total,
                       COUNT(*) FILTER (WHERE kyc_status='approved')::int AS verified,
                       COUNT(*) FILTER (WHERE kyc_status='pending')::int AS pending_kyc,
                       COUNT(*) FILTER (WHERE status='locked')::int AS locked,
                       COUNT(*) FILTER (WHERE created_at > now() - interval '24 hours')::int AS new_24h
                  FROM users`),
    pool.query(`SELECT status, COUNT(*)::int AS n FROM merchants GROUP BY status`),
    pool.query(`SELECT severity, COUNT(*)::int AS n FROM alerts WHERE status='open' GROUP BY severity`),
    pool.query(`
      SELECT kind, currency, COUNT(*)::int AS n, SUM(amount)::bigint AS amount FROM (
        SELECT 'card_and_wallet_payments' AS kind, currency, amount_captured AS amount FROM payment_intents
          WHERE status='succeeded' AND updated_at > now() - interval '24 hours'
        UNION ALL
        SELECT 'transfers', currency, -amount - fee FROM wallet_transactions
          WHERE type='transfer_out' AND status='completed' AND created_at > now() - interval '24 hours'
        UNION ALL
        SELECT 'top_ups', currency, amount FROM wallet_transactions
          WHERE type='top_up' AND status='completed' AND created_at > now() - interval '24 hours'
      ) x GROUP BY kind, currency`),
    pool.query(`SELECT currency, (SUM(credit)-SUM(debit))::bigint AS amount FROM ledger_lines WHERE account=$1 GROUP BY currency`, [acct.fees]),
    pool.query(`SELECT currency, (SUM(credit)-SUM(debit))::bigint AS amount FROM ledger_lines WHERE account=$1 GROUP BY currency`, [FX_POSITION]),
    pool.query(`
      SELECT d::date AS day, x.currency, COALESCE(SUM(x.amount),0)::bigint AS amount
        FROM generate_series((now() - interval '6 days')::date, now()::date, interval '1 day') d
        LEFT JOIN (
          SELECT created_at, currency, amount_captured AS amount FROM payment_intents WHERE status='succeeded'
          UNION ALL SELECT created_at, currency, -amount - fee FROM wallet_transactions WHERE type='transfer_out' AND status='completed'
        ) x ON x.created_at::date = d::date
       GROUP BY d, x.currency ORDER BY d`),
    trialBalance(pool),
    pool.query(`SELECT COUNT(*)::int AS n, MIN(created_at) AS oldest FROM kyc_submissions WHERE status='pending'`),
  ]);

  const byDay = new Map<string, number>();
  for (const r of daily.rows) {
    const k = new Date(r.day).toISOString().slice(0, 10);
    byDay.set(k, (byDay.get(k) ?? 0) + (r.currency ? toUsd(r.amount, r.currency) : 0));
  }
  const vol = volume.rows.map((r) => ({ ...r, amount_usd: toUsd(r.amount, r.currency) }));
  const sumUsd = (kind: string) => vol.filter((v) => v.kind === kind).reduce((s, v) => s + v.amount_usd, 0);

  return {
    users: users.rows[0],
    merchants: Object.fromEntries(merchants.rows.map((r) => [r.status, r.n])),
    open_alerts: { low: 0, medium: 0, high: 0, ...Object.fromEntries(alerts.rows.map((r) => [r.severity, r.n])) },
    kyc_queue: { pending: pendingKyc.rows[0].n, oldest: pendingKyc.rows[0].oldest },
    volume_24h: {
      payments_usd: sumUsd('card_and_wallet_payments'),
      transfers_usd: sumUsd('transfers'),
      top_ups_usd: sumUsd('top_ups'),
      detail: vol,
    },
    revenue: {
      fees: revenue.rows,
      fees_usd: revenue.rows.reduce((s, r) => s + toUsd(r.amount, r.currency), 0),
      fx_margin_usd: fx.rows.reduce((s, r) => s + toUsd(r.amount, r.currency), 0),
    },
    daily_volume_usd: [...byDay].map(([day, amount_usd]) => ({ day, amount_usd })),
    ledger: { balanced: tb.every((r) => Number(r.debits) === Number(r.credits)), currencies: tb },
  };
}

// ------------------------------------------------------------------ transactions
const TX_UNION = `
  SELECT 'payment'::text AS kind, pi.id,
         CASE WHEN pi.status='requires_payment_method' AND pi.decline_code IS NOT NULL THEN 'declined'
              WHEN pi.status='requires_payment_method' THEN 'incomplete' ELSE pi.status END AS status,
         CASE WHEN pi.amount_captured > 0 THEN pi.amount_captured ELSE pi.amount END AS amount, pi.currency,
         COALESCE(u.name, CASE WHEN t.id IS NOT NULL THEN initcap(t.brand) || ' •••• ' || t.last4 END, '—') AS from_label,
         m.name AS to_label, pi.wallet_user_id AS user_id, pi.merchant_id,
         COALESCE(pi.description, '') AS description, pi.fee, pi.created_at,
         CASE WHEN pi.wallet_user_id IS NOT NULL THEN 'Global Gold wallet' WHEN t.id IS NOT NULL THEN 'Card' END AS method
    FROM payment_intents pi
    JOIN merchants m ON m.id = pi.merchant_id
    LEFT JOIN card_tokens t ON t.id = pi.token_id
    LEFT JOIN users u ON u.id = pi.wallet_user_id
  UNION ALL
  SELECT 'refund', r.id, r.status, r.amount, pi.currency, m.name,
         COALESCE(u.name, 'Card refund'), pi.wallet_user_id, r.merchant_id, 'Refund of ' || pi.id, 0, r.created_at,
         CASE WHEN pi.wallet_user_id IS NOT NULL THEN 'Global Gold wallet' ELSE 'Card' END
    FROM refunds r JOIN payment_intents pi ON pi.id = r.payment_intent_id
    JOIN merchants m ON m.id = r.merchant_id LEFT JOIN users u ON u.id = pi.wallet_user_id
  UNION ALL
  SELECT CASE w.type WHEN 'transfer_out' THEN (CASE WHEN w.international THEN 'international_transfer' ELSE 'transfer' END)
                     WHEN 'conversion_out' THEN 'conversion' ELSE w.type END,
         w.id, w.status, abs(w.amount) - w.fee, w.currency,
         CASE WHEN w.type IN ('top_up') THEN COALESCE(w.note, 'Card') WHEN w.type = 'refund' THEN w.counterparty ELSE u.name END,
         CASE WHEN w.type IN ('top_up','refund') THEN u.name WHEN w.type = 'conversion_out' THEN u.name || ' (' || w.counter_currency || ')' ELSE w.counterparty END,
         w.user_id, NULL, COALESCE(w.note, ''), w.fee, w.created_at,
         CASE WHEN w.type = 'top_up' THEN 'Card' ELSE 'Global Gold wallet' END
    FROM wallet_transactions w JOIN users u ON u.id = w.user_id
   WHERE w.type NOT IN ('transfer_in', 'conversion_in', 'payment', 'business_payout')
  UNION ALL
  SELECT 'payout', p.id, p.status, p.amount, p.currency, m.name,
         CASE WHEN p.destination = 'wallet' THEN u.name || ' (wallet)' ELSE 'Bank account' END,
         p.wallet_user_id, p.merchant_id, 'Merchant payout', 0, p.created_at,
         CASE WHEN p.destination = 'wallet' THEN 'Global Gold wallet' ELSE 'Bank transfer' END
    FROM payouts p JOIN merchants m ON m.id = p.merchant_id LEFT JOIN users u ON u.id = p.wallet_user_id`;

export async function listTransactions(f: {
  kind?: string; status?: string; q?: string; currency?: string; flagged?: boolean;
  user?: string; merchant?: string; limit?: number; before?: string;
}) {
  const where: string[] = [], params: unknown[] = [];
  const add = (sql: string, v: unknown) => { params.push(v); where.push(sql.replace('?', `$${params.length}`)); };
  if (f.kind) add('x.kind = ?', f.kind);
  if (f.status) add('x.status = ?', f.status);
  if (f.currency) add('x.currency = ?', f.currency.toLowerCase());
  if (f.user) add('x.user_id = ?', f.user);
  if (f.merchant) add('x.merchant_id = ?', f.merchant);
  if (f.before) add('x.created_at < ?', f.before);
  if (f.q) add(`(x.id ILIKE ? OR x.from_label ILIKE $${params.length + 1} OR x.to_label ILIKE $${params.length + 1} OR x.description ILIKE $${params.length + 1})`, `%${f.q}%`);
  if (f.flagged) where.push(`EXISTS (SELECT 1 FROM alerts a WHERE a.subject_id = x.id AND a.status = 'open')`);
  params.push(Math.min(f.limit ?? 50, 200));
  const r = await pool.query(
    `SELECT x.*, (SELECT COUNT(*)::int FROM alerts a WHERE a.subject_id = x.id AND a.status = 'open') AS open_alerts
       FROM (${TX_UNION}) x
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY x.created_at DESC, x.id LIMIT $${params.length}`, params);
  return { object: 'list', data: r.rows.map((x) => ({ ...x, amount_usd: toUsd(x.amount, x.currency) })) };
}

export async function transactionDetail(id: string) {
  const summary = await one(pool, `SELECT * FROM (${TX_UNION}) x WHERE x.id = $1`, [id]);
  let record: any;
  if (id.startsWith('pi_')) {
    record = await one(pool, `SELECT pi.*, NULL AS client_secret, t.brand, t.last4, t.bin FROM payment_intents pi LEFT JOIN card_tokens t ON t.id = pi.token_id WHERE pi.id = $1`, [id]);
    if (record) delete record.client_secret;
  } else if (id.startsWith('re_')) record = await one(pool, 'SELECT * FROM refunds WHERE id = $1', [id]);
  else if (id.startsWith('wtx_')) record = await one(pool, 'SELECT * FROM wallet_transactions WHERE id = $1', [id]);
  else if (id.startsWith('po_')) record = await one(pool, 'SELECT * FROM payouts WHERE id = $1', [id]);
  if (!record) throw new ApiError(404, 'resource_missing', `No transaction ${id}.`);

  const [ledger, alerts, attempts] = await Promise.all([
    pool.query(`SELECT j.id AS journal_id, j.description, l.account, l.currency, l.debit, l.credit, l.created_at
                  FROM journals j JOIN ledger_lines l ON l.journal_id = j.id WHERE j.ref_id = $1 ORDER BY l.id`, [id]),
    pool.query(`SELECT * FROM alerts WHERE subject_id = $1 ORDER BY created_at DESC`, [id]),
    id.startsWith('pi_')
      ? pool.query(`SELECT outcome, response_code, risk_score, created_at FROM payment_attempts WHERE payment_intent_id = $1 ORDER BY id`, [id])
      : Promise.resolve({ rows: [] as any[] }),
  ]);
  return { summary, record, ledger: ledger.rows, alerts: alerts.rows, attempts: attempts.rows };
}

// ------------------------------------------------------------------ customers
export async function listUsers(f: { q?: string; kyc?: string; status?: string; limit?: number }) {
  const where: string[] = [], params: unknown[] = [];
  if (f.q) { params.push(`%${f.q}%`); where.push(`(u.email ILIKE $${params.length} OR u.name ILIKE $${params.length} OR u.id = $${params.length + 1})`); params.push(f.q); }
  if (f.kyc) { params.push(f.kyc); where.push(`u.kyc_status = $${params.length}`); }
  if (f.status) { params.push(f.status); where.push(`u.status = $${params.length}`); }
  params.push(Math.min(f.limit ?? 50, 200));
  const r = await pool.query(
    `SELECT u.id, u.email, u.name, u.country, u.currency, u.status, u.kyc_status, u.created_at,
            (SELECT COALESCE(SUM(credit - debit), 0)::bigint FROM ledger_lines l WHERE l.account = 'wallet:' || u.id AND l.currency = u.currency) AS home_balance,
            (SELECT COUNT(*)::int FROM alerts a WHERE a.user_id = u.id AND a.status = 'open') AS open_alerts
       FROM users u ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY u.created_at DESC LIMIT $${params.length}`, params);
  return { object: 'list', data: r.rows.map((u) => ({ ...u, country_name: COUNTRIES[u.country]?.name })) };
}

export async function userDetail(id: string) {
  const user = await one(pool, 'SELECT id, email, name, country, currency, status, locked_reason, kyc_status, created_at FROM users WHERE id = $1', [id]);
  if (!user) throw new ApiError(404, 'resource_missing', 'Customer not found.');
  const [balances, kyc, alerts, cards, txs] = await Promise.all([
    pool.query(`SELECT currency, (SUM(credit)-SUM(debit))::bigint AS amount FROM ledger_lines WHERE account = $1 GROUP BY currency ORDER BY currency`, [acct.wallet(id)]),
    pool.query(`SELECT id, legal_name, date_of_birth, address_line, city, postal_code, country, id_type, id_number_last4,
                       document_mime, status, reviewer_label, review_note, created_at, reviewed_at
                  FROM kyc_submissions WHERE user_id = $1 ORDER BY created_at DESC`, [id]),
    pool.query(`SELECT * FROM alerts WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`, [id]),
    pool.query(`SELECT id, brand, last4, exp_month, exp_year, removed_at FROM card_tokens WHERE user_id = $1 ORDER BY created_at`, [id]),
    listTransactions({ user: id, limit: 50 }),
  ]);
  return { user: { ...user, country_name: COUNTRIES[user.country]?.name }, balances: balances.rows, kyc: kyc.rows, alerts: alerts.rows, cards: cards.rows, transactions: txs.data };
}

export async function setUserLocked(staff: Staff, id: string, locked: boolean, reason?: string) {
  return tx(async (c) => {
    const u = await one(c, `UPDATE users SET status = $2, locked_reason = $3 WHERE id = $1 RETURNING id, status, locked_reason`,
      [id, locked ? 'locked' : 'active', locked ? reason ?? null : null]);
    if (!u) throw new ApiError(404, 'resource_missing', 'Customer not found.');
    if (locked) await c.query('DELETE FROM user_sessions WHERE user_id = $1', [id]);
    await audit(c, staff, locked ? 'user.freeze' : 'user.unfreeze', 'user', id, { reason });
    return u;
  });
}

// ------------------------------------------------------------------ KYC
export async function kycQueue(status = 'pending', limit = 100) {
  const r = await pool.query(
    `SELECT k.id, k.user_id, k.legal_name, k.date_of_birth, k.address_line, k.city, k.postal_code, k.country, k.id_type,
            k.id_number_last4, k.document_mime, k.status, k.reviewer_label, k.review_note, k.created_at, k.reviewed_at,
            u.email, u.name AS account_name, u.country AS account_country, u.created_at AS account_created_at,
            (SELECT COUNT(*)::int FROM alerts a WHERE a.subject_id = k.id AND a.status = 'open') AS open_alerts,
            (SELECT COUNT(DISTINCT k2.user_id)::int FROM kyc_submissions k2 WHERE k2.id_number_hash = k.id_number_hash AND k2.user_id <> k.user_id) AS duplicate_accounts
       FROM kyc_submissions k JOIN users u ON u.id = k.user_id
      WHERE k.status = $1
      ORDER BY CASE WHEN $1 = 'pending' THEN k.created_at END ASC, k.reviewed_at DESC NULLS LAST
      LIMIT $2`, [status, limit]);
  return {
    object: 'list',
    data: r.rows.map((k) => ({
      ...k,
      country_name: COUNTRIES[k.country]?.name,
      checks: {
        name_matches_account: k.legal_name.trim().toLowerCase() === k.account_name.trim().toLowerCase(),
        country_matches_account: k.country === k.account_country,
        duplicate_identity: k.duplicate_accounts > 0,
      },
    })),
  };
}

export async function kycDocument(id: string) {
  const r = await one(pool, 'SELECT document, document_mime FROM kyc_submissions WHERE id = $1', [id]);
  if (!r) throw new ApiError(404, 'resource_missing', 'Submission not found.');
  return r;
}

export async function decideKyc(staff: Staff, id: string, decision: 'approve' | 'reject', note?: string) {
  if (decision === 'reject' && !note?.trim()) throw new ApiError(400, 'reason_required', 'Give the customer a reason for the rejection.');
  return tx(async (c) => {
    const k = await one(c, 'SELECT * FROM kyc_submissions WHERE id = $1 FOR UPDATE', [id]);
    if (!k) throw new ApiError(404, 'resource_missing', 'Submission not found.');
    if (k.status !== 'pending') throw new ApiError(400, 'already_reviewed', `This submission was already ${k.status}.`);
    const status = decision === 'approve' ? 'approved' : 'rejected';
    await c.query(
      `UPDATE kyc_submissions SET status = $2, reviewer_label = $3, review_note = $4, reviewed_at = now() WHERE id = $1`,
      [id, status, `${staff.name} (${staff.email})`, note?.trim() || null]);
    await c.query('UPDATE users SET kyc_status = $2 WHERE id = $1', [k.user_id, status]);
    await audit(c, staff, `kyc.${decision}`, 'kyc_submission', id, { user_id: k.user_id, note });
    return { id, user_id: k.user_id, status };
  });
}

// ------------------------------------------------------------------ merchants
export async function listMerchants() {
  const r = await pool.query(
    `SELECT m.id, m.name, m.email, m.status, m.fee_bps, m.fee_fixed, m.max_amount, m.webhook_url IS NOT NULL AS has_webhook, m.created_at,
            m.country, m.website, m.business_type, m.description, m.review_note, m.payout_method,
            (SELECT u.name FROM users u WHERE u.id = m.payout_wallet_user_id) AS payout_wallet_name,
            (SELECT mu.name FROM merchant_users mu WHERE mu.merchant_id = m.id ORDER BY mu.created_at LIMIT 1) AS owner_name,
            (SELECT COUNT(*)::int FROM payment_intents p WHERE p.merchant_id = m.id AND p.status = 'succeeded') AS payments,
            (SELECT COALESCE(SUM(amount_captured),0)::bigint FROM payment_intents p WHERE p.merchant_id = m.id AND p.status = 'succeeded' AND p.currency = 'usd') AS volume_usd,
            (SELECT COALESCE(SUM(credit-debit),0)::bigint FROM ledger_lines l WHERE l.account = 'merchant:' || m.id || ':available' AND l.currency = 'usd') AS available_usd,
            (SELECT COUNT(*)::int FROM alerts a WHERE a.merchant_id = m.id AND a.status = 'open') AS open_alerts
       FROM merchants m ORDER BY (m.status = 'pending_review') DESC, m.created_at DESC`);
  return { object: 'list', data: r.rows.map((m) => ({ ...m, country_name: COUNTRIES[m.country]?.name })) };
}

export async function setMerchantStatus(staff: Staff, id: string, status: 'pending_review' | 'active' | 'suspended', reason?: string) {
  return tx(async (c) => {
    const m = await one(c, 'UPDATE merchants SET status = $2, review_note = COALESCE($3, review_note) WHERE id = $1 RETURNING id, name, status, review_note',
      [id, status, reason ?? null]);
    if (!m) throw new ApiError(404, 'resource_missing', 'Merchant not found.');
    if (status !== 'pending_review') {
      await c.query(
        `UPDATE alerts SET status = 'resolved', resolved_by = $2, resolution_note = $3, resolved_at = now()
          WHERE subject_id = $1 AND rule = 'business_review' AND status = 'open'`,
        [id, `${staff.name} (${staff.email})`, status === 'active' ? 'Business approved' : `Business ${status}`]);
    }
    await audit(c, staff, `merchant.${status}`, 'merchant', id, { reason });
    return m;
  });
}

// ------------------------------------------------------------------ alerts & audit
export async function listAlerts(f: { status?: string; severity?: string; limit?: number }) {
  const where: string[] = [], params: unknown[] = [];
  if (f.status) { params.push(f.status); where.push(`a.status = $${params.length}`); }
  if (f.severity) { params.push(f.severity); where.push(`a.severity = $${params.length}`); }
  params.push(Math.min(f.limit ?? 100, 500));
  const r = await pool.query(
    `SELECT a.*, u.name AS user_name, u.email AS user_email, u.status AS user_status, m.name AS merchant_name
       FROM alerts a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN merchants m ON m.id = a.merchant_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY CASE a.severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, a.created_at DESC
      LIMIT $${params.length}`, params);
  return { object: 'list', data: r.rows };
}

export async function resolveAlert(staff: Staff, id: string, resolution: 'resolved' | 'dismissed', note?: string) {
  return tx(async (c) => {
    const a = await one(c,
      `UPDATE alerts SET status = $2, resolved_by = $3, resolution_note = $4, resolved_at = now()
        WHERE id = $1 AND status = 'open' RETURNING *`,
      [id, resolution, `${staff.name} (${staff.email})`, note ?? null]);
    if (!a) throw new ApiError(400, 'alert_not_open', 'This alert is not open.');
    await audit(c, staff, `alert.${resolution}`, 'alert', id, { note });
    return a;
  });
}

export async function auditLog(limit = 100) {
  const r = await pool.query('SELECT * FROM audit_log ORDER BY created_at DESC, id DESC LIMIT $1', [Math.min(limit, 500)]);
  return { object: 'list', data: r.rows };
}
