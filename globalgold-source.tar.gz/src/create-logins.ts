/**
 * Give one person a login to every part of the platform.
 *
 *   ggp logins you@example.com
 *
 * There are three separate account systems here, and that is deliberate:
 *
 *   /admin      platform staff — approves businesses, sees every transaction
 *   /dashboard  one business — sees only its own money
 *   /wallet     one customer — holds a balance, sends and receives
 *
 * They are separate because they are different ROLES, not different doors to
 * one account. A platform operator who is also a merchant cannot answer "who
 * approved this business, and were they the business?", which is the first
 * question a sponsor bank or a PCI assessor asks about separation of duties.
 *
 * What this does NOT do is merge them. It creates one account in each with the
 * same email and the same password, so one person can reach all three without
 * three sets of credentials — while they stay three accounts that can be
 * audited, disabled and given away independently.
 *
 * The password is read from stdin, never argv or the environment: an argument
 * is visible in `ps` and lands in the shell's history file.
 *
 * Safe to run again. An account that already exists has its password set
 * rather than being duplicated or erroring.
 */
import { parseArgs } from 'node:util';
import { one, pool } from './db.js';
import { createStaff, setStaffPassword, MIN_PASSWORD_LENGTH } from './admin/staff.js';
import { businessSignUp } from './merchants/accounts.js';
import { hashPassword } from './util/passwords.js';

const { values } = parseArgs({
  options: {
    email: { type: 'string' },
    name: { type: 'string' },
    business: { type: 'string' },
    country: { type: 'string', default: 'US' },
    activate: { type: 'boolean', default: false },
  },
});

if (!values.email) {
  console.error('Usage: node dist/create-logins.js --email you@example.com [--name "Your Name"] [--business "Trading name"] [--country US] [--activate]');
  process.exit(1);
}

const email = values.email.trim().toLowerCase();
const name = values.name?.trim() || email.split('@')[0]!;
const businessName = values.business?.trim() || `${name}'s business`;

const chunks: Buffer[] = [];
for await (const c of process.stdin) chunks.push(Buffer.from(c));
const password = Buffer.concat(chunks).toString('utf8').replace(/\r?\n$/, '');

if (password.length < MIN_PASSWORD_LENGTH) {
  console.error(`That password is ${password.length} characters. Use at least ${MIN_PASSWORD_LENGTH}.`);
  process.exit(1);
}

const done: string[] = [];
const notes: string[] = [];

// ───────────────────────────────────────────────────────────── /admin
try {
  const existing = await one(pool, 'SELECT id FROM admin_users WHERE email = $1', [email]);
  if (existing) {
    await setStaffPassword(email, password);
    done.push('admin       password set on the existing account');
  } else {
    await createStaff({ email, name, password, role: 'owner' });
    done.push('admin       created as owner');
  }
} catch (e: any) {
  notes.push(`admin: ${e?.message ?? e}`);
}

// ───────────────────────────────────────────────────────── /dashboard
try {
  const existing = await one<{ id: string; merchant_id: string }>(pool,
    'SELECT id, merchant_id FROM merchant_users WHERE email = $1', [email]);
  if (existing) {
    await pool.query('UPDATE merchant_users SET password_hash = $2 WHERE id = $1',
      [existing.id, await hashPassword(password)]);
    await pool.query('DELETE FROM merchant_sessions WHERE merchant_user_id = $1', [existing.id]);
    done.push('business    password set on the existing account');
    if (values.activate) {
      await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [existing.merchant_id]);
      done.push('business    approved, so it can take payments');
    }
  } else {
    const r = await businessSignUp({
      business_name: businessName, name, email, password,
      country: (values.country ?? 'US').toUpperCase(), business_type: 'company',
    });
    done.push(`business    created — "${businessName}"`);
    if (values.activate) {
      await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [r.merchant_id]);
      done.push('business    approved, so it can take payments');
    } else {
      notes.push('The business is pending review, which is correct — approve it in /admin → Businesses, '
        + 'or rerun this with --activate.');
    }
  }
} catch (e: any) {
  notes.push(`business: ${e?.message ?? e}`);
}

// ──────────────────────────────────────────────────────────── /wallet
// The wallet is optional — a platform that only does merchant acquiring may
// have it switched off, and that is not an error worth failing over.
try {
  const wallet = await import('./wallet/wallet.js');
  const existing = await one<{ id: string }>(pool, 'SELECT id FROM users WHERE email = $1', [email]);
  if (existing) {
    await pool.query('UPDATE users SET password_hash = $2 WHERE id = $1',
      [existing.id, await hashPassword(password)]);
    await pool.query('DELETE FROM user_sessions WHERE user_id = $1', [existing.id]);
    done.push('wallet      password set on the existing account');
  } else {
    await wallet.signUp({ email, name, password, country: (values.country ?? 'US').toUpperCase() });
    done.push('wallet      created');
  }
} catch (e: any) {
  notes.push(`wallet: ${e?.message ?? e} (the wallet may be turned off on this machine — harmless)`);
}

const url = process.env.PUBLIC_URL ?? 'http://localhost:8080';
console.log('');
for (const d of done) console.log(`  ${d}`);
console.log('');
console.log(`  Sign in with ${email} and the password you just typed:`);
console.log('');
console.log(`    ${url}/admin        run the platform`);
console.log(`    ${url}/dashboard    take payments as a business`);
console.log(`    ${url}/wallet       hold a balance as a customer`);
console.log('');
if (notes.length) {
  for (const n of notes) console.log(`  note: ${n}`);
  console.log('');
}
console.log('  These are three separate accounts sharing one password, not one');
console.log('  account. That is on purpose — see src/create-logins.ts.');
console.log('');

await pool.end();
