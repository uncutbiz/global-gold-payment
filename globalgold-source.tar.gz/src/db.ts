import fs from 'node:fs';
import pg from 'pg';
import { config } from './config.js';

// BIGINT (int8) -> JS number. Safe for amounts below 2^53 minor units.
pg.types.setTypeParser(20, (v) => Number(v));

function sslOptions() {
  if (config.databaseSsl === 'off') return undefined;
  if (config.databaseSsl === 'no-verify') {
    console.warn(JSON.stringify({ level: 'warn', msg: 'DATABASE_SSL=no-verify: the database certificate is not being checked. Add a CA bundle and switch to require.' }));
    return { rejectUnauthorized: false };
  }
  if (!config.databaseCaFile) return { rejectUnauthorized: true };
  if (!fs.existsSync(config.databaseCaFile)) {
    throw new Error(`DATABASE_CA_FILE ${config.databaseCaFile} is missing. Run "npm run fetch-rds-ca" before building the image, or set DATABASE_SSL=no-verify.`);
  }
  return { rejectUnauthorized: true, ca: fs.readFileSync(config.databaseCaFile, 'utf8') };
}

const ssl = sslOptions();

export const pool = new pg.Pool({
  connectionString: config.databaseUrl,
  max: Number(process.env.DB_POOL_MAX ?? 20),
  ssl,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
});
pool.on('error', (err) => console.error(JSON.stringify({ level: 'error', msg: 'postgres pool error', err: err.message })));

export type Db = pg.Pool | pg.PoolClient;

export async function tx<T>(fn: (c: pg.PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

export async function one<T = any>(db: Db, sql: string, params: unknown[] = []): Promise<T | undefined> {
  const r = await db.query(sql, params);
  return r.rows[0] as T | undefined;
}
