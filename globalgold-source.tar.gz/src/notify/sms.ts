/**
 * Sending an SMS.
 *
 * Same shape as the payment providers: one interface, a file per service, and
 * nothing above this layer knows which one is in use. Picked by SMS_PROVIDER.
 *
 *   twilio   the usual choice; needs an A2P-registered number in the US
 *   aws      AWS End User Messaging / SNS, for an account already on AWS
 *   console  logs the message instead of sending it — development and tests
 *
 * `console` is the default ON PURPOSE. A misconfigured deployment that quietly
 * logs codes is recoverable; one that silently fails to send them locks every
 * user out of their account with no error anyone can see.
 */
import crypto from 'node:crypto';

export interface SmsResult { sent: boolean; id?: string; error?: string }

export interface SmsProvider {
  readonly name: string;
  send(to: string, body: string): Promise<SmsResult>;
}

/**
 * Normalise to E.164, or null if it cannot be.
 *
 * Strict on purpose. A number that is merely "probably fine" ends up as an
 * account's only recovery route, and the failure shows up months later when
 * someone actually needs it.
 */
export function toE164(raw: string, defaultCountryCode = '1'): string | null {
  if (!raw) return null;
  const trimmed = String(raw).trim();
  const hasPlus = trimmed.startsWith('+');
  const digits = trimmed.replace(/\D/g, '');
  if (!digits) return null;

  // Already international.
  if (hasPlus) return digits.length >= 8 && digits.length <= 15 ? `+${digits}` : null;
  // A bare national number with a leading trunk zero, e.g. UK 07… — the zero
  // is dropped when the country code goes on.
  if (digits.startsWith('00')) {
    const rest = digits.slice(2);
    return rest.length >= 8 && rest.length <= 15 ? `+${rest}` : null;
  }
  if (digits.length === 10 && defaultCountryCode === '1') return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith('1') && defaultCountryCode === '1') return `+${digits}`;
  return null;
}

/** What a number looks like in a log or a reply: enough to recognise, not enough to dial. */
export function maskPhone(e164: string): string {
  return e164.length <= 4 ? '••••' : `${e164.slice(0, 3)}••••${e164.slice(-2)}`;
}

// ---------------------------------------------------------------------- console

class ConsoleSms implements SmsProvider {
  readonly name = 'console';
  async send(to: string, body: string): Promise<SmsResult> {
    // The code is deliberately visible here — this provider exists so a
    // developer can complete the flow without a phone. It must never be the
    // provider in production, which is why the config warns loudly.
    console.log(JSON.stringify({ level: 'warn', msg: 'SMS not sent (console provider)', to, body }));
    return { sent: true, id: `console_${crypto.randomBytes(6).toString('hex')}` };
  }
}

// ----------------------------------------------------------------------- twilio

export interface TwilioConfig {
  accountSid: string; authToken: string; from: string;
  fetchImpl?: typeof fetch; timeoutMs?: number;
}

class TwilioSms implements SmsProvider {
  readonly name = 'twilio';
  private readonly doFetch: typeof fetch;
  constructor(private readonly cfg: TwilioConfig) {
    this.doFetch = cfg.fetchImpl ?? fetch;
  }
  async send(to: string, body: string): Promise<SmsResult> {
    const url = `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(this.cfg.accountSid)}/Messages.json`;
    const form = new URLSearchParams({ To: to, From: this.cfg.from, Body: body });
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), this.cfg.timeoutMs ?? 12_000);
    try {
      const res = await this.doFetch(url, {
        method: 'POST',
        headers: {
          Authorization: 'Basic ' + Buffer.from(`${this.cfg.accountSid}:${this.cfg.authToken}`).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: form.toString(),
        signal: ac.signal,
      });
      const json: any = await res.json().catch(() => ({}));
      if (!res.ok) return { sent: false, error: json?.message ?? `Twilio returned ${res.status}` };
      return { sent: true, id: json?.sid };
    } catch (e: any) {
      return { sent: false, error: e?.name === 'AbortError' ? 'Twilio did not respond in time.' : 'Could not reach Twilio.' };
    } finally {
      clearTimeout(timer);
    }
  }
}

// -------------------------------------------------------------------------- aws

export interface AwsSmsConfig {
  region: string;
  /** Left empty to use the instance role, which is the better way on EC2. */
  accessKeyId?: string; secretAccessKey?: string; sessionToken?: string;
  senderId?: string;
  fetchImpl?: typeof fetch; timeoutMs?: number;
}

/**
 * AWS SNS Publish to a phone number, signed with SigV4.
 *
 * Signed by hand rather than pulling in the AWS SDK: this is one request to one
 * endpoint, and the SDK is tens of megabytes of dependency for it. The signing
 * is the fiddly part, so it is written out step by step rather than cleverly.
 */
class AwsSms implements SmsProvider {
  readonly name = 'aws';
  private readonly doFetch: typeof fetch;
  constructor(private readonly cfg: AwsSmsConfig) {
    this.doFetch = cfg.fetchImpl ?? fetch;
  }

  private hmac(key: crypto.BinaryLike | Buffer, data: string): Buffer {
    return crypto.createHmac('sha256', key).update(data, 'utf8').digest();
  }

  async send(to: string, body: string): Promise<SmsResult> {
    const { region } = this.cfg;
    const host = `sns.${region}.amazonaws.com`;
    const params = new URLSearchParams({
      Action: 'Publish', Version: '2010-03-31',
      PhoneNumber: to, Message: body,
      // Transactional, not promotional: a one-time code must not be dropped
      // in favour of a marketing message, and must reach opted-out numbers.
      'MessageAttributes.entry.1.Name': 'AWS.SNS.SMS.SMSType',
      'MessageAttributes.entry.1.Value.DataType': 'String',
      'MessageAttributes.entry.1.Value.StringValue': 'Transactional',
    });
    if (this.cfg.senderId) {
      params.set('MessageAttributes.entry.2.Name', 'AWS.SNS.SMS.SenderID');
      params.set('MessageAttributes.entry.2.Value.DataType', 'String');
      params.set('MessageAttributes.entry.2.Value.StringValue', this.cfg.senderId);
    }
    const payload = params.toString();

    const key = this.cfg.accessKeyId ?? process.env.AWS_ACCESS_KEY_ID;
    const secret = this.cfg.secretAccessKey ?? process.env.AWS_SECRET_ACCESS_KEY;
    const token = this.cfg.sessionToken ?? process.env.AWS_SESSION_TOKEN;
    if (!key || !secret) {
      return { sent: false, error: 'No AWS credentials. Attach an instance role, or set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY.' };
    }

    const now = new Date();
    const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '');
    const dateStamp = amzDate.slice(0, 8);
    const hash = (s: string) => crypto.createHash('sha256').update(s, 'utf8').digest('hex');

    const signedHeaders = token ? 'content-type;host;x-amz-date;x-amz-security-token' : 'content-type;host;x-amz-date';
    const canonicalHeaders =
      'content-type:application/x-www-form-urlencoded; charset=utf-8\n'
      + `host:${host}\n`
      + `x-amz-date:${amzDate}\n`
      + (token ? `x-amz-security-token:${token}\n` : '');
    const canonicalRequest = ['POST', '/', '', canonicalHeaders, signedHeaders, hash(payload)].join('\n');
    const scope = `${dateStamp}/${region}/sns/aws4_request`;
    const toSign = ['AWS4-HMAC-SHA256', amzDate, scope, hash(canonicalRequest)].join('\n');

    const kDate = this.hmac(`AWS4${secret}`, dateStamp);
    const kRegion = this.hmac(kDate, region);
    const kService = this.hmac(kRegion, 'sns');
    const kSigning = this.hmac(kService, 'aws4_request');
    const signature = crypto.createHmac('sha256', kSigning).update(toSign, 'utf8').digest('hex');

    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), this.cfg.timeoutMs ?? 12_000);
    try {
      const res = await this.doFetch(`https://${host}/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
          'X-Amz-Date': amzDate,
          ...(token ? { 'X-Amz-Security-Token': token } : {}),
          Authorization: `AWS4-HMAC-SHA256 Credential=${key}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`,
        },
        body: payload,
        signal: ac.signal,
      });
      const text = await res.text();
      if (!res.ok) {
        return { sent: false, error: (text.match(/<Message>([^<]+)<\/Message>/)?.[1] ?? `SNS returned ${res.status}`) };
      }
      return { sent: true, id: text.match(/<MessageId>([^<]+)<\/MessageId>/)?.[1] };
    } catch (e: any) {
      return { sent: false, error: e?.name === 'AbortError' ? 'AWS did not respond in time.' : 'Could not reach AWS.' };
    } finally {
      clearTimeout(timer);
    }
  }
}

// ----------------------------------------------------------------------- picker

let cached: SmsProvider | undefined;

export function smsProvider(): SmsProvider {
  if (cached) return cached;
  const want = (process.env.SMS_PROVIDER ?? 'console').toLowerCase();

  if (want === 'twilio') {
    const accountSid = process.env.TWILIO_ACCOUNT_SID ?? '';
    const authToken = process.env.TWILIO_AUTH_TOKEN ?? '';
    const from = process.env.TWILIO_FROM ?? '';
    if (!accountSid || !authToken || !from) {
      throw new Error('SMS_PROVIDER=twilio needs TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_FROM.');
    }
    cached = new TwilioSms({ accountSid, authToken, from });
  } else if (want === 'aws') {
    cached = new AwsSms({
      region: process.env.AWS_REGION ?? process.env.SMS_AWS_REGION ?? 'us-east-2',
      senderId: process.env.SMS_SENDER_ID || undefined,
    });
  } else {
    cached = new ConsoleSms();
  }
  return cached;
}

/** Tests replace the provider rather than stubbing global fetch. */
export function setSmsProvider(p: SmsProvider | undefined) { cached = p; }

export { ConsoleSms, TwilioSms, AwsSms };
