/**
 * The provider registry.
 *
 * Global Gold is not tied to one processor. Several can be enabled at once, and
 * each merchant is routed to whichever one can actually serve them:
 *
 *   - A merchant that has already connected an account keeps that provider,
 *     forever. Changing it would strand their payment history.
 *   - A new merchant is offered the providers that support their country.
 *   - Square covers US, CA, GB, AU, the eurozone and JP.
 *   - Stripe covers those plus Nigeria, Kenya, India, Brazil, Mexico and more —
 *     which is the whole reason for having two.
 *
 * Enable them with PAYMENT_PROVIDERS=square,stripe. The first one listed that
 * supports a country is the default offered for it.
 *
 * To add a third: write src/providers/<name>.ts implementing PaymentProvider,
 * add a case to build() below, and add its name to the config type. Nothing
 * else in the codebase changes.
 */
import { config } from '../config.js';
import { ApiError } from '../util/common.js';
import { PaymentProvider, platformFee, ProviderName } from './provider.js';
import { SimulatedProvider } from './simulated.js';
import { SquareProvider } from './square.js';
import { StripeProvider } from './stripe.js';

function build(name: ProviderName): PaymentProvider {
  switch (name) {
    case 'square':
      return new SquareProvider({
        env: config.square.env,
        appId: config.square.appId,
        appSecret: config.square.appSecret,
        webhookSignatureKey: config.square.webhookSignatureKey,
        platformAccessToken: config.square.platformAccessToken,
      });
    case 'stripe':
      return new StripeProvider({
        secretKey: config.stripe.secretKey,
        clientId: config.stripe.clientId,
        webhookSecret: config.stripe.webhookSecret,
      });
    case 'simulated':
      return new SimulatedProvider();
    default: {
      const never: never = name;
      throw new Error(`Unknown payment provider: ${never}`);
    }
  }
}

/** Every enabled provider, in the order they were configured. */
export const providers: readonly PaymentProvider[] = config.paymentProviders.map(build);

const byName = new Map<string, PaymentProvider>(providers.map((p) => [p.name, p]));

/** The one used when nothing else decides — the first enabled. */
export const defaultProvider: PaymentProvider = providers[0]!;

/**
 * Backwards-compatible single-provider accessor. Code that charges a specific
 * merchant should use providerFor() instead, so that two merchants on different
 * processors both work.
 */
export const provider: PaymentProvider = defaultProvider;

export function providerNamed(name: string): PaymentProvider {
  const p = byName.get(name);
  if (!p) {
    throw new ApiError(400, 'unknown_provider',
      `${name} is not enabled here. Available: ${[...byName.keys()].join(', ')}.`);
  }
  return p;
}

export function isEnabled(name: string): boolean {
  return byName.has(name);
}

/** Providers that can onboard a business in this country, best first. */
export function providersForCountry(country: string): PaymentProvider[] {
  const c = country.toUpperCase();
  return providers.filter((p) => p.merchantCountries.includes(c));
}

/** The provider a new merchant in this country should be offered. */
export function defaultProviderForCountry(country: string): PaymentProvider | undefined {
  return providersForCountry(country)[0];
}

/**
 * The provider to use for a merchant.
 * A merchant that has already connected one keeps it; otherwise it is chosen
 * from their country. Throws a readable error when no enabled provider can
 * serve that country at all.
 */
export function providerFor(merchant: { provider?: string | null; country?: string | null }): PaymentProvider {
  if (merchant.provider && byName.has(merchant.provider)) return byName.get(merchant.provider)!;
  const country = merchant.country ?? '';
  const chosen = defaultProviderForCountry(country);
  if (chosen) return chosen;
  if (!merchant.provider && providers.length === 1) return defaultProvider;
  throw new ApiError(400, 'country_not_supported',
    `No enabled processor can onboard a business in ${country || 'that country'}. ` +
    `Enabled: ${providers.map((p) => p.name).join(', ')}.`);
}

/** True when any enabled provider can serve this country. */
export function supportsCountry(country: string): boolean {
  return providersForCountry(country).length > 0;
}

/** Our platform fee for an amount, from configuration. */
export function ourFee(amount: number): number {
  return platformFee(amount, config.platformFeeBps, config.platformFeeFixed);
}

/** Refund our fee in proportion to a partial refund. */
export function ourFeeRefund(originalAmount: number, refundAmount: number): number {
  if (originalAmount <= 0 || refundAmount <= 0) return 0;
  const full = ourFee(originalAmount);
  if (refundAmount >= originalAmount) return full;
  return Math.floor((full * refundAmount) / originalAmount);
}

export * from './provider.js';
