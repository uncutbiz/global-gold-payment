/**
 * Payment provider interface.
 *
 * Global Gold is a payments *platform*: merchants use our API and dashboard, and
 * a provider underneath does the regulated work — acquiring, merchant KYB,
 * payouts, disputes. We take our cut as a platform fee on each payment.
 *
 *   square    — Square Payments API with app_fee_money (US, CA, GB, AU, EU, JP)
 *   stripe    — PaymentIntents on connected accounts with application_fee_amount;
 *               reaches the countries Square will not onboard (NG, KE, IN, …)
 *   simulated — the built-in ISO 8583 test network, for development and tests
 *
 * Nothing above this layer knows which provider is in use, so adding one is a
 * new file plus a line in index.ts — never a rewrite.
 *
 * IMPORTANT: a provider with `tokenizesInBrowser` never receives a card number.
 * The browser tokenises with the provider's own SDK and we only ever see the
 * resulting single-use token. That is what keeps card data out of our servers
 * and our PCI scope at SAQ A instead of a full Level 1 assessment.
 */

export type ProviderName = 'simulated' | 'square' | 'stripe';

/** Where the money comes from. */
export type PaymentSource =
  /** A single-use token produced in the browser by the provider's SDK. */
  | { kind: 'provider_token'; token: string; verificationToken?: string }
  /** A raw card. Only the simulated provider accepts this. */
  | { kind: 'pan'; pan: string; exp_month: number; exp_year: number }
  /**
   * A card the provider already holds for this buyer. Used by recurring
   * payments, where nobody is at the keyboard to enter anything.
   */
  | { kind: 'saved_card'; cardId: string; customerId?: string | null };

/** The merchant being paid, as the provider knows them. */
export interface ProviderMerchant {
  id: string;
  /** The provider's id for this seller (Square merchant id, Stripe acct_…). */
  accountId?: string | null;
  /** OAuth access token for acting on the seller's behalf. */
  accessToken?: string | null;
  /** Square sellers take payments against a location. */
  locationId?: string | null;
}

export interface ChargeRequest {
  amount: number;
  currency: string;
  source: PaymentSource;
  merchant: ProviderMerchant;
  /** Our platform fee in minor units. The provider pays it to us directly. */
  platformFee?: number;
  /** false authorises only, leaving the capture for later. */
  capture: boolean;
  /** Our own id for this payment, so both sides can be reconciled. */
  reference?: string;
  /** Same key ⇒ same payment. Never charge twice because of a retry. */
  idempotencyKey: string;
  note?: string;
  buyerEmail?: string;
}

export interface ProviderResult {
  approved: boolean;
  /** The provider's id for the payment, needed to capture, void or refund it. */
  providerPaymentId?: string;
  /** Issuer authorisation code, when the provider exposes it. */
  authCode?: string;
  /** A reference we can show on statements and reconcile against. */
  networkRef: string;
  declineCode?: string;
  declineMessage?: string;
  /** What the provider actually took as our platform fee. */
  platformFee?: number;
  /** Provider processing fee, when reported (Square reports it after settlement). */
  providerFee?: number;
  status?: string;
}

export interface CaptureRequest {
  providerPaymentId: string;
  merchant: ProviderMerchant;
  /** Minor units. Some providers only allow capturing the full amount. */
  amount?: number;
  currency: string;
  idempotencyKey: string;
}

export interface RefundRequest {
  providerPaymentId: string;
  merchant: ProviderMerchant;
  amount: number;
  currency: string;
  idempotencyKey: string;
  reason?: string;
  /** Give back our platform fee in proportion to the refund. */
  platformFeeRefund?: number;
  /**
   * The card again, for a provider that has no stored payment to refund
   * against. Only the simulated network needs this — Square and Stripe refund
   * by their own payment id and would refuse a card number here.
   */
  source?: PaymentSource;
}

export interface OnboardingStart {
  url: string;
  state: string;
}

export interface OnboardingResult {
  accountId: string;
  accessToken: string;
  refreshToken?: string;
  expiresAt?: Date;
  locationId?: string;
  businessName?: string;
  currency?: string;
  country?: string;
}

/** Ask the provider to keep this card for future, unattended charges. */
export interface SaveCardRequest {
  /** The same single-use token a one-off payment would use. */
  source: PaymentSource;
  merchant: ProviderMerchant;
  idempotencyKey: string;
  /** Our customer, so the provider can file the card against its own record. */
  customerRef: string;
  email?: string | null;
  name?: string | null;
  /** The provider's existing customer id, when this buyer already has one. */
  providerCustomerId?: string | null;
}

export interface SavedCardResult {
  /** The provider's id for the stored card, to charge later. */
  cardId: string;
  /** The provider's customer id, to reuse for the next card. */
  customerId?: string | null;
  brand?: string;
  last4?: string;
  expMonth?: number;
  expYear?: number;
}

export interface PaymentProvider {
  readonly name: ProviderName;

  /** True when card data is tokenised in the browser and never reaches us. */
  readonly tokenizesInBrowser: boolean;

  /**
   * True when the provider can hold a card for later, unattended charges.
   * Without this a merchant on that provider cannot offer subscriptions, and
   * saying so up front is better than failing on the first renewal.
   */
  readonly supportsSavedCards: boolean;

  /** File a card against the provider's own customer record. */
  saveCard?(req: SaveCardRequest): Promise<SavedCardResult>;

  /** Countries whose merchants this provider can onboard, ISO 3166-1 alpha-2. */
  readonly merchantCountries: readonly string[];

  charge(req: ChargeRequest): Promise<ProviderResult>;
  capture(req: CaptureRequest): Promise<ProviderResult>;
  /** Cancel an authorisation that was never captured. */
  void(req: CaptureRequest): Promise<ProviderResult>;
  refund(req: RefundRequest): Promise<ProviderResult>;

  /** Send the merchant to the provider to connect their account. */
  startOnboarding?(merchantId: string, redirectUri: string): OnboardingStart;
  /** Exchange the code the provider redirects back with for tokens. */
  completeOnboarding?(code: string, redirectUri: string): Promise<OnboardingResult>;
  /** Refresh an access token that is close to expiring. */
  refreshAccess?(refreshToken: string): Promise<OnboardingResult>;

  /** Verify a provider webhook. Must be constant-time. */
  verifyWebhook?(rawBody: string, headers: Record<string, string | undefined>, notificationUrl: string): boolean;
}

/** Our platform fee, in minor units, rounded half-up. */
export function platformFee(amount: number, bps: number, fixed = 0): number {
  if (amount <= 0) return 0;
  return Math.floor((amount * bps + 5000) / 10000) + fixed;
}

export class ProviderError extends Error {
  constructor(
    message: string,
    readonly code: string = 'provider_error',
    readonly retryable = false,
    readonly detail?: unknown,
  ) {
    super(message);
    this.name = 'ProviderError';
  }
}
