/**
 * Changes a staff account's password, and ends that account's live sessions.
 *
 *   ggp set-password you@example.com          (on a server)
 *   npm run set-password -- --email you@…      (locally; password on stdin)
 *
 * The password is read from **stdin** — never from argv, never from the
 * environment. An argument is visible to every user on the box in `ps` output
 * and is written to the shell's history file; an environment variable is
 * visible in /proc and in a sudo log. Neither is a place a staff credential for
 * a payments platform should ever appear.
 *
 * The work itself is setStaffPassword(), so this and any future
 * change-your-own-password screen in the admin panel behave identically.
 */
import { parseArgs } from 'node:util';
import { MIN_PASSWORD_LENGTH, setStaffPassword } from './admin/staff.js';
import { pool } from './db.js';

const { values } = parseArgs({ options: { email: { type: 'string' } } });
if (!values.email) {
  console.error('Usage: node dist/set-password.js --email you@example.com   (new password on stdin)');
  process.exit(1);
}

const chunks: Buffer[] = [];
for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk));
// Strip one trailing newline and nothing else: `echo | …` adds one, and a
// password may legitimately contain spaces, so this must not trim generally.
const password = Buffer.concat(chunks).toString('utf8').replace(/\r?\n$/, '');

if (password.length < MIN_PASSWORD_LENGTH) {
  console.error(`That password is ${password.length} characters. Use at least ${MIN_PASSWORD_LENGTH}.`);
  process.exit(1);
}

try {
  const { staff, sessionsEnded } = await setStaffPassword(values.email, password);
  console.log(`Password changed for ${staff.role} ${staff.email}.`);
  console.log(sessionsEnded
    ? `${sessionsEnded} signed-in session${sessionsEnded === 1 ? '' : 's'} ended — sign in again with the new password.`
    : 'No sessions were signed in.');
} catch (e) {
  console.error(e instanceof Error ? e.message : String(e));
  console.error(`List the accounts that exist with: ggp staff`);
  await pool.end();
  process.exit(1);
}
await pool.end();
