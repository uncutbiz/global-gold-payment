/**
 * Fills a fresh database with demo data, then exits.
 *
 *   node dist/demo-seed.js
 *
 * The demo stack (docker-compose.demo.yml) runs this once before the app starts,
 * so the platform you open already has businesses, customers, payments and a
 * couple of things waiting in the admin queues.
 *
 * It does the whole job in one process — migrate, start the server on a loopback
 * port, drive the public API through src/seed.ts, stop — because the alternative
 * is a shell script juggling a background server, and that is how you get a
 * seeder that silently runs against a server which was not listening yet.
 *
 * Running it twice is safe: it notices existing data, leaves it alone, and
 * re-prints the sign-in details from the copy it kept the first time. Those
 * details include a generated admin password and a generated API key, which
 * exist nowhere else in readable form, so if they were only ever printed to a
 * log the second `up` would leave you locked out of your own demo.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createApp } from './server.js';
import { config } from './config.js';
import { pool } from './db.js';
import { migrate } from './migrate.js';

/**
 * Where the sign-in details are kept between runs. A Docker volume in the demo
 * stack; a plain file otherwise. Demo-only credentials for a simulated card
 * network on a loopback port — see the notice in docker-compose.demo.yml.
 */
const notesDir = process.env.DEMO_STATE_DIR ?? '/state';
const notesFile = path.join(notesDir, 'demo-credentials.txt');

function remember(text: string) {
  try {
    fs.mkdirSync(notesDir, { recursive: true });
    fs.writeFileSync(notesFile, text, { mode: 0o600 });
  } catch (e) {
    // Not fatal: the details were just printed. Say why they will not come back.
    console.warn(`(Could not save the sign-in details to ${notesFile}: ${(e as Error).message})`);
  }
}

function recall(): string | null {
  try { return fs.readFileSync(notesFile, 'utf8'); } catch { return null; }
}

await migrate();

// Already seeded? Leave the data alone — this runs on every `up` — but still
// print the sign-in details, because that is what the person is looking for.
const existing = await pool.query<{ n: number }>('SELECT count(*)::int AS n FROM merchants');
if ((existing.rows[0]?.n ?? 0) > 0) {
  console.log('Demo data is already there, leaving it alone.');
  const kept = recall();
  if (kept) console.log(kept);
  else console.log(
    'The sign-in details were printed when the data was first created, and were not kept.\n'
    + 'To start over with a fresh set:\n'
    + '    docker compose -f docker-compose.demo.yml down -v\n'
    + '    docker compose -f docker-compose.demo.yml up -d',
  );
  await pool.end();
  process.exit(0);
}

const server = createApp().listen(config.port);
await new Promise<void>((resolve, reject) => {
  server.once('listening', () => resolve());
  server.once('error', reject);
});

// src/seed.ts is a script that prints the sign-in details it generated and then
// exits; it has no return value to read. Tee its output so the details can be
// kept for the next run as well as shown now. The running server logs each
// request through console.log as a JSON line, so skip those — otherwise the
// kept copy is a few hundred request logs with the details buried in them.
const transcript: string[] = [];
const realLog = console.log;
console.log = (...args: unknown[]) => {
  const line = args.map((a) => (typeof a === 'string' ? a : String(a))).join(' ');
  if (!line.startsWith('{"level"')) transcript.push(line);
  realLog(...args);
};

try {
  // Importing it runs it, and it closes the pool itself.
  await import('./seed.js');
} catch (e) {
  console.log = realLog;
  console.error('Could not create the demo data:', (e as Error).message);
  server.close();
  process.exit(1);
}

console.log = realLog;
remember(transcript.join('\n'));

server.close();
process.exit(0);
