import crypto from 'node:crypto';

export function newId(prefix: string, bytes = 12): string {
  return `${prefix}_${crypto.randomBytes(bytes).toString('base64url')}`;
}

export function sha256(s: string | Buffer): string {
  return crypto.createHash('sha256').update(s).digest('hex');
}

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public extra: Record<string, unknown> = {}) {
    super(message);
  }
}

export const SUPPORTED_CURRENCIES = ['usd', 'eur', 'gbp', 'cad', 'aud', 'mxn', 'brl', 'ngn', 'ghs', 'kes', 'zar', 'inr', 'php'] as const;

// ISO 4217 numeric codes for ISO 8583 field 49.
export const CURRENCY_NUMERIC: Record<string, string> = {
  usd: '840', eur: '978', gbp: '826', cad: '124', aud: '036', mxn: '484', brl: '986',
  ngn: '566', ghs: '936', kes: '404', zar: '710', inr: '356', php: '608',
};

export function luhnValid(pan: string): boolean {
  if (!/^\d{12,19}$/.test(pan)) return false;
  let sum = 0;
  let dbl = false;
  for (let i = pan.length - 1; i >= 0; i--) {
    let d = pan.charCodeAt(i) - 48;
    if (dbl) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
    dbl = !dbl;
  }
  return sum % 10 === 0;
}

export function cardBrand(pan: string): string {
  if (/^4/.test(pan)) return 'visa';
  if (/^(5[1-5]|2(2[2-9]|[3-6]\d|7[01]|720))/.test(pan)) return 'mastercard';
  if (/^3[47]/.test(pan)) return 'amex';
  if (/^(6011|65|64[4-9])/.test(pan)) return 'discover';
  return 'unknown';
}

export function maskPan(pan: string): string {
  return pan.slice(0, 6) + '*'.repeat(Math.max(0, pan.length - 10)) + pan.slice(-4);
}

/** Percentage fee in basis points plus fixed fee, rounded half-up. */
export function computeFee(amount: number, bps: number, fixed: number): number {
  return Math.floor((amount * bps + 5000) / 10000) + fixed;
}
