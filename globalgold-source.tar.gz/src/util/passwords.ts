import crypto from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(crypto.scrypt) as (pw: string, salt: Buffer, len: number) => Promise<Buffer>;

export async function hashPassword(pw: string): Promise<string> {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, 32);
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}

export async function checkPassword(pw: string, stored: string): Promise<boolean> {
  const [, salt, key] = stored.split('$');
  const got = await scrypt(pw, Buffer.from(salt, 'base64'), 32);
  return crypto.timingSafeEqual(got, Buffer.from(key, 'base64'));
}

// Keeps login timing the same whether or not the account exists.
let dummy: Promise<string> | undefined;
export const dummyHash = () => (dummy ??= hashPassword(crypto.randomBytes(8).toString('hex')));
