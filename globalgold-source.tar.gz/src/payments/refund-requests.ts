/**
 * Refund requests — the customer asks, the merchant answers.
 *
 * The money movement is not here. Approval calls createRefund(), the same
 * function a merchant-initiated refund calls, so there is exactly one piece of
 * code in this system that moves money out of a merchant's balance back to a
 * payer. This module decides WHETHER, and records the conversation.
 *
 * THE RULES ARE PURE FUNCTIONS, ON PURPOSE
 *
 * canRequestRefund() and canRespond() take plain objects and return a verdict.
 * No database, no transaction, no merchant context. That is what makes the
 * interesting cases testable: a payment that was already fully refunded, a
 * request for more than was captured, a second request while one is open, a
 * customer poking at somebody else's payment. Every one of those is a branch
 * that a database-driven test can only reach by constructing an elaborate
 * fixture, and that a pure function can be handed directly.
 *
 * The handlers below are then thin: check the verdict, write the row, in a
 * transaction with the row locked.
 */
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { emitEvent } from '../webhooks/webhooks.js';
import { createRefund } from './service.js';
import type { Merchant } from './service.js';

export const REFUND_REASONS = [
  'not_received', 'not_as_described', 'damaged', 'duplicate',
  'accidental', 'cancelled_order', 'other',
] as const;
export type RefundReason = typeof REFUND_REASONS[number];

/** How long the merchant has before the request starts looking bad. Advisory. */
export const RESPOND_WITHIN_DAYS = 5;

/*
 * Plain-English labels. These live next to the codes rather than in the page,
 * because the merchant dashboard, the customer's wallet and the admin console
 * all show the same request and must call the reason the same thing.
 */
export const REASON_LABELS: Record<RefundReason, string> = {
  not_received: 'Never arrived',
  not_as_described: 'Not what was described',
  damaged: 'Arrived damaged or faulty',
  duplicate: 'Charged twice for the same thing',
  accidental: 'Paid by mistake',
  cancelled_order: 'Order was cancelled',
  other: 'Something else',
};

export interface PaymentFacts {
  id: string;
  status: string;
  amount_captured: number;
  amount_refunded: number;
  currency: string;
  wallet_user_id: string | null;
  refund_requested_at?: Date | null;
}

export interface RequestFacts {
  status: string;
  refund_id: string | null;
  amount: number;
}

export type Verdict = { ok: true } | { ok: false; code: string; message: string };

const no = (code: string, message: string): Verdict => ({ ok: false, code, message });

/**
 * May this customer ask for this refund, for this amount?
 *
 * Note what is NOT checked here: whether the asker is the payer. That is
 * authentication, it happens in the route, and conflating the two is how you
 * get a rule that looks correct and authorises strangers.
 */
export function canRequestRefund(
  pi: PaymentFacts,
  amount: number,
  openRequests: number,
): Verdict {
  if (pi.status !== 'succeeded') {
    return no('payment_not_refundable',
      'This payment has not completed, so there is nothing to refund yet.');
  }
  const remaining = pi.amount_captured - pi.amount_refunded;
  if (remaining <= 0) {
    return no('already_refunded',
      'This payment has already been refunded in full.');
  }
  if (!Number.isInteger(amount) || amount <= 0) {
    return no('invalid_amount', 'Enter an amount greater than zero.');
  }
  if (amount > remaining) {
    // The figure is given because "too much" without saying how much is a
    // customer emailing support to ask how much.
    return no('amount_too_large',
      `The most that can be refunded on this payment is ${money(remaining, pi.currency)}.`);
  }
  if (openRequests > 0) {
    return no('request_already_open',
      'You have already asked for a refund on this payment. The merchant has not answered yet.');
  }
  return { ok: true };
}

/** May the merchant still answer this request? */
export function canRespond(r: RequestFacts): Verdict {
  if (r.status === 'approved' || r.refund_id) {
    return no('already_approved', 'This request was already approved and refunded.');
  }
  if (r.status === 'declined') return no('already_declined', 'This request was already declined.');
  if (r.status === 'withdrawn') return no('withdrawn', 'The customer withdrew this request.');
  if (r.status !== 'open') return no('not_open', 'This request is no longer open.');
  return { ok: true };
}

/** Only the customer who made it, and only while it is open. */
export function canWithdraw(r: RequestFacts): Verdict {
  if (r.status !== 'open') {
    return no('not_open', 'This request is no longer open, so it cannot be withdrawn.');
  }
  return { ok: true };
}

function money(minor: number, currency: string): string {
  return `${(minor / 100).toFixed(2)} ${currency.toUpperCase()}`;
}

function assert(v: Verdict): void {
  if (!v.ok) throw new ApiError(400, v.code, v.message);
}

function present(r: any) {
  return {
    object: 'refund_request',
    id: r.id,
    payment_intent: r.payment_intent_id,
    amount: Number(r.amount),
    currency: r.currency,
    reason: r.reason,
    reason_label: REASON_LABELS[r.reason as RefundReason] ?? r.reason,
    note: r.note,
    status: r.status,
    merchant_response: r.merchant_response,
    refund: r.refund_id,
    respond_by: r.respond_by,
    responded_at: r.responded_at,
    created_at: r.created_at,
  };
}

// ------------------------------------------------------------- the customer
/**
 * Ask for a refund.
 *
 * `asker` is how the route proves who this is, and the route has already done
 * that work: either a signed-in wallet user, or somebody holding the checkout
 * link's client_secret. This function trusts it and does not re-derive it.
 */
export async function requestRefund(input: {
  paymentIntentId: string;
  asker: { walletUserId: string } | { email: string };
  amount?: number;
  reason: RefundReason;
  note?: string;
}) {
  return tx(async (c) => {
    // Locked, because the open-request check and the insert must not race. The
    // unique partial index would catch it anyway, but a clean error beats a
    // constraint violation surfacing as a 500.
    const pi = await one<PaymentFacts & { merchant_id: string }>(c,
      `SELECT id, merchant_id, status, amount_captured, amount_refunded, currency, wallet_user_id
         FROM payment_intents WHERE id = $1 FOR UPDATE`, [input.paymentIntentId]);
    if (!pi) throw new ApiError(404, 'resource_missing', 'No such payment.');

    const open = await one<{ n: string }>(c,
      `SELECT count(*)::int AS n FROM refund_requests
        WHERE payment_intent_id = $1 AND status = 'open'`, [input.paymentIntentId]);

    const amount = input.amount ?? (pi.amount_captured - pi.amount_refunded);
    assert(canRequestRefund(pi, amount, Number(open?.n ?? 0)));

    const id = newId('rr');
    const row = await one(c,
      `INSERT INTO refund_requests
         (id, merchant_id, payment_intent_id, wallet_user_id, requested_email,
          amount, currency, reason, note, respond_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9, now() + make_interval(days => $10))
       RETURNING *`,
      [id, pi.merchant_id, pi.id,
       'walletUserId' in input.asker ? input.asker.walletUserId : null,
       'email' in input.asker ? input.asker.email.trim().toLowerCase() : null,
       amount, pi.currency, input.reason, input.note?.slice(0, 2000) || null,
       RESPOND_WITHIN_DAYS]);

    await c.query(
      `UPDATE payment_intents SET refund_requested_at = now(), updated_at = now() WHERE id = $1`,
      [pi.id]);

    // The merchant's integration hears about this like any other event, so a
    // merchant running their own support tooling is not forced to poll.
    await emitEvent(c, pi.merchant_id, 'refund_request.created', present(row));
    return present(row);
  });
}

/** What a signed-in wallet customer has asked for. */
export async function listMyRequests(walletUserId: string, limit = 25) {
  const r = await pool.query(
    `SELECT rr.*, m.name AS merchant_name, pi.description
       FROM refund_requests rr
       JOIN merchants m ON m.id = rr.merchant_id
       JOIN payment_intents pi ON pi.id = rr.payment_intent_id
      WHERE rr.wallet_user_id = $1
      ORDER BY rr.created_at DESC LIMIT $2`, [walletUserId, limit]);
  return {
    object: 'list',
    data: r.rows.map((x) => ({ ...present(x), merchant: x.merchant_name, description: x.description })),
  };
}

/** The request attached to one payment, for whoever is allowed to see it. */
export async function requestForPayment(paymentIntentId: string) {
  const r = await one(pool,
    `SELECT * FROM refund_requests WHERE payment_intent_id = $1
      ORDER BY created_at DESC LIMIT 1`, [paymentIntentId]);
  return r ? present(r) : null;
}

export async function withdrawRequest(id: string, walletUserId: string) {
  return tx(async (c) => {
    const r = await one<RequestFacts & { id: string; wallet_user_id: string; merchant_id: string }>(c,
      `SELECT * FROM refund_requests WHERE id = $1 FOR UPDATE`, [id]);
    if (!r || r.wallet_user_id !== walletUserId) {
      throw new ApiError(404, 'resource_missing', 'No such refund request.');
    }
    assert(canWithdraw(r));
    const row = await one(c,
      `UPDATE refund_requests SET status='withdrawn', updated_at=now()
        WHERE id=$1 RETURNING *`, [id]);
    await emitEvent(c, r.merchant_id, 'refund_request.withdrawn', present(row));
    return present(row);
  });
}

// ------------------------------------------------------------- the merchant
export async function listRequests(m: Merchant, status?: string, limit = 50) {
  const params: unknown[] = [m.id];
  let where = 'rr.merchant_id = $1';
  if (status) { params.push(status); where += ` AND rr.status = $${params.length}`; }
  params.push(limit);
  const r = await pool.query(
    `SELECT rr.*, pi.description, pi.amount_captured, pi.amount_refunded,
            u.name AS customer_name, u.email AS customer_email
       FROM refund_requests rr
       JOIN payment_intents pi ON pi.id = rr.payment_intent_id
       LEFT JOIN users u ON u.id = rr.wallet_user_id
      WHERE ${where}
      -- Oldest open first: the longest wait is the closest to a chargeback.
      ORDER BY (rr.status = 'open') DESC, rr.created_at ASC
      LIMIT $${params.length}`, params);
  return {
    object: 'list',
    data: r.rows.map((x) => ({
      ...present(x),
      description: x.description,
      customer: x.customer_name ?? x.requested_email,
      customer_email: x.customer_email ?? x.requested_email,
      payment_captured: Number(x.amount_captured),
      payment_refunded: Number(x.amount_refunded),
    })),
  };
}

/**
 * Approve — and actually refund.
 *
 * The request row is marked BEFORE createRefund() runs, in its own
 * transaction, and holds refund_id afterwards. The order matters: if the
 * provider call fails, the request stays open and the merchant can retry,
 * rather than a request marked approved with no money sent. createRefund()
 * has its own reservation and rollback for the money itself.
 */
export async function approveRequest(m: Merchant, id: string, staff?: string) {
  const r = await tx(async (c) => {
    const row = await one<RequestFacts & { id: string; payment_intent_id: string; amount: string }>(c,
      `SELECT * FROM refund_requests WHERE id=$1 AND merchant_id=$2 FOR UPDATE`, [id, m.id]);
    if (!row) throw new ApiError(404, 'resource_missing', 'No such refund request.');
    assert(canRespond(row));
    return row;
  });

  const refund = await createRefund(m, r.payment_intent_id, Number(r.amount));

  return tx(async (c) => {
    const row = await one(c,
      `UPDATE refund_requests
          SET status='approved', refund_id=$2, responded_at=now(), responded_by=$3,
              merchant_response=COALESCE(merchant_response, 'Approved — refunded in full.'),
              updated_at=now()
        WHERE id=$1 RETURNING *`, [id, refund.id, staff ?? null]);
    await emitEvent(c, m.id, 'refund_request.approved', present(row));
    return { ...present(row), refund_detail: refund };
  });
}

/**
 * Decline, with a reason.
 *
 * The reason is required. A bare "no" is the single most reliable way to turn a
 * refund request into a chargeback, which costs the merchant the money, a
 * non-refundable fee and a mark against their dispute rate. Requiring one
 * sentence here is the cheapest risk control in this file.
 */
export async function declineRequest(m: Merchant, id: string, response: string, staff?: string) {
  const reason = response?.trim();
  if (!reason || reason.length < 10) {
    throw new ApiError(400, 'response_required',
      'Tell the customer why, in a sentence or two. A decline with no explanation usually comes back as a chargeback, which costs you more than the refund.');
  }
  return tx(async (c) => {
    const row = await one<RequestFacts & { id: string }>(c,
      `SELECT * FROM refund_requests WHERE id=$1 AND merchant_id=$2 FOR UPDATE`, [id, m.id]);
    if (!row) throw new ApiError(404, 'resource_missing', 'No such refund request.');
    assert(canRespond(row));
    const out = await one(c,
      `UPDATE refund_requests
          SET status='declined', merchant_response=$2, responded_at=now(), responded_by=$3, updated_at=now()
        WHERE id=$1 RETURNING *`, [id, reason.slice(0, 2000), staff ?? null]);
    await emitEvent(c, m.id, 'refund_request.declined', present(out));
    return present(out);
  });
}

/** For the dashboard's badge: how many are waiting. */
export async function openRequestCount(merchantId: string): Promise<number> {
  const r = await one<{ n: number }>(pool,
    `SELECT count(*)::int AS n FROM refund_requests WHERE merchant_id=$1 AND status='open'`,
    [merchantId]);
  return Number(r?.n ?? 0);
}

// ---------------------------------------------------------------- the admin
/**
 * Every refund request on the platform.
 *
 * This is an operational and a risk view, not a support tool — the admin never
 * answers a request on a merchant's behalf, because it is the merchant's money
 * and their customer relationship. What the admin needs to see is the pattern:
 * a merchant who never answers, a merchant refunding far more than they keep,
 * one payer asking repeatedly. Those are the shapes that precede a loss.
 */
export async function adminListRequests(filter: {
  status?: string; merchantId?: string; q?: string; limit?: number;
} = {}) {
  const params: unknown[] = [];
  const where: string[] = [];
  if (filter.status) { params.push(filter.status); where.push(`rr.status = $${params.length}`); }
  if (filter.merchantId) { params.push(filter.merchantId); where.push(`rr.merchant_id = $${params.length}`); }
  if (filter.q) {
    params.push(`%${filter.q.toLowerCase()}%`);
    where.push(`(lower(m.name) LIKE $${params.length} OR lower(COALESCE(u.email, rr.requested_email, '')) LIKE $${params.length}
                 OR lower(COALESCE(pi.description,'')) LIKE $${params.length} OR rr.id LIKE $${params.length})`);
  }
  params.push(Math.min(filter.limit ?? 100, 200));
  const r = await pool.query(
    `SELECT rr.*, m.name AS merchant_name, pi.description,
            u.name AS customer_name, u.email AS customer_email,
            -- How long the merchant has been sitting on it, in whole hours.
            EXTRACT(EPOCH FROM (COALESCE(rr.responded_at, now()) - rr.created_at))/3600 AS age_hours
       FROM refund_requests rr
       JOIN merchants m ON m.id = rr.merchant_id
       JOIN payment_intents pi ON pi.id = rr.payment_intent_id
       LEFT JOIN users u ON u.id = rr.wallet_user_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY (rr.status = 'open') DESC, rr.created_at DESC
      LIMIT $${params.length}`, params);
  return {
    object: 'list',
    data: r.rows.map((x) => ({
      ...present(x),
      merchant: x.merchant_name,
      merchant_id: x.merchant_id,
      description: x.description,
      customer: x.customer_name ?? x.requested_email,
      customer_email: x.customer_email ?? x.requested_email,
      age_hours: Math.round(Number(x.age_hours)),
    })),
  };
}

/**
 * The numbers worth watching, platform-wide.
 *
 * approval_rate and median response time are the two that tell you whether
 * merchants are using this properly. A merchant with a 0% approval rate and a
 * long response time is generating chargebacks, and that is the platform's
 * problem too — the networks measure the platform, not just the merchant.
 */
export async function adminRequestStats() {
  const r = await one<any>(pool, `
    SELECT count(*)::int                                                        AS total,
           count(*) FILTER (WHERE status = 'open')::int                         AS open,
           count(*) FILTER (WHERE status = 'approved')::int                     AS approved,
           count(*) FILTER (WHERE status = 'declined')::int                     AS declined,
           COALESCE(sum(amount) FILTER (WHERE status = 'approved'), 0)::bigint   AS approved_amount,
           count(*) FILTER (WHERE status = 'open'
                              AND created_at < now() - interval '5 days')::int  AS overdue,
           COALESCE(percentile_cont(0.5) WITHIN GROUP (
             ORDER BY EXTRACT(EPOCH FROM (responded_at - created_at))/3600
           ) FILTER (WHERE responded_at IS NOT NULL), 0)                        AS median_response_hours
      FROM refund_requests`);
  const answered = Number(r?.approved ?? 0) + Number(r?.declined ?? 0);
  return {
    total: Number(r?.total ?? 0),
    open: Number(r?.open ?? 0),
    approved: Number(r?.approved ?? 0),
    declined: Number(r?.declined ?? 0),
    approved_amount: Number(r?.approved_amount ?? 0),
    overdue: Number(r?.overdue ?? 0),
    median_response_hours: Math.round(Number(r?.median_response_hours ?? 0)),
    approval_rate: answered ? Math.round((Number(r?.approved ?? 0) / answered) * 100) : null,
  };
}
