/**
 * Rule-based pre-authorization risk checks. Production systems add ML scoring,
 * device fingerprinting, 3-D Secure step-up, and BIN/IP/country mismatch rules.
 */
import { Db } from '../db.js';
import type { CardToken } from '../vault/vault.js';

export interface RiskDecision { score: number; action: 'allow' | 'block'; reasons: string[] }

/**
 * `card` is absent when the processor's own SDK tokenised the card in the
 * browser: we never see the number, so there is no fingerprint to score or to
 * count velocity against. The amount rules still apply, and the processor runs
 * its own fraud checks on top — Square and Stripe both decline before we hear
 * about it. Scoring a payment we can see less of must not silently score it
 * *safer* than one we can, so nothing here awards a discount for a missing card.
 */
export async function assessRisk(
  db: Db, p: { amount: number; maxAmount: number; card?: CardToken },
): Promise<RiskDecision> {
  const reasons: string[] = [];
  let score = 5;

  if (p.amount > p.maxAmount) { score += 80; reasons.push('amount_over_merchant_limit'); }
  if (p.amount >= 500_00) { score += 10; reasons.push('high_amount'); }
  if (p.card?.brand === 'unknown') { score += 15; reasons.push('unknown_brand'); }

  // Velocity: attempts with the same card across ALL merchants in the last hour.
  if (p.card) {
    const v = await db.query(
      `SELECT COUNT(*)::int AS n,
              COUNT(*) FILTER (WHERE outcome IN ('declined','blocked'))::int AS failed
         FROM payment_attempts
        WHERE fingerprint = $1 AND created_at > now() - interval '1 hour'`,
      [p.card.fingerprint]);
    const { n, failed } = v.rows[0];
    if (n >= 10) { score += 80; reasons.push('card_velocity'); }
    if (failed >= 3) { score += 80; reasons.push('repeated_declines'); }
  }

  score = Math.min(score, 100);
  return { score, action: score >= 75 ? 'block' : 'allow', reasons };
}
