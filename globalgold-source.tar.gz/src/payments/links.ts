/**
 * Payment links — a shareable URL that takes a payment.
 *
 * The merchant creates one and sends it by email, SMS, invoice or QR code.
 * Anyone who opens it pays. For a merchant with no website and no developer,
 * this is the entire product.
 *
 * A link is a template, not a payment. Opening one creates a fresh payment
 * intent, which then goes down exactly the same road as an API-created
 * payment: the same provider routing, the same browser tokenisation, the same
 * platform fee, the same ledger entries. Nothing about charging lives here,
 * which is the point — a second charge path is a second place for money to go
 * wrong.
 *
 * Three rules decide whether a link will still take money, and all three are
 * enforced server-side on every resolve. A link is public: whoever holds the
 * URL is an untrusted stranger, and anything the page appears to enforce is
 * merely a suggestion.
 */
import crypto from 'node:crypto';
import type { PoolClient } from 'pg';
import { Db, one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import type { Merchant } from './service.js';

/** How many uses are left, or null when the link is uncapped. */
function usesLeft(l: { max_uses: number | null; paid_count: number }): number | null {
  return l.max_uses === null ? null : Math.max(0, l.max_uses - l.paid_count);
}

/**
 * A short, unambiguous public code.
 *
 * Crockford's alphabet: no I, L, O or U, so it survives being read down a
 * phone or copied off a printed invoice without turning into a different
 * link. 10 characters from 32 is about 50 bits — not guessable by brute force,
 * which matters because the code is the only thing protecting the link.
 */
function newCode(): string {
  const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  const bytes = crypto.randomBytes(10);
  let out = '';
  for (const b of bytes) out += ALPHABET[b % 32];
  return out;
}

export interface LinkInput {
  title: string;
  currency: string;
  amount?: number | null;
  min_amount?: number | null;
  max_amount?: number | null;
  description?: string | null;
  expires_at?: Date | null;
  max_uses?: number | null;
  metadata?: Record<string, string>;
}

export async function createLink(m: Merchant, input: LinkInput) {
  if (m.status !== 'active') {
    throw new ApiError(403, 'account_inactive', 'This account cannot accept payments yet.');
  }
  if (input.amount == null && input.min_amount == null) {
    throw new ApiError(400, 'parameter_missing',
      'Set amount for a fixed price, or min_amount to let the buyer choose.');
  }
  if (input.amount != null && (input.min_amount != null || input.max_amount != null)) {
    throw new ApiError(400, 'parameter_invalid',
      'A link has a fixed amount or a buyer-chosen range, not both.');
  }
  if (input.expires_at && input.expires_at.getTime() <= Date.now()) {
    throw new ApiError(400, 'parameter_invalid', 'expires_at is in the past.');
  }

  // Unique on `code`, so on the vanishingly rare collision, try again rather
  // than handing the merchant a 500.
  for (let attempt = 0; ; attempt++) {
    try {
      return present(await one(pool,
        `INSERT INTO payment_links
           (id, merchant_id, code, amount, min_amount, max_amount, currency, title,
            description, expires_at, max_uses, metadata)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
        [newId('plink'), m.id, newCode(), input.amount ?? null, input.min_amount ?? null,
         input.max_amount ?? null, input.currency, input.title, input.description ?? null,
         input.expires_at ?? null, input.max_uses ?? null, JSON.stringify(input.metadata ?? {})]));
    } catch (e: any) {
      if (e?.code === '23505' && attempt < 3) continue;
      throw e;
    }
  }
}

export async function listLinks(m: Merchant, limit = 50) {
  const r = await pool.query(
    `SELECT l.*, (SELECT coalesce(sum(amount_captured - amount_refunded), 0)
                    FROM payment_intents p
                   WHERE p.payment_link_id = l.id AND p.status = 'succeeded') AS collected
       FROM payment_links l WHERE l.merchant_id = $1
      ORDER BY l.created_at DESC LIMIT $2`, [m.id, Math.min(limit, 100)]);
  return r.rows.map(present);
}

export async function getLink(m: Merchant, id: string) {
  const l = await one(pool, 'SELECT * FROM payment_links WHERE id = $1 AND merchant_id = $2', [id, m.id]);
  if (!l) throw new ApiError(404, 'resource_missing', 'Payment link not found.');
  return present(l);
}

export async function setLinkActive(m: Merchant, id: string, active: boolean) {
  const l = await one(pool,
    'UPDATE payment_links SET active = $3, updated_at = now() WHERE id = $1 AND merchant_id = $2 RETURNING *',
    [id, m.id, active]);
  if (!l) throw new ApiError(404, 'resource_missing', 'Payment link not found.');
  return present(l);
}

/**
 * Why a link will not take money, or null when it will.
 *
 * One function, used by both the public page and the intent creation below, so
 * the page can never show "pay now" for something the server would refuse.
 */
function unusableReason(l: any): string | null {
  if (!l.active) return 'This payment link has been turned off.';
  if (l.expires_at && new Date(l.expires_at).getTime() <= Date.now()) return 'This payment link has expired.';
  if (usesLeft(l) === 0) return 'This payment link has already been used.';
  return null;
}

/** The public view of a link: enough to render a pay page, and nothing else. */
export async function resolveLink(code: string) {
  const l = await one(pool,
    `SELECT l.*, m.name AS merchant_name, m.status AS merchant_status
       FROM payment_links l JOIN merchants m ON m.id = l.merchant_id
      WHERE l.code = $1`, [code]);
  // Same error whether the code is wrong or the link is gone: a stranger
  // probing codes learns nothing from the difference.
  if (!l) throw new ApiError(404, 'resource_missing', 'This payment link does not exist.');

  const reason = unusableReason(l);
  if (reason) throw new ApiError(410, 'link_unavailable', reason);
  if (l.merchant_status !== 'active') {
    throw new ApiError(410, 'link_unavailable', 'This business cannot take payments at the moment.');
  }

  return {
    code: l.code,
    merchant: l.merchant_name,
    title: l.title,
    description: l.description,
    currency: l.currency,
    amount: l.amount === null ? null : Number(l.amount),
    min_amount: l.min_amount === null ? null : Number(l.min_amount),
    max_amount: l.max_amount === null ? null : Number(l.max_amount),
  };
}

/**
 * What the buyer will actually be charged.
 *
 * A fixed-amount link ignores whatever the browser sent: the page is public,
 * so a buyer can put any number in the request. Only a buyer-chooses link
 * takes the number from the request, and only within the merchant's bounds.
 */
export function amountFor(l: any, requested?: number | null): number {
  if (l.amount !== null && l.amount !== undefined) return Number(l.amount);
  if (requested == null) throw new ApiError(400, 'parameter_missing', 'Choose an amount to pay.');
  if (!Number.isInteger(requested) || requested <= 0) {
    throw new ApiError(400, 'parameter_invalid', 'Amount must be a whole number of minor units.');
  }
  const min = l.min_amount === null ? null : Number(l.min_amount);
  const max = l.max_amount === null ? null : Number(l.max_amount);
  if (min !== null && requested < min) {
    throw new ApiError(400, 'amount_too_small', `The smallest payment for this link is ${min}.`);
  }
  if (max !== null && requested > max) {
    throw new ApiError(400, 'amount_too_large', `The largest payment for this link is ${max}.`);
  }
  return requested;
}

/**
 * Turn a link into a payment intent the buyer can pay.
 *
 * Re-checks the link inside the transaction and locks the row: two buyers
 * opening a one-use link at the same moment must not both get an intent.
 */
export async function intentForLink(code: string, requested?: number | null) {
  return tx(async (c) => {
    const l = await one(c,
      `SELECT l.*, m.status AS merchant_status FROM payment_links l
         JOIN merchants m ON m.id = l.merchant_id
        WHERE l.code = $1 FOR UPDATE OF l`, [code]);
    if (!l) throw new ApiError(404, 'resource_missing', 'This payment link does not exist.');
    const reason = unusableReason(l);
    if (reason) throw new ApiError(410, 'link_unavailable', reason);
    if (l.merchant_status !== 'active') {
      throw new ApiError(410, 'link_unavailable', 'This business cannot take payments at the moment.');
    }

    const amount = amountFor(l, requested);
    const pi = await one(c,
      `INSERT INTO payment_intents
         (id, merchant_id, amount, currency, status, capture_method, client_secret,
          description, metadata, payment_link_id)
       VALUES ($1,$2,$3,$4,'requires_payment_method','automatic',$5,$6,$7,$8) RETURNING *`,
      [newId('pi'), l.merchant_id, amount, l.currency, newId('secret', 18),
       l.title, JSON.stringify({ payment_link: l.id }), l.id]);
    return { intentId: pi.id as string, clientSecret: pi.client_secret as string };
  });
}

/**
 * Count one successful payment against the link's cap.
 *
 * Called from inside the transaction that marks the intent succeeded, so the
 * count cannot drift and a capped link cannot be over-sold by two payments
 * landing together. A no-op for payments that did not come from a link.
 */
export async function countLinkPayment(c: PoolClient | Db, pi: { payment_link_id?: string | null }) {
  if (!pi.payment_link_id) return;
  await c.query(
    'UPDATE payment_links SET paid_count = paid_count + 1, updated_at = now() WHERE id = $1',
    [pi.payment_link_id]);
}

function present(l: any) {
  return {
    id: l.id,
    object: 'payment_link',
    code: l.code,
    url: `/pay/${l.code}`,
    title: l.title,
    description: l.description,
    currency: l.currency,
    amount: l.amount === null ? null : Number(l.amount),
    min_amount: l.min_amount === null ? null : Number(l.min_amount),
    max_amount: l.max_amount === null ? null : Number(l.max_amount),
    active: l.active,
    expires_at: l.expires_at,
    max_uses: l.max_uses,
    paid_count: l.paid_count,
    uses_left: usesLeft(l),
    collected: l.collected === undefined ? undefined : Number(l.collected),
    metadata: l.metadata,
    created_at: l.created_at,
  };
}
