/**
 * Recurring payments.
 *
 * Everything else in this system charges because someone just clicked
 * something. This charges because a clock said so, with nobody watching, so
 * the failures are quieter and worse: a double charge is not noticed until a
 * chargeback, and a charge after cancellation is not noticed until a
 * complaint.
 *
 * Three defences against billing a period twice, deliberately overlapping —
 * any one of them alone would be a single point of failure:
 *
 *   1. The worker claims due rows with FOR UPDATE SKIP LOCKED, so two workers
 *      running at once take different subscriptions rather than the same one.
 *   2. The cycle number is advanced inside that same claim, so a crash between
 *      claiming and charging loses the cycle rather than repeating it.
 *   3. A unique index on (subscription_id, subscription_cycle) means the
 *      second payment for a cycle cannot be written even if the first two
 *      defences were removed, and the provider's idempotency key — derived
 *      from the cycle number — means it could not be taken at the processor
 *      either.
 *
 * Cancellation sets next_charge_at to NULL, so a canceled subscription stops
 * being *selected* rather than being selected and then declined. There is no
 * code path that charges a row the query did not return.
 */
import type { PoolClient } from 'pg';
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { confirmPaymentIntent, providerForIntent, type Merchant } from './service.js';
import { emitEvent } from '../webhooks/webhooks.js';

export type IntervalUnit = 'day' | 'week' | 'month' | 'year';

/** Stop retrying a card that keeps failing, and tell the merchant instead. */
const MAX_FAILURES = 4;

/**
 * Advance a billing date by one interval.
 *
 * Done in SQL rather than JavaScript because Postgres already knows that one
 * month after 31 January is 28 February, and that a year after 29 February is
 * 28 February. Reimplementing that here is how subscriptions end up skipping
 * a month every leap year.
 */
function advanceSql(column: string) {
  return `${column} + (interval_count || ' ' || interval_unit)::interval`;
}

// ------------------------------------------------------------------ the model

export async function saveCardForCustomer(m: Merchant, input: {
  customerId: string;
  providerToken?: string;
  verificationToken?: string;
  vaultTokenId?: string;
}) {
  const cus = await one(pool, 'SELECT * FROM customers WHERE id=$1 AND merchant_id=$2',
    [input.customerId, m.id]);
  if (!cus) throw new ApiError(404, 'resource_missing', 'Customer not found.');

  const pm = await providerForIntent({ merchant_id: m.id });
  const provider = pm.provider;
  if (!provider.supportsSavedCards) {
    throw new ApiError(400, 'not_supported',
      `${provider.name} cannot store cards for later, so this account cannot take subscriptions.`);
  }

  // The simulated network has no vault of its own, so development and tests
  // keep the card in ours. A real processor holds it against the merchant's
  // own account and hands back an id — we never store the card itself.
  if (!provider.tokenizesInBrowser) {
    if (!input.vaultTokenId) {
      throw new ApiError(400, 'parameter_missing', 'payment_token is required on this network.');
    }
    const tok = await one(pool, 'SELECT * FROM card_tokens WHERE id=$1 AND merchant_id=$2',
      [input.vaultTokenId, m.id]);
    if (!tok) throw new ApiError(400, 'invalid_payment_method', 'Unknown payment token for this account.');
    return present(await one(pool,
      `INSERT INTO saved_payment_methods
         (id, merchant_id, customer_id, provider, vault_token_id, brand, last4, exp_month, exp_year)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [newId('pm'), m.id, cus.id, provider.name, tok.id, tok.brand, tok.last4, tok.exp_month, tok.exp_year]));
  }

  if (!input.providerToken) {
    throw new ApiError(400, 'parameter_missing', 'provider_token is required on this network.');
  }
  if (!provider.saveCard) {
    throw new ApiError(400, 'not_supported', `${provider.name} cannot store cards.`);
  }

  // Reuse the processor's customer record if this buyer already has one, so a
  // second card lands on the same customer rather than creating a duplicate.
  const existing = await one<{ provider_customer_id: string | null }>(pool,
    `SELECT provider_customer_id FROM saved_payment_methods
      WHERE customer_id=$1 AND provider=$2 AND provider_customer_id IS NOT NULL
      ORDER BY created_at DESC LIMIT 1`, [cus.id, provider.name]);

  const saved = await provider.saveCard({
    source: { kind: 'provider_token', token: input.providerToken, verificationToken: input.verificationToken },
    merchant: pm,
    idempotencyKey: `${cus.id}-${Date.now().toString(36)}`,
    customerRef: cus.id,
    email: cus.email,
    name: cus.name,
    providerCustomerId: existing?.provider_customer_id ?? null,
  });

  return present(await one(pool,
    `INSERT INTO saved_payment_methods
       (id, merchant_id, customer_id, provider, provider_card_id, provider_customer_id,
        brand, last4, exp_month, exp_year)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [newId('pm'), m.id, cus.id, provider.name, saved.cardId, saved.customerId ?? null,
     saved.brand ?? null, saved.last4 ?? null, saved.expMonth ?? null, saved.expYear ?? null]));
}

export async function listPaymentMethods(m: Merchant, customerId: string) {
  const r = await pool.query(
    `SELECT * FROM saved_payment_methods
      WHERE merchant_id=$1 AND customer_id=$2 AND deleted_at IS NULL ORDER BY created_at DESC`,
    [m.id, customerId]);
  return r.rows.map(present);
}

export async function createSubscription(m: Merchant, input: {
  customer: string;
  payment_method: string;
  amount: number;
  currency: string;
  interval: IntervalUnit;
  interval_count?: number;
  description?: string;
  max_cycles?: number;
  start_at?: Date;
  charge_now?: boolean;
}) {
  if (m.status !== 'active') {
    throw new ApiError(403, 'account_inactive', 'This account cannot accept payments yet.');
  }
  const pm = await one(pool,
    `SELECT * FROM saved_payment_methods
      WHERE id=$1 AND merchant_id=$2 AND customer_id=$3 AND deleted_at IS NULL`,
    [input.payment_method, m.id, input.customer]);
  if (!pm) throw new ApiError(404, 'resource_missing', 'That saved payment method does not belong to this customer.');

  // A start date in the past would make the first tick bill every period since
  // then, which is never what someone meant to set up.
  const start = input.start_at ?? new Date();
  if (start.getTime() < Date.now() - 60_000) {
    throw new ApiError(400, 'parameter_invalid', 'start_at is in the past.');
  }

  const sub = await one(pool,
    `INSERT INTO subscriptions
       (id, merchant_id, customer_id, payment_method_id, amount, currency, description,
        interval_unit, interval_count, next_charge_at, max_cycles)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [newId('sub'), m.id, input.customer, input.payment_method, input.amount, input.currency,
     input.description ?? null, input.interval, input.interval_count ?? 1,
     input.charge_now ? new Date() : start, input.max_cycles ?? null]);

  await tx((c) => emitEvent(c, m.id, 'subscription.created', present(sub)));
  return present(sub);
}

export async function listSubscriptions(m: Merchant, customerId?: string) {
  const r = await pool.query(
    `SELECT s.*, c.email AS customer_email, c.name AS customer_name
       FROM subscriptions s JOIN customers c ON c.id = s.customer_id
      WHERE s.merchant_id = $1 AND ($2::text IS NULL OR s.customer_id = $2)
      ORDER BY s.created_at DESC LIMIT 200`, [m.id, customerId ?? null]);
  return r.rows.map(present);
}

export async function getSubscription(m: Merchant, id: string) {
  const s = await one(pool, 'SELECT * FROM subscriptions WHERE id=$1 AND merchant_id=$2', [id, m.id]);
  if (!s) throw new ApiError(404, 'resource_missing', 'Subscription not found.');
  const charges = await pool.query(
    `SELECT id, amount, currency, status, subscription_cycle, created_at
       FROM payment_intents WHERE subscription_id=$1 ORDER BY subscription_cycle DESC LIMIT 100`, [id]);
  return { ...present(s), charges: charges.rows.map((x) => ({ ...x, amount: Number(x.amount) })) };
}

/**
 * Pause, resume or cancel.
 *
 * Cancelling clears next_charge_at as well as setting the status. Either alone
 * would be enough only as long as every future query remembers to check the
 * other; clearing the date means the worker's index does not even contain the
 * row. Cancelling is final — resuming a cancelled subscription would silently
 * restart billing someone thought they had ended.
 */
export async function setSubscriptionStatus(m: Merchant, id: string, action: 'pause' | 'resume' | 'cancel') {
  const s = await one<any>(pool, 'SELECT * FROM subscriptions WHERE id=$1 AND merchant_id=$2', [id, m.id]);
  if (!s) throw new ApiError(404, 'resource_missing', 'Subscription not found.');
  if (s.status === 'canceled') {
    throw new ApiError(400, 'subscription_canceled', 'This subscription was cancelled and cannot be changed.');
  }

  let row;
  if (action === 'cancel') {
    row = await one(pool,
      `UPDATE subscriptions SET status='canceled', next_charge_at=NULL, canceled_at=now(), updated_at=now()
        WHERE id=$1 RETURNING *`, [id]);
  } else if (action === 'pause') {
    row = await one(pool,
      `UPDATE subscriptions SET status='paused', updated_at=now() WHERE id=$1 RETURNING *`, [id]);
  } else {
    // Resuming from a date in the past would fire immediately and then again
    // next tick. Catch the schedule up to now instead.
    row = await one(pool,
      `UPDATE subscriptions SET status='active', failures=0, updated_at=now(),
         next_charge_at = greatest(coalesce(next_charge_at, now()), now())
        WHERE id=$1 RETURNING *`, [id]);
  }
  await tx((c) => emitEvent(c, m.id, `subscription.${action === 'cancel' ? 'canceled' : action === 'pause' ? 'paused' : 'resumed'}`, present(row)));
  return present(row);
}

// ----------------------------------------------------------------- the worker

interface Claimed {
  id: string; merchant_id: string; customer_id: string; amount: number; currency: string;
  description: string | null; cycle: number;
  provider_card_id: string | null; provider_customer_id: string | null; vault_token_id: string | null;
  payment_method_id: string;
}

/**
 * Take ownership of up to `limit` subscriptions that are due.
 *
 * SKIP LOCKED is what makes more than one worker safe: a row another
 * transaction is already holding is passed over rather than waited for. The
 * cycle number is incremented here, in the same statement, so the claim and
 * the right to bill that cycle are inseparable.
 */
async function claimDue(c: PoolClient, limit: number): Promise<Claimed[]> {
  const r = await c.query(
    `WITH due AS (
       SELECT id FROM subscriptions
        WHERE status='active' AND next_charge_at IS NOT NULL AND next_charge_at <= now()
        ORDER BY next_charge_at
        FOR UPDATE SKIP LOCKED
        LIMIT $1
     )
     UPDATE subscriptions s
        SET cycles_billed = s.cycles_billed + 1,
            last_charge_at = now(),
            -- From the scheduled date, not from now: advancing from now makes
            -- the billing day creep later every cycle by however long the
            -- worker happened to be late.
            next_charge_at = ${advanceSql('s.next_charge_at')},
            updated_at = now()
       FROM due
      WHERE s.id = due.id
      RETURNING s.id, s.merchant_id, s.customer_id, s.amount, s.currency, s.description,
                s.cycles_billed AS cycle, s.payment_method_id`,
    [limit]);
  if (!r.rows.length) return [];

  const methods = await c.query(
    `SELECT id, provider_card_id, provider_customer_id, vault_token_id
       FROM saved_payment_methods WHERE id = ANY($1)`,
    [r.rows.map((x) => x.payment_method_id)]);
  const byId = new Map(methods.rows.map((m) => [m.id, m]));

  return r.rows.map((x) => ({
    ...x,
    amount: Number(x.amount),
    cycle: Number(x.cycle),
    provider_card_id: byId.get(x.payment_method_id)?.provider_card_id ?? null,
    provider_customer_id: byId.get(x.payment_method_id)?.provider_customer_id ?? null,
    vault_token_id: byId.get(x.payment_method_id)?.vault_token_id ?? null,
  }));
}

/** Charge one claimed subscription. Never throws: one bad card must not stop the run. */
async function chargeClaimed(s: Claimed): Promise<'succeeded' | 'failed'> {
  const m = await one<Merchant>(pool, 'SELECT * FROM merchants WHERE id=$1', [s.merchant_id]);
  if (!m) return 'failed';

  try {
    // The unique index on (subscription_id, subscription_cycle) is the last
    // line of defence: if this cycle somehow came round twice, the insert
    // fails here rather than a second charge reaching the processor.
    const pi = await one<any>(pool,
      `INSERT INTO payment_intents
         (id, merchant_id, customer_id, amount, currency, status, capture_method,
          client_secret, description, subscription_id, subscription_cycle, metadata)
       VALUES ($1,$2,$3,$4,$5,'requires_payment_method','automatic',$6,$7,$8,$9,$10)
       RETURNING *`,
      [newId('pi'), s.merchant_id, s.customer_id, s.amount, s.currency, newId('secret', 18),
       s.description ?? 'Subscription payment', s.id, s.cycle,
       JSON.stringify({ subscription: s.id, cycle: String(s.cycle) })]);

    const out = await confirmPaymentIntent(m, pi.id, {
      kind: 'saved_card',
      methodId: s.payment_method_id,
      cardId: s.provider_card_id,
      customerId: s.provider_customer_id,
      vaultTokenId: s.vault_token_id,
    });

    if (out.status === 'succeeded' || out.status === 'requires_capture') {
      await pool.query('UPDATE subscriptions SET failures=0, updated_at=now() WHERE id=$1', [s.id]);
      await tx((c) => emitEvent(c, s.merchant_id, 'subscription.charged',
        { subscription: s.id, cycle: s.cycle, payment_intent: pi.id, amount: s.amount, currency: s.currency }));
      await finishIfComplete(s.id, s.merchant_id);
      return 'succeeded';
    }
    await noteFailure(s, out.last_payment_error?.message ?? 'The card was declined.');
    return 'failed';
  } catch (e: any) {
    // A duplicate-key error here means this cycle was already billed. That is
    // the guard working, not an incident: say nothing and move on.
    if (e?.code === '23505') return 'succeeded';
    await noteFailure(s, e?.message ?? 'The payment could not be taken.');
    return 'failed';
  }
}

async function noteFailure(s: Claimed, message: string) {
  const row = await one<any>(pool,
    `UPDATE subscriptions
        SET failures = failures + 1,
            -- Back off, then give up: a card that has expired will not start
            -- working because it was tried a hundred more times, and every
            -- retry is another decline on the merchant's record.
            status = CASE WHEN failures + 1 >= $2 THEN 'unpaid' ELSE status END,
            next_charge_at = CASE WHEN failures + 1 >= $2 THEN NULL
                                  ELSE now() + ((failures + 1) || ' days')::interval END,
            updated_at = now()
      WHERE id = $1 RETURNING *`, [s.id, MAX_FAILURES]);
  await tx((c) => emitEvent(c, s.merchant_id,
    row?.status === 'unpaid' ? 'subscription.unpaid' : 'subscription.charge_failed',
    { subscription: s.id, cycle: s.cycle, message, failures: row?.failures }));
}

/** A subscription with a fixed number of cycles stops once it has billed them. */
async function finishIfComplete(id: string, merchantId: string) {
  const done = await one<any>(pool,
    `UPDATE subscriptions SET status='canceled', next_charge_at=NULL, canceled_at=now(), updated_at=now()
      WHERE id=$1 AND max_cycles IS NOT NULL AND cycles_billed >= max_cycles AND status='active'
      RETURNING *`, [id]);
  if (done) {
    await tx((c) => emitEvent(c, merchantId, 'subscription.completed', present(done)));
  }
}

/**
 * One pass over everything that is due.
 *
 * The claim is committed before any charging starts. Holding the transaction
 * open across a network call to a processor would keep rows locked for as long
 * as the processor takes to answer, and a worker that died mid-call would
 * leave them locked until its connection timed out.
 */
export async function runDueSubscriptions(limit = 50): Promise<{ charged: number; failed: number }> {
  const claimed = await tx((c) => claimDue(c, limit));
  let charged = 0, failed = 0;
  for (const s of claimed) {
    if (await chargeClaimed(s) === 'succeeded') charged++;
    else failed++;
  }
  return { charged, failed };
}

/** The background loop. Off in tests, which call runDueSubscriptions directly. */
export function startSubscriptionWorker(everyMs = 60_000) {
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;          // never overlap with itself
    running = true;
    try { await runDueSubscriptions(); }
    catch { /* a failed pass is retried on the next tick */ }
    finally { running = false; }
  }, everyMs);
  timer.unref?.();
  return () => clearInterval(timer);
}

function present(s: any) {
  if (!s) return s;
  if (s.provider_card_id !== undefined || s.vault_token_id !== undefined) {
    return {
      id: s.id, object: 'payment_method', brand: s.brand, last4: s.last4,
      exp_month: s.exp_month, exp_year: s.exp_year, created_at: s.created_at,
    };
  }
  return {
    id: s.id,
    object: 'subscription',
    customer: s.customer_id,
    customer_email: s.customer_email,
    payment_method: s.payment_method_id,
    amount: Number(s.amount),
    currency: s.currency,
    description: s.description,
    interval: s.interval_unit,
    interval_count: s.interval_count,
    status: s.status,
    next_charge_at: s.next_charge_at,
    last_charge_at: s.last_charge_at,
    cycles_billed: s.cycles_billed,
    max_cycles: s.max_cycles,
    failures: s.failures,
    created_at: s.created_at,
    canceled_at: s.canceled_at,
  };
}
