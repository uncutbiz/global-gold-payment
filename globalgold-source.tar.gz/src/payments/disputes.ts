/**
 * Disputes (chargebacks).
 *
 * A dispute is the one thing here that happens TO the platform rather than
 * because someone asked. The cardholder complains to their bank, the bank pulls
 * the money back through the network, and a webhook tells us afterwards.
 *
 * So the job of this file is not to move money — the network already did — but
 * to make our books agree with reality, on time, exactly once:
 *
 *   - `reverseOnce` writes the ledger entry that takes the money back, guarded
 *     by a column rather than by a caller remembering. Processors retry
 *     webhooks; a reversal that ran twice would take the merchant's money
 *     twice, and nothing downstream would notice.
 *
 *   - Status names are normalised. Square says EVIDENCE_REQUIRED, Stripe says
 *     needs_response, and the merchant should not have to learn both to know
 *     whether they still have time to reply.
 *
 *   - The deadline is surfaced loudly. Card networks give a fixed window and
 *     missing it loses by default, with no appeal — so a dispute arriving
 *     raises an alert with the date on it rather than sitting in a table.
 */
import type { PoolClient } from 'pg';
import { one, pool, tx } from '../db.js';
import { acct, postJournal } from '../ledger/ledger.js';
import { ApiError, newId } from '../util/common.js';
import { raiseAlert } from '../admin/monitoring.js';
import { emitEvent } from '../webhooks/webhooks.js';
import type { Merchant } from './service.js';

export type DisputeStatus = 'needs_response' | 'under_review' | 'won' | 'lost' | 'accepted';

/** A dispute is finished when the network has decided, or the merchant gave up. */
const FINAL: DisputeStatus[] = ['won', 'lost', 'accepted'];

/**
 * Square's and Stripe's names for the same five states.
 *
 * Anything unrecognised becomes `needs_response` rather than being dropped: a
 * dispute we failed to classify still needs a human to look at it, and
 * silently ignoring an unknown status is how a deadline passes unnoticed.
 */
export function normaliseStatus(provider: string, raw: string | undefined): DisputeStatus {
  const s = String(raw ?? '').toUpperCase();
  if (provider === 'square') {
    if (s === 'WON') return 'won';
    if (s === 'LOST') return 'lost';
    if (s === 'ACCEPTED') return 'accepted';
    if (s === 'PROCESSING' || s === 'EVIDENCE_UNDER_REVIEW') return 'under_review';
    return 'needs_response';   // EVIDENCE_REQUIRED, INQUIRY_EVIDENCE_REQUIRED, …
  }
  // Stripe
  if (s === 'WON') return 'won';
  if (s === 'LOST') return 'lost';
  if (s === 'WARNING_CLOSED' || s === 'CHARGE_REFUNDED') return 'accepted';
  if (s === 'UNDER_REVIEW' || s === 'WARNING_UNDER_REVIEW') return 'under_review';
  return 'needs_response';
}

export interface IncomingDispute {
  provider: string;
  providerDisputeId: string;
  providerPaymentId?: string | null;
  merchantId?: string | null;
  amount: number;
  currency: string;
  fee?: number;
  status: DisputeStatus;
  reason?: string | null;
  evidenceDueBy?: Date | null;
}

/**
 * The ledger entry for money the network has already taken back.
 *
 * Which entry depends on whose acquiring account the payment landed in, the
 * same split as postCapture:
 *
 *   simulated  — we are the acquirer, so the merchant's balance on our books
 *                is what shrinks, and we hand back the fee we charged.
 *   real       — the processor settles to the merchant directly, so their
 *                balance was never ours to reduce. What we lose is the
 *                platform fee the processor now claws back from us.
 *
 * `reversed_at` is the guard. The UPDATE that claims it is conditional, so two
 * concurrent webhooks cannot both proceed — the second gets no row back and
 * does nothing.
 */
async function reverseOnce(c: PoolClient, d: any): Promise<boolean> {
  const claimed = await one(c,
    `UPDATE disputes SET reversed_at = now(), updated_at = now()
      WHERE id = $1 AND reversed_at IS NULL RETURNING *`, [d.id]);
  if (!claimed) return false;

  const pi = d.payment_intent_id
    ? await one(c, 'SELECT * FROM payment_intents WHERE id = $1', [d.payment_intent_id])
    : null;
  const amount = Number(d.amount);
  const fee = Number(d.fee ?? 0);

  if (pi && (pi.provider ?? 'simulated') === 'simulated') {
    // We hold the money, so we take it off the merchant and give back the fee
    // we took on the original payment. The dispute fee itself is ours to keep
    // as revenue, because the network charged us for handling it.
    const feeBack = Number(pi.fee ?? 0);
    await postJournal(c, d.currency, { type: 'dispute', id: d.id }, `chargeback ${d.id}`, [
      { account: acct.available(d.merchant_id), debit: amount - feeBack },
      { account: acct.fees, debit: feeBack },
      { account: acct.receivable, credit: amount },
    ]);
    if (fee > 0) {
      await postJournal(c, d.currency, { type: 'dispute_fee', id: d.id }, `chargeback fee ${d.id}`, [
        { account: acct.available(d.merchant_id), debit: fee },
        { account: acct.fees, credit: fee },
      ]);
    }
  } else {
    // The buyer's money never touched us, so there is no merchant balance here
    // to reduce — that happens on the processor's books. What reverses on ours
    // is the platform fee we earned on a payment that has now been undone.
    const platformFee = Number(pi?.platform_fee ?? 0);
    if (platformFee > 0) {
      await postJournal(c, d.currency, { type: 'dispute', id: d.id }, `chargeback ${d.id}`, [
        { account: acct.fees, debit: platformFee },
        { account: acct.providerReceivable, credit: platformFee },
      ]);
    }
  }
  return true;
}

/** Give the money back after a dispute is won on appeal, also exactly once. */
async function restoreOnce(c: PoolClient, d: any): Promise<boolean> {
  const claimed = await one(c,
    `UPDATE disputes SET restored_at = now(), updated_at = now()
      WHERE id = $1 AND reversed_at IS NOT NULL AND restored_at IS NULL RETURNING *`, [d.id]);
  if (!claimed) return false;

  const pi = d.payment_intent_id
    ? await one(c, 'SELECT * FROM payment_intents WHERE id = $1', [d.payment_intent_id])
    : null;
  const amount = Number(d.amount);

  if (pi && (pi.provider ?? 'simulated') === 'simulated') {
    const feeBack = Number(pi.fee ?? 0);
    await postJournal(c, d.currency, { type: 'dispute_won', id: d.id }, `chargeback reversed ${d.id}`, [
      { account: acct.receivable, debit: amount },
      { account: acct.available(d.merchant_id), credit: amount - feeBack },
      { account: acct.fees, credit: feeBack },
    ]);
  } else {
    const platformFee = Number(pi?.platform_fee ?? 0);
    if (platformFee > 0) {
      await postJournal(c, d.currency, { type: 'dispute_won', id: d.id }, `chargeback reversed ${d.id}`, [
        { account: acct.providerReceivable, debit: platformFee },
        { account: acct.fees, credit: platformFee },
      ]);
    }
  }
  return true;
}

/**
 * Record a dispute a processor has told us about, or update one we already
 * have. Safe to call repeatedly with the same event — which is necessary,
 * because processors retry.
 */
export async function upsertDispute(input: IncomingDispute) {
  return tx(async (c) => {
    // Find the payment by the processor's id for it, so the dispute attaches to
    // the right row without the webhook having to know ours.
    const pi = input.providerPaymentId
      ? await one(c, 'SELECT * FROM payment_intents WHERE provider_payment_id = $1', [input.providerPaymentId])
      : null;
    const merchantId = pi?.merchant_id ?? input.merchantId;
    if (!merchantId) {
      // Nothing to attach it to. Better to say so than to invent a merchant.
      throw new ApiError(404, 'resource_missing',
        `Dispute ${input.providerDisputeId} does not match any payment on this platform.`);
    }

    const existing = await one<any>(c,
      'SELECT * FROM disputes WHERE provider = $1 AND provider_dispute_id = $2 FOR UPDATE',
      [input.provider, input.providerDisputeId]);

    let d: any;
    let isNew = false;
    if (existing) {
      // A dispute that has already been decided does not go back to needing a
      // response; a late-arriving earlier webhook must not undo the outcome.
      const keepStatus = FINAL.includes(existing.status) && !FINAL.includes(input.status);
      d = await one(c,
        `UPDATE disputes SET
           status = $2, reason = coalesce($3, reason),
           evidence_due_by = coalesce($4, evidence_due_by),
           fee = GREATEST(fee, $5),
           resolved_at = CASE WHEN $6 THEN coalesce(resolved_at, now()) ELSE resolved_at END,
           updated_at = now()
         WHERE id = $1 RETURNING *`,
        [existing.id, keepStatus ? existing.status : input.status, input.reason ?? null,
         input.evidenceDueBy ?? null, input.fee ?? 0, FINAL.includes(input.status)]);
    } else {
      isNew = true;
      d = await one(c,
        `INSERT INTO disputes
           (id, merchant_id, payment_intent_id, provider, provider_dispute_id,
            amount, currency, fee, status, reason, evidence_due_by, resolved_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
        [newId('dp'), merchantId, pi?.id ?? null, input.provider, input.providerDisputeId,
         input.amount, input.currency, input.fee ?? 0, input.status, input.reason ?? null,
         input.evidenceDueBy ?? null, FINAL.includes(input.status) ? new Date() : null]);
      if (pi) {
        await c.query('UPDATE payment_intents SET disputed_at = coalesce(disputed_at, now()) WHERE id = $1', [pi.id]);
      }
    }

    // The money moves when the dispute is opened, not when it is decided: the
    // network debits immediately and only gives it back if the merchant wins.
    if (d.status !== 'won') await reverseOnce(c, d);
    if (d.status === 'won') {
      if (d.reversed_at) await restoreOnce(c, d);
    }

    if (isNew) {
      const due = d.evidence_due_by ? new Date(d.evidence_due_by).toISOString().slice(0, 10) : 'unknown';
      await raiseAlert(c, {
        severity: 'high',
        rule: 'dispute_opened',
        message: `Chargeback on ${d.currency.toUpperCase()} payment — respond by ${due}. Reason: ${d.reason ?? 'not given'}.`,
        subjectType: 'dispute', subjectId: d.id,
        merchantId, amount: Number(d.amount), currency: d.currency,
      });
    }
    await emitEvent(c, merchantId, isNew ? 'dispute.created' : `dispute.${d.status}`, present(d));
    return present(d);
  });
}

// ------------------------------------------------------------------ merchant API

export async function listDisputes(m: Merchant, status?: string) {
  const r = await pool.query(
    `SELECT d.*, p.description AS payment_description
       FROM disputes d LEFT JOIN payment_intents p ON p.id = d.payment_intent_id
      WHERE d.merchant_id = $1 AND ($2::text IS NULL OR d.status = $2)
      ORDER BY (d.status = 'needs_response') DESC, d.evidence_due_by NULLS LAST, d.created_at DESC
      LIMIT 200`, [m.id, status ?? null]);
  return r.rows.map(present);
}

export async function getDispute(m: Merchant, id: string) {
  const d = await one(pool, 'SELECT * FROM disputes WHERE id = $1 AND merchant_id = $2', [id, m.id]);
  if (!d) throw new ApiError(404, 'resource_missing', 'Dispute not found.');
  return present(d);
}

/**
 * Attach the merchant's evidence.
 *
 * Only while it can still be sent. Accepting evidence for a dispute that has
 * closed would let a merchant believe they had replied when nothing could
 * reach the network.
 */
export async function submitEvidence(m: Merchant, id: string, evidence: Record<string, string>) {
  const d = await one<any>(pool, 'SELECT * FROM disputes WHERE id = $1 AND merchant_id = $2', [id, m.id]);
  if (!d) throw new ApiError(404, 'resource_missing', 'Dispute not found.');
  if (d.status !== 'needs_response') {
    throw new ApiError(400, 'dispute_closed',
      `This dispute is ${d.status} and no longer accepts evidence.`);
  }
  if (d.evidence_due_by && new Date(d.evidence_due_by).getTime() < Date.now()) {
    throw new ApiError(400, 'dispute_expired',
      'The deadline for evidence on this dispute has passed.');
  }
  const row = await one(pool,
    `UPDATE disputes SET evidence = $2, evidence_sent_at = now(), status = 'under_review', updated_at = now()
      WHERE id = $1 RETURNING *`, [id, JSON.stringify(evidence)]);
  await tx((c) => emitEvent(c, m.id, 'dispute.evidence_submitted', present(row)));
  return present(row);
}

/**
 * Give up on a dispute.
 *
 * Worth offering rather than making people ignore it: the money is already
 * gone either way, and accepting stops the clock and the reminders. It does not
 * move money, because reverseOnce already did when the dispute opened.
 */
export async function acceptDispute(m: Merchant, id: string) {
  const d = await one<any>(pool, 'SELECT * FROM disputes WHERE id = $1 AND merchant_id = $2', [id, m.id]);
  if (!d) throw new ApiError(404, 'resource_missing', 'Dispute not found.');
  if (FINAL.includes(d.status)) {
    throw new ApiError(400, 'dispute_closed', `This dispute is already ${d.status}.`);
  }
  const row = await one(pool,
    `UPDATE disputes SET status = 'accepted', resolved_at = now(), updated_at = now()
      WHERE id = $1 RETURNING *`, [id]);
  await tx((c) => emitEvent(c, m.id, 'dispute.accepted', present(row)));
  return present(row);
}

/** Disputes whose deadline is close, for a reminder job or the dashboard. */
export async function disputesDueSoon(withinHours = 72) {
  const r = await pool.query(
    `SELECT * FROM disputes
      WHERE status = 'needs_response' AND evidence_due_by IS NOT NULL
        AND evidence_due_by <= now() + make_interval(hours => $1)
      ORDER BY evidence_due_by`, [withinHours]);
  return r.rows.map(present);
}

function present(d: any) {
  if (!d) return d;
  return {
    id: d.id,
    object: 'dispute',
    payment_intent: d.payment_intent_id,
    amount: Number(d.amount),
    currency: d.currency,
    fee: Number(d.fee ?? 0),
    status: d.status,
    reason: d.reason,
    evidence_due_by: d.evidence_due_by,
    evidence_submitted: Boolean(d.evidence_sent_at),
    money_taken_back: Boolean(d.reversed_at) && !d.restored_at,
    opened_at: d.opened_at,
    resolved_at: d.resolved_at,
    provider: d.provider,
  };
}
