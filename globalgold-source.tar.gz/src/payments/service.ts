/**
 * PaymentIntent state machine.
 *
 *   requires_payment_method ──confirm──▶ processing ──approved──▶ requires_capture ──capture──▶ succeeded
 *            ▲                               │          (manual)          │
 *            └──────── declined / blocked ───┘                            └──cancel──▶ canceled
 *                                                  approved (automatic) ─────────────▶ succeeded
 *
 * Network calls happen OUTSIDE database transactions: we move the intent to
 * `processing` (a lock by state), call the processor, then finalize. A crash in
 * between leaves the intent in `processing`; a reconciliation job must match it
 * against the processor's records (see README "Production gaps").
 *
 * Which processor is not decided here. Every payment goes through the provider
 * layer (src/providers/), so the same code charges Square, Stripe or the
 * built-in simulated network depending on what the merchant has connected. Two
 * consequences worth knowing:
 *
 *   - A processor that tokenises in the browser never receives a card number.
 *     Confirm takes either a vault token (simulated only) or a single-use token
 *     the processor's own SDK made in the shopper's browser, and mixing them up
 *     is refused rather than worked around.
 *   - The money does not flow the same way. On the simulated network we are the
 *     acquirer, so the merchant's balance sits on our books. On a merchant's own
 *     Square or Stripe account the processor settles to them directly and pays
 *     us our platform fee; our books then hold only that fee. postCapture() is
 *     where those two shapes are kept apart.
 */
import crypto from 'node:crypto';
import type { PoolClient } from 'pg';
import { one, pool, tx } from '../db.js';
import { acct, postJournal } from '../ledger/ledger.js';
import { providerMerchant } from '../merchants/connect.js';
import { ourFee, ourFeeRefund } from '../providers/index.js';
import { ProviderError, type PaymentProvider, type PaymentSource, type ProviderMerchant } from '../providers/provider.js';
import { ApiError, computeFee, newId } from '../util/common.js';
import { detokenize, getToken } from '../vault/vault.js';
import { emitEvent } from '../webhooks/webhooks.js';
import { assessRisk } from './risk.js';
import { raiseAlert } from '../admin/monitoring.js';

export interface Merchant {
  id: string; name: string; email: string; status: string;
  fee_bps: number; fee_fixed: number; max_amount: number;
  webhook_url: string | null; webhook_secret: string;
  payout_method?: 'bank' | 'wallet'; payout_wallet_user_id?: string | null;
}

/** How the shopper is paying. */
export type ConfirmSource =
  /** A card in our vault. Only the simulated network can charge one. */
  | { kind: 'vault_token'; tokenId: string }
  /** A single-use token from the processor's SDK. We never see the card. */
  | { kind: 'provider_token'; token: string; verificationToken?: string };

/** A bare string is a vault token, which is what every existing caller sends. */
function asConfirmSource(src: string | ConfirmSource): ConfirmSource {
  return typeof src === 'string' ? { kind: 'vault_token', tokenId: src } : src;
}

/**
 * Same intent + same payment method ⇒ same key, so a retry after a timeout
 * cannot charge twice: the processor returns the original payment instead of
 * making a second one. A different card gives a different key, so a shopper
 * whose first card was declined can try another.
 */
function chargeKey(intentId: string, src: ConfirmSource): string {
  const method = src.kind === 'vault_token' ? src.tokenId : src.token;
  return crypto.createHash('sha256').update(`${intentId}|${method}`).digest('hex').slice(0, 40);
}

type Connected = ProviderMerchant & { provider: PaymentProvider };

/**
 * The processor a payment was actually taken on — read from the intent, not
 * looked up fresh. A merchant could have connected a different account since,
 * and capturing or refunding against the wrong processor would at best fail and
 * at worst act on an unrelated payment that happens to share an id.
 */
async function providerForIntent(pi: { merchant_id: string; provider?: string | null }): Promise<Connected> {
  const pm = await providerMerchant(pool, pi.merchant_id);
  if (pi.provider && pi.provider !== pm.provider.name) {
    throw new ApiError(409, 'provider_changed',
      `This payment was taken on ${pi.provider}, but this business is now connected to ${pm.provider.name}. `
      + `It has to be settled from the ${pi.provider} dashboard.`);
  }
  return pm;
}

/**
 * Our cut, in minor units.
 *
 * From configuration (PLATFORM_FEE_BPS), not from the merchant's own fee_bps:
 * fee_bps is the all-in acquiring rate for the simulated network, where we are
 * the acquirer. Charging that on top of Square's own rate would bill the
 * merchant twice for the same payment.
 */
function platformFeeFor(providerName: string, amount: number): number {
  return providerName === 'simulated' ? 0 : ourFee(amount);
}

export function present(pi: any, card?: any) {
  return {
    id: pi.id,
    object: 'payment_intent',
    amount: pi.amount,
    currency: pi.currency,
    status: pi.status,
    capture_method: pi.capture_method,
    amount_capturable: pi.status === 'requires_capture' ? pi.amount : 0,
    amount_captured: pi.amount_captured,
    amount_refunded: pi.amount_refunded,
    fee: pi.fee,
    client_secret: pi.client_secret,
    description: pi.description,
    metadata: pi.metadata,
    payment_method: pi.wallet_user_id ? { type: 'global_gold_wallet' }
      : card ? { token: card.id, brand: card.brand, last4: card.last4, exp_month: card.exp_month, exp_year: card.exp_year }
      : pi.provider && pi.provider !== 'simulated' ? { type: 'card', tokenized_by: pi.provider }
      : pi.token_id,
    processor: pi.provider ? { provider: pi.provider, payment_id: pi.provider_payment_id ?? null, platform_fee: pi.platform_fee ?? 0, provider_fee: pi.provider_fee ?? null } : null,
    network: pi.auth_code ? { auth_code: pi.auth_code, rrn: pi.network_ref } : null,
    last_payment_error: pi.decline_code ? { code: pi.decline_code, message: pi.decline_message } : null,
    risk_score: pi.risk_score,
    created: pi.created_at,
  };
}

async function load(c: PoolClient | typeof pool, merchantId: string, id: string, lock = false) {
  const pi = await one(c, `SELECT * FROM payment_intents WHERE id = $1 AND merchant_id = $2 ${lock ? 'FOR UPDATE' : ''}`, [id, merchantId]);
  if (!pi) throw new ApiError(404, 'resource_missing', `No such payment_intent: ${id}`);
  return pi;
}

export async function getPaymentIntent(merchantId: string, id: string) {
  const pi = await load(pool, merchantId, id);
  const card = pi.token_id ? await getToken(pool, pi.token_id, merchantId) : undefined;
  return present(pi, card);
}

export async function listPaymentIntents(merchantId: string, limit = 25) {
  const r = await pool.query(
    `SELECT pi.*, t.brand, t.last4, t.exp_month, t.exp_year
       FROM payment_intents pi LEFT JOIN card_tokens t ON t.id = pi.token_id
      WHERE pi.merchant_id = $1 ORDER BY pi.created_at DESC LIMIT $2`, [merchantId, limit]);
  return r.rows.map((row) => present(row, row.token_id ? { id: row.token_id, brand: row.brand, last4: row.last4, exp_month: row.exp_month, exp_year: row.exp_year } : undefined));
}

export async function createPaymentIntent(m: Merchant, input: {
  amount: number; currency: string; capture_method?: 'automatic' | 'manual';
  description?: string; metadata?: Record<string, string>;
}) {
  if (m.status !== 'active') throw new ApiError(403, 'account_inactive', 'This account cannot accept payments yet.');
  return tx(async (c) => {
    const pi = await one(c,
      `INSERT INTO payment_intents (id, merchant_id, amount, currency, status, capture_method, client_secret, description, metadata)
       VALUES ($1,$2,$3,$4,'requires_payment_method',$5,$6,$7,$8) RETURNING *`,
      [newId('pi'), m.id, input.amount, input.currency, input.capture_method ?? 'automatic',
       newId('secret', 18), input.description ?? null, JSON.stringify(input.metadata ?? {})]);
    await emitEvent(c, m.id, 'payment_intent.created', present(pi));
    return present(pi);
  });
}

/**
 * The ledger entries for money captured, which depend on whose acquiring
 * account it landed in. Returns what the merchant is charged for this payment.
 */
async function postCapture(
  c: PoolClient, m: Merchant, pi: any, amount: number,
  at: { provider: string; platformFee: number },
) {
  if (at.provider === 'simulated') {
    // We are the acquirer: the money is ours to hold and settle, minus our fee.
    const fee = computeFee(amount, m.fee_bps, m.fee_fixed);
    await postJournal(c, pi.currency, { type: 'payment_intent', id: pi.id }, `capture ${pi.id}`, [
      { account: acct.receivable, debit: amount },
      { account: acct.pending(m.id), credit: amount - fee },
      { account: acct.fees, credit: fee },
    ]);
    return fee;
  }

  // The merchant's own processor account: the buyer's money goes straight to
  // them and never touches us, so crediting a merchant balance here would be
  // inventing money we do not hold. All that is ours is the platform fee the
  // processor owes us.
  const fee = at.platformFee;
  if (fee > 0) {
    await postJournal(c, pi.currency, { type: 'payment_intent', id: pi.id }, `platform fee on ${pi.id}`, [
      { account: acct.providerReceivable, debit: fee },
      { account: acct.fees, credit: fee },
    ]);
  }
  return fee;
}

export async function confirmPaymentIntent(m: Merchant, id: string, source: string | ConfirmSource) {
  const src = asConfirmSource(source);

  // Which processor, and this merchant's account on it. Resolved before the
  // intent is claimed, so a merchant who has not connected an account gets a
  // clear error with their intent still confirmable afterwards.
  const pm = await providerForIntent({ merchant_id: m.id });
  const provider = pm.provider;

  // The invariant that keeps card data off our servers. It is enforced here,
  // not only inside each provider, so the refusal is a clean 400 to the caller
  // rather than an exception from three layers down.
  if (provider.tokenizesInBrowser && src.kind === 'vault_token') {
    throw new ApiError(400, 'raw_card_not_accepted',
      `${provider.name} requires a payment token created in the shopper's browser by its own SDK. `
      + 'Send provider_token instead of payment_token.');
  }
  if (!provider.tokenizesInBrowser && src.kind === 'provider_token') {
    throw new ApiError(400, 'provider_token_not_accepted',
      `The ${provider.name} network does not issue browser tokens. Send payment_token, a token from the card vault.`);
  }

  // Phase 1: claim the intent.
  const vaultTokenId = src.kind === 'vault_token' ? src.tokenId : null;
  const { pi, card } = await tx(async (c) => {
    const pi = await load(c, m.id, id, true);
    if (pi.status !== 'requires_payment_method') {
      throw new ApiError(400, 'payment_intent_unexpected_state', `This PaymentIntent is ${pi.status} and cannot be confirmed.`);
    }
    let card;
    if (vaultTokenId) {
      card = await getToken(c, vaultTokenId, m.id);
      if (!card) throw new ApiError(400, 'invalid_payment_method', 'Unknown payment token for this account.');
    }
    await c.query(
      `UPDATE payment_intents SET status='processing', token_id=$2, provider=$3,
         decline_code=NULL, decline_message=NULL, updated_at=now() WHERE id=$1`,
      [id, vaultTokenId, provider.name]);
    return { pi, card };
  });

  const fail = async (outcome: 'declined' | 'blocked' | 'error', code: string, message: string, responseCode: string | null, score: number | null) =>
    tx(async (c) => {
      const row = await one(c,
        `UPDATE payment_intents SET status='requires_payment_method', decline_code=$2, decline_message=$3, risk_score=$4, updated_at=now()
          WHERE id=$1 RETURNING *`, [id, code, message, score]);
      await c.query(
        `INSERT INTO payment_attempts (payment_intent_id, token_id, fingerprint, outcome, response_code, risk_score, provider)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [id, vaultTokenId, card?.fingerprint ?? null, outcome, responseCode, score, provider.name]);
      if (outcome === 'blocked') {
        await raiseAlert(c, { severity: 'low', rule: 'risk_block', message: `Card payment blocked by risk rules at ${m.name}: ${message}`,
          subjectType: 'payment_intent', subjectId: id, merchantId: m.id, amount: pi.amount, currency: pi.currency });
      }
      await emitEvent(c, m.id, 'payment_intent.payment_failed', present(row, card));
      return present(row, card);
    });

  // Phase 2: risk. With a browser-tokenised card there is no fingerprint to
  // score, so only the amount rules apply — see assessRisk.
  const risk = await assessRisk(pool, { amount: pi.amount, maxAmount: m.max_amount, card });
  if (risk.action === 'block') return fail('blocked', 'risk_blocked', `Blocked by risk rules: ${risk.reasons.join(', ')}`, null, risk.score);

  // Phase 3: charge.
  const platformFee = platformFeeFor(provider.name, pi.amount);
  const paymentSource: PaymentSource = src.kind === 'provider_token'
    ? { kind: 'provider_token', token: src.token, verificationToken: src.verificationToken }
    : { kind: 'pan', ...(await detokenize(pool, src.tokenId)) };

  let result;
  try {
    result = await provider.charge({
      amount: pi.amount,
      currency: pi.currency,
      source: paymentSource,
      merchant: pm,
      platformFee,
      capture: pi.capture_method === 'automatic',
      reference: pi.id,
      idempotencyKey: chargeKey(pi.id, src),
      note: pi.description ?? undefined,
    });
  } catch (e) {
    // Timeout or transport error: the outcome is unknown. Going back to
    // requires_payment_method is safe because a retry with the same card reuses
    // the idempotency key, so the processor returns the original payment rather
    // than making a second one. A retry with a *different* card can still
    // double-charge if the first attempt did land, which is what reconciliation
    // against the processor's records is for.
    const pe = e instanceof ProviderError ? e : undefined;
    return fail('error', pe?.code ?? 'processing_error',
      pe ? `${provider.name}: ${pe.message}` : 'The payment network did not respond. Try again.',
      null, risk.score);
  }
  if (!result.approved) {
    return fail('declined', result.declineCode ?? 'card_declined',
      result.declineMessage ?? 'The card was declined.', result.status ?? null, risk.score);
  }

  // Phase 4: finalize.
  const collected = result.platformFee ?? platformFee;
  return tx(async (c) => {
    await c.query(
      `INSERT INTO payment_attempts (payment_intent_id, token_id, fingerprint, outcome, response_code, risk_score, provider)
       VALUES ($1,$2,$3,'approved','00',$4,$5)`,
      [id, vaultTokenId, card?.fingerprint ?? null, risk.score, provider.name]);
    let row;
    if (pi.capture_method === 'automatic') {
      const fee = await postCapture(c, m, pi, pi.amount, { provider: provider.name, platformFee: collected });
      row = await one(c,
        `UPDATE payment_intents SET status='succeeded', amount_captured=amount, fee=$2, auth_code=$3, network_ref=$4,
           risk_score=$5, provider_payment_id=$6, platform_fee=$7, provider_fee=$8, updated_at=now()
          WHERE id=$1 RETURNING *`,
        [id, fee, result.authCode ?? null, result.networkRef, risk.score,
         result.providerPaymentId ?? null, collected, result.providerFee ?? null]);
      await emitEvent(c, m.id, 'payment_intent.succeeded', present(row, card));
    } else {
      row = await one(c,
        `UPDATE payment_intents SET status='requires_capture', auth_code=$2, network_ref=$3, risk_score=$4,
           provider_payment_id=$5, platform_fee=$6, updated_at=now()
          WHERE id=$1 RETURNING *`,
        [id, result.authCode ?? null, result.networkRef, risk.score, result.providerPaymentId ?? null, collected]);
      await emitEvent(c, m.id, 'payment_intent.amount_capturable_updated', present(row, card));
    }
    return present(row, card);
  });
}

export async function capturePaymentIntent(m: Merchant, id: string, amountToCapture?: number) {
  const pm = await providerMerchant(pool, m.id);

  // Phase 1: claim it, so two captures cannot both reach the processor.
  const { pi, amount } = await tx(async (c) => {
    const pi = await load(c, m.id, id, true);
    if (pi.status !== 'requires_capture') throw new ApiError(400, 'payment_intent_unexpected_state', `This PaymentIntent is ${pi.status} and cannot be captured.`);
    if (pi.provider && pi.provider !== pm.provider.name) {
      throw new ApiError(409, 'provider_changed',
        `This payment was authorised on ${pi.provider}, but this business is now connected to ${pm.provider.name}. `
        + `It has to be captured from the ${pi.provider} dashboard.`);
    }
    const amount = amountToCapture ?? pi.amount;
    if (amount <= 0 || amount > pi.amount) throw new ApiError(400, 'amount_too_large', `Capture amount must be between 1 and ${pi.amount}.`);
    await c.query(`UPDATE payment_intents SET status='processing', updated_at=now() WHERE id=$1`, [id]);
    return { pi, amount };
  });

  const release = async () => {
    await pool.query(`UPDATE payment_intents SET status='requires_capture', updated_at=now() WHERE id=$1`, [id]);
  };

  // Phase 2: tell the processor to take the money it is holding.
  if (pi.provider_payment_id) {
    let result;
    try {
      result = await pm.provider.capture({
        providerPaymentId: pi.provider_payment_id,
        merchant: pm,
        amount,
        currency: pi.currency,
        idempotencyKey: `${pi.id}:capture`,
      });
    } catch (e) {
      // Leave it capturable rather than stranding it in processing: the
      // authorisation is still good and the merchant can try again.
      await release();
      const pe = e instanceof ProviderError ? e : undefined;
      throw new ApiError(502, 'capture_failed',
        pe ? `${pm.provider.name} could not capture this payment: ${pe.message}` : 'The processor did not respond. Try again.');
    }
    if (!result.approved) {
      await release();
      throw new ApiError(502, 'capture_failed',
        result.declineMessage ?? `${pm.provider.name} refused to capture this payment.`);
    }
  }

  // Phase 3: finalize. Any uncaptured remainder is released by the processor.
  return tx(async (c) => {
    const fee = await postCapture(c, m, pi, amount, {
      provider: pi.provider ?? pm.provider.name,
      platformFee: platformFeeFor(pi.provider ?? pm.provider.name, amount),
    });
    const row = await one(c,
      `UPDATE payment_intents SET status='succeeded', amount_captured=$2, fee=$3, platform_fee=$4, updated_at=now()
         WHERE id=$1 RETURNING *`,
      [id, amount, fee, platformFeeFor(pi.provider ?? pm.provider.name, amount)]);
    const card = pi.token_id ? await getToken(c, pi.token_id, m.id) : undefined;
    await emitEvent(c, m.id, 'payment_intent.succeeded', present(row, card));
    return present(row, card);
  });
}

export async function cancelPaymentIntent(m: Merchant, id: string) {
  const pi = await tx(async (c) => {
    const pi = await load(c, m.id, id, true);
    if (!['requires_payment_method', 'requires_capture'].includes(pi.status)) {
      throw new ApiError(400, 'payment_intent_unexpected_state', `This PaymentIntent is ${pi.status} and cannot be canceled.`);
    }
    if (pi.status === 'requires_capture') {
      await c.query(`UPDATE payment_intents SET status='processing', updated_at=now() WHERE id=$1`, [id]);
    }
    return pi;
  });

  if (pi.status === 'requires_capture' && pi.provider_payment_id) {
    const pm = await providerForIntent(pi);
    try {
      await pm.provider.void({
        providerPaymentId: pi.provider_payment_id,
        merchant: pm,
        amount: pi.amount,
        currency: pi.currency,
        idempotencyKey: `${pi.id}:void`,
      });
    } catch {
      // The authorisation will expire at the issuer on its own. Record the
      // cancel anyway: refusing to cancel because the processor was briefly
      // unreachable would leave the merchant unable to close the payment at all.
    }
  }

  return tx(async (c) => {
    const row = await one(c, `UPDATE payment_intents SET status='canceled', updated_at=now() WHERE id=$1 RETURNING *`, [id]);
    await emitEvent(c, m.id, 'payment_intent.canceled', present(row));
    return present(row);
  });
}

export async function createRefund(m: Merchant, paymentIntentId: string, amount?: number) {
  // Reserve the refund amount first so concurrent refunds cannot exceed the captured amount.
  const { pi, refundAmount } = await tx(async (c) => {
    const pi = await load(c, m.id, paymentIntentId, true);
    if (pi.status !== 'succeeded') throw new ApiError(400, 'charge_not_refundable', 'Only succeeded payments can be refunded.');
    const remaining = pi.amount_captured - pi.amount_refunded;
    const refundAmount = amount ?? remaining;
    if (refundAmount <= 0 || refundAmount > remaining) {
      throw new ApiError(400, 'amount_too_large', `Refund amount must be between 1 and ${remaining}.`);
    }
    await c.query('UPDATE payment_intents SET amount_refunded = amount_refunded + $2, updated_at=now() WHERE id=$1', [pi.id, refundAmount]);
    return { pi, refundAmount };
  });

  const unreserve = (c: PoolClient) =>
    c.query('UPDATE payment_intents SET amount_refunded = amount_refunded - $2, updated_at=now() WHERE id=$1', [pi.id, refundAmount]);

  if (pi.wallet_user_id) {
    // Wallet-funded payment: no card network, the money goes straight back to the wallet.
    return tx(async (c) => {
      const id = newId('re');
      await postJournal(c, pi.currency, { type: 'refund', id }, `wallet refund ${id} for ${pi.id}`, [
        { account: acct.pending(m.id), debit: refundAmount },
        { account: acct.wallet(pi.wallet_user_id), credit: refundAmount },
      ]);
      await c.query(
        `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, note, payment_intent_id)
         VALUES ($1,$2,'refund',$3,$4,$5,$6,$7)`,
        [newId('wtx'), pi.wallet_user_id, refundAmount, pi.currency, m.name, pi.description, pi.id]);
      const re = await one(c,
        `INSERT INTO refunds (id, merchant_id, payment_intent_id, amount, status) VALUES ($1,$2,$3,$4,'succeeded') RETURNING *`,
        [id, m.id, pi.id, refundAmount]);
      await emitEvent(c, m.id, 'refund.succeeded', re);
      return { object: 'refund', ...re };
    });
  }

  const pm = await providerForIntent(pi);
  const providerName = pi.provider ?? pm.provider.name;

  // Our fee goes back in proportion, so a fully refunded payment earns us
  // nothing. The processor's own fee usually does not come back — that is the
  // industry norm and it is the processor's rule, not ours.
  const feeRefund = providerName === 'simulated' ? 0 : ourFeeRefund(pi.amount_captured, refundAmount);

  // The simulated network has no stored payment to refund against, so it needs
  // the card again. Square and Stripe refund by their own payment id.
  const source: PaymentSource | undefined = providerName === 'simulated' && pi.token_id
    ? { kind: 'pan', ...(await detokenize(pool, pi.token_id)) }
    : undefined;

  let result;
  try {
    result = await pm.provider.refund({
      providerPaymentId: pi.provider_payment_id ?? pi.network_ref ?? pi.id,
      merchant: pm,
      amount: refundAmount,
      currency: pi.currency,
      idempotencyKey: `${pi.id}:refund:${pi.amount_refunded}`,
      platformFeeRefund: feeRefund,
      source,
    });
  } catch (e) {
    const pe = e instanceof ProviderError ? e : undefined;
    result = { approved: false, networkRef: '', declineMessage: pe?.message };
  }

  if (!result.approved) {
    const re = await tx(async (c) => {
      await unreserve(c);
      const re = await one(c,
        `INSERT INTO refunds (id, merchant_id, payment_intent_id, amount, status, provider) VALUES ($1,$2,$3,$4,'failed',$5) RETURNING *`,
        [newId('re'), m.id, pi.id, refundAmount, providerName]);
      await emitEvent(c, m.id, 'refund.failed', re);
      return re;
    });
    throw new ApiError(502, 'refund_failed',
      result.declineMessage ?? 'The processor rejected the refund. Try again later.', { refund: re });
  }

  return tx(async (c) => {
    const id = newId('re');
    if (providerName === 'simulated') {
      // We hold the money, so refunding it moves it back off the merchant's
      // balance. The processing fee is not returned (configurable).
      await postJournal(c, pi.currency, { type: 'refund', id }, `refund ${id} for ${pi.id}`, [
        { account: acct.pending(m.id), debit: refundAmount },
        { account: acct.receivable, credit: refundAmount },
      ]);
    } else if (feeRefund > 0) {
      // We never held the buyer's money — the processor did, and it is giving
      // it back. All that reverses on our books is our own fee.
      await postJournal(c, pi.currency, { type: 'refund', id }, `platform fee returned on ${pi.id}`, [
        { account: acct.fees, debit: feeRefund },
        { account: acct.providerReceivable, credit: feeRefund },
      ]);
    }
    const re = await one(c,
      `INSERT INTO refunds (id, merchant_id, payment_intent_id, amount, status, network_ref, provider, provider_refund_id)
       VALUES ($1,$2,$3,$4,'succeeded',$5,$6,$7) RETURNING *`,
      [id, m.id, pi.id, refundAmount, result.networkRef || null, providerName, result.providerPaymentId ?? null]);
    await emitEvent(c, m.id, 'refund.succeeded', re);
    return { object: 'refund', ...re };
  });
}
