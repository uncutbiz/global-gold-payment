/**
 * Invoices.
 *
 * A document with line items, sent to a customer, that gets paid.
 *
 * Paying it is not reimplemented here. Sending an invoice creates a payment
 * link, and the customer pays that — so an invoice payment runs down exactly
 * the same road as every other payment: same provider routing, same browser
 * tokenisation, same platform fee, same ledger entries. There is one charge
 * path on this platform and this is not a second one.
 *
 * Money rules worth stating, because each is a way invoices go wrong:
 *
 *   - Totals are computed from the lines, in SQL, every time a line changes.
 *     They are never accepted from the caller. A client-supplied total is a
 *     client-supplied price.
 *   - Tax is worked out per line and rounded per line, then summed. Summing
 *     first and taxing the total gives a different, wrong number, and it is
 *     the number an accountant will query.
 *   - Quantity is thousandths of a unit, as an integer. "0.1 + 0.2 hours" in
 *     floating point is 0.30000000000000004, and that ends up on a bill.
 *   - A draft is not payable. The link is created when it is sent, so an
 *     unfinished invoice cannot be paid by someone who guessed the URL.
 */
import type { PoolClient } from 'pg';
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { createLink, setLinkActive } from './links.js';
import { emitEvent } from '../webhooks/webhooks.js';
import type { Merchant } from './service.js';

/** Quantities are thousandths, so this is the divisor, not a magic number. */
const QTY_SCALE = 1000;

export interface LineInput {
  description: string;
  quantity?: number;      // whole units; 1.5 is allowed and becomes 1500
  unit_amount: number;    // minor units
  tax_bps?: number;
}

/**
 * Recompute and store the totals from the lines.
 *
 * Runs inside the caller's transaction and is the ONLY thing that writes
 * subtotal, tax_total or total. Every mutation of a line calls it, so the
 * stored totals cannot drift from the lines that justify them.
 */
async function recalcInvoice(c: PoolClient, invoiceId: string) {
  // Rounded per line, then summed: rounding the sum instead produces a total
  // that does not equal the column of numbers printed above it.
  await c.query(
    `WITH totals AS (
       SELECT
         coalesce(sum( (quantity * unit_amount) / ${QTY_SCALE} ), 0)::bigint AS subtotal,
         coalesce(sum( round( ((quantity * unit_amount) / ${QTY_SCALE}::numeric) * tax_bps / 10000 ) ), 0)::bigint AS tax_total
         FROM invoice_lines WHERE invoice_id = $1
     )
     UPDATE invoices SET
       subtotal = totals.subtotal,
       tax_total = totals.tax_total,
       total = totals.subtotal + totals.tax_total,
       updated_at = now()
     FROM totals WHERE invoices.id = $1`, [invoiceId]);
}

/** The next invoice number for this merchant, counted per merchant. */
async function nextNumber(c: PoolClient, merchantId: string): Promise<string> {
  const row = await one<{ next_number: string }>(c,
    `INSERT INTO invoice_counters (merchant_id, next_number) VALUES ($1, 2)
     ON CONFLICT (merchant_id) DO UPDATE SET next_number = invoice_counters.next_number + 1
     RETURNING invoice_counters.next_number - 1 AS next_number`, [merchantId]);
  return `INV-${String(row!.next_number).padStart(4, '0')}`;
}

function toQty(q?: number): number {
  if (q === undefined) return QTY_SCALE;
  if (!Number.isFinite(q) || q <= 0) {
    throw new ApiError(400, 'parameter_invalid', 'Quantity must be greater than zero.');
  }
  return Math.round(q * QTY_SCALE);
}

export async function createInvoice(m: Merchant, input: {
  customer: string;
  currency: string;
  title?: string;
  note?: string;
  due_at?: Date;
  lines?: LineInput[];
  metadata?: Record<string, string>;
}) {
  if (m.status !== 'active') {
    throw new ApiError(403, 'account_inactive', 'This account cannot accept payments yet.');
  }
  return tx(async (c) => {
    const cus = await one(c, 'SELECT * FROM customers WHERE id=$1 AND merchant_id=$2', [input.customer, m.id]);
    if (!cus) throw new ApiError(404, 'resource_missing', 'Customer not found.');

    const inv = await one<any>(c,
      `INSERT INTO invoices (id, merchant_id, customer_id, number, currency, title, note, due_at, metadata)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [newId('inv'), m.id, cus.id, await nextNumber(c, m.id), input.currency,
       input.title ?? null, input.note ?? null, input.due_at ?? null,
       JSON.stringify(input.metadata ?? {})]);

    let pos = 0;
    for (const l of input.lines ?? []) {
      await c.query(
        `INSERT INTO invoice_lines (id, invoice_id, position, description, quantity, unit_amount, tax_bps)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [newId('il'), inv.id, pos++, l.description, toQty(l.quantity), l.unit_amount, l.tax_bps ?? 0]);
    }
    await recalcInvoice(c, inv.id);
    return loadInvoice(c, m.id, inv.id);
  });
}

export async function addLine(m: Merchant, invoiceId: string, line: LineInput) {
  return tx(async (c) => {
    const inv = await mutableInvoice(c, m.id, invoiceId);
    const pos = await one<{ n: number }>(c,
      'SELECT coalesce(max(position), -1) + 1 AS n FROM invoice_lines WHERE invoice_id=$1', [inv.id]);
    await c.query(
      `INSERT INTO invoice_lines (id, invoice_id, position, description, quantity, unit_amount, tax_bps)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [newId('il'), inv.id, pos!.n, line.description, toQty(line.quantity), line.unit_amount, line.tax_bps ?? 0]);
    await recalcInvoice(c, inv.id);
    return loadInvoice(c, m.id, inv.id);
  });
}

export async function removeLine(m: Merchant, invoiceId: string, lineId: string) {
  return tx(async (c) => {
    const inv = await mutableInvoice(c, m.id, invoiceId);
    const r = await c.query('DELETE FROM invoice_lines WHERE id=$1 AND invoice_id=$2', [lineId, inv.id]);
    if (!r.rowCount) throw new ApiError(404, 'resource_missing', 'That line is not on this invoice.');
    await recalcInvoice(c, inv.id);
    return loadInvoice(c, m.id, inv.id);
  });
}

/**
 * An invoice that may still be edited.
 *
 * Only a draft. Once it is sent the customer has a copy, and changing the
 * amount underneath them is how a dispute starts — the line items they agreed
 * to have to be the line items they are charged for.
 */
async function mutableInvoice(c: PoolClient, merchantId: string, id: string) {
  const inv = await one<any>(c,
    'SELECT * FROM invoices WHERE id=$1 AND merchant_id=$2 FOR UPDATE', [id, merchantId]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  if (inv.status !== 'draft') {
    throw new ApiError(400, 'invoice_not_editable',
      `This invoice is ${inv.status}. Only a draft can be changed — void it and raise a new one.`);
  }
  return inv;
}

/**
 * Send it: the invoice becomes payable and gets its link.
 *
 * The link's amount is the stored total, which came from the lines. Nothing
 * the caller sends decides what the customer pays.
 */
export async function sendInvoice(m: Merchant, id: string) {
  const inv = await one<any>(pool, 'SELECT * FROM invoices WHERE id=$1 AND merchant_id=$2', [id, m.id]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  if (inv.status === 'open') return loadInvoice(pool, m.id, id);   // already sent; idempotent
  if (inv.status !== 'draft') {
    throw new ApiError(400, 'invoice_not_sendable', `This invoice is ${inv.status}.`);
  }
  if (Number(inv.total) <= 0) {
    throw new ApiError(400, 'invoice_empty', 'Add at least one line before sending.');
  }

  // createLink enforces its own minimum and the merchant's active status.
  const link = await createLink(m, {
    title: inv.title || `Invoice ${inv.number}`,
    currency: inv.currency,
    amount: Number(inv.total),
    description: inv.note ?? undefined,
    max_uses: 1,                       // an invoice is paid once
    expires_at: null,
  });

  const row = await one<any>(pool,
    `UPDATE invoices SET status='open', sent_at=now(), payment_link_id=$2, updated_at=now()
      WHERE id=$1 AND status='draft' RETURNING *`, [id, link.id]);
  if (!row) return loadInvoice(pool, m.id, id);   // someone else sent it first

  await tx((c) => emitEvent(c, m.id, 'invoice.sent', { id: row.id, number: row.number, total: Number(row.total) }));
  return loadInvoice(pool, m.id, id);
}

/**
 * Cancel an unpaid invoice.
 *
 * Voided, never deleted: an invoice number that vanishes is a gap in a
 * sequence an auditor will ask about. The payment link is switched off in the
 * same breath, or the customer could still pay a bill that no longer exists.
 */
export async function voidInvoice(m: Merchant, id: string) {
  const inv = await one<any>(pool, 'SELECT * FROM invoices WHERE id=$1 AND merchant_id=$2', [id, m.id]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  if (inv.status === 'paid') {
    throw new ApiError(400, 'invoice_paid', 'This invoice has been paid. Refund the payment instead of voiding it.');
  }
  if (inv.status === 'void') return loadInvoice(pool, m.id, id);

  if (inv.payment_link_id) await setLinkActive(m, inv.payment_link_id, false);
  const row = await one<any>(pool,
    `UPDATE invoices SET status='void', voided_at=now(), updated_at=now() WHERE id=$1 RETURNING *`, [id]);
  await tx((c) => emitEvent(c, m.id, 'invoice.voided', { id: row.id, number: row.number }));
  return loadInvoice(pool, m.id, id);
}

/**
 * Credit a successful payment to the invoice it settled.
 *
 * Called from the payment success path, inside its transaction, so an invoice
 * cannot be marked paid by a payment that later failed to commit.
 */
export async function creditInvoicePayment(c: PoolClient, pi: {
  id: string; payment_link_id?: string | null; amount_captured?: number | string | null;
}) {
  if (!pi.payment_link_id) return;
  const inv = await one<any>(c,
    'SELECT * FROM invoices WHERE payment_link_id = $1 FOR UPDATE', [pi.payment_link_id]);
  if (!inv) return;

  const paid = Number(pi.amount_captured ?? 0);
  if (paid <= 0) return;

  await c.query('UPDATE payment_intents SET invoice_id = $2 WHERE id = $1', [pi.id, inv.id]);
  const row = await one<any>(c,
    `UPDATE invoices SET
       amount_paid = amount_paid + $2,
       status = CASE WHEN amount_paid + $2 >= total THEN 'paid' ELSE status END,
       paid_at = CASE WHEN amount_paid + $2 >= total THEN coalesce(paid_at, now()) ELSE paid_at END,
       updated_at = now()
     WHERE id = $1 RETURNING *`, [inv.id, paid]);
  if (row?.status === 'paid') {
    await emitEvent(c, inv.merchant_id, 'invoice.paid',
      { id: row.id, number: row.number, total: Number(row.total) });
  }
}

export async function listInvoices(m: Merchant, opts: { status?: string; customer?: string } = {}) {
  const r = await pool.query(
    `SELECT i.*, c.email AS customer_email, c.name AS customer_name,
            l.code AS link_code
       FROM invoices i
       JOIN customers c ON c.id = i.customer_id
       LEFT JOIN payment_links l ON l.id = i.payment_link_id
      WHERE i.merchant_id = $1
        AND ($2::text IS NULL OR i.status = $2)
        AND ($3::text IS NULL OR i.customer_id = $3)
      ORDER BY i.created_at DESC LIMIT 200`,
    [m.id, opts.status ?? null, opts.customer ?? null]);
  return r.rows.map(present);
}

export async function getInvoice(m: Merchant, id: string) {
  return loadInvoice(pool, m.id, id);
}

/** Sent, unpaid and past its due date. */
export async function overdueInvoices(m: Merchant) {
  const r = await pool.query(
    `SELECT i.*, c.email AS customer_email, c.name AS customer_name, l.code AS link_code
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       LEFT JOIN payment_links l ON l.id = i.payment_link_id
      WHERE i.merchant_id=$1 AND i.status='open' AND i.due_at IS NOT NULL AND i.due_at < now()
      ORDER BY i.due_at`, [m.id]);
  return r.rows.map(present);
}

async function loadInvoice(db: PoolClient | typeof pool, merchantId: string, id: string) {
  const inv = await one<any>(db,
    `SELECT i.*, c.email AS customer_email, c.name AS customer_name, l.code AS link_code
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       LEFT JOIN payment_links l ON l.id = i.payment_link_id
      WHERE i.id=$1 AND i.merchant_id=$2`, [id, merchantId]);
  if (!inv) throw new ApiError(404, 'resource_missing', 'Invoice not found.');
  const lines = await db.query(
    'SELECT * FROM invoice_lines WHERE invoice_id=$1 ORDER BY position', [id]);
  return { ...present(inv), lines: lines.rows.map(presentLine) };
}

function presentLine(l: any) {
  const amount = Math.trunc((Number(l.quantity) * Number(l.unit_amount)) / QTY_SCALE);
  return {
    id: l.id,
    description: l.description,
    quantity: Number(l.quantity) / QTY_SCALE,
    unit_amount: Number(l.unit_amount),
    tax_bps: l.tax_bps,
    amount,
    tax: Math.round((amount * Number(l.tax_bps)) / 10000),
  };
}

function present(i: any) {
  return {
    id: i.id,
    object: 'invoice',
    number: i.number,
    customer: i.customer_id,
    customer_email: i.customer_email,
    customer_name: i.customer_name,
    currency: i.currency,
    subtotal: Number(i.subtotal),
    tax_total: Number(i.tax_total),
    total: Number(i.total),
    amount_paid: Number(i.amount_paid),
    amount_due: Math.max(0, Number(i.total) - Number(i.amount_paid)),
    status: i.status,
    title: i.title,
    note: i.note,
    due_at: i.due_at,
    overdue: i.status === 'open' && i.due_at != null && new Date(i.due_at).getTime() < Date.now(),
    payment_url: i.link_code ? `/pay/${i.link_code}` : null,
    sent_at: i.sent_at,
    paid_at: i.paid_at,
    created_at: i.created_at,
  };
}
