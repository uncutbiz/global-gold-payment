/**
 * Reports — what a merchant earned, over a period.
 *
 * No new tables. Every figure here is derived from payment_intents and
 * refunds, which are the same rows the ledger is built from, so a report and
 * the books cannot disagree about what happened.
 *
 * Two things this is careful about, because getting either wrong means a
 * merchant files the wrong numbers:
 *
 *   1. Currency is never mixed. A merchant taking USD and NGN has two
 *      separate sets of totals, never one meaningless sum. Everything is
 *      grouped by currency and returned as a list.
 *
 *   2. A refund counts on the day the money went BACK, not the day the
 *      payment came in. Netting it against the original date would silently
 *      restate a month that has already been reported and reconciled.
 */
import { pool } from '../db.js';
import { ApiError } from '../util/common.js';
import type { Merchant } from '../payments/service.js';

export interface Period { from: Date; to: Date }

/** Default to the last 30 days, and refuse a range that cannot be answered. */
export function periodFrom(input: { from?: string; to?: string }): Period {
  const to = input.to ? new Date(input.to) : new Date();
  const from = input.from ? new Date(input.from) : new Date(to.getTime() - 30 * 86_400_000);
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) {
    throw new ApiError(400, 'parameter_invalid', 'from and to must be dates.');
  }
  if (from > to) throw new ApiError(400, 'parameter_invalid', 'from is after to.');
  if (to.getTime() - from.getTime() > 400 * 86_400_000) {
    throw new ApiError(400, 'parameter_invalid', 'Ask for at most 400 days at a time.');
  }
  return { from, to };
}

/**
 * Headline totals per currency.
 *
 * `net` is what the merchant actually keeps: captured, less what was refunded,
 * less our fee. It is computed here rather than stored so that it cannot drift
 * from its parts.
 */
export async function summary(m: Merchant, p: Period) {
  const r = await pool.query(
    `WITH captured AS (
       SELECT currency,
              count(*)::int                        AS payments,
              coalesce(sum(amount_captured), 0)    AS gross,
              coalesce(sum(fee), 0)                AS fees,
              coalesce(sum(platform_fee), 0)       AS platform_fees
         FROM payment_intents
        WHERE merchant_id = $1 AND status = 'succeeded'
          AND created_at >= $2 AND created_at < $3
        GROUP BY currency
     ),
     -- Refunds land on their own date, so they are counted separately and
     -- joined on currency rather than netted into the payment's row.
     refunded AS (
       SELECT p.currency,
              count(r.*)::int                 AS refunds,
              coalesce(sum(r.amount), 0)      AS refunded
         FROM refunds r JOIN payment_intents p ON p.id = r.payment_intent_id
        WHERE r.merchant_id = $1 AND r.status = 'succeeded'
          AND r.created_at >= $2 AND r.created_at < $3
        GROUP BY p.currency
     )
     SELECT coalesce(c.currency, f.currency)   AS currency,
            coalesce(c.payments, 0)            AS payments,
            coalesce(c.gross, 0)               AS gross,
            coalesce(c.fees, 0)                AS fees,
            coalesce(c.platform_fees, 0)       AS platform_fees,
            coalesce(f.refunds, 0)             AS refunds,
            coalesce(f.refunded, 0)            AS refunded
       FROM captured c FULL OUTER JOIN refunded f ON f.currency = c.currency
      ORDER BY 1`,
    [m.id, p.from, p.to]);

  return r.rows.map((x) => {
    const gross = Number(x.gross), refunded = Number(x.refunded), fees = Number(x.fees);
    return {
      currency: x.currency,
      payments: Number(x.payments),
      gross,
      refunds: Number(x.refunds),
      refunded,
      fees,
      platform_fees: Number(x.platform_fees),
      net: gross - refunded - fees,
      average_payment: x.payments > 0 ? Math.round(gross / Number(x.payments)) : 0,
    };
  });
}

/** One row per day per currency, for a chart or a spreadsheet. */
export async function daily(m: Merchant, p: Period) {
  const r = await pool.query(
    `WITH days AS (
       SELECT generate_series(date_trunc('day', $2::timestamptz),
                              date_trunc('day', $3::timestamptz), interval '1 day') AS day
     ),
     ccy AS (
       SELECT DISTINCT currency FROM payment_intents
        WHERE merchant_id = $1 AND created_at >= $2 AND created_at < $3
     ),
     pay AS (
       SELECT date_trunc('day', created_at) AS day, currency,
              count(*)::int AS payments,
              coalesce(sum(amount_captured), 0) AS gross,
              coalesce(sum(fee), 0) AS fees
         FROM payment_intents
        WHERE merchant_id = $1 AND status = 'succeeded' AND created_at >= $2 AND created_at < $3
        GROUP BY 1, 2
     ),
     ref AS (
       SELECT date_trunc('day', r.created_at) AS day, p.currency,
              coalesce(sum(r.amount), 0) AS refunded
         FROM refunds r JOIN payment_intents p ON p.id = r.payment_intent_id
        WHERE r.merchant_id = $1 AND r.status = 'succeeded' AND r.created_at >= $2 AND r.created_at < $3
        GROUP BY 1, 2
     )
     -- Cross-joined against every day so quiet days appear as zeroes. A chart
     -- that simply omits them draws a line straight over the gap and makes a
     -- dead week look like a steady one.
     SELECT d.day, c.currency,
            coalesce(pay.payments, 0) AS payments,
            coalesce(pay.gross, 0)    AS gross,
            coalesce(pay.fees, 0)     AS fees,
            coalesce(ref.refunded, 0) AS refunded
       FROM days d CROSS JOIN ccy c
       LEFT JOIN pay ON pay.day = d.day AND pay.currency = c.currency
       LEFT JOIN ref ON ref.day = d.day AND ref.currency = c.currency
      ORDER BY c.currency, d.day`,
    [m.id, p.from, p.to]);

  return r.rows.map((x) => ({
    day: (x.day as Date).toISOString().slice(0, 10),
    currency: x.currency,
    payments: Number(x.payments),
    gross: Number(x.gross),
    fees: Number(x.fees),
    refunded: Number(x.refunded),
    net: Number(x.gross) - Number(x.refunded) - Number(x.fees),
  }));
}

/**
 * Approved vs failed authorizations, one row per day — the dashboard chart.
 *
 * Counted from payment_attempts, not from payment_intents. An intent carries
 * only its FINAL state, so a card that was declined twice and then approved
 * shows up as one success and the two declines vanish. The attempts table is
 * the record of what the networks actually answered, which is the number a
 * merchant needs when they are trying to work out why sales dipped.
 *
 * Counts, not money, and deliberately so: a merchant taking USD and NGN has no
 * meaningful single total, and this chart is one line per outcome across the
 * whole account. Money stays in `summary`, grouped by currency.
 *
 * `blocked` (our own risk engine) is reported separately from `declined` (the
 * issuer's answer). They look the same to a customer and mean opposite things
 * to the merchant, so the chart adds them into one "failed" line while the
 * per-day detail keeps them apart.
 */
export async function series(m: Merchant, days = 7) {
  const n = Math.min(Math.max(Math.trunc(days) || 7, 1), 90);
  const r = await pool.query(
    `WITH span AS (
       SELECT generate_series(date_trunc('day', now()) - make_interval(days => $2 - 1),
                              date_trunc('day', now()), interval '1 day') AS day
     ),
     att AS (
       SELECT date_trunc('day', a.created_at) AS day,
              count(*) FILTER (WHERE a.outcome = 'approved')::int AS approved,
              count(*) FILTER (WHERE a.outcome = 'declined')::int AS declined,
              count(*) FILTER (WHERE a.outcome = 'blocked')::int  AS blocked,
              count(*) FILTER (WHERE a.outcome = 'error')::int    AS errored
         FROM payment_attempts a
         JOIN payment_intents p ON p.id = a.payment_intent_id
        WHERE p.merchant_id = $1
          AND a.created_at >= date_trunc('day', now()) - make_interval(days => $2 - 1)
        GROUP BY 1
     )
     -- LEFT JOIN against the full span: a day with no attempts must come back
     -- as a zero, not be missing. A line chart draws straight through a gap
     -- and turns a dead Sunday into a normal one.
     SELECT s.day,
            coalesce(a.approved, 0) AS approved,
            coalesce(a.declined, 0) AS declined,
            coalesce(a.blocked,  0) AS blocked,
            coalesce(a.errored,  0) AS errored
       FROM span s LEFT JOIN att a ON a.day = s.day
      ORDER BY s.day`,
    [m.id, n]);

  return r.rows.map((x) => {
    const declined = Number(x.declined), blocked = Number(x.blocked), errored = Number(x.errored);
    return {
      day: (x.day as Date).toISOString().slice(0, 10),
      approved: Number(x.approved),
      declined,
      blocked,
      errored,
      failed: declined + blocked + errored,
    };
  });
}

/** Which payment links earned the most over the period. */
export async function topLinks(m: Merchant, p: Period, limit = 10) {
  const r = await pool.query(
    `SELECT l.id, l.title, l.code, p.currency,
            count(*)::int AS payments,
            coalesce(sum(p.amount_captured - p.amount_refunded), 0) AS collected
       FROM payment_intents p JOIN payment_links l ON l.id = p.payment_link_id
      WHERE p.merchant_id = $1 AND p.status = 'succeeded'
        AND p.created_at >= $2 AND p.created_at < $3
      GROUP BY l.id, l.title, l.code, p.currency
      ORDER BY collected DESC LIMIT $4`,
    [m.id, p.from, p.to, Math.min(limit, 50)]);
  return r.rows.map((x) => ({ ...x, collected: Number(x.collected) }));
}

/**
 * The daily figures as CSV, for a spreadsheet or an accountant.
 *
 * Amounts are written as decimal currency (12.34), not minor units: this file
 * is read by people and by Excel, and 1234 in a column headed "gross" gets
 * filed as twelve hundred pounds. Every field is quoted and internal quotes
 * doubled — a merchant's own text ends up in here.
 */
export async function dailyCsv(m: Merchant, p: Period): Promise<string> {
  const rows = await daily(m, p);
  const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const money = (minor: number) => (minor / 100).toFixed(2);
  const head = ['Date', 'Currency', 'Payments', 'Gross', 'Refunded', 'Fees', 'Net'];
  const lines = [head.map(q).join(',')];
  for (const r of rows) {
    lines.push([
      q(r.day), q(r.currency.toUpperCase()), q(r.payments),
      q(money(r.gross)), q(money(r.refunded)), q(money(r.fees)), q(money(r.net)),
    ].join(','));
  }
  return lines.join('\r\n') + '\r\n';
}
