/**
 * Customers — the people a merchant sells to.
 *
 * A customer belongs to exactly one merchant. There is no shared identity
 * across the platform: if two merchants both sell to the same person, they
 * hold two unrelated records. Linking them would let one merchant's list
 * disclose the existence of another's, which is not ours to give away.
 *
 * Every function here takes the merchant and scopes its query by it. That is
 * the whole of the access control for this resource, so it is not optional in
 * any one of them — a single unscoped query is a customer list leak.
 */
import type { PoolClient } from 'pg';
import { Db, one, pool } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import type { Merchant } from '../payments/service.js';

export interface CustomerInput {
  email?: string | null;
  name?: string | null;
  phone?: string | null;
  metadata?: Record<string, string>;
}

function clean(email?: string | null): string | null {
  const e = email?.trim().toLowerCase();
  return e ? e : null;
}

export async function createCustomer(m: Merchant, input: CustomerInput) {
  const email = clean(input.email);
  if (!email && !input.name) {
    throw new ApiError(400, 'parameter_missing', 'A customer needs an email or a name.');
  }
  try {
    return present(await one(pool,
      `INSERT INTO customers (id, merchant_id, email, name, phone, metadata)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [newId('cus'), m.id, email, input.name ?? null, input.phone ?? null,
       JSON.stringify(input.metadata ?? {})]));
  } catch (e: any) {
    if (e?.code === '23505') {
      throw new ApiError(409, 'customer_exists', 'You already have a customer with that email.');
    }
    throw e;
  }
}

/**
 * The customer with this email, created if there is not one yet.
 *
 * Used by checkout, where the buyer types an email and neither they nor the
 * merchant should have to care whether they have bought before. Races on the
 * unique index rather than checking first: two simultaneous checkouts by the
 * same buyer must not produce two records.
 */
export async function upsertCustomer(c: PoolClient | Db, merchantId: string, input: CustomerInput) {
  const email = clean(input.email);
  if (!email) return null;
  const row = await one(c,
    `INSERT INTO customers (id, merchant_id, email, name, phone)
     VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (merchant_id, lower(email)) WHERE email IS NOT NULL
     DO UPDATE SET
       -- Fill in blanks from the new payment, but never overwrite something
       -- the merchant typed with something a checkout form guessed.
       name  = coalesce(customers.name,  EXCLUDED.name),
       phone = coalesce(customers.phone, EXCLUDED.phone),
       updated_at = now()
     RETURNING *`,
    [newId('cus'), merchantId, email, input.name ?? null, input.phone ?? null]);
  return row ?? null;
}

export async function listCustomers(m: Merchant, opts: { query?: string; limit?: number } = {}) {
  const limit = Math.min(opts.limit ?? 50, 100);
  const q = opts.query?.trim();
  const r = await pool.query(
    `SELECT c.*,
            (SELECT count(*)::int FROM payment_intents p
              WHERE p.customer_id = c.id AND p.status = 'succeeded') AS payments,
            (SELECT coalesce(sum(p.amount_captured - p.amount_refunded), 0) FROM payment_intents p
              WHERE p.customer_id = c.id AND p.status = 'succeeded') AS spent,
            (SELECT max(p.created_at) FROM payment_intents p
              WHERE p.customer_id = c.id AND p.status = 'succeeded') AS last_payment_at
       FROM customers c
      WHERE c.merchant_id = $1
        AND ($2::text IS NULL OR c.email ILIKE '%'||$2||'%' OR c.name ILIKE '%'||$2||'%')
      ORDER BY c.created_at DESC LIMIT $3`,
    [m.id, q || null, limit]);
  return r.rows.map(present);
}

export async function getCustomer(m: Merchant, id: string) {
  const c = await one(pool,
    `SELECT c.*,
            (SELECT count(*)::int FROM payment_intents p
              WHERE p.customer_id = c.id AND p.status = 'succeeded') AS payments,
            (SELECT coalesce(sum(p.amount_captured - p.amount_refunded), 0) FROM payment_intents p
              WHERE p.customer_id = c.id AND p.status = 'succeeded') AS spent
       FROM customers c WHERE c.id = $1 AND c.merchant_id = $2`, [id, m.id]);
  if (!c) throw new ApiError(404, 'resource_missing', 'Customer not found.');

  const history = await pool.query(
    `SELECT id, amount, currency, status, description, created_at
       FROM payment_intents WHERE customer_id = $1 ORDER BY created_at DESC LIMIT 50`, [id]);
  return { ...present(c), payments_list: history.rows.map((p) => ({ ...p, amount: Number(p.amount) })) };
}

export async function updateCustomer(m: Merchant, id: string, input: CustomerInput) {
  const email = input.email === undefined ? undefined : clean(input.email);
  try {
    const c = await one(pool,
      `UPDATE customers SET
         email = coalesce($3, email), name = coalesce($4, name),
         phone = coalesce($5, phone), updated_at = now()
       WHERE id = $1 AND merchant_id = $2 RETURNING *`,
      [id, m.id, email ?? null, input.name ?? null, input.phone ?? null]);
    if (!c) throw new ApiError(404, 'resource_missing', 'Customer not found.');
    return present(c);
  } catch (e: any) {
    if (e?.code === '23505') {
      throw new ApiError(409, 'customer_exists', 'Another customer already has that email.');
    }
    throw e;
  }
}

function present(c: any) {
  return {
    id: c.id,
    object: 'customer',
    email: c.email,
    name: c.name,
    phone: c.phone,
    metadata: c.metadata,
    payments: c.payments === undefined ? undefined : Number(c.payments),
    spent: c.spent === undefined ? undefined : Number(c.spent),
    last_payment_at: c.last_payment_at,
    created_at: c.created_at,
  };
}
