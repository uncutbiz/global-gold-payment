/**
 * Connecting a merchant's processor account.
 *
 * The merchant clicks "Connect Square" in their dashboard, authorises us on
 * Square, and Square sends them back with a code. We exchange that code for an
 * access token that lets us take payments on their behalf — with our platform
 * fee attached — and store it encrypted.
 *
 * Two things here are security-critical rather than merely tidy:
 *
 *   1. The `state` value. It is created server-side, tied to one merchant, used
 *      once, and expires. Without that check, anyone who could reach the
 *      callback URL could attach their own Square account to someone else's
 *      Global Gold merchant, and that merchant's payments would land in the
 *      attacker's bank account.
 *
 *   2. The tokens. An access token is as good as the merchant's payment
 *      credentials, so it is encrypted with AES-256-GCM and bound to the
 *      merchant id as additional authenticated data — a row copied from one
 *      merchant to another fails to decrypt instead of silently working.
 */
import crypto from 'node:crypto';
import { config } from '../config.js';
import { Db, one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { isEnabled, providerFor, providerNamed, providersForCountry, supportsCountry } from '../providers/index.js';
import type { PaymentProvider, ProviderMerchant } from '../providers/provider.js';

const STATE_MINUTES = 15;

// ---------------------------------------------------------------- encryption

function seal(merchantId: string, plaintext: string) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', config.vaultKey, iv);
  c.setAAD(Buffer.from(merchantId));
  const ct = Buffer.concat([c.update(plaintext, 'utf8'), c.final()]);
  return { iv, ct, tag: c.getAuthTag() };
}

function open(merchantId: string, iv: Buffer, ct: Buffer, tag: Buffer): string {
  const d = crypto.createDecipheriv('aes-256-gcm', config.vaultKey, iv);
  d.setAAD(Buffer.from(merchantId));
  d.setAuthTag(tag);
  return Buffer.concat([d.update(ct), d.final()]).toString('utf8');
}

// ------------------------------------------------------------------ callbacks

export function redirectUri(providerName: string): string {
  return `${config.publicUrl.replace(/\/$/, '')}/v1/connect/${providerName}/callback`;
}

export function webhookUrl(providerName: string): string {
  return `${config.publicUrl.replace(/\/$/, '')}/v1/webhooks/${providerName}`;
}

// ------------------------------------------------------------------- connect

/**
 * Step 1: where to send the merchant, and the state we expect back.
 *
 * `want` picks a specific processor; without it the merchant keeps the one they
 * already use, or gets the best one for their country.
 */
export async function startConnect(merchantId: string, want?: string): Promise<{ url: string; state: string; provider: string }> {
  const m = await one(pool, 'SELECT id, country, status, provider FROM merchants WHERE id = $1', [merchantId]);
  if (!m) throw new ApiError(404, 'resource_missing', 'Business not found.');

  if (!supportsCountry(m.country)) {
    throw new ApiError(400, 'country_not_supported',
      `No processor enabled here can onboard a business in ${m.country}. ` +
      'We will need a different processor for this country.');
  }

  const chosen: PaymentProvider = want ? providerNamed(want) : providerFor(m);
  if (want && !chosen.merchantCountries.includes(m.country?.toUpperCase())) {
    const alternatives = providersForCountry(m.country).map((p) => p.name);
    throw new ApiError(400, 'country_not_supported',
      `${chosen.name} cannot onboard businesses in ${m.country}.` +
      (alternatives.length ? ` Use ${alternatives.join(' or ')} instead.` : ''));
  }
  if (!chosen.startOnboarding) {
    throw new ApiError(400, 'not_supported', `${chosen.name} accounts are not connected through this platform.`);
  }

  const uri = redirectUri(chosen.name);
  const { url, state } = chosen.startOnboarding(merchantId, uri);
  await pool.query(
    `INSERT INTO provider_oauth_states (state, merchant_id, provider, redirect_uri, expires_at)
     VALUES ($1,$2,$3,$4, now() + ($5 || ' minutes')::interval)`,
    [state, merchantId, chosen.name, uri, String(STATE_MINUTES)]);
  return { url, state, provider: chosen.name };
}

/** Step 2: the merchant came back. Trade the code for tokens and store them. */
export async function completeConnect(providerName: string, state: string, code: string) {
  const provider = providerNamed(providerName);
  if (!provider.completeOnboarding) throw new ApiError(400, 'not_supported', 'This provider has no connect flow.');

  // Claim the state atomically: a replayed callback finds nothing to claim.
  // Matching on the provider too stops a state issued for one processor being
  // redeemed at another's callback.
  const claimed = await one(pool,
    `UPDATE provider_oauth_states SET used_at = now()
      WHERE state = $1 AND provider = $2 AND used_at IS NULL AND expires_at > now()
      RETURNING merchant_id, redirect_uri`,
    [state, provider.name]);
  if (!claimed) {
    throw new ApiError(400, 'invalid_state',
      'That connection link has expired or was already used. Start again from your dashboard.');
  }

  const result = await provider.completeOnboarding(code, claimed.redirect_uri);

  // Refuse an account already attached to a different merchant of ours.
  const clash = await one(pool,
    `SELECT id FROM merchants WHERE provider = $1 AND provider_account_id = $2 AND id <> $3`,
    [provider.name, result.accountId, claimed.merchant_id]);
  if (clash) {
    throw new ApiError(409, 'account_already_connected',
      `That ${provider.name} account is already connected to another business here.`);
  }

  // Square hands us a seller token; Stripe does not (we use our platform key
  // with a Stripe-Account header). Only store what actually exists.
  const access = result.accessToken ? seal(claimed.merchant_id, result.accessToken) : null;
  const refresh = result.refreshToken ? seal(claimed.merchant_id, result.refreshToken) : null;

  await pool.query(
    `UPDATE merchants SET
       provider = $2, provider_account_id = $3, provider_location_id = $4,
       provider_key_id = $5,
       provider_access_iv = $6, provider_access_ct = $7, provider_access_tag = $8,
       provider_refresh_iv = $9, provider_refresh_ct = $10, provider_refresh_tag = $11,
       provider_expires_at = $12, provider_connected_at = now()
     WHERE id = $1`,
    [claimed.merchant_id, provider.name, result.accountId, result.locationId ?? null,
     config.vaultKeyId,
     access?.iv ?? null, access?.ct ?? null, access?.tag ?? null,
     refresh?.iv ?? null, refresh?.ct ?? null, refresh?.tag ?? null,
     result.expiresAt ?? null]);

  return {
    merchant_id: claimed.merchant_id,
    provider: provider.name,
    account_id: result.accountId,
    business_name: result.businessName,
    location_id: result.locationId,
    currency: result.currency,
    country: result.country,
  };
}

/**
 * What the payment code needs to charge on this merchant's behalf, together with
 * the provider that merchant is actually on — so two merchants on different
 * processors both work.
 */
export async function providerMerchant(db: Db, merchantId: string): Promise<ProviderMerchant & { provider: PaymentProvider }> {
  const m = await one(db,
    `SELECT id, country, provider, provider_account_id, provider_location_id, provider_key_id,
            provider_access_iv, provider_access_ct, provider_access_tag,
            provider_refresh_iv, provider_refresh_ct, provider_refresh_tag,
            provider_expires_at
       FROM merchants WHERE id = $1`, [merchantId]);
  if (!m) throw new ApiError(404, 'resource_missing', 'Business not found.');

  const provider = providerFor(m);

  // The simulated provider needs no connected account.
  if (provider.name === 'simulated') return { id: merchantId, provider };

  if (!m.provider_account_id) {
    throw new ApiError(400, 'merchant_not_connected',
      `This business has not connected its ${provider.name} account yet, so it cannot take payments.`);
  }
  // Stripe uses our platform key plus a Stripe-Account header, so there is no
  // per-merchant token to decrypt. Square stores one, and it is encrypted.
  let accessToken = '';
  if (m.provider_access_ct) {
    if (m.provider_key_id !== config.vaultKeyId) {
      throw new Error(`vault key ${m.provider_key_id} is not loaded; cannot read merchant ${merchantId}'s token`);
    }
    accessToken = open(merchantId, m.provider_access_iv, m.provider_access_ct, m.provider_access_tag);
  }

  // Refresh within a day of expiry, so a charge never fails on a stale token.
  const soon = m.provider_expires_at && new Date(m.provider_expires_at).getTime() - Date.now() < 24 * 3600_000;
  if (soon && m.provider_refresh_ct && provider.refreshAccess) {
    try {
      const refreshToken = open(merchantId, m.provider_refresh_iv, m.provider_refresh_ct, m.provider_refresh_tag);
      const next = await provider.refreshAccess(refreshToken);
      const a = seal(merchantId, next.accessToken);
      const r = next.refreshToken ? seal(merchantId, next.refreshToken) : null;
      await pool.query(
        `UPDATE merchants SET provider_access_iv=$2, provider_access_ct=$3, provider_access_tag=$4,
           provider_refresh_iv=COALESCE($5, provider_refresh_iv),
           provider_refresh_ct=COALESCE($6, provider_refresh_ct),
           provider_refresh_tag=COALESCE($7, provider_refresh_tag),
           provider_expires_at=$8, provider_key_id=$9
         WHERE id=$1`,
        [merchantId, a.iv, a.ct, a.tag, r?.iv ?? null, r?.ct ?? null, r?.tag ?? null,
         next.expiresAt ?? null, config.vaultKeyId]);
      accessToken = next.accessToken;
    } catch {
      // Keep using the current token: it may still have hours left, and failing
      // the payment because a refresh failed would be worse than trying.
    }
  }

  return {
    id: merchantId,
    accountId: m.provider_account_id,
    accessToken,
    locationId: m.provider_location_id,
    provider,
  };
}

/** Dashboard status, with nothing secret in it. */
/**
 * What a checkout page in the shopper's browser needs in order to tokenise a
 * card with the merchant's processor.
 *
 * Every value returned here is public by design — a Square application id, a
 * Square location id, a Stripe publishable key, a Stripe account id. They are
 * meant to be in page source; none of them can move money on their own. The
 * secret half (application secret, `sk_…`, the merchant's access token) stays
 * on the server and is never part of this object.
 *
 * Callers authenticate with the PaymentIntent's client secret, so this does not
 * expose which processor a business uses to anyone who merely knows its name.
 */
export async function checkoutConfig(merchantId: string) {
  const m = await one(pool,
    `SELECT country, provider, provider_account_id, provider_location_id FROM merchants WHERE id = $1`,
    [merchantId]);
  if (!m) throw new ApiError(404, 'resource_missing', 'Business not found.');

  const provider = providerFor(m);
  const out: Record<string, unknown> = {
    object: 'checkout_config',
    provider: provider.name,
    tokenizes_in_browser: provider.tokenizesInBrowser,
  };

  if (provider.name === 'square') {
    if (!config.square.appId) {
      throw new ApiError(503, 'checkout_unavailable',
        'This deployment has Square enabled but SQUARE_APP_ID is not set, so the checkout page cannot tokenise a card.');
    }
    out.square = {
      application_id: config.square.appId,
      location_id: m.provider_location_id,
      environment: config.square.env,
      // The SDK itself differs between sandbox and production.
      sdk_url: config.square.env === 'production'
        ? 'https://web.squarecdn.com/v1/square.js'
        : 'https://sandbox.web.squarecdn.com/v1/square.js',
    };
  }

  if (provider.name === 'stripe') {
    if (!config.stripe.publishableKey) {
      throw new ApiError(503, 'checkout_unavailable',
        'This deployment has Stripe enabled but STRIPE_PUBLISHABLE_KEY is not set, so the checkout page cannot tokenise a card.');
    }
    out.stripe = {
      publishable_key: config.stripe.publishableKey,
      // Tokenising on the connected account is what makes the resulting
      // PaymentMethod usable in a direct charge on that account.
      account: m.provider_account_id,
      sdk_url: 'https://js.stripe.com/v3/',
    };
  }

  return out;
}

export async function connectionStatus(merchantId: string) {
  const m = await one(pool,
    `SELECT country, provider, provider_account_id, provider_location_id, provider_connected_at
       FROM merchants WHERE id = $1`, [merchantId]);
  if (!m) throw new ApiError(404, 'resource_missing', 'Business not found.');
  const available = providersForCountry(m.country);
  // Once connected, the merchant stays on that provider; otherwise show the
  // one they would get, plus any alternatives for their country.
  const current = m.provider && isEnabled(m.provider) ? providerNamed(m.provider) : available[0];
  return {
    provider: current?.name ?? null,
    required: current ? current.name !== 'simulated' : false,
    connected: Boolean(m.provider_account_id),
    account_id: m.provider_account_id ?? null,
    location_id: m.provider_location_id ?? null,
    connected_at: m.provider_connected_at ?? null,
    country: m.country,
    country_supported: available.length > 0,
    available_providers: available.map((p) => ({
      name: p.name,
      connect_url_path: `/v1/connect/start?provider=${p.name}`,
    })),
  };
}

export async function disconnect(merchantId: string) {
  await pool.query(
    `UPDATE merchants SET provider_account_id=NULL, provider_location_id=NULL,
       provider_access_iv=NULL, provider_access_ct=NULL, provider_access_tag=NULL,
       provider_refresh_iv=NULL, provider_refresh_ct=NULL, provider_refresh_tag=NULL,
       provider_expires_at=NULL, provider_connected_at=NULL
     WHERE id=$1`, [merchantId]);
  return { disconnected: true };
}

// ------------------------------------------------------------------ webhooks

/**
 * Record a provider notification once. Providers retry, so the same event can
 * arrive several times; the unique index makes the second arrival a no-op.
 * Returns false when we have seen it before.
 */
export async function recordProviderEvent(input: {
  provider: string; eventId: string; type: string; accountId?: string | null; payload: unknown;
}): Promise<boolean> {
  return tx(async (db) => {
    const merchant = input.accountId
      ? await one(db, 'SELECT id FROM merchants WHERE provider = $1 AND provider_account_id = $2',
                  [input.provider, input.accountId])
      : null;
    const r = await db.query(
      `INSERT INTO provider_events (id, provider, event_id, type, merchant_id, payload)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (provider, event_id) DO NOTHING`,
      [newId('pev'), input.provider, input.eventId, input.type, merchant?.id ?? null,
       JSON.stringify(input.payload)]);
    return r.rowCount === 1;
  });
}
