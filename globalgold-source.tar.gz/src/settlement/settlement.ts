/**
 * Daily clearing & settlement (simulated).
 *
 * 1. Clearing: gather captured payments and refunds not yet cleared, write a
 *    clearing file for the sponsor processor (real formats: Visa BASE II / TC05,
 *    Mastercard IPM, or the processor's own layout).
 * 2. Funding: the sponsor bank pays the net amount into our FBO account
 *    (simulated as immediate; really T+1/T+2 minus interchange & scheme fees).
 * 3. Merchant settlement: pending balances become available.
 * Payouts then move available balances to merchants' bank accounts (ACH/RTP).
 */
import { one, pool, tx } from '../db.js';
import { acct, balance, postJournal } from '../ledger/ledger.js';
import { ApiError, newId } from '../util/common.js';
import { emitEvent } from '../webhooks/webhooks.js';
import type { Merchant } from '../payments/service.js';

function line(kind: 'SALE' | 'RFND', id: string, rrn: string, auth: string, amount: number, merchantId: string) {
  return [kind, id.padEnd(32), (rrn ?? '').padEnd(12), (auth ?? '').padEnd(6), String(amount).padStart(12, '0'), merchantId.padEnd(24)].join('|');
}

export async function runSettlement() {
  return tx(async (c) => {
    const results: any[] = [];
    const currencies = await c.query(
      `SELECT DISTINCT currency FROM payment_intents WHERE status='succeeded' AND clearing_batch_id IS NULL
       UNION SELECT DISTINCT pi.currency FROM refunds r JOIN payment_intents pi ON pi.id = r.payment_intent_id
             WHERE r.status='succeeded' AND r.clearing_batch_id IS NULL
       UNION SELECT DISTINCT currency FROM wallet_transactions
             WHERE type='top_up' AND status='completed' AND clearing_batch_id IS NULL`);

    for (const { currency } of currencies.rows) {
      const sales = (await c.query(
        `SELECT * FROM payment_intents WHERE status='succeeded' AND clearing_batch_id IS NULL AND currency=$1 ORDER BY created_at FOR UPDATE`,
        [currency])).rows;
      const refunds = (await c.query(
        `SELECT r.*, pi.wallet_user_id FROM refunds r JOIN payment_intents pi ON pi.id = r.payment_intent_id
          WHERE r.status='succeeded' AND r.clearing_batch_id IS NULL AND pi.currency=$1 ORDER BY r.created_at FOR UPDATE OF r`,
        [currency])).rows;

      const topUps = (await c.query(
        `SELECT * FROM wallet_transactions WHERE type='top_up' AND status='completed' AND clearing_batch_id IS NULL AND currency=$1
          ORDER BY created_at FOR UPDATE`, [currency])).rows;

      // Wallet-funded payments and their refunds never touch the card network:
      // they settle to the merchant but are not in the clearing file or the bank funding.
      const cardSales = sales.filter((p) => !p.wallet_user_id);
      const cardRefunds = refunds.filter((r) => !r.wallet_user_id);

      const batchId = newId('clr');
      const salesTotal = sales.reduce((s, p) => s + p.amount_captured, 0);
      const refundTotal = refunds.reduce((s, r) => s + r.amount, 0);
      const topUpTotal = topUps.reduce((s, t) => s + t.amount, 0);
      const net = cardSales.reduce((s, p) => s + p.amount_captured, 0) + topUpTotal
                - cardRefunds.reduce((s, r) => s + r.amount, 0);
      const records = cardSales.length + cardRefunds.length + topUps.length;
      const file = [
        `HDR|${batchId}|${new Date().toISOString()}|${currency.toUpperCase()}`,
        ...cardSales.map((p) => line('SALE', p.id, p.network_ref, p.auth_code, p.amount_captured, p.merchant_id)),
        ...topUps.map((t) => line('SALE', t.id, t.network_ref, t.auth_code, t.amount, 'GLOBALGOLD_WALLET')),
        ...cardRefunds.map((r) => line('RFND', r.id, r.network_ref, '', r.amount, r.merchant_id)),
        `TRL|${records}|${String(net).padStart(14, '0')}`,
      ].join('\n');

      await c.query(
        `INSERT INTO clearing_batches (id, record_count, net_amount, currency, file_content, status) VALUES ($1,$2,$3,$4,$5,'funded')`,
        [batchId, records, net, currency, file]);
      await c.query('UPDATE payment_intents SET clearing_batch_id=$1 WHERE id = ANY($2)', [batchId, sales.map((s) => s.id)]);
      await c.query('UPDATE refunds SET clearing_batch_id=$1 WHERE id = ANY($2)', [batchId, refunds.map((r) => r.id)]);
      await c.query('UPDATE wallet_transactions SET clearing_batch_id=$1 WHERE id = ANY($2)', [batchId, topUps.map((t) => t.id)]);

      // Sponsor bank funding of the net batch.
      if (net !== 0) {
        await postJournal(c, currency, { type: 'clearing_batch', id: batchId }, `funding ${batchId}`, net > 0
          ? [{ account: acct.bankCash, debit: net }, { account: acct.receivable, credit: net }]
          : [{ account: acct.receivable, debit: -net }, { account: acct.bankCash, credit: -net }]);
      }

      // Merchant settlement: move exactly this batch's net (after fees) from pending -> available.
      const perMerchant = new Map<string, number>();
      for (const s of sales) perMerchant.set(s.merchant_id, (perMerchant.get(s.merchant_id) ?? 0) + s.amount_captured - s.fee);
      for (const r of refunds) perMerchant.set(r.merchant_id, (perMerchant.get(r.merchant_id) ?? 0) - r.amount);
      for (const [mId, pending] of perMerchant) {
        if (pending === 0) continue;
        await postJournal(c, currency, { type: 'clearing_batch', id: batchId }, `settle ${mId}`, pending > 0
          ? [{ account: acct.pending(mId), debit: pending }, { account: acct.available(mId), credit: pending }]
          : [{ account: acct.available(mId), debit: -pending }, { account: acct.pending(mId), credit: -pending }]);
      }
      results.push({ id: batchId, currency, records, sales: salesTotal, refunds: refundTotal, wallet_top_ups: topUpTotal, bank_funding: net });
    }
    return results;
  });
}

export async function getBalance(merchantId: string) {
  const r = await pool.query(
    `SELECT currency,
            COALESCE(SUM(credit - debit) FILTER (WHERE account = $1), 0)::bigint AS pending,
            COALESCE(SUM(credit - debit) FILTER (WHERE account = $2), 0)::bigint AS available
       FROM ledger_lines WHERE account IN ($1, $2) GROUP BY currency ORDER BY currency`,
    [acct.pending(merchantId), acct.available(merchantId)]);
  return { object: 'balance', balances: r.rows };
}

export async function createPayout(m: Merchant, currency: string, amount?: number) {
  return tx(async (c) => {
    // Serialize payouts per merchant.
    const cur = await one(c, 'SELECT status FROM merchants WHERE id=$1 FOR UPDATE', [m.id]);
    if (cur.status !== 'active') throw new ApiError(403, 'account_inactive', 'Payouts are paused while this account is not active.');
    const available = await balance(c, acct.available(m.id), currency);
    const amt = amount ?? available;
    if (amt <= 0 || amt > available) {
      throw new ApiError(400, 'balance_insufficient', `Payout must be between 1 and your available balance of ${available}.`);
    }
    const id = newId('po');
    const dest = await one(c, `SELECT m.name, m.payout_method, u.id AS wallet_user_id, u.status AS wallet_status
                                 FROM merchants m LEFT JOIN users u ON u.id = m.payout_wallet_user_id WHERE m.id = $1`, [m.id]);
    const toWallet = dest.payout_method === 'wallet' && dest.wallet_user_id;
    if (dest.payout_method === 'wallet' && (!toWallet || dest.wallet_status !== 'active')) {
      throw new ApiError(400, 'payout_wallet_unavailable', 'The Global Gold wallet set for payouts is not available. Choose another payout destination.');
    }
    // To a Global Gold wallet: instant and internal. To a bank: leaves our settlement account (ACH/RTP).
    await postJournal(c, currency, { type: 'payout', id }, `payout ${id}`, [
      { account: acct.available(m.id), debit: amt },
      { account: toWallet ? acct.wallet(dest.wallet_user_id) : acct.bankCash, credit: amt },
    ]);
    const po = await one(c,
      `INSERT INTO payouts (id, merchant_id, amount, currency, status, destination, wallet_user_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [id, m.id, amt, currency, toWallet ? 'paid' : 'in_transit', toWallet ? 'wallet' : 'bank', toWallet ? dest.wallet_user_id : null]);
    if (toWallet) {
      await c.query(
        `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, note)
         VALUES ($1,$2,'business_payout',$3,$4,$5,'Business payout')`,
        [newId('wtx'), dest.wallet_user_id, amt, currency, dest.name]);
    }
    await emitEvent(c, m.id, 'payout.created', po);
    return { object: 'payout', ...po };
  });
}
