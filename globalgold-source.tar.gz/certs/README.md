# certs

`rds-global-bundle.pem` — Amazon RDS certificate bundle, used to verify TLS to the
database on AWS. It is **not** committed (it changes when AWS rotates certificates).

Download it before building for AWS:

    npm run fetch-rds-ca

The Docker image copies whatever is in this folder to `/etc/ssl/rds/`. If the bundle
is missing, start the app with `DATABASE_SSL=no-verify` (still encrypted, but the
database certificate is not checked) until you add it.
