output "app_url" {
  value = "https://${var.domain_name}"
}

output "ecr_repository_url" {
  value = aws_ecr_repository.app.repository_url
}

output "ecs_cluster" {
  value = aws_ecs_cluster.main.name
}

output "ecs_service" {
  value = aws_ecs_service.app.name
}

output "task_definition_family" {
  value = aws_ecs_task_definition.app.family
}

output "app_subnets" {
  value = join(",", aws_subnet.app[*].id)
}

output "app_security_group" {
  value = aws_security_group.app.id
}

output "db_endpoint" {
  value = aws_db_instance.main.address
}

output "app_secret_arn" {
  description = "Holds ADMIN_TOKEN, VAULT_KEY, FINGERPRINT_KEY"
  value       = aws_secretsmanager_secret.app.arn
}

output "github_deploy_role_arn" {
  value = var.github_repository != "" ? aws_iam_role.deploy[0].arn : ""
}

output "log_group" {
  description = "CloudWatch log group with the container logs"
  value       = aws_cloudwatch_log_group.app.name
}
