# Global Gold Payment on AWS
#
#   Internet ─▶ WAF ─▶ Application Load Balancer (HTTPS) ─▶ ECS Fargate (2+ tasks, private subnets)
#                                                              │
#                                                              ├─▶ RDS PostgreSQL 16 (Multi-AZ, encrypted, TLS only)
#                                                              └─▶ Secrets Manager (app keys, DB password) · KMS · CloudWatch Logs
#
# See DEPLOY.md in the repository root for the step-by-step guide.

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws    = { source = "hashicorp/aws", version = "~> 6.0" }
    random = { source = "hashicorp/random", version = "~> 3.6" }
  }
  # Recommended: keep state in S3 with locking. Create the bucket first, then uncomment.
  # backend "s3" {
  #   bucket       = "your-terraform-state-bucket"
  #   key          = "global-gold-payment/terraform.tfstate"
  #   region       = "us-east-1"
  #   encrypt      = true
  #   use_lockfile = true
  # }
}

provider "aws" {
  region = var.region
  default_tags {
    tags = {
      Project     = "global-gold-payment"
      Environment = var.environment
      ManagedBy   = "terraform"
    }
  }
}

locals {
  name = "ggp-${var.environment}"
  azs  = slice(data.aws_availability_zones.available.names, 0, 2)
}

data "aws_availability_zones" "available" {
  state = "available"
}

data "aws_caller_identity" "current" {}

# One customer-managed key for the database, secrets, logs and images.
resource "aws_kms_key" "main" {
  description             = "${local.name} data encryption"
  enable_key_rotation     = true
  deletion_window_in_days = 30
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AccountAdmin"
        Effect    = "Allow"
        Principal = { AWS = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:root" }
        Action    = "kms:*"
        Resource  = "*"
      },
      {
        Sid       = "CloudWatchLogs"
        Effect    = "Allow"
        Principal = { Service = "logs.${var.region}.amazonaws.com" }
        Action    = ["kms:Encrypt*", "kms:Decrypt*", "kms:ReEncrypt*", "kms:GenerateDataKey*", "kms:Describe*"]
        Resource  = "*"
      },
      {
        Sid       = "CloudWatchAlarmsToEncryptedSNS"
        Effect    = "Allow"
        Principal = { Service = "cloudwatch.amazonaws.com" }
        Action    = ["kms:Decrypt", "kms:GenerateDataKey*"]
        Resource  = "*"
      },
    ]
  })
}

resource "aws_kms_alias" "main" {
  name          = "alias/${local.name}"
  target_key_id = aws_kms_key.main.key_id
}
