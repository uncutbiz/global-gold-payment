# ---------------------------------------------------------------- database
resource "aws_db_subnet_group" "main" {
  name       = local.name
  subnet_ids = aws_subnet.db[*].id
}

resource "aws_db_parameter_group" "main" {
  name   = "${local.name}-pg16"
  family = "postgres16"
  parameter {
    name  = "rds.force_ssl"
    value = "1"
  }
  parameter {
    name  = "log_min_duration_statement"
    value = "1000"
  }
}

resource "aws_db_instance" "main" {
  identifier            = local.name
  engine                = "postgres"
  engine_version        = "16"
  instance_class        = var.db_instance_class
  allocated_storage     = var.db_allocated_storage
  max_allocated_storage = var.db_allocated_storage * 10
  storage_type          = "gp3"
  storage_encrypted     = true
  kms_key_id            = aws_kms_key.main.arn
  db_name               = "globalgold"
  username              = "globalgold"
  # The password is generated here and handed to the app through Secrets Manager.
  # (RDS-managed rotating passwords would break running containers, which read secrets only at start.)
  password                        = random_password.db.result
  db_subnet_group_name            = aws_db_subnet_group.main.name
  vpc_security_group_ids          = [aws_security_group.db.id]
  parameter_group_name            = aws_db_parameter_group.main.name
  publicly_accessible             = false
  multi_az                        = var.db_multi_az
  backup_retention_period         = 14
  copy_tags_to_snapshot           = true
  deletion_protection             = var.environment == "production"
  skip_final_snapshot             = var.environment != "production"
  final_snapshot_identifier       = "${local.name}-final"
  auto_minor_version_upgrade      = true
  performance_insights_enabled    = true
  performance_insights_kms_key_id = aws_kms_key.main.arn
  enabled_cloudwatch_logs_exports = ["postgresql"]
  apply_immediately               = var.environment != "production"
}

# ---------------------------------------------------------------- app secrets
# These values are stored in Terraform state: keep state in an encrypted, access-controlled S3 bucket.
resource "random_password" "db" {
  length  = 40
  special = false
}

resource "random_password" "admin_token" {
  length  = 48
  special = false
}

# 32-byte keys for the card vault and card fingerprints.
# PCI DSS production: replace with KMS/HSM envelope encryption (see DEPLOY.md).
resource "random_id" "vault_key" {
  byte_length = 32
}

resource "random_id" "fingerprint_key" {
  byte_length = 32
}

resource "aws_secretsmanager_secret" "app" {
  name                    = "${local.name}/app"
  description             = "Global Gold Payment application secrets"
  kms_key_id              = aws_kms_key.main.arn
  recovery_window_in_days = 7
}

resource "aws_secretsmanager_secret_version" "app" {
  secret_id = aws_secretsmanager_secret.app.id
  secret_string = jsonencode({
    DB_USER         = "globalgold"
    DB_PASSWORD     = random_password.db.result
    ADMIN_TOKEN     = random_password.admin_token.result
    VAULT_KEY       = random_id.vault_key.b64_std
    FINGERPRINT_KEY = random_id.fingerprint_key.b64_std
  })
  lifecycle {
    # Rotating the vault key makes existing card tokens unreadable. Do it deliberately.
    ignore_changes = [secret_string]
  }
}

# ---------------------------------------------------------------- container registry
resource "aws_ecr_repository" "app" {
  name                 = "global-gold-payment"
  image_tag_mutability = "IMMUTABLE"
  force_delete         = var.environment != "production"
  image_scanning_configuration {
    scan_on_push = true
  }
  encryption_configuration {
    encryption_type = "KMS"
    kms_key         = aws_kms_key.main.arn
  }
}

resource "aws_ecr_lifecycle_policy" "app" {
  repository = aws_ecr_repository.app.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep the last 50 images"
      selection    = { tagStatus = "any", countType = "imageCountMoreThan", countNumber = 50 }
      action       = { type = "expire" }
    }]
  })
}
