# A machine image with the platform already running

Three ways to get a working server without a deployment:

| | What it is | When |
|---|---|---|
| **Quickstart** | `sudo bash infra/ami/quickstart.sh` on a machine you already have | You have launched an instance and want it running now. No Packer, no registry, no image to publish — it builds the app on the box |
| **Baked AMI** | `bash infra/ami/build.sh` builds an AWS image with Docker, the app, Postgres and Caddy inside it | You will launch more than one, or want a boot that is quick and needs no registry |
| **User data** | Paste `user-data.sh` into EC2's *User data* box when launching | You want the machine to install itself with nothing typed at a terminal. It fetches the source from S3 or an HTTPS URL and hands over to the quickstart |

All three end at the same machine: it generates its own keys, starts the
platform under systemd, and answers on port 8080 — or on 443 with a real
certificate once you give it a domain.

Amazon Linux 2023 and Ubuntu 22.04/24.04 both work, on x86_64 or arm64. The
quickstart builds the app image on the machine itself, so the architecture
always matches whatever you launched.

This is the alternative to `make deploy`, which builds the full Fargate
deployment (load balancer, RDS, autoscaling, WAF). One box is cheaper and far
simpler; it is also one box, with no standby and nothing backing it up for you.
Use it for staging, demos, and showing a sponsor bank something real. `make
deploy` is what you run for production.

## Why the server is Linux

Your own machine stays Windows and nothing about how you work changes — you
still double-click, and the setup scripts still run in WSL. The *server* is
Amazon Linux because the application ships as a Linux container: Windows EC2
cannot run Linux containers without nested virtualisation, which only bare-metal
instance types offer, and Windows adds a per-hour licence charge on top (on
Fargate it is about 3.4× the Linux rate). A Linux server is the cheap, ordinary
choice here, and you never have to log into it — `ggp` is the only command.

## Quickstart on an instance you already launched

Get this source tree onto the machine, then one command does the rest:

```bash
sudo bash infra/ami/quickstart.sh
```

It installs Docker and the compose plugin, adds swap if the instance is small
enough for the build to need it, checks there is disk to build in, installs the
systemd units and the `ggp` command, builds the app image from this tree, and
starts the stack. Ten to fifteen minutes on a small instance, most of it
`npm ci`. Safe to run again — it rebuilds and restarts without touching the
database or the machine's keys.

### Getting the source onto the instance

`go.sh` does this, and the whole install, in one line:

```bash
curl -fsSL -o /tmp/go.sh https://raw.githubusercontent.com/uncutbiz/global-gold-payment/main/go.sh \
  && sudo bash /tmp/go.sh
```

It grows the filesystem if the volume was enlarged but the partition was not,
reclaims an oversized swapfile if that is what is eating the disk the build
needs, sizes swap to what is left, fetches `globalgold-source.tar.gz`, and hands
over to `quickstart.sh`.

With no argument it reads the source from the `raw.githubusercontent.com`
address in `DEFAULT_URL` at the top of the script. That address is the point: a
presigned S3 URL expires within the hour and is 500 characters of query string
to paste into a terminal, and an `s3://` URI needs an IAM role attached to the
instance — both are extra moving parts at exactly the moment you want none. A
raw GitHub link is an ordinary unauthenticated HTTPS GET that keeps working.
The repository has to be public for that, which is fine because the tarball
carries no keys; make it private again once the machine is up.

Override it any of three ways:

```bash
sudo bash /tmp/go.sh "https://any-other-url/globalgold-source.tar.gz"
sudo bash /tmp/go.sh s3://my-bucket/globalgold-source.tar.gz   # needs an instance role
sudo bash /tmp/go.sh /home/ubuntu/globalgold-source.tar.gz     # a file already there
GGP_URL="https://…" sudo -E bash /tmp/go.sh
```

Anything that is neither a URL nor an existing file is rejected by name, so a
placeholder pasted verbatim says so instead of turning into a DNS error.

The instance needs outbound internet for the package manager, Docker Hub and
GitHub — a public subnet with a public IP, or a NAT gateway.

## Letting the instance install itself

`user-data.sh` is the same install with no terminal involved. Set `GGP_SOURCE`
at the top of it to wherever the source tarball lives — an `s3://` URI, or any
HTTPS URL including a presigned S3 link — paste the whole script into the
**User data** box in the EC2 launch form, and the machine fetches the source and
runs the quickstart on its own.

Make the tarball with:

```bash
tar -czf globalgold-source.tar.gz \
  --exclude='./node_modules' --exclude='./dist' --exclude='./.git' \
  --exclude='./.env' --exclude='./infra/aws/terraform.tfvars' \
  --exclude='*.tfstate' --exclude='*.tfstate.*' .
```

For an `s3://` source the instance needs an IAM role with read access to that
bucket — **EC2 → Instances → Actions → Security → Modify IAM role**. That is
better than a presigned URL for anything you will launch more than once: the
credentials are temporary, fetched by the instance, and never written to a file.

Cloud-init runs user data on an instance's **first** boot only, so this is for
launching a new instance rather than reconfiguring one that is already up. Watch
it with `sudo tail -f /var/log/globalgold-install.log`.

## Building the AMI

Needs the AWS CLI signed in and Packer installed.

```bash
npm run fetch-rds-ca          # once: the image copies this CA bundle in
bash infra/ami/build.sh       # or: make ami
```

Options: `--arch x86_64` (default `arm64`, which is cheaper), `--region
eu-west-1`, `--dry-run` to validate the template and build nothing.

About ten minutes and a few cents of instance time. It prints the AMI id and the
`aws ec2 run-instances` command to launch it.

The app image is built **on the build instance**, from a tarball of this
repository, so it is native to the architecture you asked for. Cross-building on
a laptop is the usual way to get an AMI that will not start.

## What is and is not in the image

Baked in: Docker and the Compose plugin, the app image, `postgres:16`,
`caddy:2`, the two systemd units, and `/usr/local/bin/ggp`.

**No secrets.** The database password, `VAULT_KEY`, `FINGERPRINT_KEY` and
`ADMIN_TOKEN` are generated by each machine on its first boot and written to
`/etc/globalgold/env`. This matters more than it sounds: an AMI can be copied,
shared with another account, or made public by one careless click, and every
instance launched from a key-carrying image would share one vault key — the key
stored card tokens are encrypted with.

The build also clears cloud-init state, SSH authorized_keys, the build cache and
the logs, so a launched instance runs its own first boot rather than inheriting
the builder's identity.

## Launching

```bash
aws ec2 run-instances \
  --image-id ami-… \
  --instance-type t4g.small \
  --key-name YOUR_KEY_PAIR \
  --security-group-ids sg-… \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=global-gold-payment}]'
```

Security group: port 22 from your own IP only; 80 and 443 once a domain points
at it. Port 8080 from your own IP only, and only until TLS is on.

`t4g.small` (2 vCPU, 2 GB) is enough for staging and a demo. `t4g.medium` if you
will be showing it to people while it also holds a real dataset.

Then, on the instance:

```bash
ggp status
ggp create-admin you@example.com "Your Name"
ggp set-domain pay.example.com
```

`infra/ami/files/README.md` is installed at `/opt/globalgold/README.md` on the
machine and covers the rest: keys, backups, updating, and what to do when it
does not start.

## The scripts on the machine

Installed by every route into `/opt/globalgold/scripts`, and linked onto PATH:

| | |
|---|---|
| `globalgold-check` | Which build is actually *running* — asks the service, not the files on disk |
| `globalgold-doctor` | Service, disk, memory, database, configuration and recent errors. Read-only, secrets masked, safe to paste to anyone helping |
| `globalgold-update` | Fetch the latest build and install it. Remembers the source, so later updates need no argument |
| `globalgold-autoupdate` | Checks for a new build; `--apply` installs it, `--enable` schedules it nightly |
| `globalgold-grow-disk` | Enlarges the EBS volume and claims the space. Reads the volume id off the disk itself, so it needs no credentials to tell you *which* volume |
| `globalgold-backup` | Database and vault key, verified readable before it counts as a backup |

On a machine running an older build, get them with:

```bash
curl -fsSL https://raw.githubusercontent.com/uncutbiz/global-gold-payment/main/install-scripts.sh | sudo bash
```

### On automatic updates

`globalgold-autoupdate` **checks** by default and installs only with `--apply`.
That asymmetry is deliberate. Unattended updates mean whoever controls the
source URL controls this server: they push a tarball and wait, without ever
touching the machine. On something that takes payments that is worth choosing
knowingly rather than inheriting.

Two things blunt it. `GGP_PIN_SHA256` in `/etc/globalgold/autoupdate` pins one
exact build and refuses anything else, which turns automatic updating into
"install the thing I approved". And every `--apply` takes a database backup
first and runs `globalgold-check` afterwards, so a failed update is loud rather
than a quietly broken server.

## The pieces

| File | |
|---|---|
| `globalgold.pkr.hcl` | Packer template: source AMI, provisioning, clean-up |
| `build.sh` | Packs the source, validates, builds, prints the launch command |
| `go.sh` | One command from a bare instance: grows the filesystem, adds swap, fetches the source, then runs the quickstart. Says what to do when a step needs you |
| `quickstart.sh` | Brings the platform up on a machine you already have: swap, disk check, Docker, build, start |
| `provision.sh` | Installs Docker and the service files on Amazon Linux or Ubuntu. Shared by all three routes, so they cannot drift |
| `user-data.sh` | Self-install at launch: fetches the source, then runs the quickstart |
| `files/compose.yml` | What the service runs |
| `files/firstboot.sh` | Generates this machine's keys, once |
| `files/grow-disk.sh` | Enlarges the EBS root volume and claims the space (`ggp grow-disk`) |
| `files/scripts/` | The operator scripts, installed to `/opt/globalgold/scripts` and linked onto PATH |
| `files/globalgold.service` | Starts the stack at boot, waits for health |
| `files/globalgold-firstboot.service` | Runs `firstboot.sh` before it |
| `files/Caddyfile` | TLS, used only when a domain is set |
| `files/ggp` | The one command on the machine |
| `files/README.md` | Installed at `/opt/globalgold/README.md` |
