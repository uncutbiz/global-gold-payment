#!/usr/bin/env bash
# First boot: write /etc/globalgold/env with freshly generated secrets.
#
# This runs on the machine, at boot, rather than at image-build time, on
# purpose. Secrets baked into an AMI are the same on every instance launched
# from it, and an AMI can be copied or shared — so the image ships with no keys
# at all and each machine generates its own the first time it starts.
#
# Idempotent: if /etc/globalgold/env already exists it changes nothing, so a
# reboot never rotates the keys out from under the database.
set -euo pipefail

ENV_FILE=/etc/globalgold/env
NOTES=/root/globalgold-first-boot.txt
mkdir -p /etc/globalgold

if [ -f "$ENV_FILE" ]; then
  echo "$ENV_FILE already exists; leaving it alone."
  exit 0
fi

# 32 bytes, base64 — what the app's key parser expects.
key() { openssl rand -base64 32; }
# URL-safe, for a bearer token that ends up in shell commands and headers.
token() { openssl rand -hex 24; }

POSTGRES_PASSWORD=$(token)
VAULT_KEY=$(key)
FINGERPRINT_KEY=$(key)
ADMIN_TOKEN=$(token)

# A domain can be set before the first boot (user-data writing this file) or
# afterwards with `ggp set-domain`.
DOMAIN=""
[ -f /etc/globalgold/domain ] && DOMAIN=$(tr -d '[:space:]' < /etc/globalgold/domain)

# Which app image to run. provision.sh writes this: a local image for a baked
# AMI, a registry URI when the machine pulls one.
GGP_IMAGE=globalgold:local
if [ -f /etc/globalgold/image ]; then
  GGP_IMAGE=$(sed -n 's/^GGP_IMAGE=//p' /etc/globalgold/image | tail -1)
  [ -n "$GGP_IMAGE" ] || GGP_IMAGE=globalgold:local
fi

# IMDSv2. Not fatal if it is unavailable — this may not be EC2 at all.
PUBLIC_IP=""
if TOKEN=$(curl -sf -m 2 -X PUT http://169.254.169.254/latest/api/token \
             -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' 2>/dev/null); then
  PUBLIC_IP=$(curl -sf -m 2 -H "X-aws-ec2-metadata-token: $TOKEN" \
                http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || true)
fi

if [ -n "$DOMAIN" ]; then
  PUBLIC_URL="https://$DOMAIN"
  BIND=127.0.0.1          # Caddy is the only thing the internet talks to
  PROFILES=tls
else
  PUBLIC_URL="http://${PUBLIC_IP:-localhost}:8080"
  BIND=0.0.0.0            # otherwise nothing could reach it at all
  PROFILES=""
fi

umask 077
cat > "$ENV_FILE" <<ENV
# Global Gold Payment — this machine's configuration.
#
# Written once, on the first boot, by globalgold-firstboot.service. The keys
# below are unique to this machine. Edit this file and then run
# \`ggp restart\` to apply a change.
#
# Read by both docker compose (for \${...} in /opt/globalgold/compose.yml) and
# the app container itself, so keep it to plain KEY=value lines.

NODE_ENV=production
PORT=8080
PUBLIC_URL=$PUBLIC_URL

# The app image this machine runs. Change it with \`ggp update <image>\`.
GGP_IMAGE=$GGP_IMAGE

# Where the app is published, and whether Caddy terminates TLS in front of it.
GGP_DOMAIN=$DOMAIN
GGP_BIND=$BIND
COMPOSE_PROFILES=$PROFILES

# Generated on this machine. Losing VAULT_KEY makes stored card tokens
# unreadable; back this file up somewhere safe before you store anything real.
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
VAULT_KEY=$VAULT_KEY
FINGERPRINT_KEY=$FINGERPRINT_KEY

# A bootstrap credential for the admin API. Rotate it once staff accounts exist.
ADMIN_TOKEN=$ADMIN_TOKEN

# The built-in test network: card 4242 4242 4242 4242 approves and no money
# moves. Add square and/or stripe here, with their keys, when you have them —
# see SETUP-ACCOUNTS.md.
PAYMENT_PROVIDERS=simulated

# Your platform's cut, in basis points. 50 = 0.5%.
PLATFORM_FEE_BPS=50

# Holding customer balances and moving money between people is money
# transmission and needs licensing, so it is off. The app refuses to start with
# WALLET_MODE=full in production unless that permission is declared.
WALLET_MODE=off
ENV
chmod 600 "$ENV_FILE"

{
  echo "Global Gold Payment — first boot $(date -Is)"
  echo
  echo "  Home               $PUBLIC_URL/"
  echo "  Business dashboard $PUBLIC_URL/dashboard"
  echo "  Customer wallet    $PUBLIC_URL/wallet"
  echo "  Admin panel        $PUBLIC_URL/admin"
  echo
  echo "  Configuration      $ENV_FILE  (root only)"
  echo "  Admin API token    in that file, as ADMIN_TOKEN"
  echo
  echo "  Create your admin-panel login:   ggp create-admin you@example.com \"Your Name\""
  if [ -z "$DOMAIN" ]; then
    echo
    echo "  No domain is set, so this is plain HTTP on port 8080 with no"
    echo "  certificate. Restrict port 8080 to your own IP in the security"
    echo "  group, and when you have a domain pointing here run:"
    echo "      ggp set-domain pay.example.com"
    echo "  which switches on TLS. Do that before anything real goes in."
  fi
} > "$NOTES"
chmod 600 "$NOTES"
cat "$NOTES"
