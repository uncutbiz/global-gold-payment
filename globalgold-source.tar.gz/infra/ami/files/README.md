# Global Gold Payment on this machine

Everything is installed and starts at boot. One command drives it:

```bash
ggp status          # is it up, and on what URL
ggp logs app        # follow the logs (app, db, caddy)
ggp restart        # apply a change to /etc/globalgold/env
ggp help            # the rest
```

## The first two things to do

```bash
ggp create-admin you@example.com "Your Name"
ggp set-domain pay.example.com
```

The first creates your admin-panel login and prints a temporary password once.
The second points a domain here and switches on HTTPS — Caddy gets a real
certificate from Let's Encrypt and renews it. Before running it, make sure the
domain resolves to this machine and that ports 80 and 443 are open in its
security group, or the certificate request fails.

**Until a domain is set, this is plain HTTP on port 8080 with no certificate.**
Restrict 8080 to your own IP in the security group and treat it as a preview.

## Staff logins

```bash
ggp staff                              # which accounts exist
ggp create-admin you@example.com "Name" # add one
ggp set-password you@example.com        # change one
```

`set-password` asks for the new password twice without showing it, so it stays
out of your shell history, out of `ps`, and out of any scrollback you might
later screenshot. It also **ends every session that account had open**, which is
the point: a session token lives for eight hours regardless of the password that
created it, so without that step someone holding a stolen token keeps their
access for the rest of the day and the change achieves nothing.

Rotate a password whenever it has been anywhere it should not be — a chat
window, a support ticket, a screenshot, an email. The temporary password
`create-admin` prints counts: it was printed to a terminal, so change it once
you are in.

`ADMIN_TOKEN` in `/etc/globalgold/env` is a separate bootstrap credential that
acts as an owner. Once you have real staff accounts, clear it.

## Where things are

| | |
|---|---|
| Configuration, including this machine's keys | `/etc/globalgold/env` (root only) |
| What the service runs | `/opt/globalgold/compose.yml` |
| TLS configuration | `/opt/globalgold/Caddyfile` |
| Database files | Docker volume `globalgold_pgdata` |
| First-boot notes | `/root/globalgold-first-boot.txt` (`ggp notes`) |

## The keys

`/etc/globalgold/env` was written on this machine's first boot with keys
generated here. They are not in the image and not in any repository, and no
other machine has them.

`VAULT_KEY` is the one that matters: stored card tokens are encrypted with it,
and losing it makes them permanently unreadable. **Copy that file somewhere safe
before you store anything real.**

`ADMIN_TOKEN` is a bootstrap credential for the admin API. Rotate it once you
have staff accounts: change it in that file and `ggp restart`.

## Test mode

`PAYMENT_PROVIDERS=simulated` — the card network is simulated, `4242 4242 4242
4242` approves, and no money moves. To take real payments, add your Square or
Stripe credentials to `/etc/globalgold/env` and set
`PAYMENT_PROVIDERS=square,stripe` (see `SETUP-ACCOUNTS.md` in the repository),
then `ggp restart`.

`WALLET_MODE=off` — customer balances and person-to-person transfers are off.
That is money transmission: it needs licensing, and Square prohibits it on its
rails. The app refuses to start in production with it on unless that permission
is declared.

## Updating the app

```bash
ggp update ghcr.io/you/global-gold-payment:v2
```

Pulls the image, restarts, and the app migrates the database itself. Running the
old image again is `ggp update` with the old tag.

## Backups

The database is a Docker volume on this machine's root disk. Nothing backs it up
for you. The two things to take regularly:

```bash
# the data
sudo docker compose -f /opt/globalgold/compose.yml exec -T db \
  pg_dump -U globalgold globalgold | gzip > globalgold-$(date +%F).sql.gz

# the keys, once — without these a dump of card tokens is unreadable
sudo cat /etc/globalgold/env
```

An EBS snapshot schedule on the root volume covers the first of those and is
worth setting up. It does not replace keeping the keys somewhere else.

## If it is not running

```bash
systemctl status globalgold
journalctl -u globalgold -n 50
journalctl -u globalgold-firstboot -n 50
ggp logs app
```

The commonest cause is a value in `/etc/globalgold/env` the app rejects at
start-up; the app says which one and why, in `ggp logs app`.
