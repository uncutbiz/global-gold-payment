#!/usr/bin/env bash
# Turns a plain Linux machine into a Global Gold Payment server.
#
# Amazon Linux 2023 and Ubuntu 22.04/24.04 are both supported: the package
# manager and the default login user differ between them and nothing else does.
#
# Used three ways, and it is the same script every time so they cannot drift:
#   - Packer runs it while building an AMI (infra/ami/globalgold.pkr.hcl)
#   - EC2 user-data runs it on a stock instance (user-data.sh)
#   - quickstart.sh runs it on a machine you already have
#
# It installs Docker, installs the service files, and leaves the service enabled
# but not started: the machine's own keys are generated on its first boot, not
# here, so that an image does not carry secrets. See files/firstboot.sh.
#
# Expects the service files in ./files next to it, or in $GGP_FILES.
set -euo pipefail

FILES=${GGP_FILES:-"$(cd "$(dirname "$0")" && pwd)/files"}
COMPOSE_VERSION=${COMPOSE_VERSION:-v2.32.4}
# Which app image the service runs. The AMI build sets this to a local image it
# bakes in; user-data sets it to a registry URI it can pull.
GGP_IMAGE=${GGP_IMAGE:-globalgold:local}

say() { printf '\n== %s\n' "$*"; }

[ "$(id -u)" = 0 ] || { echo "run as root" >&2; exit 1; }
[ -d "$FILES" ] || { echo "service files not found at $FILES" >&2; exit 1; }

say "Packages"
if command -v dnf >/dev/null 2>&1; then
  DISTRO=rpm
  dnf -y update
  dnf -y install docker openssl jq curl
elif command -v apt-get >/dev/null 2>&1; then
  DISTRO=deb
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  # docker.io is Ubuntu's own packaging of the engine. Using it rather than
  # Docker's repository keeps this to one command and one source of updates;
  # the compose plugin is fetched separately below either way.
  apt-get install -y --no-install-recommends docker.io openssl jq curl ca-certificates
else
  echo "no supported package manager found (need dnf or apt-get)" >&2
  exit 1
fi
echo "package manager: $DISTRO"

say "Docker Compose $COMPOSE_VERSION"
case "$(uname -m)" in
  aarch64|arm64) CARCH=aarch64 ;;
  x86_64|amd64)  CARCH=x86_64 ;;
  *) echo "unsupported architecture $(uname -m)" >&2; exit 1 ;;
esac
# Ubuntu looks for CLI plugins under /usr/libexec/docker/cli-plugins too, but
# /usr/local/lib/docker/cli-plugins is the location both distributions agree on
# and it survives a package upgrade of the engine.
PLUGINS=/usr/local/lib/docker/cli-plugins
install -d "$PLUGINS"
curl -fsSL -o "$PLUGINS/docker-compose" \
  "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-linux-${CARCH}"
chmod 0755 "$PLUGINS/docker-compose"
systemctl enable --now docker
docker compose version

# So poking at the containers by hand does not need sudo. `ggp` re-runs itself
# as root regardless, because the configuration file holds this machine's keys.
# The default login user is ec2-user on Amazon Linux and ubuntu on Ubuntu.
for u in ec2-user ubuntu admin; do
  id "$u" >/dev/null 2>&1 && usermod -aG docker "$u" && echo "added $u to the docker group"
done

say "Service files"
install -d -m 0755 /opt/globalgold
install -m 0644 "$FILES/compose.yml" /opt/globalgold/compose.yml
install -m 0644 "$FILES/Caddyfile"   /opt/globalgold/Caddyfile
install -m 0755 "$FILES/firstboot.sh" /opt/globalgold/firstboot.sh
install -m 0755 "$FILES/grow-disk.sh" /opt/globalgold/grow-disk.sh

# The operator scripts. Installed into a directory of their own and linked into
# PATH, so they are both discoverable (ls /opt/globalgold/scripts) and usable
# without a path (globalgold-doctor).
install -d -m 0755 /opt/globalgold/scripts
for s in "$FILES"/scripts/*; do
  [ -f "$s" ] || continue
  n=$(basename "$s")
  install -m 0755 "$s" "/opt/globalgold/scripts/$n"
  ln -sf "/opt/globalgold/scripts/$n" "/usr/local/bin/$n"
  echo "installed $n"
done
install -m 0644 "$FILES/README.md"   /opt/globalgold/README.md
install -m 0755 "$FILES/ggp"         /usr/local/bin/ggp
install -m 0644 "$FILES/globalgold.service"          /etc/systemd/system/globalgold.service
install -m 0644 "$FILES/globalgold-firstboot.service" /etc/systemd/system/globalgold-firstboot.service
install -d -m 0700 /etc/globalgold

# The image to run is a property of the machine, so it lives beside the rest of
# the configuration. firstboot.sh writes that file, so seed it here and let
# firstboot append to it.
echo "GGP_IMAGE=$GGP_IMAGE" > /etc/globalgold/image
chmod 0644 /etc/globalgold/image

say "Enable at boot"
systemctl daemon-reload
systemctl enable globalgold-firstboot.service globalgold.service

say "Pre-pull the images this machine needs"
# Baked into the image so a first boot needs no registry and no waiting. Caddy
# too, because it is wanted at the moment a domain is set, not before.
docker pull postgres:16
docker pull caddy:2
if [ "$GGP_IMAGE" != "globalgold:local" ]; then
  docker pull "$GGP_IMAGE" || echo "(could not pull $GGP_IMAGE now; it will be pulled at boot)"
fi

say "Done"
echo "The service is enabled but not started; it comes up on the next boot,"
echo "after this machine generates its own keys."
