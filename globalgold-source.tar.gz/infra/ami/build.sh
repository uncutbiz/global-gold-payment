#!/usr/bin/env bash
# Builds the Global Gold Payment machine image.
#
#   bash infra/ami/build.sh                 # arm64, us-east-1
#   bash infra/ami/build.sh --arch x86_64
#   bash infra/ami/build.sh --region eu-west-1
#   bash infra/ami/build.sh --dry-run       # validate the template, build nothing
#
# Takes about 10 minutes and costs a few cents of instance time. When it
# finishes it prints the AMI id and how to launch it.
set -euo pipefail

here=$(cd "$(dirname "$0")" && pwd)
root=$(cd "$here/../.." && pwd)

ARCH=arm64
REGION=${AWS_REGION:-${AWS_DEFAULT_REGION:-us-east-1}}
DRY=0

while [ $# -gt 0 ]; do
  case "$1" in
    --arch)    ARCH=${2:?}; shift 2 ;;
    --region)  REGION=${2:?}; shift 2 ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option $1" >&2; exit 2 ;;
  esac
done

die() { printf '\n  %s\n\n' "$*" >&2; exit 1; }

command -v packer >/dev/null || die "Packer is not installed.
  Linux:  sudo dnf install -y packer   (or see https://developer.hashicorp.com/packer/install)
  Ubuntu: sudo apt-get install -y packer"
command -v aws >/dev/null || die "The AWS CLI is not installed. Run scripts/wsl-setup.sh."
aws sts get-caller-identity >/dev/null 2>&1 || die "Not signed in to AWS. Run: aws configure"

# The app image is built on the instance, from this tarball, so it is native to
# the target architecture. Excludes are the things that must never travel: real
# secrets, local state, and anything big enough to slow the upload down.
archive=$(mktemp -t ggp-source-XXXXXX.tar.gz)
trap 'rm -f "$archive"' EXIT
echo "Packing the source..."
tar -czf "$archive" -C "$root" \
  --exclude='./node_modules' --exclude='./dist' --exclude='./.git' \
  --exclude='./.deploy-logs' --exclude='./.deploy-state' \
  --exclude='./infra/ami/manifest.json' \
  --exclude='./.env' --exclude='./.env.production' \
  --exclude='*.tfstate' --exclude='*.tfstate.*' --exclude='./infra/aws/.terraform' \
  --exclude='./infra/aws/terraform.tfvars' \
  --exclude='./test-results' --exclude='./playwright-report' \
  .
echo "  $(du -h "$archive" | cut -f1)"

# certs/ travels deliberately: the Dockerfile copies it, and it holds Amazon's
# public RDS CA bundle, which is not a secret. Checked here, by name, because
# without it the docker build fails ten minutes into the Packer run — and
# certs/ is never empty (it has a README), so "the directory is there" is not
# the same question.
#
# Not written as `tar … | grep -q`: grep -q exits at the first match, tar then
# dies of SIGPIPE, and `set -o pipefail` turns that into a failure — so the
# check would report the file missing precisely when it is there.
listing=$(tar -tzf "$archive")
case "$listing" in
  *"./certs/rds-global-bundle.pem"*) ;;
  *) die "certs/rds-global-bundle.pem is missing. Run this first:
      npm run fetch-rds-ca" ;;
esac

cd "$here"
packer init globalgold.pkr.hcl

args=(
  -var "region=$REGION"
  -var "architecture=$ARCH"
  -var "source_archive=$archive"
)

packer validate "${args[@]}" globalgold.pkr.hcl
echo "Template is valid."

if [ "$DRY" = 1 ]; then
  echo
  echo "Dry run: nothing was built. Drop --dry-run to build the image."
  exit 0
fi

echo
echo "Building in $REGION for $ARCH. This takes about ten minutes."
echo
packer build "${args[@]}" globalgold.pkr.hcl

ami=$(jq -r '.builds[-1].artifact_id' manifest.json 2>/dev/null | cut -d: -f2)
[ -n "${ami:-}" ] || { echo "Built, but could not read the AMI id from manifest.json."; exit 0; }

cat <<DONE

  ─────────────────────────────────────────────────────────────────────
   Image ready:  $ami   ($REGION, $ARCH)

   Launch a server from it:

     aws ec2 run-instances --region $REGION \\
       --image-id $ami \\
       --instance-type $([ "$ARCH" = arm64 ] && echo t4g.small || echo t3.small) \\
       --key-name YOUR_KEY_PAIR \\
       --security-group-ids YOUR_SECURITY_GROUP \\
       --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=global-gold-payment}]'

   The security group needs 22 from your own IP, and 80 + 443 once you
   point a domain at it. Then, on the instance:

     ggp status                                    is it up, and where
     ggp create-admin you@example.com "Your Name"  your admin login
     ggp set-domain pay.example.com                a real certificate

   infra/ami/README.md has the rest.
  ─────────────────────────────────────────────────────────────────────

DONE
