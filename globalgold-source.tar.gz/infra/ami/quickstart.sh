#!/usr/bin/env bash
# Bring Global Gold Payment up on a Linux machine you already have.
#
#   sudo bash infra/ami/quickstart.sh
#
# For an EC2 instance you have just launched and can reach with EC2 Instance
# Connect or SSH. Unlike the Packer path (infra/ami/build.sh) this needs no
# image build and no registry: it installs Docker, builds the app here from this
# source tree, and starts the stack under systemd so it comes back after a
# reboot.
#
# Works on Amazon Linux 2023 and Ubuntu 22.04/24.04, on x86_64 or arm64. The app
# image is built on this machine, so the architecture always matches.
#
# Afterwards, everything is driven by one command:
#
#   ggp status                                    is it up, and where
#   ggp create-admin you@example.com "Your Name"  your admin-panel login
#   ggp set-domain pay.example.com                real certificate, HTTPS
#
# Safe to run again: it reinstalls the service files, rebuilds the image, and
# leaves the database and this machine's keys alone.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SRC=/opt/globalgold/src
# What the build needs free, in MB. The swap sizing below respects it.
NEED_MB=3000

say()  { printf '\n\033[1m== %s\033[0m\n' "$*"; }
note() { printf '   %s\n' "$*"; }
die()  { printf '\n\033[31m%s\033[0m\n\n' "$*" >&2; exit 1; }

[ "$(id -u)" = 0 ] || die "Run this with sudo:  sudo bash $0"
[ -f "$ROOT/package.json" ] && [ -f "$ROOT/Dockerfile" ] \
  || die "This does not look like the project. Expected package.json and Dockerfile in $ROOT."

# ---------------------------------------------------------------------- disk
# Building the image writes a node_modules layer, then the base images for
# Postgres and Caddy land on top. Together that is roughly 2 GB, and a default
# 8 GB EC2 root volume is already half full before any of it. Running out
# part-way through surfaces as a baffling "npm error" rather than as a disk
# message, so check first and say so in plain words.
say "Disk"
AVAIL_MB=$(df -Pm / | awk 'NR==2{print $4}')
note "${AVAIL_MB} MB free on /"
if [ "$AVAIL_MB" -lt "$NEED_MB" ]; then
  die "Not enough free disk to build: ${AVAIL_MB} MB free, and this needs ${NEED_MB} MB.
  Grow the root volume (EC2 → Volumes → Modify volume, then reboot), or free
  space with:  docker system prune -af"
elif [ "$AVAIL_MB" -lt 6000 ]; then
  note "That is tight. It should fit, but grow the root volume to 20 GB before"
  note "you put real data on this machine."
fi

# ---------------------------------------------------------------------- swap
# The image build runs npm ci and the TypeScript compiler, which want more than
# a small instance has; without swap the build is killed by the OOM reaper and
# surfaces as a mysterious "npm error" rather than a memory problem.
#
# But a swapfile is a FILE, competing for the same disk the build needs. Adding
# 2 GB on a machine with 4.6 GB free leaves too little to build in — so this
# runs AFTER the disk check and takes only what can be spared.
say "Memory"
MEM_MB=$(( $(awk '/MemTotal/{print $2}' /proc/meminfo) / 1024 ))
note "${MEM_MB} MB of RAM"
if [ "$MEM_MB" -ge 1900 ]; then
  note "enough RAM; no swap needed"
elif [ -f /swapfile ]; then
  note "swapfile already present"
else
  SWAP_MB=0
  for want in 2048 1024 512; do
    if [ $(( AVAIL_MB - want )) -ge "$NEED_MB" ]; then SWAP_MB=$want; break; fi
  done
  if [ "$SWAP_MB" = 0 ]; then
    note "skipping swap: only ${AVAIL_MB} MB free and the build needs ${NEED_MB} MB"
    note "the build may run short of memory; enlarge the volume to 20 GiB"
  else
    note "adding a ${SWAP_MB} MB swapfile (leaves $(( AVAIL_MB - SWAP_MB )) MB to build in)"
    fallocate -l "${SWAP_MB}M" /swapfile 2>/dev/null \
      || dd if=/dev/zero of=/swapfile bs=1M count="$SWAP_MB" status=none
    chmod 600 /swapfile
    mkswap /swapfile >/dev/null
    swapon /swapfile
    grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
    note "swap on"
  fi
fi

# ------------------------------------------------------------------ install
say "Docker and the service files"
GGP_IMAGE=globalgold:local GGP_FILES="$HERE/files" bash "$HERE/provision.sh"

# Keep the source on the machine so a later `ggp` rebuild, or a rerun of this
# script, does not need it uploaded again.
say "Source"
install -d -m 0755 /opt/globalgold
if [ "$ROOT" != "$SRC" ]; then
  rm -rf "$SRC.new"
  mkdir -p "$SRC.new"
  # tar rather than cp -r: it copies dotfiles without the shell glob surprises,
  # and certs/ must travel because the Dockerfile copies it.
  tar -cf - -C "$ROOT" --exclude=./node_modules --exclude=./dist --exclude=./.git . \
    | tar -xf - -C "$SRC.new"
  rm -rf "$SRC.old"
  [ -d "$SRC" ] && mv "$SRC" "$SRC.old"
  mv "$SRC.new" "$SRC"
  rm -rf "$SRC.old"
fi
note "$SRC"

# ------------------------------------------------------------------- build
say "Building the app image (a few minutes the first time)"
# certs/ holds Amazon's public RDS CA bundle. The database is on this machine
# over a private Docker network so it is not needed, but the Dockerfile copies
# the directory and would fail on an empty one.
[ -d "$SRC/certs" ] || install -d "$SRC/certs"
[ -n "$(ls -A "$SRC/certs" 2>/dev/null)" ] || echo 'placeholder' > "$SRC/certs/.keep"
docker build -t globalgold:local "$SRC"
docker image inspect globalgold:local >/dev/null

# ------------------------------------------------------------------- start
say "Starting"
# firstboot writes this machine's own keys, once. Already-configured machines
# skip it, so rerunning never rotates keys out from under the database.
systemctl start globalgold-firstboot.service || true
systemctl restart globalgold.service

say "Up"
ggp status || true

URL=$(sed -n 's/^PUBLIC_URL=//p' /etc/globalgold/env 2>/dev/null | tail -1)
cat <<DONE

  ─────────────────────────────────────────────────────────────────────
   Global Gold Payment is running on this machine.

     ${URL:-http://<this machine>:8080}/

   Next:

     sudo ggp create-admin you@example.com "Your Name"
          your admin-panel login; the password is printed once

     sudo ggp set-domain pay.example.com
          points a domain here and switches on HTTPS with a real
          certificate. Open ports 80 and 443 in the security group first.

   Until a domain is set this is plain HTTP on port 8080 with no
   certificate, so restrict 8080 to your own IP in the security group.

   /opt/globalgold/README.md covers keys, backups and updates.
  ─────────────────────────────────────────────────────────────────────

DONE
