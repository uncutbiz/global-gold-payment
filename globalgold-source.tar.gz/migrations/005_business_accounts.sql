-- Self-serve business accounts: people sign in to the dashboard, businesses
-- wait for approval before taking payments, and payouts can go to a wallet.

CREATE TABLE merchant_users (
  id             TEXT PRIMARY KEY,
  merchant_id    TEXT NOT NULL REFERENCES merchants(id),
  email          TEXT NOT NULL UNIQUE,
  name           TEXT NOT NULL,
  password_hash  TEXT NOT NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE merchant_sessions (
  token_hash        TEXT PRIMARY KEY,
  merchant_user_id  TEXT NOT NULL REFERENCES merchant_users(id),
  expires_at        TIMESTAMPTZ NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE merchants ADD COLUMN country        TEXT NOT NULL DEFAULT 'US';
ALTER TABLE merchants ADD COLUMN website        TEXT;
ALTER TABLE merchants ADD COLUMN business_type  TEXT;
ALTER TABLE merchants ADD COLUMN description    TEXT;
ALTER TABLE merchants ADD COLUMN review_note    TEXT;
ALTER TABLE merchants ADD COLUMN payout_method  TEXT NOT NULL DEFAULT 'bank' CHECK (payout_method IN ('bank','wallet'));
ALTER TABLE merchants ADD COLUMN payout_wallet_user_id TEXT REFERENCES users(id);

ALTER TABLE payouts ADD COLUMN destination    TEXT NOT NULL DEFAULT 'bank' CHECK (destination IN ('bank','wallet'));
ALTER TABLE payouts ADD COLUMN wallet_user_id TEXT REFERENCES users(id);

ALTER TABLE wallet_transactions DROP CONSTRAINT wallet_transactions_type_check;
ALTER TABLE wallet_transactions ADD CONSTRAINT wallet_transactions_type_check
  CHECK (type IN ('top_up','transfer_out','transfer_in','payment','refund','withdrawal','conversion_out','conversion_in','business_payout'));
