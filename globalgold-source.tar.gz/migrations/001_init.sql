-- Global Gold Payment core schema. All money is stored in minor units (cents) as BIGINT.

CREATE TABLE merchants (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  email           TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('pending_review','active','suspended')),
  fee_bps         INTEGER NOT NULL DEFAULT 290,   -- 2.90%
  fee_fixed       INTEGER NOT NULL DEFAULT 30,    -- $0.30
  max_amount      BIGINT  NOT NULL DEFAULT 1000000, -- per-transaction limit ($10,000)
  webhook_url     TEXT,
  webhook_secret  TEXT NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE api_keys (
  id           TEXT PRIMARY KEY,
  merchant_id  TEXT NOT NULL REFERENCES merchants(id),
  kind         TEXT NOT NULL CHECK (kind IN ('secret','publishable')),
  key_hash     TEXT NOT NULL UNIQUE,   -- sha256 of the key; raw key shown once
  prefix       TEXT NOT NULL,          -- first chars, for display
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at   TIMESTAMPTZ
);

-- Token vault. In production this table lives in a separate, PCI-scoped database.
CREATE TABLE card_tokens (
  id            TEXT PRIMARY KEY,
  merchant_id   TEXT NOT NULL REFERENCES merchants(id),
  key_id        TEXT NOT NULL,
  iv            BYTEA NOT NULL,
  ciphertext    BYTEA NOT NULL,
  auth_tag      BYTEA NOT NULL,
  fingerprint   TEXT NOT NULL,         -- HMAC of PAN, lets risk rules link cards without decrypting
  brand         TEXT NOT NULL,
  last4         TEXT NOT NULL,
  bin           TEXT NOT NULL,
  exp_month     SMALLINT NOT NULL,
  exp_year      SMALLINT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON card_tokens (fingerprint);

CREATE TABLE payment_intents (
  id                 TEXT PRIMARY KEY,
  merchant_id        TEXT NOT NULL REFERENCES merchants(id),
  amount             BIGINT NOT NULL CHECK (amount > 0),
  currency           TEXT NOT NULL,
  status             TEXT NOT NULL CHECK (status IN (
                       'requires_payment_method','processing','requires_capture',
                       'succeeded','canceled')),
  capture_method     TEXT NOT NULL CHECK (capture_method IN ('automatic','manual')),
  client_secret      TEXT NOT NULL,
  token_id           TEXT REFERENCES card_tokens(id),
  amount_captured    BIGINT NOT NULL DEFAULT 0,
  amount_refunded    BIGINT NOT NULL DEFAULT 0,
  fee                BIGINT NOT NULL DEFAULT 0,
  auth_code          TEXT,
  network_ref        TEXT,       -- retrieval reference number (ISO 8583 field 37)
  decline_code       TEXT,
  decline_message    TEXT,
  risk_score         INTEGER,
  description        TEXT,
  metadata           JSONB NOT NULL DEFAULT '{}',
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (amount_captured <= amount),
  CHECK (amount_refunded <= amount_captured)
);
CREATE INDEX ON payment_intents (merchant_id, created_at DESC);

-- Every authorization attempt, approved or not (audit trail + risk velocity).
CREATE TABLE payment_attempts (
  id                 BIGSERIAL PRIMARY KEY,
  payment_intent_id  TEXT NOT NULL REFERENCES payment_intents(id),
  token_id           TEXT NOT NULL REFERENCES card_tokens(id),
  fingerprint        TEXT NOT NULL,
  outcome            TEXT NOT NULL CHECK (outcome IN ('approved','declined','blocked','error')),
  response_code      TEXT,
  risk_score         INTEGER,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON payment_attempts (fingerprint, created_at);

CREATE TABLE refunds (
  id                 TEXT PRIMARY KEY,
  merchant_id        TEXT NOT NULL REFERENCES merchants(id),
  payment_intent_id  TEXT NOT NULL REFERENCES payment_intents(id),
  amount             BIGINT NOT NULL CHECK (amount > 0),
  status             TEXT NOT NULL CHECK (status IN ('succeeded','failed')),
  network_ref        TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Double-entry ledger ------------------------------------------------------
CREATE TABLE journals (
  id           TEXT PRIMARY KEY,
  ref_type     TEXT NOT NULL,
  ref_id       TEXT NOT NULL,
  description  TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ledger_lines (
  id           BIGSERIAL PRIMARY KEY,
  journal_id   TEXT NOT NULL REFERENCES journals(id),
  account      TEXT NOT NULL,
  currency     TEXT NOT NULL,
  debit        BIGINT NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit       BIGINT NOT NULL DEFAULT 0 CHECK (credit >= 0),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((debit = 0) <> (credit = 0))
);
CREATE INDEX ON ledger_lines (account, currency);

-- Ledger is append-only.
CREATE FUNCTION ledger_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'ledger_lines is append-only';
END $$;
CREATE TRIGGER ledger_no_update BEFORE UPDATE OR DELETE ON ledger_lines
  FOR EACH ROW EXECUTE FUNCTION ledger_immutable();

-- Every journal must balance per currency, checked at commit time.
CREATE FUNCTION ledger_check_balanced() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bad RECORD;
BEGIN
  SELECT currency, SUM(debit) d, SUM(credit) c INTO bad
    FROM ledger_lines WHERE journal_id = NEW.journal_id
    GROUP BY currency HAVING SUM(debit) <> SUM(credit) LIMIT 1;
  IF FOUND THEN
    RAISE EXCEPTION 'journal % unbalanced in %: debits % credits %', NEW.journal_id, bad.currency, bad.d, bad.c;
  END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER ledger_balanced AFTER INSERT ON ledger_lines
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ledger_check_balanced();

-- Events & webhooks ---------------------------------------------------------
CREATE TABLE events (
  id           TEXT PRIMARY KEY,
  merchant_id  TEXT NOT NULL REFERENCES merchants(id),
  type         TEXT NOT NULL,
  data         JSONB NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON events (merchant_id, created_at DESC);

CREATE TABLE webhook_deliveries (
  id               BIGSERIAL PRIMARY KEY,
  event_id         TEXT NOT NULL REFERENCES events(id),
  merchant_id      TEXT NOT NULL REFERENCES merchants(id),
  url              TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','delivered','failed')),
  attempts         INTEGER NOT NULL DEFAULT 0,
  next_attempt_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_error       TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON webhook_deliveries (status, next_attempt_at);

-- Idempotency ---------------------------------------------------------------
CREATE TABLE idempotency_keys (
  merchant_id      TEXT NOT NULL REFERENCES merchants(id),
  key              TEXT NOT NULL,
  request_hash     TEXT NOT NULL,
  response_status  INTEGER,
  response_body    JSONB,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (merchant_id, key)
);

-- Settlement & payouts ------------------------------------------------------
CREATE TABLE clearing_batches (
  id            TEXT PRIMARY KEY,
  record_count  INTEGER NOT NULL,
  net_amount    BIGINT NOT NULL,
  currency      TEXT NOT NULL,
  file_content  TEXT NOT NULL,     -- what gets sent (SFTP) to the sponsor processor
  status        TEXT NOT NULL CHECK (status IN ('submitted','funded')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE payment_intents ADD COLUMN clearing_batch_id TEXT REFERENCES clearing_batches(id);
ALTER TABLE refunds         ADD COLUMN clearing_batch_id TEXT REFERENCES clearing_batches(id);

CREATE TABLE payouts (
  id           TEXT PRIMARY KEY,
  merchant_id  TEXT NOT NULL REFERENCES merchants(id),
  amount       BIGINT NOT NULL CHECK (amount > 0),
  currency     TEXT NOT NULL,
  status       TEXT NOT NULL CHECK (status IN ('in_transit','paid','failed')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
