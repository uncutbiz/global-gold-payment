-- Customers: the people a merchant sells to, remembered between payments.
--
-- Until now a payment stood alone. A merchant could see that $250 came in, but
-- not that it was the same buyer as last month. That matters for refunds,
-- disputes and support — and it is a hard requirement for subscriptions, which
-- have to belong to somebody.
--
-- A customer belongs to ONE merchant. There is no shared identity across the
-- platform: two merchants who both sell to the same person hold two unrelated
-- customer records. That is deliberate. Linking them would mean one merchant's
-- customer list leaking the existence of another's.

CREATE TABLE customers (
  id           TEXT PRIMARY KEY,
  merchant_id  TEXT NOT NULL REFERENCES merchants(id),
  email        TEXT,
  name         TEXT,
  phone        TEXT,
  metadata     JSONB NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One record per email per merchant, so repeat business attaches to the
-- customer already there rather than growing a new row every checkout.
-- Case-insensitive: Ada@x.com and ada@x.com are one person.
CREATE UNIQUE INDEX customers_merchant_email_idx
  ON customers (merchant_id, lower(email)) WHERE email IS NOT NULL;
CREATE INDEX customers_merchant_idx ON customers (merchant_id, created_at DESC);

ALTER TABLE payment_intents ADD COLUMN customer_id TEXT REFERENCES customers(id);
CREATE INDEX payment_intents_customer_idx ON payment_intents (customer_id)
  WHERE customer_id IS NOT NULL;
