-- Recurring payments.
--
-- Everything else in this system charges because a human just clicked
-- something. This charges because a clock said so, with nobody watching — so
-- the failure modes are different and worse. The two that matter:
--
--   Double-charging. Two workers, or one worker retried after a crash, must
--   not bill the same period twice. Handled two ways at once: a worker claims
--   a due row with FOR UPDATE SKIP LOCKED before charging it, and the charge
--   carries an idempotency key derived from the cycle number, so even if a
--   claim were lost the provider itself would collapse the retry.
--
--   Charging after cancellation. A canceled subscription must stop, and
--   "stop" has to mean the row is never selected again, not that something
--   downstream declines to act on it.

CREATE TABLE saved_payment_methods (
  id                   TEXT PRIMARY KEY,
  merchant_id          TEXT NOT NULL REFERENCES merchants(id),
  customer_id          TEXT NOT NULL REFERENCES customers(id),
  provider             TEXT NOT NULL,

  -- Where the card actually lives. For Square and Stripe the card is held by
  -- THEM against the merchant's own account and we keep only these handles;
  -- we never store a card number for a real processor, which is the whole
  -- reason this platform stays at SAQ A.
  provider_card_id     TEXT,
  provider_customer_id TEXT,
  -- The simulated network has no vault of its own, so development and tests
  -- keep a card token in ours instead.
  vault_token_id       TEXT REFERENCES card_tokens(id),

  brand                TEXT,
  last4                TEXT,
  exp_month            INTEGER,
  exp_year             INTEGER,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at           TIMESTAMPTZ,

  CONSTRAINT has_a_card CHECK (provider_card_id IS NOT NULL OR vault_token_id IS NOT NULL)
);
CREATE INDEX spm_customer_idx ON saved_payment_methods (customer_id) WHERE deleted_at IS NULL;

CREATE TABLE subscriptions (
  id                TEXT PRIMARY KEY,
  merchant_id       TEXT NOT NULL REFERENCES merchants(id),
  customer_id       TEXT NOT NULL REFERENCES customers(id),
  payment_method_id TEXT NOT NULL REFERENCES saved_payment_methods(id),

  amount            BIGINT NOT NULL CHECK (amount > 0),
  currency          TEXT NOT NULL,
  description       TEXT,

  interval_unit     TEXT NOT NULL CHECK (interval_unit IN ('day','week','month','year')),
  interval_count    INTEGER NOT NULL DEFAULT 1 CHECK (interval_count > 0),

  status            TEXT NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active','paused','canceled','unpaid')),

  -- When the next charge is due. NULL means never again — which is how a
  -- canceled or finished subscription becomes invisible to the worker rather
  -- than merely unwelcome to it.
  next_charge_at    TIMESTAMPTZ,
  last_charge_at    TIMESTAMPTZ,

  -- The cycle number, and what the idempotency key is built from. Only ever
  -- incremented by the worker, inside the claim.
  cycles_billed     INTEGER NOT NULL DEFAULT 0 CHECK (cycles_billed >= 0),
  max_cycles        INTEGER CHECK (max_cycles IS NULL OR max_cycles > 0),

  -- Consecutive failures. A card that has expired should stop being retried
  -- forever; after enough tries the subscription goes 'unpaid' and waits for
  -- a human.
  failures          INTEGER NOT NULL DEFAULT 0,

  metadata          JSONB NOT NULL DEFAULT '{}',
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  canceled_at       TIMESTAMPTZ
);

-- The worker's query: due, active, soonest first. Partial, so the index holds
-- only the rows that can actually be charged.
CREATE INDEX subscriptions_due_idx ON subscriptions (next_charge_at)
  WHERE status = 'active' AND next_charge_at IS NOT NULL;
CREATE INDEX subscriptions_merchant_idx ON subscriptions (merchant_id, created_at DESC);

ALTER TABLE payment_intents ADD COLUMN subscription_id TEXT REFERENCES subscriptions(id);

-- One payment per subscription per cycle, enforced by the database rather than
-- by the worker being careful. If every other guard failed, this would still
-- make the second charge for a cycle impossible.
ALTER TABLE payment_intents ADD COLUMN subscription_cycle INTEGER;
CREATE UNIQUE INDEX payment_intents_subscription_cycle_idx
  ON payment_intents (subscription_id, subscription_cycle)
  WHERE subscription_id IS NOT NULL;
