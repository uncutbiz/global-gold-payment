-- Business cards: a merchant spending its own settled balance.
--
-- Same engine as a customer card — the authorization decision, the spend
-- controls, the hold-then-capture — with one thing changed: which ledger
-- account the money comes out of.
--
--   a customer card spends  wallet:<user_id>
--   a business card spends  merchant:<merchant_id>:available
--
-- WHICH MERCHANTS THIS CAN WORK FOR, and it is not all of them. A business
-- card can only spend money we actually hold. On the simulated network we are
-- the acquirer, so a merchant's settled balance sits on our books and a card
-- can draw on it. A merchant on their OWN connected Square or Stripe account
-- settles directly to their own bank — that money never passes through us, so
-- there is no platform balance to issue a card against. For those merchants a
-- business card needs either a funding account they top up here, or the card
-- programme to be issued against the sponsor bank's account rather than ours.
-- Ordering one is refused rather than silently creating a card that declines
-- every payment.

-- One owner per card, never both and never neither. A card with no owner has
-- no balance to check; a card with two has no single answer to "whose money".
ALTER TABLE issued_cards ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE issued_cards ADD COLUMN merchant_id TEXT REFERENCES merchants(id);
ALTER TABLE issued_cards ADD CONSTRAINT issued_cards_one_owner CHECK (
  (user_id IS NOT NULL AND merchant_id IS NULL) OR
  (user_id IS NULL AND merchant_id IS NOT NULL)
);
CREATE INDEX ON issued_cards (merchant_id, created_at DESC);

-- A business card is issued to a named person at the business — the employee
-- who carries it — which is what a card network requires and what makes an
-- expense card auditable.
ALTER TABLE issued_cards ADD COLUMN cardholder_name TEXT;

ALTER TABLE card_orders ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE card_orders ADD COLUMN merchant_id TEXT REFERENCES merchants(id);
ALTER TABLE card_orders ADD CONSTRAINT card_orders_one_owner CHECK (
  (user_id IS NOT NULL AND merchant_id IS NULL) OR
  (user_id IS NULL AND merchant_id IS NOT NULL)
);

ALTER TABLE card_authorizations ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE card_authorizations ADD COLUMN merchant_id TEXT REFERENCES merchants(id);
ALTER TABLE card_authorizations ADD CONSTRAINT card_auth_one_owner CHECK (
  (user_id IS NOT NULL AND merchant_id IS NULL) OR
  (user_id IS NULL AND merchant_id IS NOT NULL)
);
CREATE INDEX ON card_authorizations (merchant_id, created_at DESC);
