-- Payments taken through a merchant's own processor account.
--
-- Until now every payment went to the built-in simulated network, so an intent
-- only needed the ISO 8583 retrieval reference (network_ref). A payment taken
-- through Square or Stripe has a processor-side id instead, and that id is what
-- a later capture, void or refund has to be addressed to — without it, an
-- authorisation could be made but never captured.

ALTER TABLE payment_intents ADD COLUMN provider            TEXT;
ALTER TABLE payment_intents ADD COLUMN provider_payment_id TEXT;
-- What we asked the processor to route to us out of this payment, in minor
-- units. Distinct from `fee`: `fee` is what the merchant is charged in total,
-- and for a processor-backed payment the processor's own cut is not ours.
ALTER TABLE payment_intents ADD COLUMN platform_fee        BIGINT NOT NULL DEFAULT 0;
-- The processor's own fee, when it reports one. Square only knows it after
-- settlement, so this stays NULL until a webhook fills it in.
ALTER TABLE payment_intents ADD COLUMN provider_fee        BIGINT;

-- One processor payment backs at most one of our intents. If a retry ever
-- produced two intents pointing at the same Square payment, one of them would
-- be a phantom the merchant could capture or refund a second time.
CREATE UNIQUE INDEX payment_intents_provider_payment_idx
  ON payment_intents (provider, provider_payment_id)
  WHERE provider_payment_id IS NOT NULL;

ALTER TABLE refunds ADD COLUMN provider           TEXT;
ALTER TABLE refunds ADD COLUMN provider_refund_id TEXT;

-- A card tokenised in the browser by the processor's own SDK never reaches us,
-- so there is no vault row and no fingerprint to record. That is the entire
-- point of it: card data stays out of our servers, which keeps PCI scope at
-- SAQ A. These two columns therefore stop being mandatory.
ALTER TABLE payment_attempts ALTER COLUMN token_id    DROP NOT NULL;
ALTER TABLE payment_attempts ALTER COLUMN fingerprint DROP NOT NULL;
-- Which processor declined it, so a decline can be traced to the right console.
ALTER TABLE payment_attempts ADD COLUMN provider TEXT;

-- No new index here: 001 already covers (fingerprint, created_at), which is
-- what the velocity rule reads, and a NULL fingerprint simply matches nothing.
