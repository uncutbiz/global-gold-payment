-- Issued cards: virtual, and physical ones a customer orders.
--
-- WHAT THIS IS NOT. Nothing here issues a real card. A real card needs an
-- issuer-processor (Lithic, Marqeta, Stripe Issuing) sitting on a sponsor
-- bank's BIN. This is our side of that boundary: the card record, the spend
-- rules, the authorization decision and the money movement. The issuer is
-- behind an interface with a simulated implementation, exactly as Square and
-- Stripe are for acquiring, so adopting a real one is an adapter rather than
-- a rewrite.
--
-- The PAN is never stored here. It goes in the existing vault (card_tokens),
-- encrypted, and this table keeps only the token id plus what is safe to show.

CREATE TABLE issued_cards (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL REFERENCES users(id),
  kind            TEXT NOT NULL CHECK (kind IN ('virtual','physical')),
  status          TEXT NOT NULL CHECK (status IN
                    ('ordered','shipped','active','frozen','canceled')),
  -- The vault row holding the PAN. Null for a physical card that has been
  -- ordered but not yet produced: there is no number until it is made.
  vault_token_id  TEXT REFERENCES card_tokens(id),
  issuer          TEXT NOT NULL DEFAULT 'simulated',
  issuer_card_id  TEXT,
  brand           TEXT NOT NULL DEFAULT 'visa',
  last4           TEXT,
  exp_month       SMALLINT,
  exp_year        SMALLINT,
  currency        TEXT NOT NULL,
  nickname        TEXT,

  -- ── the programmable part ────────────────────────────────────────────────
  -- All limits are in minor units. NULL means "no limit of this kind", which
  -- is different from 0 ("nothing may be spent") — a distinction worth keeping
  -- because 0 is a legitimate way to park a card without freezing it.
  per_auth_limit  BIGINT CHECK (per_auth_limit IS NULL OR per_auth_limit >= 0),
  daily_limit     BIGINT CHECK (daily_limit    IS NULL OR daily_limit    >= 0),
  monthly_limit   BIGINT CHECK (monthly_limit  IS NULL OR monthly_limit  >= 0),
  -- Merchant category codes. An allow list wins if present: with allowed_mcc
  -- set, anything not in it is refused, and blocked_mcc is only consulted when
  -- there is no allow list.
  allowed_mcc     TEXT[],
  blocked_mcc     TEXT[],
  -- A single-use card dies on its first approval. Used for one-off payments
  -- where handing over a reusable number is the risk.
  single_use      BOOLEAN NOT NULL DEFAULT false,

  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  activated_at    TIMESTAMPTZ,
  canceled_at     TIMESTAMPTZ,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON issued_cards (user_id, created_at DESC);

-- Where a physical card is being sent, and how far along it is.
-- Separate from issued_cards because an address is personal data with its own
-- lifetime: a card can be cancelled while the delivery record still matters.
CREATE TABLE card_orders (
  id            TEXT PRIMARY KEY,
  card_id       TEXT NOT NULL REFERENCES issued_cards(id),
  user_id       TEXT NOT NULL REFERENCES users(id),
  name          TEXT NOT NULL,
  line1         TEXT NOT NULL,
  line2         TEXT,
  city          TEXT NOT NULL,
  region        TEXT,
  postal_code   TEXT NOT NULL,
  country       TEXT NOT NULL,
  status        TEXT NOT NULL CHECK (status IN ('ordered','printing','shipped','delivered','returned')),
  carrier       TEXT,
  tracking      TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  shipped_at    TIMESTAMPTZ,
  delivered_at  TIMESTAMPTZ
);
CREATE INDEX ON card_orders (card_id);

-- Every authorization the network asked us about, approved or not.
--
-- Kept even when declined, and that is the point: "why was my card refused"
-- is the single most common support question a card programme gets, and
-- without this row the honest answer is "no idea".
CREATE TABLE card_authorizations (
  id              TEXT PRIMARY KEY,
  card_id         TEXT NOT NULL REFERENCES issued_cards(id),
  user_id         TEXT NOT NULL REFERENCES users(id),
  amount          BIGINT NOT NULL CHECK (amount > 0),
  currency        TEXT NOT NULL,
  merchant_name   TEXT,
  mcc             TEXT,
  status          TEXT NOT NULL CHECK (status IN ('pending','approved','declined','reversed','captured','expired')),
  decline_reason  TEXT,
  -- The issuer's own handle, so a later capture or reversal can be matched.
  network_ref     TEXT,
  captured_amount BIGINT NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at      TIMESTAMPTZ,
  captured_at     TIMESTAMPTZ,
  reversed_at     TIMESTAMPTZ
);
CREATE INDEX ON card_authorizations (card_id, created_at DESC);
CREATE INDEX ON card_authorizations (user_id, created_at DESC);
-- The daily and monthly limit checks sum approved spend over a window, so the
-- index they lean on is card + decision time.
CREATE INDEX ON card_authorizations (card_id, decided_at)
  WHERE status IN ('approved','captured');
