-- Disputes (chargebacks).
--
-- Unlike everything else here, a dispute is not something anyone on this
-- platform decides to do. The cardholder tells their bank they do not
-- recognise a payment; the bank pulls the money back through the card network
-- and tells the processor, which tells us. By the time we hear about it the
-- money has usually already gone.
--
-- That has three consequences the schema has to carry:
--
--   1. There is a CLOCK. The card networks give a fixed window to submit
--      evidence — typically 7 to 21 days depending on the network and reason
--      — and missing it is an automatic loss with no appeal. evidence_due_by
--      is therefore not decoration; it is the most important column here.
--
--   2. The money moves WITHOUT US. A ledger that does not record the reversal
--      is a ledger that overstates what the merchant is owed, and a platform
--      that pays that balance out is a platform that has lost real money.
--
--   3. The same event arrives MORE THAN ONCE. Processors retry webhooks, and
--      a dispute changes state several times over its life. Every write here
--      has to be safe to repeat.

CREATE TABLE disputes (
  id                  TEXT PRIMARY KEY,
  merchant_id         TEXT NOT NULL REFERENCES merchants(id),
  payment_intent_id   TEXT REFERENCES payment_intents(id),

  provider            TEXT NOT NULL,
  -- The processor's id for the dispute. Unique per provider so a repeated
  -- webhook updates the row it already made instead of adding another.
  provider_dispute_id TEXT NOT NULL,

  amount              BIGINT NOT NULL CHECK (amount > 0),
  currency            TEXT NOT NULL,
  -- What the network charges for handling it, when the processor tells us.
  -- Usually non-refundable even if the dispute is won.
  fee                 BIGINT NOT NULL DEFAULT 0,

  -- Normalised across providers, because Square and Stripe name these
  -- differently and the merchant should not have to learn both.
  --   needs_response  evidence can still be submitted
  --   under_review    submitted, waiting on the network
  --   won             the merchant keeps the money
  --   lost            the money is gone
  --   accepted        the merchant chose not to fight it
  status              TEXT NOT NULL CHECK (status IN
                        ('needs_response','under_review','won','lost','accepted')),
  reason              TEXT,

  evidence_due_by     TIMESTAMPTZ,
  evidence            JSONB NOT NULL DEFAULT '{}',
  evidence_sent_at    TIMESTAMPTZ,

  -- Set once, when the reversal is written to the ledger. The guard against
  -- taking the money back twice on a repeated webhook is this column, not the
  -- handler remembering to check.
  reversed_at         TIMESTAMPTZ,
  -- Set once, if a lost dispute is later won on appeal and the money returns.
  restored_at         TIMESTAMPTZ,

  opened_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at         TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX disputes_provider_idx ON disputes (provider, provider_dispute_id);
CREATE INDEX disputes_merchant_idx ON disputes (merchant_id, created_at DESC);
-- The worklist: what still needs an answer, soonest deadline first.
CREATE INDEX disputes_due_idx ON disputes (evidence_due_by)
  WHERE status = 'needs_response';

-- So a payment can show that it is being disputed without a second query.
ALTER TABLE payment_intents ADD COLUMN disputed_at TIMESTAMPTZ;
