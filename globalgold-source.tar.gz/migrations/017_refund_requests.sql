-- Refund requests: the customer asking, rather than the merchant deciding.
--
-- Every refund in this system so far has started with the merchant. This table
-- is the other direction: the person who paid says "I want my money back", and
-- the merchant answers. That sounds small and it is not, because it changes
-- who is allowed to start a money movement.
--
-- WHY THIS IS A REQUEST AND NOT A REFUND
--
-- A customer cannot be allowed to move money out of a merchant's balance. If
-- they could, anyone who paid could empty the merchant's account by asking. So
-- a row here authorises nothing on its own — it is a message with a state. The
-- money only moves when the merchant approves, and approval runs the same
-- createRefund() path a merchant-initiated refund runs, with the same ledger
-- entries, the same fee handling and the same provider call. There is no
-- second refund code path, because a second code path is a second set of bugs.
--
-- WHY IT MATTERS THAT THIS EXISTS AT ALL
--
-- The alternative to a refund request is a chargeback. A customer who cannot
-- reach the merchant goes to their bank instead, and then: the merchant pays a
-- non-refundable network fee, loses the money anyway most of the time, and
-- takes a dispute-rate hit that at 1% gets them dropped by the card networks.
-- A refund request is the cheap version of a dispute for everyone involved.
-- That is the business case for building it, and it is why the merchant-facing
-- copy tells them the clock matters.
--
-- WHO IS ALLOWED TO ASK
--
-- Two kinds of payer, and they prove who they are differently:
--
--   wallet payer   signed in. payment_intents.wallet_user_id matches them.
--   card payer     has no account at all. They hold the checkout URL, which
--                  contains the PaymentIntent's client_secret, and that is
--                  their credential — the same secret that let them pay in the
--                  first place. Nothing new to issue, nothing new to leak.
--
-- Deliberately NOT here: an email-address-only request form. "Enter the email
-- you paid with" is not authentication, and a refund request queue that any
-- passer-by can fill is a support-desk denial-of-service.

CREATE TABLE refund_requests (
  id                  TEXT PRIMARY KEY,
  merchant_id         TEXT NOT NULL REFERENCES merchants(id),
  payment_intent_id   TEXT NOT NULL REFERENCES payment_intents(id),

  -- Set when a signed-in wallet customer asked. NULL for a card payer, who has
  -- no account; requested_email carries whatever they gave us to reply to.
  wallet_user_id      TEXT REFERENCES users(id),
  requested_email     TEXT,

  amount              BIGINT NOT NULL CHECK (amount > 0),
  currency            TEXT NOT NULL,

  -- A short code the customer picks, plus their own words. The code is what
  -- the merchant filters and reports on; the note is what actually explains it.
  reason              TEXT NOT NULL CHECK (reason IN
                        ('not_received','not_as_described','damaged','duplicate',
                         'accidental','cancelled_order','other')),
  note                TEXT,

  --   open      waiting on the merchant
  --   approved  the merchant said yes and the refund went through
  --   declined  the merchant said no, with a reason the customer can read
  --   withdrawn the customer changed their mind
  --   expired   nobody answered (see the note on the clock below)
  status              TEXT NOT NULL CHECK (status IN
                        ('open','approved','declined','withdrawn','expired'))
                      DEFAULT 'open',

  -- The merchant's answer, shown to the customer verbatim. A decline with no
  -- explanation is how a refund request becomes a chargeback, so the API
  -- requires this on a decline.
  merchant_response   TEXT,
  responded_at        TIMESTAMPTZ,
  responded_by        TEXT,

  -- The refund this produced, once approved. Also the idempotency guard: a
  -- request that already has one cannot make another.
  refund_id           TEXT,

  -- Advisory, not enforced by a job. The merchant sees "asked 6 days ago" and
  -- the admin can see who is sitting on requests. Nothing auto-approves —
  -- automatically moving a merchant's money because they were slow to read
  -- their dashboard would be indefensible.
  respond_by          TIMESTAMPTZ,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- A card payer must leave a contact address, since we have no other way to
  -- tell them the answer. A wallet payer is reachable through their account.
  CHECK (wallet_user_id IS NOT NULL OR requested_email IS NOT NULL)
);

-- One open request per payment. This is the real defence against a customer
-- spamming the queue, and it is a database constraint rather than a check in
-- the handler because two simultaneous submissions would both pass the check.
CREATE UNIQUE INDEX refund_requests_one_open_idx
  ON refund_requests (payment_intent_id) WHERE status = 'open';

-- The merchant's worklist, oldest first: the one that has been waiting longest
-- is the one closest to becoming a chargeback.
CREATE INDEX refund_requests_merchant_idx
  ON refund_requests (merchant_id, status, created_at);
-- The admin's platform-wide view, newest first.
CREATE INDEX refund_requests_all_idx ON refund_requests (created_at DESC);
CREATE INDEX refund_requests_user_idx ON refund_requests (wallet_user_id, created_at DESC);

-- So a payment row can show "refund requested" without a second query, the
-- same way disputed_at works.
ALTER TABLE payment_intents ADD COLUMN refund_requested_at TIMESTAMPTZ;
