-- Admin panel: staff accounts, audit log, KYC, transaction-monitoring alerts.

CREATE TABLE admin_users (
  id             TEXT PRIMARY KEY,
  email          TEXT NOT NULL UNIQUE,
  name           TEXT NOT NULL,
  password_hash  TEXT NOT NULL,
  role           TEXT NOT NULL CHECK (role IN ('owner','compliance','support','viewer')),
  disabled_at    TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE admin_sessions (
  token_hash   TEXT PRIMARY KEY,
  admin_id     TEXT NOT NULL REFERENCES admin_users(id),
  expires_at   TIMESTAMPTZ NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Every staff action that changes something. Append-only.
CREATE TABLE audit_log (
  id           BIGSERIAL PRIMARY KEY,
  admin_id     TEXT,                 -- NULL when the bootstrap ADMIN_TOKEN was used
  admin_label  TEXT NOT NULL,
  action       TEXT NOT NULL,
  target_type  TEXT NOT NULL,
  target_id    TEXT NOT NULL,
  details      JSONB NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON audit_log (created_at DESC);
CREATE TRIGGER audit_no_update BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION ledger_immutable();

-- KYC -----------------------------------------------------------------------
ALTER TABLE users ADD COLUMN kyc_status TEXT NOT NULL DEFAULT 'unverified'
  CHECK (kyc_status IN ('unverified','pending','approved','rejected'));
ALTER TABLE users ADD COLUMN locked_reason TEXT;

CREATE TABLE kyc_submissions (
  id               TEXT PRIMARY KEY,
  user_id          TEXT NOT NULL REFERENCES users(id),
  legal_name       TEXT NOT NULL,
  date_of_birth    DATE NOT NULL,
  address_line     TEXT NOT NULL,
  city             TEXT NOT NULL,
  postal_code      TEXT NOT NULL,
  country          TEXT NOT NULL,
  id_type          TEXT NOT NULL CHECK (id_type IN ('passport','national_id','drivers_license')),
  id_number_last4  TEXT NOT NULL,
  id_number_hash   TEXT NOT NULL,     -- HMAC, for duplicate-identity checks without storing the number
  document         BYTEA NOT NULL,    -- production: object storage with encryption, not the database
  document_mime    TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewer_label   TEXT,
  review_note      TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  reviewed_at      TIMESTAMPTZ
);
CREATE INDEX ON kyc_submissions (status, created_at);
CREATE INDEX ON kyc_submissions (id_number_hash);

-- Transaction monitoring ----------------------------------------------------
CREATE TABLE alerts (
  id               TEXT PRIMARY KEY,
  severity         TEXT NOT NULL CHECK (severity IN ('low','medium','high')),
  rule             TEXT NOT NULL,
  message          TEXT NOT NULL,
  subject_type     TEXT NOT NULL,     -- wallet_transaction | payment_intent | user | merchant | kyc_submission
  subject_id       TEXT NOT NULL,
  user_id          TEXT REFERENCES users(id),
  merchant_id      TEXT REFERENCES merchants(id),
  amount           BIGINT,
  currency         TEXT,
  status           TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved','dismissed')),
  resolved_by      TEXT,
  resolution_note  TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at      TIMESTAMPTZ
);
CREATE INDEX ON alerts (status, created_at DESC);
CREATE INDEX ON alerts (subject_id);
