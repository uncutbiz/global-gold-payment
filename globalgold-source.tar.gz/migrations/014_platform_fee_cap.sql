-- A monthly ceiling on what the platform charges one merchant.
--
-- Why a table rather than summing payment_intents: the cap has to be decided
-- BEFORE the processor is told what app fee to take, and two payments
-- confirming at the same moment would both read the same running total and
-- both be granted the last of the room. Summing is a read; this is a row we
-- can lock, so the arithmetic is atomic and a merchant cannot be charged past
-- the cap by a race.
--
-- `charged` is money already taken this month, in minor units. It goes up when
-- a payment succeeds and back down when one is refunded or an authorization is
-- abandoned, so a merchant who refunds half their month gets that room back.
CREATE TABLE platform_fee_months (
  merchant_id  TEXT NOT NULL REFERENCES merchants(id),
  month        DATE NOT NULL,              -- first day of the month, UTC
  charged      BIGINT NOT NULL DEFAULT 0 CHECK (charged >= 0),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (merchant_id, month)
);
