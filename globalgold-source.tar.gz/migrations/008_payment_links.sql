-- Payment links: a reusable, shareable page that takes a payment.
--
-- The merchant creates one, sends the URL by email, SMS, invoice or QR code,
-- and anyone who opens it pays. This is the thing a small merchant actually
-- reaches for — no site, no integration, no code.
--
-- A link is a *template*, not a payment. Opening one creates a fresh payment
-- intent for that buyer, which then goes through exactly the same checkout,
-- provider routing, fee and ledger path as any API-created payment. Nothing
-- about charging is duplicated here.

CREATE TABLE payment_links (
  id            TEXT PRIMARY KEY,
  merchant_id   TEXT NOT NULL REFERENCES merchants(id),

  -- The short public token in the URL. Not the primary key: the id identifies
  -- the row to the merchant's API, while this is what a stranger sees and
  -- types. Keeping them separate means the public code can be rotated, and a
  -- guessed id reveals nothing.
  code          TEXT NOT NULL UNIQUE,

  -- NULL means the buyer chooses what to pay — donations, tips, part-payment
  -- of an invoice. min/max bound that choice.
  amount        BIGINT CHECK (amount IS NULL OR amount > 0),
  min_amount    BIGINT CHECK (min_amount IS NULL OR min_amount > 0),
  max_amount    BIGINT CHECK (max_amount IS NULL OR max_amount > 0),
  currency      TEXT NOT NULL,

  title         TEXT NOT NULL,
  description   TEXT,

  active        BOOLEAN NOT NULL DEFAULT TRUE,
  expires_at    TIMESTAMPTZ,

  -- A cap on how many times it can be PAID. Counting successful payments
  -- rather than page views matters: a buyer who opens the link, thinks better
  -- of it and closes the tab must not burn one of a limited run.
  max_uses      INTEGER CHECK (max_uses IS NULL OR max_uses > 0),
  paid_count    INTEGER NOT NULL DEFAULT 0 CHECK (paid_count >= 0),

  metadata      JSONB NOT NULL DEFAULT '{}',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- A fixed amount and a buyer-chosen range are alternatives, never both.
  CONSTRAINT amount_or_range CHECK (
    (amount IS NOT NULL AND min_amount IS NULL AND max_amount IS NULL)
    OR amount IS NULL),
  CONSTRAINT range_ordered CHECK (
    min_amount IS NULL OR max_amount IS NULL OR min_amount <= max_amount)
);

CREATE INDEX payment_links_merchant_idx ON payment_links (merchant_id, created_at DESC);

-- Which link produced a payment, so the merchant can see what each one earned
-- and so a successful payment can count against the link's cap.
ALTER TABLE payment_intents ADD COLUMN payment_link_id TEXT REFERENCES payment_links(id);
CREATE INDEX payment_intents_link_idx ON payment_intents (payment_link_id)
  WHERE payment_link_id IS NOT NULL;
