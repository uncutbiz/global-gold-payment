-- Global Gold wallet: consumer accounts that hold a balance, send money, and pay merchants.
-- A wallet balance is stored money, which is money transmission: see the blueprint before going live.

CREATE TABLE users (
  id             TEXT PRIMARY KEY,
  email          TEXT NOT NULL UNIQUE,
  name           TEXT NOT NULL,
  password_hash  TEXT NOT NULL,          -- scrypt
  status         TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','locked')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE user_sessions (
  token_hash   TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id),
  expires_at   TIMESTAMPTZ NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Cards can now belong to a merchant (API tokenization) or a wallet user (linked cards).
ALTER TABLE card_tokens ALTER COLUMN merchant_id DROP NOT NULL;
ALTER TABLE card_tokens ADD COLUMN user_id TEXT REFERENCES users(id);
ALTER TABLE card_tokens ADD COLUMN removed_at TIMESTAMPTZ;
ALTER TABLE card_tokens ADD CONSTRAINT card_tokens_owner CHECK ((merchant_id IS NULL) <> (user_id IS NULL));

-- Every wallet movement, for the user's activity feed. The ledger remains the source of truth.
CREATE TABLE wallet_transactions (
  id                 TEXT PRIMARY KEY,
  user_id            TEXT NOT NULL REFERENCES users(id),
  type               TEXT NOT NULL CHECK (type IN ('top_up','transfer_out','transfer_in','payment','refund','withdrawal')),
  amount             BIGINT NOT NULL,     -- signed: + money in, - money out
  currency           TEXT NOT NULL,
  counterparty       TEXT,                -- other user's name/email or merchant name
  note               TEXT,
  status             TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('completed','failed')),
  failure_message    TEXT,
  payment_intent_id  TEXT REFERENCES payment_intents(id),
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON wallet_transactions (user_id, created_at DESC);

-- Merchant payments funded from a wallet (no card network involved).
ALTER TABLE payment_intents ADD COLUMN wallet_user_id TEXT REFERENCES users(id);

-- Card top-ups are card sales: they go into the clearing file like merchant payments.
ALTER TABLE wallet_transactions ADD COLUMN card_token_id TEXT REFERENCES card_tokens(id);
ALTER TABLE wallet_transactions ADD COLUMN network_ref TEXT;
ALTER TABLE wallet_transactions ADD COLUMN auth_code TEXT;
ALTER TABLE wallet_transactions ADD COLUMN clearing_batch_id TEXT REFERENCES clearing_batches(id);
