-- Invoices.
--
-- A document with line items, sent to a customer, that gets paid. The payment
-- itself is not reimplemented here: an invoice carries a payment link, and
-- paying it runs down exactly the same road as every other payment on the
-- platform. A second charge path would be a second place for money to go wrong.
--
-- Totals are computed from the lines and stored, never accepted from the
-- caller. Two reasons, and the second is the one that bites: arithmetic done
-- once in SQL cannot disagree with itself, and a client-supplied total is a
-- client-supplied price — anyone who can call the API could invoice a customer
-- for £500 of lines and collect £5, or the reverse.

CREATE TABLE invoices (
  id              TEXT PRIMARY KEY,
  merchant_id     TEXT NOT NULL REFERENCES merchants(id),
  customer_id     TEXT NOT NULL REFERENCES customers(id),

  -- Human-facing, sequential per merchant, and what a customer quotes on the
  -- phone. Separate from the id for the same reason a payment link's code is:
  -- one is for machines, one is for people.
  number          TEXT NOT NULL,

  currency        TEXT NOT NULL,
  -- All computed from invoice_lines. See recalcInvoice().
  subtotal        BIGINT NOT NULL DEFAULT 0 CHECK (subtotal >= 0),
  tax_total       BIGINT NOT NULL DEFAULT 0 CHECK (tax_total >= 0),
  total           BIGINT NOT NULL DEFAULT 0 CHECK (total >= 0),
  amount_paid     BIGINT NOT NULL DEFAULT 0 CHECK (amount_paid >= 0),

  --   draft     still being edited; the customer has seen nothing
  --   open      sent, payable
  --   paid      settled in full
  --   void      cancelled before payment; kept, never deleted
  --   uncollectible  written off
  status          TEXT NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft','open','paid','void','uncollectible')),

  title           TEXT,
  note            TEXT,
  due_at          TIMESTAMPTZ,

  -- How it gets paid. Created when the invoice is sent, not before: a draft
  -- must not be payable by anyone who guesses the URL.
  payment_link_id TEXT REFERENCES payment_links(id),

  sent_at         TIMESTAMPTZ,
  paid_at         TIMESTAMPTZ,
  voided_at       TIMESTAMPTZ,
  metadata        JSONB NOT NULL DEFAULT '{}',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX invoices_number_idx ON invoices (merchant_id, number);
CREATE INDEX invoices_merchant_idx ON invoices (merchant_id, created_at DESC);
CREATE INDEX invoices_customer_idx ON invoices (customer_id);
-- The chasing list: what is sent, unpaid, and past its date.
CREATE INDEX invoices_overdue_idx ON invoices (due_at) WHERE status = 'open';

CREATE TABLE invoice_lines (
  id           TEXT PRIMARY KEY,
  invoice_id   TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  position     INTEGER NOT NULL,

  description  TEXT NOT NULL,
  -- Thousandths, so "1.5 hours" and "0.25 days" are exact. Storing quantity as
  -- a float is how an invoice for 0.1 + 0.2 hours bills 0.30000000000000004.
  quantity     BIGINT NOT NULL DEFAULT 1000 CHECK (quantity > 0),
  unit_amount  BIGINT NOT NULL CHECK (unit_amount >= 0),
  -- Basis points: 2000 is 20%.
  tax_bps      INTEGER NOT NULL DEFAULT 0 CHECK (tax_bps >= 0 AND tax_bps <= 10000),

  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX invoice_lines_invoice_idx ON invoice_lines (invoice_id, position);

-- Which invoice a payment settled, so an invoice can be reconciled without
-- guessing from amounts and dates.
ALTER TABLE payment_intents ADD COLUMN invoice_id TEXT REFERENCES invoices(id);
CREATE INDEX payment_intents_invoice_idx ON payment_intents (invoice_id)
  WHERE invoice_id IS NOT NULL;

-- Per-merchant invoice numbering. A sequence would be global across every
-- merchant on the platform, so each merchant's first invoice would be numbered
-- however many invoices everyone else had already sent — which tells a customer
-- exactly how much business the platform does.
CREATE TABLE invoice_counters (
  merchant_id TEXT PRIMARY KEY REFERENCES merchants(id),
  next_number BIGINT NOT NULL DEFAULT 1
);
