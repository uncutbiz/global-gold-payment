-- International wallets: home country/currency, multi-currency balances, FX quotes.
ALTER TABLE users ADD COLUMN country  TEXT NOT NULL DEFAULT 'US';
ALTER TABLE users ADD COLUMN currency TEXT NOT NULL DEFAULT 'usd';

CREATE TABLE fx_quotes (
  id             TEXT PRIMARY KEY,
  user_id        TEXT NOT NULL REFERENCES users(id),
  from_currency  TEXT NOT NULL,
  to_currency    TEXT NOT NULL,
  amount_from    BIGINT NOT NULL CHECK (amount_from > 0),
  amount_to      BIGINT NOT NULL CHECK (amount_to >= 0),
  rate           NUMERIC(20,10) NOT NULL,
  expires_at     TIMESTAMPTZ NOT NULL,
  used_at        TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE wallet_transactions DROP CONSTRAINT wallet_transactions_type_check;
ALTER TABLE wallet_transactions ADD CONSTRAINT wallet_transactions_type_check
  CHECK (type IN ('top_up','transfer_out','transfer_in','payment','refund','withdrawal','conversion_out','conversion_in'));
ALTER TABLE wallet_transactions ADD COLUMN counter_amount   BIGINT;   -- the other side of an FX movement
ALTER TABLE wallet_transactions ADD COLUMN counter_currency TEXT;
ALTER TABLE wallet_transactions ADD COLUMN fx_rate          NUMERIC(20,10);
ALTER TABLE wallet_transactions ADD COLUMN international    BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE wallet_transactions ADD COLUMN fee BIGINT NOT NULL DEFAULT 0;   -- our fee on this movement, in `currency`
