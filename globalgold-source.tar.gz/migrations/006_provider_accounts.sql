-- Connecting a merchant's own processor account (Square today, Stripe later).
--
-- We hold OAuth tokens that can take payments on the merchant's behalf, so they
-- are encrypted at rest with the same AES-256-GCM scheme as the card vault:
-- ciphertext bound to the merchant id as additional authenticated data, so a
-- token stolen from one row cannot be replayed against another.

ALTER TABLE merchants ADD COLUMN provider             TEXT;
ALTER TABLE merchants ADD COLUMN provider_account_id  TEXT;
ALTER TABLE merchants ADD COLUMN provider_location_id TEXT;
ALTER TABLE merchants ADD COLUMN provider_key_id      TEXT;
ALTER TABLE merchants ADD COLUMN provider_access_iv   BYTEA;
ALTER TABLE merchants ADD COLUMN provider_access_ct   BYTEA;
ALTER TABLE merchants ADD COLUMN provider_access_tag  BYTEA;
ALTER TABLE merchants ADD COLUMN provider_refresh_iv  BYTEA;
ALTER TABLE merchants ADD COLUMN provider_refresh_ct  BYTEA;
ALTER TABLE merchants ADD COLUMN provider_refresh_tag BYTEA;
ALTER TABLE merchants ADD COLUMN provider_expires_at  TIMESTAMPTZ;
ALTER TABLE merchants ADD COLUMN provider_connected_at TIMESTAMPTZ;

-- One processor account cannot serve two of our merchants: that would let one
-- business take payments into another's account.
CREATE UNIQUE INDEX merchants_provider_account_idx
  ON merchants (provider, provider_account_id)
  WHERE provider_account_id IS NOT NULL;

-- Short-lived state for the OAuth round trip. The state value is what ties the
-- provider's callback back to the merchant who started it, so it is single-use
-- and expires; without this check any visitor could connect their own Square
-- account to someone else's Global Gold merchant.
CREATE TABLE provider_oauth_states (
  state        TEXT PRIMARY KEY,
  merchant_id  TEXT NOT NULL REFERENCES merchants(id),
  provider     TEXT NOT NULL,
  redirect_uri TEXT NOT NULL,
  used_at      TIMESTAMPTZ,
  expires_at   TIMESTAMPTZ NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX provider_oauth_states_merchant_idx ON provider_oauth_states (merchant_id);

-- Every webhook the provider sends, kept once. The provider retries, so the id
-- is the idempotency guard: a replayed notification must not be acted on twice.
CREATE TABLE provider_events (
  id           TEXT PRIMARY KEY,
  provider     TEXT NOT NULL,
  event_id     TEXT NOT NULL,
  type         TEXT NOT NULL,
  merchant_id  TEXT REFERENCES merchants(id),
  payload      JSONB NOT NULL,
  processed_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX provider_events_unique_idx ON provider_events (provider, event_id);
CREATE INDEX provider_events_type_idx ON provider_events (type, created_at DESC);
