-- Phone numbers, and resetting a password by SMS.
--
-- Two tables and two columns, but the security lives almost entirely in how
-- they are used (src/auth/reset.ts). The parts the schema itself has to get
-- right:
--
--   1. A number must be VERIFIED before it can recover an account. An
--      unverified number is just a string someone typed, and letting a typed
--      string reset a password means anyone can reset anyone's password by
--      claiming their number.
--
--   2. Codes are stored HASHED. A six-digit code is not a secret worth much,
--      but a database read should not hand over every live reset code on the
--      platform, and a backup should not either.
--
--   3. Attempts are counted IN the row. A six-digit code is one in a million
--      only if you get a handful of guesses; with unlimited guesses it is one
--      in one.

ALTER TABLE merchant_users ADD COLUMN phone TEXT;
ALTER TABLE merchant_users ADD COLUMN phone_verified_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN phone TEXT;
ALTER TABLE users ADD COLUMN phone_verified_at TIMESTAMPTZ;

-- Partial and unique: one account per verified number, so a reset code can
-- never be ambiguous about whose account it opens. Unverified numbers are not
-- constrained, because two people may well type the same wrong number.
CREATE UNIQUE INDEX merchant_users_phone_idx ON merchant_users (phone)
  WHERE phone IS NOT NULL AND phone_verified_at IS NOT NULL;
CREATE UNIQUE INDEX users_phone_idx ON users (phone)
  WHERE phone IS NOT NULL AND phone_verified_at IS NOT NULL;

-- One table for both jobs, because they are the same mechanism: send a short
-- code to a number and check it came back.
--   verify_phone    proving a number belongs to you, before it can recover you
--   reset_password  recovering the account
CREATE TABLE otp_codes (
  id            TEXT PRIMARY KEY,
  purpose       TEXT NOT NULL CHECK (purpose IN ('verify_phone','reset_password')),

  -- Which account this is for. Exactly one is set.
  merchant_user_id TEXT REFERENCES merchant_users(id) ON DELETE CASCADE,
  user_id          TEXT REFERENCES users(id) ON DELETE CASCADE,

  -- E.164, as sent to. Kept so a code cannot be replayed against a number the
  -- account has since changed away from.
  phone         TEXT NOT NULL,
  -- sha256(code + pepper). Never the code.
  code_hash     TEXT NOT NULL,

  attempts      INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  expires_at    TIMESTAMPTZ NOT NULL,
  -- Set the moment it is accepted, so it cannot be used a second time.
  consumed_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_ip    TEXT,

  CONSTRAINT one_subject CHECK (
    (merchant_user_id IS NOT NULL)::int + (user_id IS NOT NULL)::int = 1)
);

CREATE INDEX otp_live_idx ON otp_codes (phone, purpose, created_at DESC)
  WHERE consumed_at IS NULL;
CREATE INDEX otp_expiry_idx ON otp_codes (expires_at) WHERE consumed_at IS NULL;

-- A short-lived ticket handed out once a code is accepted, so the new password
-- is sent in a separate request from the code. Without this the code itself
-- would have to be re-sent alongside the password, which means it lives longer
-- and travels further than it needs to.
CREATE TABLE reset_tickets (
  token_hash       TEXT PRIMARY KEY,
  merchant_user_id TEXT REFERENCES merchant_users(id) ON DELETE CASCADE,
  user_id          TEXT REFERENCES users(id) ON DELETE CASCADE,
  expires_at       TIMESTAMPTZ NOT NULL,
  used_at          TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT one_ticket_subject CHECK (
    (merchant_user_id IS NOT NULL)::int + (user_id IS NOT NULL)::int = 1)
);
