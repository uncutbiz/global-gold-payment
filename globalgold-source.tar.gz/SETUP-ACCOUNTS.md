# The three accounts only you can open

Everything else is built. These three need your legal identity, your payment
method, and someone accepting terms of service, so they cannot be automated.
Each one is a form; this file is the exact values to put in it.

Do them in this order — the Square application needs your domain, and the domain
needs the AWS account.

---

## 1. AWS account — 10 minutes

<https://aws.amazon.com> → **Create an AWS account**. Needs an email, a card
(there's a free tier, but a card is required) and a phone for verification.

Then, before anything else, two things that take two minutes and save a bad day:

- **Turn on MFA for the root user**, and then stop using it. IAM → Security
  credentials → Multi-factor authentication.
- **Make yourself an admin user** for daily work: IAM Identity Center → Users →
  add user → give it the `AdministratorAccess` permission set. Sign in as that
  from now on.

Nothing else to configure. `make deploy` creates every resource it needs.

## 2. Domain — 5 minutes

AWS console → **Route 53 → Registered domains → Register domains**.
A `.com` is about $14/year and the hosted zone appears automatically, so there is
no DNS delegation step.

Or let the script do it once the AWS CLI is signed in:

```bash
bash scripts/register-domain.sh globalgoldpay.com
```

It checks availability, shows the price, asks for your registrant details, and
only charges after you type `YES`. It then finds the hosted zone and writes
`infra/aws/terraform.tfvars` for you.

## 3. Square developer application — 15 minutes

<https://developer.squareup.com/apps> → sign in with your Square account (or
create one) → **Create app**. Name it *Global Gold Payment*.

Square gives you a **Sandbox** and a **Production** set of credentials. Do
everything below in Sandbox first; production is the same form again.

### 3a. OAuth

Open the app → **OAuth** in the left sidebar.

| Field | Value |
|---|---|
| Redirect URL | `https://staging.globalgoldpay.com/v1/connect/square/callback` |

Copy these two into your environment (below):

- **Application ID** → `SQUARE_APP_ID`
- **Application Secret** → `SQUARE_APP_SECRET`

### 3b. The permission that app fees need

App fees are not enabled by default. Request the
**`PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS`** permission for your application —
Square's developer support or the OAuth page handles this. Without it, payments
still work but your 0.5% is silently not collected, so do this early.

The full set the platform asks a seller for:

```
MERCHANT_PROFILE_READ  PAYMENTS_READ  PAYMENTS_WRITE
PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS  ORDERS_READ  ORDERS_WRITE
```

### 3c. Webhooks

Open the app → **Webhooks → Subscriptions → Add subscription**.

| Field | Value |
|---|---|
| Notification URL | `https://staging.globalgoldpay.com/v1/webhooks/square` |
| API version | the newest offered |
| Events | `payment.updated`, `refund.updated`, `oauth.authorization.revoked` |

Then copy the **Signature key** → `SQUARE_WEBHOOK_SIGNATURE_KEY`.

The signature is checked on every notification, over the raw request bytes plus
that exact URL — so if you change the URL later, the key check will start failing
until the subscription is updated to match.

---

## Putting the values in

For a local run, in `.env`:

```bash
PAYMENT_PROVIDER=square
SQUARE_ENV=sandbox
SQUARE_APP_ID=sandbox-sq0idb-...
SQUARE_APP_SECRET=sandbox-sq0csb-...
SQUARE_WEBHOOK_SIGNATURE_KEY=...
PLATFORM_FEE_BPS=50          # your 0.5%
WALLET_MODE=off              # no stored value; see below
```

On AWS, put the three Square values into the app's secret in Secrets Manager
(the ARN comes from `make outputs`) rather than into the task definition, so they
never appear in the console or in Terraform state:

```bash
aws secretsmanager get-secret-value --secret-id "$(cd infra/aws && terraform output -raw app_secret_arn)" \
  --query SecretString --output text > /tmp/secret.json
# edit /tmp/secret.json, adding the SQUARE_* keys
aws secretsmanager put-secret-value --secret-id "$(cd infra/aws && terraform output -raw app_secret_arn)" \
  --secret-string "file:///tmp/secret.json"
shred -u /tmp/secret.json
```

### Check it took

```bash
curl https://staging.globalgoldpay.com/v1/connect/config
```

That prints the redirect URL and webhook URL the running server expects. They
must match what you typed into Square, character for character.

---

## 4. Stripe — optional, and the answer to Square's country limits

Square cannot onboard a merchant in Nigeria, Kenya, Ghana, India, Brazil, Mexico
or South Africa. Stripe can. Both can run at once, and each merchant is routed to
whichever serves their country — the merchant never sees the difference.

<https://dashboard.stripe.com/register> → then **Connect → Get started** (choose
a platform account) → **Settings → OAuth**.

| Field | Value |
|---|---|
| Redirect URI | `https://staging.globalgoldpay.com/v1/connect/stripe/callback` |
| Webhook endpoint | `https://staging.globalgoldpay.com/v1/webhooks/stripe` (listen to **Connect** events) |

Copy into your environment:

- **Client ID** (`ca_…`, on the OAuth settings page) → `STRIPE_CLIENT_ID`
- **Secret key** (`sk_test_…`, then `sk_live_…`) → `STRIPE_SECRET_KEY`
- **Publishable key** (`pk_test_…`, then `pk_live_…`) → `STRIPE_PUBLISHABLE_KEY`
- **Webhook signing secret** (`whsec_…`) → `STRIPE_WEBHOOK_SECRET`

The publishable key is the one the checkout page sends to the shopper's browser
so Stripe.js can turn their card into a token. Without it the hosted checkout
refuses to draw a card form at all, rather than falling back to collecting the
number itself — see *How a card reaches the processor* below.

Then turn both on:

```bash
PAYMENT_PROVIDERS=square,stripe
```

The order matters: the first provider that serves a country is the one a new
merchant in that country is offered. `square,stripe` means US merchants go to
Square and Nigerian merchants go to Stripe; swapping the order sends everyone to
Stripe who can go there.

Check what a deployment offers:

```bash
curl https://staging.globalgoldpay.com/v1/connect/config
curl 'https://staging.globalgoldpay.com/v1/connect/providers?country=NG'
```

One difference worth knowing: Square issues a token per seller, which we encrypt
and store. Stripe deprecated that — we call with your platform key plus a
`Stripe-Account` header, so a connected Stripe merchant has no secret stored at
all.

---

## How a card reaches the processor

Worth knowing, because it decides how much of PCI DSS applies to you.

On the **simulated** network the shopper's card number is posted to this server
and encrypted into our own vault. That is fine for a test network and nowhere
near fine for a real one.

On **Square** and **Stripe** it never comes near us. The checkout page asks
`GET /v1/checkout/:id/payment_config`, gets back the merchant's processor and
its *public* keys, and loads that processor's own SDK. The SDK draws the card
fields inside an iframe on its own domain and hands the page back a single-use
token. Only that token is posted here, and only that token is what we send with
the charge. The card number is never in our page's JavaScript, our logs, our
database or our backups.

That is the difference between a **SAQ A** self-assessment and a full **Level 1**
assessment by a QSA, which is a materially different amount of work and money.

Two consequences the code enforces rather than merely documents:

- Sending a card number for a Square or Stripe merchant is refused with
  `raw_card_not_accepted`, before the number is stored — not after.
- If the SDK fails to load (a network block, an ad blocker), the checkout page
  shows an error instead of quietly falling back to its own card fields. A
  silent fallback would route a real card through this server, which is the one
  thing the design exists to prevent.

## Two things to know before you start selling

**Square cannot onboard merchants everywhere.** App fees work in the US, Canada,
the UK, Australia, the eurozone and Japan, and the seller must be in the same
country and currency as your platform account — so one Square account per
country. Nigeria, Kenya, Ghana, India, the Philippines, Brazil, Mexico and South
Africa are not available on Square at all. The code knows this: a merchant in an
unsupported country is routed to Stripe when it is enabled, and otherwise refused
at `POST /v1/connect/start` with an explanation rather than failing later at the
till. Section 4 above is how you cover those countries.

**`WALLET_MODE=off` is deliberate.** Holding customer balances and letting people
send money to each other is money transmission: it needs licensing, and Square
prohibits peer-to-peer transfers on its rails. The wallet code is complete and
switched off. Production refuses to start with `WALLET_MODE=full` unless you
declare that you hold that permission.

**Your pricing.** Square bills the seller its own rate — currently 3.3% + 30¢
online, or 2.9% + 30¢ on a Plus plan — and deposits your `app_fee_money` to you.
You pay Square nothing directly. Your merchant's total is therefore Square's rate
plus your 0.5%, shown as separate lines on every payment.
