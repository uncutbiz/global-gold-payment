/**
 * Prove a language switch works, and that a half-finished catalogue falls
 * back per string rather than blanking the page.
 *
 *   npx tsx scripts/i18n-check.ts
 *
 * Exits non-zero if any page fails, so this can go in CI.
 *
 * WHY THE TEST DOES NOT WRITE TO public/i18n/es.json
 *
 * It used to: seed a few Spanish strings, run, then put the file back. That is
 * the wrong shape twice over. The restore ran after pool.end() with a
 * process.on('exit') handler as backup, and when the run was interrupted the
 * seeded strings stayed on disk — which is exactly what happened: es.json sat
 * in the tree with 13 machine-written strings in it, contradicting the
 * decision that nothing ships translated until a human translates it.
 *
 * So now the catalogue the browser receives is invented in memory and served
 * by intercepting the request. The file on disk is never opened for writing,
 * and the run asserts its hash is unchanged at the end. A test that can
 * corrupt the thing it is testing is not a test.
 */
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import type { AddressInfo } from 'node:net';
import { chromium } from 'playwright';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'i18n-check';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off'; process.env.LOG_REQUESTS = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
await migrate();
const server = createApp().listen(0);
await new Promise((r) => server.once('listening', r));
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

const ES_FILE = new URL('../public/i18n/es.json', import.meta.url);
const hashBefore = crypto.createHash('sha256').update(await fs.readFile(ES_FILE)).digest('hex');

/*
 * The catalogue served to the browser, built in memory from the English file.
 * Deliberately partial: the point of the fallback test is that the untouched
 * keys still render in English.
 */
const WORDS: Record<string, string> = {
  'sign in': 'Iniciar sesión', 'password': 'Contraseña', 'work email': 'Correo de trabajo',
  'email': 'Correo electrónico', 'home': 'Inicio', 'payments': 'Pagos', 'settings': 'Ajustes',
};
const en: Record<string, string> = JSON.parse(
  await fs.readFile(new URL('../public/i18n/en.json', import.meta.url), 'utf8'));
const fakeEs: Record<string, string> = {};
for (const k of Object.keys(en)) fakeEs[k] = WORDS[en[k].trim().toLowerCase()] ?? '';
const seeded = Object.values(fakeEs).filter((v) => v).length;
if (!seeded) { console.error('  no seed words matched en.json — the check would prove nothing'); process.exit(1); }

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
let failures = 0;

for (const page of ['/', '/dashboard', '/wallet']) {
  const p = await browser.newPage({ viewport: { width: 1200, height: 900 } });
  const errs: string[] = [];
  p.on('pageerror', (e) => errs.push(e.message));

  // The only place the Spanish strings exist.
  let served = 0;
  await p.route('**/static/i18n/es.json', async (route) => {
    served++;
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(fakeEs) });
  });

  await p.goto(base + page);
  await p.waitForFunction(
    () => (document.getElementById('languageSelect') as HTMLSelectElement || { options: [] }).options.length >= 5,
    null, { timeout: 8000 });

  const opts = await p.locator('#languageSelect option').allTextContents();
  const before = (await p.locator('[data-i18n]').first().textContent())?.trim();

  await p.selectOption('#languageSelect', 'es');
  await p.waitForTimeout(600);
  const lang = await p.evaluate(() => document.documentElement.lang);
  // A string that IS translated, and one that is not.
  const translated = await p.evaluate(() => {
    const n = [...document.querySelectorAll('[data-i18n]')]
      .find((e) => (e as HTMLElement).innerText && /Contraseña|Iniciar sesión|Inicio|Pagos|Correo/.test((e as HTMLElement).innerText));
    return n ? (n as HTMLElement).innerText.trim() : null;
  });
  const stillEnglish = await p.evaluate(() => {
    const n = [...document.querySelectorAll('[data-i18n]')]
      .find((e) => /^[A-Za-z][A-Za-z '’,.\-]{12,}$/.test((e as HTMLElement).innerText || ''));
    return n ? (n as HTMLElement).innerText.trim().slice(0, 44) : null;
  });

  // Switching back must restore English, not leave Spanish behind.
  await p.selectOption('#languageSelect', 'en');
  await p.waitForTimeout(400);
  const restored = (await p.locator('[data-i18n]').first().textContent())?.trim();

  const bad: string[] = [];
  if (opts.length < 5) bad.push(`picker has ${opts.length} languages`);
  if (served < 1) bad.push('es.json was never requested');
  if (lang !== 'es') bad.push(`lang="${lang}" after switching to es`);
  if (!translated) bad.push('no translated string appeared');
  if (!stillEnglish) bad.push('no untranslated string fell back to English');
  if (before !== restored) bad.push(`switching back lost the English: ${JSON.stringify(before)} -> ${JSON.stringify(restored)}`);
  if (errs.length) bad.push('page errors: ' + errs.join(' | '));

  console.log(`  ${page}   ${bad.length ? 'FAIL' : 'ok'}`);
  console.log(`    picker:        ${opts.length} languages — ${opts.join(', ')}`);
  console.log(`    es applied:    lang="${lang}"  translated: ${JSON.stringify(translated)}`);
  console.log(`    fallback:      ${JSON.stringify(stillEnglish)}`);
  console.log(`    back to en:    ${before === restored ? 'restored' : 'MISMATCH'}`);
  for (const b of bad) console.log(`    · ${b}`);
  if (bad.length) failures++;
  await p.close();
}

await browser.close(); server.close(); await pool.end();

// The file must be byte-identical: this run served its Spanish from memory.
const hashAfter = crypto.createHash('sha256').update(await fs.readFile(ES_FILE)).digest('hex');
if (hashAfter !== hashBefore) {
  console.error('\n  public/i18n/es.json CHANGED during the check — it must never be written to');
  failures++;
} else {
  console.log(`\n  es.json untouched (${seeded} Spanish strings served from memory, none written to disk)`);
}

process.exit(failures ? 1 : 0);
