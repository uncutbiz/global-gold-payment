/**
 * Wrap the strings built in JavaScript in t(), so they translate too.
 *
 *   npx tsx scripts/i18n-js.ts          # rewrite + extend the catalogues
 *   npx tsx scripts/i18n-js.ts --check  # fail if any are left bare
 *
 * WHY THIS IS A SEPARATE PASS
 *
 * i18n-extract.ts works on markup, where a translatable string is a text node
 * inside a known tag. Here the string is an argument, and the only safe way to
 * find one is to recognise the exact call shapes this codebase uses:
 *
 *   el('span', { textContent: 'no number yet' })   ->  i18n.t('key', 'no number yet')
 *   toast('Payment sent')                          ->  toast(i18n.t('key', 'Payment sent'))
 *   x.textContent = 'Loading…'                     ->  i18n.t('key', 'Loading…')
 *
 * It calls i18n.t(), never a bare t(). window.t exists as a shorthand, but
 * three functions in admin.html already declare a local `t` (a toast element,
 * two debounce timers), and inside those scopes a bare t() resolves to the
 * local and throws "t is not a function" — which it did, killing the admin
 * transactions panel until the generated calls were qualified. `i18n` is a
 * name nothing in these pages shadows.
 *
 * DELIBERATELY SKIPPED, because getting these wrong breaks the page rather
 * than merely leaving it English:
 *
 *   template literals        `Paid ${amt}` — the sentence is assembled at
 *                            runtime, so a translator needs a placeholder
 *                            convention, not a key. Left for a human.
 *   already-wrapped calls    t( ... ) anywhere in the argument
 *   single-quoted strings containing a quote or backslash — re-emitting those
 *   safely is fiddly and there are few of them, so they are reported instead.
 *
 * The English stays in the call as t()'s second argument, so the page reads
 * correctly with no catalogue, a 404'd catalogue, or JavaScript that loaded
 * before i18n.js. Same guarantee as the markup pass.
 */
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const PAGES = ['index.html', 'checkout.html', 'pay.html', 'wallet.html', 'dashboard.html', 'admin.html'];
const PUBLIC = path.join(import.meta.dirname, '..', 'public');

// Same key derivation as the markup pass, so the same English text in markup
// and in script shares one catalogue entry instead of being translated twice.
function keyFor(text: string): string {
  const slug = text.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 42);
  const hash = crypto.createHash('sha1').update(text).digest('hex').slice(0, 4);
  return `${slug || 'text'}_${hash}`;
}

function translatable(text: string): boolean {
  const t = text.trim();
  if (t.length < 2) return false;
  if (!/[a-zA-Z]/.test(t)) return false;
  if (/^[\d\s.,$%+()–—·•/-]+$/.test(t)) return false;
  if (/^(sk_|pk_|whsec_|acct_|https?:|\/v1\/|\.\/)/.test(t)) return false;
  if (/^[a-z_]+\.[a-z_.]+$/.test(t)) return false;         // invoice.paid
  if (/^[a-z]+(_[a-z]+)+$/.test(t)) return false;          // requires_capture, status enums
  if (/^[a-zA-Z-]+$/.test(t) && /^(usd|eur|gbp|htg|kes|ngn)$/i.test(t)) return false;
  return true;
}

/** A single-quoted literal we can re-emit verbatim. */
function simple(text: string): boolean {
  return !text.includes('\\') && !text.includes("'") && !text.includes('${');
}

const found: Array<{ key: string; text: string }> = [];
const skipped: string[] = [];
const check = process.argv.includes('--check');
let remaining = 0;

for (const page of PAGES) {
  const full = path.join(PUBLIC, page);
  const html = await fs.readFile(full, 'utf8');
  let changes = 0;

  // Only inside <script>, so markup is untouched by this pass.
  const out = html.replace(/<script>([\s\S]*?)<\/script>/g, (whole, body: string) => {
    let js = body;

    const wrap = (text: string) => {
      const key = keyFor(text);
      found.push({ key, text });
      changes++;
      return `i18n.t('${key}', '${text}')`;
    };

    // textContent: 'X'   and   .textContent = 'X'
    js = js.replace(/(\btextContent\s*[:=]\s*)'([^'\\\n]{2,})'/g, (m, lead, text) => {
      if (!translatable(text) || !simple(text)) { if (translatable(text)) skipped.push(text); return m; }
      return lead + wrap(text);
    });

    // toast('X')  and  toast('X', 'bad')
    js = js.replace(/\btoast\(\s*'([^'\\\n]{2,})'/g, (m, text) => {
      if (!translatable(text) || !simple(text)) { if (translatable(text)) skipped.push(text); return m; }
      return `toast(${wrap(text)}`;
    });

    // placeholder / title / aria-label in el() option objects
    js = js.replace(/\b(placeholder|title|ariaLabel)\s*:\s*'([^'\\\n]{2,})'/g, (m, attr, text) => {
      if (!translatable(text) || !simple(text)) return m;
      return `${attr}: ` + wrap(text);
    });

    // Count what this pass cannot safely take: template literals in the same slots.
    for (const _ of js.matchAll(/\btextContent\s*[:=]\s*`[^`]*\$\{/g)) remaining++;

    return `<script>${js}</script>`;
  });

  if (!check && out !== html) await fs.writeFile(full, out);
  console.log(`  ${page.padEnd(16)} ${String(changes).padStart(4)} JS strings wrapped in t()`);
}

/*
 * This pass writes NO catalogue.
 *
 * It used to, and that was wrong: i18n-extract.ts also writes en.json, from
 * the markup, so whichever ran second deleted the other's keys. Running the
 * markup pass after this one dropped all 131 JS keys without a word.
 *
 * So the catalogue has exactly one writer. i18n-extract.ts reads the t() calls
 * back out of the finished HTML — including the ones this pass just wrote —
 * and emits the union. Run order is therefore: i18n-js.ts, then
 * i18n-extract.ts. `npm run i18n` does both in that order.
 */
if (!check) console.log(`\n  ${found.length} calls rewritten — now run i18n-extract.ts to rebuild the catalogues`);

if (remaining) {
  console.log(`\n  ${remaining} template-literal strings still need a human: the sentence is`);
  console.log('  assembled at runtime, so it needs a placeholder, not a key.');
}
if (skipped.length) {
  console.log(`\n  ${skipped.length} skipped (quote or escape in the literal):`);
  for (const s of [...new Set(skipped)].slice(0, 8)) console.log(`    ${JSON.stringify(s)}`);
}
if (check && found.length) {
  console.error(`\n  ${found.length} bare JS strings. Run without --check to wrap them.`);
  process.exit(1);
}
