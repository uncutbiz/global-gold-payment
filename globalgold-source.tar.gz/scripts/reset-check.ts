/**
 * Walks the forgotten-password flow in a real browser, against a real server.
 *
 * Worth doing in a browser rather than with fetch: the thing that was broken
 * was never the API — it worked and was tested. What was broken is that no
 * page ever called it. Only clicking the actual buttons proves that is fixed.
 *
 * The SMS provider is stubbed to print codes rather than send them, so the
 * code is read back out of the database the way a phone would receive it.
 *
 * WARNING: wipes the target database's public schema.
 */
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { chromium } from 'playwright';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'reset-check';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.AUTH_RATE_LIMIT = '10000';
process.env.RESET_RATE_LIMIT = '10000';
process.env.SMS_PROVIDER = 'console';           // print, do not send

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

const PW = 'original-password-123';
const NEW = 'a-brand-new-password-456';
const PHONE = '+15555550142';

await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
await migrate();
const server = createApp().listen(0);
await new Promise((r) => server.once('listening', r));
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

const who = crypto.randomBytes(3).toString('hex');
const email = `reset-${who}@test.local`;
const su = await (await fetch(`${base}/v1/business/signup`, {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    business_name: 'Reset Co', name: 'Owner', email, password: PW,
    country: 'US', business_type: 'company',
  }),
})).json() as any;
await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [su.merchant_id]);

/*
 * The code the SMS would have carried.
 *
 * Codes are stored HASHED, so there is nothing to read out of the database —
 * which is the correct design and mildly inconvenient here. The console
 * provider prints the message it would have sent, so the text is captured off
 * console.log and the six digits pulled out of it. This is exactly what a
 * phone would receive.
 */
const sent: string[] = [];
const realLog = console.log.bind(console);
console.log = (...args: unknown[]) => {
  const line = args.map(String).join(' ');
  if (line.includes('SMS not sent')) sent.push(line);
  else realLog(...args as []);
};
const latestCode = async (): Promise<string> => {
  const line = sent[sent.length - 1] ?? '';
  return (line.match(/\b(\d{6})\b/) || [, ''])[1] as string;
};

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const p = await browser.newPage({ viewport: { width: 900, height: 1100 }, deviceScaleFactor: 2 });
const errs: string[] = [];
p.on('pageerror', (e) => errs.push(e.message));
const step = (s: string) => console.log('  ' + s);

await p.goto(base + '/dashboard');

// ── 1. sign in and add a phone, because reset is impossible without one ─────
await p.fill('#uEmail', email);
await p.fill('#uPassword', PW);
await p.click('#authBtn');
await p.waitForSelector('#app:not([hidden])', { timeout: 10_000 });
step('signed in');

await p.click('#sections button[data-sec="settings"]');
await p.waitForSelector('#phForm', { state: 'visible' });
console.log('  phone status before:', (await p.textContent('#phStatus'))?.trim());
await p.fill('#phPhone', PHONE);
await p.click('#phBtn');
await p.waitForSelector('#phCodeField:not([hidden])', { timeout: 8000 });
await p.fill('#phCode', await latestCode());
await p.click('#phBtn');
await p.waitForSelector('#toast', { timeout: 8000 });
await p.waitForTimeout(900);
console.log('  phone status after: ', (await p.textContent('#phStatus'))?.trim());
await p.screenshot({ path: '/mnt/user-data/outputs/reset-1-phone-verified.png', fullPage: false });

// ── 2. sign out, then walk the reset the way someone locked out would ──────
await p.click('#logout');
await p.waitForSelector('#auth:not([hidden])', { timeout: 8000 });
await p.click('#forgotLink');
await p.waitForSelector('#resetForm:not([hidden])');
step('opened "Forgot your password?"');
await p.screenshot({ path: '/mnt/user-data/outputs/reset-2-step1.png' });

await p.fill('#rsPhone', PHONE);
await p.click('#rsBtn');
await p.waitForSelector('#rsCodeField:not([hidden])', { timeout: 8000 });
console.log('  after step 1:', (await p.textContent('#rsIntro'))?.trim());
await p.screenshot({ path: '/mnt/user-data/outputs/reset-3-code.png' });

// A wrong code first: the form must say so and not advance.
await p.fill('#rsCode', '000000');
await p.click('#rsBtn');
await p.waitForSelector('#rsErr:not([hidden])', { timeout: 8000 });
console.log('  wrong code says:', (await p.textContent('#rsErr'))?.trim());

await p.fill('#rsCode', await latestCode());
await p.click('#rsBtn');
await p.waitForSelector('#rsPwFields:not([hidden])', { timeout: 8000 });
step('code accepted');

await p.fill('#rsNew', NEW);
await p.fill('#rsAgain', 'does-not-match-at-all');
await p.click('#rsBtn');
await p.waitForSelector('#rsErr:not([hidden])', { timeout: 8000 });
console.log('  mismatch says: ', (await p.textContent('#rsErr'))?.trim());

await p.fill('#rsAgain', NEW);
await p.click('#rsBtn');
await p.waitForSelector('#rsOk:not([hidden])', { timeout: 8000 });
console.log('  finished:      ', (await p.textContent('#rsOk'))?.trim());
await p.screenshot({ path: '/mnt/user-data/outputs/reset-4-done.png' });

// ── 3. the new password must work, and the old must not ────────────────────
const tryLogin = async (pw: string) => {
  const r = await fetch(`${base}/v1/business/login`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password: pw }),
  });
  return r.status;
};
console.log('  new password login:', await tryLogin(NEW), '(want 200)');
console.log('  old password login:', await tryLogin(PW), '(want 401)');

console.log(errs.length ? '  PAGE ERRORS: ' + errs.join(' | ') : '  no page errors');
await browser.close();
server.close();
await pool.end();
