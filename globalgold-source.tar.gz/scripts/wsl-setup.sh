#!/usr/bin/env bash
#
#  Installs the deployment toolchain inside Ubuntu (WSL2) and checks it works.
#  Safe to run again — anything already present is skipped.
#
#    bash scripts/wsl-setup.sh
#
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

C_B=$'\033[36m'; C_G=$'\033[32m'; C_Y=$'\033[33m'; C_R=$'\033[31m'; C_O=$'\033[0m'
say()  { printf '%s\n' "${C_B}▸${C_O} $*"; }
good() { printf '%s\n' "${C_G}✓${C_O} $*"; }
warn() { printf '%s\n' "${C_Y}!${C_O} $*"; }
die()  { printf '%s\n' "${C_R}✗ $*${C_O}"; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

printf '\nGlobal Gold Payment — Ubuntu toolchain\n--------------------------------------\n\n'
[ -f package.json ] || die "Run this from the project folder (the one containing package.json)."

say "Updating package lists"
sudo apt-get update -qq
sudo apt-get install -y -qq curl unzip jq make ca-certificates gnupg >/dev/null
good "curl, unzip, jq, make"

# --- Node 22 ----------------------------------------------------------------
if have node && [[ "$(node -v)" =~ ^v(2[2-9]|[3-9][0-9]) ]]; then
  good "Node $(node -v)"
else
  say "Installing Node 22"
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - >/dev/null
  sudo apt-get install -y -qq nodejs >/dev/null
  good "Node $(node -v)"
fi

# --- AWS CLI v2 -------------------------------------------------------------
if have aws; then
  good "AWS CLI $(aws --version 2>&1 | cut -d' ' -f1 | cut -d/ -f2)"
else
  say "Installing AWS CLI v2"
  ARCH="$(uname -m)"; [ "$ARCH" = "aarch64" ] && ARCH="aarch64" || ARCH="x86_64"
  tmp="$(mktemp -d)"
  curl -fsSL "https://awscli.amazonaws.com/awscli-exe-linux-$ARCH.zip" -o "$tmp/aws.zip"
  unzip -q "$tmp/aws.zip" -d "$tmp"
  sudo "$tmp/aws/install" --update >/dev/null
  rm -rf "$tmp"
  good "AWS CLI $(aws --version 2>&1 | cut -d' ' -f1 | cut -d/ -f2)"
fi

# --- Terraform --------------------------------------------------------------
if have terraform; then
  good "Terraform $(terraform version -json | jq -r .terraform_version)"
else
  say "Installing Terraform"
  curl -fsSL https://apt.releases.hashicorp.com/gpg \
    | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
  echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" \
    | sudo tee /etc/apt/sources.list.d/hashicorp.list >/dev/null
  sudo apt-get update -qq
  sudo apt-get install -y -qq terraform >/dev/null
  good "Terraform $(terraform version -json | jq -r .terraform_version)"
fi

# --- Docker (from Docker Desktop's WSL integration) -------------------------
if have docker && docker info >/dev/null 2>&1; then
  good "Docker $(docker version --format '{{.Client.Version}}') reachable"
else
  warn "Docker is not reachable from Ubuntu."
  printf '  Start Docker Desktop on Windows, then turn on:\n'
  printf '    Settings → Resources → WSL integration → Ubuntu\n'
  printf '  Then run this script again.\n'
  DOCKER_MISSING=1
fi

# --- project dependencies ---------------------------------------------------
say "Installing project dependencies"
npm ci --silent
good "node_modules ready"

say "Type-checking"
npm run --silent typecheck && good "Types clean"

# --- what's left ------------------------------------------------------------
printf '\n'
NEXT=1
if [ "${DOCKER_MISSING:-0}" = "1" ]; then
  warn "Finish the Docker step above before deploying."
fi

# Share the Windows AWS sign-in with Ubuntu, so you only sign in once.
WIN_HOME="$(wslpath "$(cmd.exe /c 'echo %USERPROFILE%' 2>/dev/null | tr -d '\r')" 2>/dev/null || echo '')"
if [ -n "$WIN_HOME" ] && [ -d "$WIN_HOME/.aws" ] && [ ! -e "$HOME/.aws" ]; then
  ln -s "$WIN_HOME/.aws" "$HOME/.aws"
  good "Linked ~/.aws to your Windows AWS credentials — no need to sign in twice"
fi

if aws sts get-caller-identity >/dev/null 2>&1; then
  ACCOUNT="$(aws sts get-caller-identity --query Account --output text)"
  good "AWS signed in (account $ACCOUNT)"
else
  printf '%s\n' "${C_Y}Step $NEXT — sign in to AWS${C_O}"
  printf '  In the AWS console: IAM → Users → your user → Security credentials → Create access key\n'
  printf '  (choose "Command Line Interface"). Then run:\n\n'
  printf '    aws configure\n\n'
  printf '  Region: us-east-2.  Output: json.  Your keys stay in ~/.aws on this machine.\n\n'
  NEXT=$((NEXT+1))
fi

printf '%s\n' "${C_Y}Step $NEXT — register the domain and write the config${C_O}"
printf '    bash scripts/register-domain.sh globalgoldpay.com\n\n'
printf '%s\n' "${C_Y}Step $((NEXT+1)) — deploy${C_O}"
printf '    make deploy-dry     # shows every command, changes nothing\n'
printf '    make deploy\n\n'
