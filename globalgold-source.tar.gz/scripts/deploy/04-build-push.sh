#!/usr/bin/env bash
# Step 4 — build the container image and push it to ECR under an immutable tag
# (the git commit). Fargate is x86_64, so the build is pinned to linux/amd64
# even when you build on an Apple Silicon Mac.
. "$(dirname "$0")/lib.sh"

heading "Step 4/8 · Build and push the image"

REGION="$(aws_region)"
TAG="$(image_tag)"
REPO="$(tf_out ecr_repository_url)"
if [ -z "$REPO" ]; then
  [ "$DRY_RUN" = "1" ] || die "No ECR repository yet. Run step 3 (registry) first."
  REPO="<account>.dkr.ecr.$REGION.amazonaws.com/ggp-app"
fi
REGISTRY="${REPO%/*}"
printf '%s' "$TAG" >"$REPO_ROOT/.deploy-image-tag" 2>/dev/null || true
info "tag: $TAG"

# Already pushed? Immutable tags mean a second push of the same tag fails.
if [ "$DRY_RUN" != "1" ] && aws ecr describe-images --region "$REGION" \
     --repository-name "${REPO##*/}" --image-ids "imageTag=$TAG" >/dev/null 2>&1; then
  ok "$REPO:$TAG is already in the registry — skipping the build"
  step_done build-push
  exit 0
fi

cd "$REPO_ROOT" || exit 1

# The image verifies TLS to RDS with Amazon's certificate bundle.
if [ -s certs/rds-global-bundle.pem ]; then
  info "RDS certificate bundle present ($(grep -c 'BEGIN CERTIFICATE' certs/rds-global-bundle.pem) certificates)"
else
  log "Fetching the Amazon RDS certificate bundle"
  run npm run --silent fetch-rds-ca \
    || die "Could not download the RDS certificate bundle. Download https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem into certs/rds-global-bundle.pem by hand, then re-run."
fi

log "Signing in to ECR"
if [ "$DRY_RUN" = "1" ]; then
  info "would run: aws ecr get-login-password | docker login --username AWS --password-stdin $REGISTRY"
else
  # Two separate steps, so the error says which one failed.
  ECR_PASSWORD="$(aws ecr get-login-password --region "$REGION")" \
    || die "aws ecr get-login-password failed. Your credentials need ecr:GetAuthorizationToken."
  printf '%s' "$ECR_PASSWORD" | docker login --username AWS --password-stdin "$REGISTRY" >/dev/null \
    || die "docker login to $REGISTRY failed."
  unset ECR_PASSWORD
  ok "Signed in to $REGISTRY"
fi

log "Building linux/amd64 image"
BUILD=(docker build --platform linux/amd64 --pull
       -t "$REPO:$TAG" -t "$REPO:latest"
       --label "org.opencontainers.image.revision=$TAG"
       --label "org.opencontainers.image.source=https://github.com/$(tfvar github_repository global-gold-payment)"
       .)
run "${BUILD[@]}" || die "Docker build failed."

log "Pushing"
run docker push "$REPO:$TAG" || die "docker push failed. Check the repository policy and your IAM permissions."
run docker push "$REPO:latest" || warn "Could not move the 'latest' tag (immutable tags block this). Harmless: deploys use $TAG."

if [ "$DRY_RUN" != "1" ]; then
  DIGEST="$(aws ecr describe-images --region "$REGION" --repository-name "${REPO##*/}" \
    --image-ids "imageTag=$TAG" --query 'imageDetails[0].imageDigest' --output text 2>/dev/null || echo '?')"
  SIZE="$(docker image inspect "$REPO:$TAG" --format '{{.Size}}' 2>/dev/null || echo 0)"
  ok "Pushed $REPO:$TAG ($(( SIZE / 1000000 )) MB)"
  info "digest $DIGEST"
fi

step_done build-push
