#!/usr/bin/env bash
# Step 7 — create the first staff account for the admin panel.
#
# Terraform generated a bootstrap ADMIN_TOKEN into Secrets Manager. This step uses
# it once to create a real owner login, then reminds you to retire the token.
#
#   ADMIN_EMAIL=you@company.com ADMIN_NAME="Your Name" [ADMIN_PASSWORD=...] make first-admin
. "$(dirname "$0")/lib.sh"

heading "Step 7/8 · First admin account"

URL="$(tf_out app_url)"
SECRET="$(tf_out app_secret_arn)"

if [ "$DRY_RUN" = "1" ]; then
  info "would read ADMIN_TOKEN from Secrets Manager (${SECRET:-the app secret})"
  info "and, if no staff exist yet, create an owner account via POST ${URL:-<app_url>}/v1/admin/staff"
  step_done first-admin
  exit 0
fi
[ -n "$URL" ] && [ -n "$SECRET" ] || die "Terraform outputs are missing. Run step 5 (infrastructure) first."

TOKEN="$(secret_field "$SECRET" ADMIN_TOKEN)"
[ -n "$TOKEN" ] || die "Could not read ADMIN_TOKEN from $SECRET. Check your IAM permissions for secretsmanager:GetSecretValue."

# Already have staff? Then there is nothing to bootstrap.
STAFF_COUNT="$(curl -fsS -H "Authorization: Bearer $TOKEN" "$URL/v1/admin/staff" 2>/dev/null \
  | jq -r '.data | length' 2>/dev/null || echo '')"
if [ -n "$STAFF_COUNT" ] && [ "$STAFF_COUNT" != "null" ] && [ "$STAFF_COUNT" -gt 0 ] 2>/dev/null; then
  ok "$STAFF_COUNT staff account(s) already exist — skipping"
  info "Sign in at $URL/admin"
  step_done first-admin
  exit 0
fi

EMAIL="${ADMIN_EMAIL:-}"
NAME="${ADMIN_NAME:-}"
if [ -z "$EMAIL" ] || [ -z "$NAME" ]; then
  if [ "$ASSUME_YES" = "1" ] || [ ! -t 0 ]; then
    warn "No ADMIN_EMAIL / ADMIN_NAME given, so no staff account was created."
    info "Create it later with: ADMIN_EMAIL=you@company.com ADMIN_NAME=\"Your Name\" make first-admin"
    exit 0
  fi
  printf '%s' "  Your work email: ";     read -r EMAIL </dev/tty
  printf '%s' "  Your name: ";           read -r NAME  </dev/tty
fi

PASSWORD="${ADMIN_PASSWORD:-}"
GENERATED=0
if [ -z "$PASSWORD" ]; then
  PASSWORD="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(18).toString("base64url"))')"
  GENERATED=1
fi

log "Creating the owner account for $EMAIL"
RESPONSE="$(curl -fsS -X POST "$URL/v1/admin/staff" \
  -H "Authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d "$(jq -nc --arg e "$EMAIL" --arg n "$NAME" --arg p "$PASSWORD" \
        '{email:$e,name:$n,password:$p,role:"owner"}')" 2>&1)" \
  || die "Creating the account failed: $RESPONSE"

ok "Owner account created: $(printf '%s' "$RESPONSE" | jq -r '.email // empty')"
if [ "$GENERATED" = "1" ]; then
  printf '\n  %sSign in at %s/admin%s\n' "$C_BLD" "$URL" "$C_OFF"
  printf '  email:    %s\n' "$EMAIL"
  printf '  password: %s%s%s\n' "$C_BLD" "$PASSWORD" "$C_OFF"
  printf '  %sThis password is shown once. Save it in your password manager now.%s\n\n' "$C_YEL" "$C_OFF"
else
  info "Sign in at $URL/admin with the password you supplied."
fi

warn "Retire the bootstrap ADMIN_TOKEN once you can sign in: it is a full-owner API key."
info "aws secretsmanager put-secret-value --secret-id $SECRET ... (rotate ADMIN_TOKEN), or remove it from the task definition."

step_done first-admin
