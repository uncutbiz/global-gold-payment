#!/usr/bin/env bash
# Step 3 — create the image registry first. ECS cannot start a service whose image
# does not exist yet, so ECR (and the KMS key it encrypts with) is applied on its own.
. "$(dirname "$0")/lib.sh"

heading "Step 3/8 · Image registry (ECR)"

APPLY=(apply -input=false -target=aws_ecr_repository.app -target=aws_ecr_lifecycle_policy.app)
[ "$ASSUME_YES" = "1" ] && APPLY+=(-auto-approve)

EXISTING="$(tf_out ecr_repository_url)"
if [ -n "$EXISTING" ]; then
  ok "Registry already exists: $EXISTING"
else
  tf "${APPLY[@]}"
fi

REPO="$(tf_out ecr_repository_url)"
if [ "$DRY_RUN" = "1" ] && [ -z "$REPO" ]; then
  info "would create an ECR repository and print its URL"
else
  [ -n "$REPO" ] || die "Terraform did not report ecr_repository_url. Check the apply output above."
  ok "Registry: $REPO"
fi

step_done registry
