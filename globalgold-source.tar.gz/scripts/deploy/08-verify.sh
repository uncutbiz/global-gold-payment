#!/usr/bin/env bash
# Step 8 — prove the deployment actually works: DNS, TLS, health, every page,
# then the full smoke test (signup, KYC, card payment, wallet transfer, refund,
# admin review, settlement) against the live site.
. "$(dirname "$0")/lib.sh"

heading "Step 8/8 · Verify the live deployment"

REGION="$(aws_region)"
URL="$(tf_out app_url)"
SECRET="$(tf_out app_secret_arn)"
CLUSTER="$(tf_out ecs_cluster)"
SERVICE="$(tf_out ecs_service)"

if [ "$DRY_RUN" = "1" ]; then
  info "would resolve DNS for ${URL:-the app domain}, check the certificate, /health, every page,"
  info "the 404 and 401 responses, the ECS running count and load-balancer target health,"
  info "then run the end-to-end smoke test (signup → KYC → card payment → wallet transfer → refund → settlement)"
  step_done verify
  exit 0
fi
[ -n "$URL" ] || die "No app_url output. Run step 5 (infrastructure) first."
HOST="${URL#*://}"; HOST="${HOST%%/*}"

fail=0
check() { # check <name> <expected-status> <path>
  local code
  # curl prints 000 itself when it cannot connect, so do not append another.
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 "$URL$3" 2>/dev/null)"
  code="${code:-000}"
  if [ "$code" = "$2" ]; then printf '  %s %-34s %s\n' "${C_GRN}✓${C_OFF}" "$1" "$code"
  else printf '  %s %-34s %s (expected %s)\n' "${C_RED}✗${C_OFF}" "$1" "$code" "$2"; fail=$((fail+1)); fi
}

log "DNS"
HOSTNAME_ONLY="${HOST%%:*}"
if command -v dig >/dev/null 2>&1; then
  RESOLVED="$(dig +short "$HOSTNAME_ONLY" | tr '\n' ' ')"
else
  RESOLVED="$(getent hosts "$HOSTNAME_ONLY" 2>/dev/null | awk '{print $1}' | tr '\n' ' ')"
fi
if [ -n "$RESOLVED" ]; then ok "$HOSTNAME_ONLY → $RESOLVED"
else warn "$HOSTNAME_ONLY does not resolve yet. Route 53 records can take a few minutes; re-run: make verify"; fi

WAIT_SECONDS="${VERIFY_WAIT_SECONDS:-300}"
if [ "$WAIT_SECONDS" -ge 120 ]; then log "Waiting for the app to answer (up to $((WAIT_SECONDS / 60)) minutes)"
else log "Waiting for the app to answer (up to ${WAIT_SECONDS}s)"; fi
waited=0
while :; do
  [ "$(curl -sS -o /dev/null -w '%{http_code}' --max-time 10 "$URL/health" 2>/dev/null)" = "200" ] && { ok "Healthy after ${waited}s"; break; }
  [ "$waited" -ge "$WAIT_SECONDS" ] && { warn "Still not answering after ${waited}s — continuing so you can see which checks fail."; break; }
  sleep 5; waited=$((waited + 5))
  [ $((waited % 60)) = 0 ] && info "still waiting… ${waited}s"
done

log "TLS"
TLS="$(curl -sS -o /dev/null -w '%{http_version} %{ssl_verify_result}' --max-time 20 "$URL/health" 2>/dev/null || echo '? 1')"
case "$TLS" in
  *" 0") ok "Certificate valid (HTTP/${TLS%% *})" ;;
  *) warn "TLS verification returned: $TLS" ; fail=$((fail+1)) ;;
esac
REDIRECT="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 "http://$HOST/" 2>/dev/null || echo 000)"
case "$REDIRECT" in 301|302|307|308) ok "HTTP redirects to HTTPS ($REDIRECT)" ;; *) warn "http:// returned $REDIRECT, expected a redirect" ;; esac

log "Endpoints"
check "health"              200 "/health"
check "home page"           200 "/"
check "customer wallet"     200 "/wallet"
check "business dashboard"  200 "/dashboard"
check "admin panel"         200 "/admin"
check "favicon"             200 "/favicon.svg"
check "stylesheet"          200 "/static/theme.css"
check "unknown endpoint 404" 404 "/v1/does-not-exist"
check "admin API needs auth" 401 "/v1/admin/overview"

log "ECS service"
RUNNING="$(aws ecs describe-services --region "$REGION" --cluster "$CLUSTER" --services "$SERVICE" \
  --query 'services[0].[runningCount,desiredCount]' --output text 2>/dev/null | tr '\t' '/')"
[ -n "$RUNNING" ] && ok "containers running/desired: $RUNNING"

log "Load balancer targets"
TG="$(aws elbv2 describe-target-groups --region "$REGION" \
  --query "TargetGroups[?contains(TargetGroupName,'ggp')].TargetGroupArn | [0]" --output text 2>/dev/null || echo '')"
if [ -n "$TG" ] && [ "$TG" != "None" ]; then
  HEALTHY="$(aws elbv2 describe-target-health --region "$REGION" --target-group-arn "$TG" \
    --query "length(TargetHealthDescriptions[?TargetHealth.State=='healthy'])" --output text 2>/dev/null || echo '?')"
  ok "healthy targets: $HEALTHY"
fi

# --- the smoke test ---------------------------------------------------------
if [ "${SKIP_SMOKE:-0}" = "1" ]; then
  warn "SKIP_SMOKE=1: not running the end-to-end smoke test."
else
  TOKEN="${ADMIN_TOKEN:-}"
  [ -n "$TOKEN" ] || [ -z "$SECRET" ] || TOKEN="$(secret_field "$SECRET" ADMIN_TOKEN)"
  if [ -z "$TOKEN" ]; then
    warn "No ADMIN_TOKEN available, so the end-to-end smoke test was skipped."
  else
    heading "End-to-end smoke test against $URL"
    cd "$REPO_ROOT" || exit 1
    [ -d node_modules ] || run npm ci --silent
    if BASE_URL="$URL" ADMIN_TOKEN="$TOKEN" SMOKE_SETTLE="${SMOKE_SETTLE:-1}" npm run --silent smoke; then
      ok "Smoke test passed"
    else
      fail=$((fail+1))
      warn "Smoke test failed. Logs: aws logs tail $(tf_out log_group) --region $REGION --since 15m"
    fi
  fi
fi

printf '\n'
if [ "$fail" -gt 0 ]; then
  die "$fail check(s) failed. The site is deployed but not fully healthy — see above."
fi
ok "Everything checks out."
step_done verify
