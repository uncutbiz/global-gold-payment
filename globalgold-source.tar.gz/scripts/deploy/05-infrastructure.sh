#!/usr/bin/env bash
# Step 5 — apply everything else: network, database, secrets, load balancer,
# firewall, ECS service, alarms and the GitHub deploy role.
# First run takes 15–25 minutes; the certificate and the Multi-AZ database are the slow parts.
. "$(dirname "$0")/lib.sh"

heading "Step 5/8 · Infrastructure (network, database, load balancer, ECS)"

TAG="$(cat "$REPO_ROOT/.deploy-image-tag" 2>/dev/null || image_tag)"
info "image tag: $TAG"

PLAN="$TF_DIR/tfplan"
tf plan -input=false -out=tfplan -var "image_tag=$TAG"

if [ "$DRY_RUN" != "1" ]; then
  SUMMARY="$( cd "$TF_DIR" && terraform show -json tfplan \
    | jq -r '[.resource_changes[]?|select(.change.actions!=["no-op"])]
             | "\(map(select(.change.actions==["create"]))|length) to add, \(map(select(.change.actions|index("update")))|length) to change, \(map(select(.change.actions|index("delete")))|length) to destroy"' )"
  info "$SUMMARY"
  DESTROYS="$( cd "$TF_DIR" && terraform show -json tfplan \
    | jq -r '[.resource_changes[]?|select(.change.actions|index("delete"))|.address]|join(", ")' )"
  if [ -n "$DESTROYS" ] && [ "$DESTROYS" != "" ]; then
    warn "This plan destroys: $DESTROYS"
    confirm "Continue anyway?" || { warn "Stopped. Review the plan with: make plan"; exit 3; }
  fi
  if ! confirm "Apply this plan?"; then warn "Stopped. Nothing was changed."; exit 3; fi
fi

tf apply -input=false tfplan
[ "$DRY_RUN" = "1" ] || rm -f "$PLAN"

if [ "$DRY_RUN" != "1" ]; then
  printf '\n'
  ok "Infrastructure ready"
  printf '  %-26s %s\n' "URL"        "$(tf_out app_url)"
  printf '  %-26s %s\n' "ECS cluster" "$(tf_out ecs_cluster)"
  printf '  %-26s %s\n' "ECS service" "$(tf_out ecs_service)"
  printf '  %-26s %s\n' "Database"    "$(tf_out db_endpoint)"
  printf '  %-26s %s\n' "Secret"      "$(tf_out app_secret_arn)"
  [ -n "$(tfvar alarm_email)" ] && info "Confirm the SNS subscription email to receive alarms."
fi

step_done infrastructure
