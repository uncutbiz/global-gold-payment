#!/usr/bin/env bash
# Step 6 — roll the new image out to the running service.
#
# On a first deploy Terraform already started the service on this image, so this
# step notices that and does nothing. On later deploys (code changes only) this is
# the whole deploy: register a task-definition revision, update the service, wait.
# ECS replaces containers one batch at a time and rolls back if the new ones fail
# their health check, so a bad release never takes the site down.
. "$(dirname "$0")/lib.sh"

heading "Step 6/8 · Release to ECS"

REGION="$(aws_region)"
TAG="$(cat "$REPO_ROOT/.deploy-image-tag" 2>/dev/null || image_tag)"
REPO="$(tf_out ecr_repository_url)"
CLUSTER="$(tf_out ecs_cluster)"
SERVICE="$(tf_out ecs_service)"
FAMILY="$(tf_out task_definition_family)"

if [ "$DRY_RUN" = "1" ]; then
  info "would register a task-definition revision of ${FAMILY:-<family>} pointing at ${REPO:-<repo>}:$TAG,"
  info "update service ${SERVICE:-<service>} on cluster ${CLUSTER:-<cluster>}, and wait for it to stabilise"
  step_done release
  exit 0
fi
[ -n "$CLUSTER" ] && [ -n "$SERVICE" ] && [ -n "$FAMILY" ] || die "Terraform outputs are missing. Run step 5 (infrastructure) first."

IMAGE="$REPO:$TAG"
CURRENT="$(aws ecs describe-services --region "$REGION" --cluster "$CLUSTER" --services "$SERVICE" \
  --query 'services[0].taskDefinition' --output text 2>/dev/null || echo '')"
CURRENT_IMAGE="$(aws ecs describe-task-definition --region "$REGION" --task-definition "$CURRENT" \
  --query 'taskDefinition.containerDefinitions[0].image' --output text 2>/dev/null || echo '')"

if [ "$CURRENT_IMAGE" = "$IMAGE" ]; then
  ok "The service already runs $IMAGE"
  log "Waiting for it to be stable"
  run aws ecs wait services-stable --region "$REGION" --cluster "$CLUSTER" --services "$SERVICE"
  ok "Service stable"
  step_done release
  exit 0
fi

info "current: ${CURRENT_IMAGE:-none}"
info "new:     $IMAGE"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

log "Registering a new task-definition revision"
aws ecs describe-task-definition --region "$REGION" --task-definition "$FAMILY" \
  --query taskDefinition --output json >"$WORK/taskdef.json"
jq --arg img "$IMAGE" '
  .containerDefinitions[0].image = $img
  | del(.taskDefinitionArn, .revision, .status, .requiresAttributes, .compatibilities, .registeredAt, .registeredBy)
' "$WORK/taskdef.json" >"$WORK/new.json"

ARN="$(aws ecs register-task-definition --region "$REGION" \
  --cli-input-json "file://$WORK/new.json" \
  --query taskDefinition.taskDefinitionArn --output text)" || die "register-task-definition failed."
ok "Registered ${ARN##*/}"

log "Updating the service (rolling deploy)"
run aws ecs update-service --region "$REGION" --cluster "$CLUSTER" --service "$SERVICE" \
  --task-definition "$ARN" --output text --query 'service.serviceName'

log "Waiting for the deployment to finish (up to 10 minutes)"
if aws ecs wait services-stable --region "$REGION" --cluster "$CLUSTER" --services "$SERVICE"; then
  ok "Deployment complete and stable"
else
  warn "The service did not stabilise. Recent events:"
  aws ecs describe-services --region "$REGION" --cluster "$CLUSTER" --services "$SERVICE" \
    --query 'services[0].events[0:8].message' --output text | tr '\t' '\n' | sed 's/^/    /'
  warn "Container logs: aws logs tail $(tf_out log_group) --region $REGION --since 15m"
  die "Release failed. ECS keeps the previous version running; fix the cause and re-run: make release"
fi

step_done release
