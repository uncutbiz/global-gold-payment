#!/usr/bin/env bash
# Step 2 — initialise Terraform (downloads the AWS provider, connects the backend,
# migrating any local state into S3 the first time).
. "$(dirname "$0")/lib.sh"

heading "Step 2/8 · terraform init"

INIT_ARGS=(-input=false)
if [ -f "$TF_DIR/terraform.tfstate" ] && [ -f "$TF_DIR/backend.tf" ]; then
  log "Local state found; migrating it into the S3 backend"
  INIT_ARGS+=(-migrate-state -force-copy)
else
  INIT_ARGS+=(-reconfigure)
fi

tf init "${INIT_ARGS[@]}"
tf fmt -check -recursive || warn "Terraform files are not canonically formatted (run: terraform fmt -recursive). Continuing."
tf validate

ok "Terraform initialised and the configuration is valid"
step_done terraform-init
