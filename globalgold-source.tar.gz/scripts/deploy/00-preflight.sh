#!/usr/bin/env bash
# Step 0 — preflight. Checks tools, AWS access, configuration and the build,
# so the deploy fails here (in seconds) rather than half-way through (in minutes).
. "$(dirname "$0")/lib.sh"

heading "Step 0/8 · Preflight checks"

need aws       "Install the AWS CLI v2: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
need terraform "Install Terraform 1.6+ (or OpenTofu and alias terraform=tofu): https://developer.hashicorp.com/terraform/install"
need docker    "Install Docker: https://docs.docker.com/get-docker/"
need node      "Install Node 22+: https://nodejs.org"
need jq        "Install jq: https://jqlang.github.io/jq/download/"
ok "aws $(aws --version 2>&1 | awk '{print $1}' | cut -d/ -f2), terraform $(terraform version -json 2>/dev/null | jq -r .terraform_version 2>/dev/null || echo '?'), docker $(docker version --format '{{.Client.Version}}' 2>/dev/null || echo '?'), node $(node -v)"

case "$(node -v)" in v2[2-9]*|v[3-9][0-9]*) ;; *) die "Node 22 or newer is required (found $(node -v))." ;; esac
docker info >/dev/null 2>&1 || die "The Docker daemon is not running. Start Docker Desktop (or dockerd) and try again."

# --- AWS identity -----------------------------------------------------------
REGION="$(aws_region)"
IDENTITY="$(aws sts get-caller-identity --region "$REGION" --output json 2>/dev/null)" \
  || die "AWS is not signed in. Run 'aws configure' (or 'aws sso login') and make sure the credentials can create infrastructure."
ACCOUNT="$(printf '%s' "$IDENTITY" | jq -r .Account)"
WHO="$(printf '%s' "$IDENTITY" | jq -r .Arn)"
ok "AWS account $ACCOUNT in $REGION"
info "as $WHO"

# --- configuration ----------------------------------------------------------
[ -f "$TFVARS" ] || die "$TFVARS is missing. Run: cp infra/aws/terraform.tfvars.example infra/aws/terraform.tfvars, then set domain_name, route53_zone_id, alarm_email."

DOMAIN="$(tfvar domain_name)"
ZONE="$(tfvar route53_zone_id)"
ENVIRONMENT="$(tfvar environment staging)"
[ -n "$DOMAIN" ] && [ "$DOMAIN" != "pay.example.com" ] || die "Set a real domain_name in infra/aws/terraform.tfvars (it is still the example value)."
[ -n "$ZONE" ] && [ "$ZONE" != "Z0123456789ABCDEFGHIJ" ] || die "Set your real route53_zone_id in infra/aws/terraform.tfvars."

ZONE_NAME="$(aws route53 get-hosted-zone --id "$ZONE" --query 'HostedZone.Name' --output text 2>/dev/null | sed 's/\.$//')" \
  || die "Route 53 hosted zone $ZONE was not found in this account. Check route53_zone_id."
case "$DOMAIN" in
  *".$ZONE_NAME"|"$ZONE_NAME") ok "$DOMAIN belongs to hosted zone $ZONE_NAME" ;;
  *) die "domain_name ($DOMAIN) is not inside hosted zone $ZONE_NAME ($ZONE). The certificate and DNS record would fail." ;;
esac

ALARM_EMAIL="$(tfvar alarm_email)"
[ -n "$ALARM_EMAIL" ] || warn "alarm_email is empty: you will get no CloudWatch alarm notifications."
if [ "$ENVIRONMENT" = "production" ]; then
  ok "environment = production (deletion protection and final snapshots on)"
else
  warn "environment = $ENVIRONMENT. Set environment = \"production\" in terraform.tfvars before real traffic."
fi

# --- service quotas that commonly block a first deploy ----------------------
EIPS="$(aws ec2 describe-addresses --region "$REGION" --query 'length(Addresses)' --output text 2>/dev/null || echo 0)"
info "Elastic IPs in use: $EIPS (a NAT gateway needs one; the default account limit is 5)"

# --- the code itself --------------------------------------------------------
cd "$REPO_ROOT" || exit 1
if [ "${SKIP_TESTS:-0}" = "1" ]; then
  warn "SKIP_TESTS=1: not type-checking or testing before deploy."
else
  log "Type-checking"
  run npm run --silent typecheck || die "TypeScript errors. Fix them, or set SKIP_TESTS=1 to deploy anyway."
  ok "Types clean"
  if [ -n "${TEST_DATABASE_URL:-}" ]; then
    log "Running the test suite against TEST_DATABASE_URL"
    run npm test || die "Tests failed. Fix them, or set SKIP_TESTS=1 to deploy anyway."
    ok "Tests passed"
  else
    info "TEST_DATABASE_URL is not set, so the test suite is skipped. CI runs it on every push."
  fi
fi

printf '\n'
ok "Preflight passed. Deploying ${C_BLD}$ENVIRONMENT${C_OFF} to ${C_BLD}https://$DOMAIN${C_OFF} in account $ACCOUNT ($REGION)."
step_done preflight
