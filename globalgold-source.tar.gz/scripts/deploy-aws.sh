#!/usr/bin/env bash
#
#  Global Gold Payment — one-command AWS deployment
#  ────────────────────────────────────────────────
#  Runs every step in order, stops at the first failure, and can be re-run
#  safely: finished steps are skipped, so a re-run picks up where it stopped.
#
#    ./scripts/deploy-aws.sh                 # full deploy (asks before it changes AWS)
#    ./scripts/deploy-aws.sh --dry-run       # print every command, change nothing
#    ./scripts/deploy-aws.sh --yes           # no prompts (for CI)
#    ./scripts/deploy-aws.sh --only release  # ship a new image to the running service
#    ./scripts/deploy-aws.sh --from build-push
#    ./scripts/deploy-aws.sh --until first-admin   # stop before the live checks
#    ./scripts/deploy-aws.sh --list
#
#  Every run is logged to .deploy-logs/.
#
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/deploy/lib.sh"

STEPS=(preflight state-backend terraform-init registry build-push infrastructure release first-admin verify)
SCRIPT_FOR() {
  case "$1" in
    preflight)      printf '00-preflight.sh' ;;
    state-backend)  printf '01-state-backend.sh' ;;
    terraform-init) printf '02-terraform-init.sh' ;;
    registry)       printf '03-registry.sh' ;;
    build-push)     printf '04-build-push.sh' ;;
    infrastructure) printf '05-infrastructure.sh' ;;
    release)        printf '06-release.sh' ;;
    first-admin)    printf '07-first-admin.sh' ;;
    verify)         printf '08-verify.sh' ;;
    *)              return 1 ;;
  esac
}
DESCRIBE() {
  case "$1" in
    preflight)      printf 'check tools, AWS access, config, types and tests' ;;
    state-backend)  printf 'encrypted S3 bucket for Terraform state' ;;
    terraform-init) printf 'download the provider, connect the backend, validate' ;;
    registry)       printf 'create the ECR image registry' ;;
    build-push)     printf 'build the linux/amd64 image and push it' ;;
    infrastructure) printf 'network, database, secrets, load balancer, WAF, ECS, alarms' ;;
    release)        printf 'roll the image out to the running service' ;;
    first-admin)    printf 'create the first admin-panel login' ;;
    verify)         printf 'DNS, TLS, pages, and the end-to-end smoke test' ;;
  esac
}

FROM=''; ONLY=''; UNTIL=''; FRESH=0
usage() { sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run|-n)  DRY_RUN=1 ;;
    --yes|-y)      ASSUME_YES=1 ;;
    --from)        FROM="${2:-}"; shift ;;
    --only)        ONLY="${2:-}"; shift ;;
    --until)       UNTIL="${2:-}"; shift ;;
    --fresh)       FRESH=1 ;;
    --skip-tests)  export SKIP_TESTS=1 ;;
    --local-state) export SKIP_REMOTE_STATE=1 ;;
    --tag)         export IMAGE_TAG="${2:-}"; shift ;;
    --list)        for s in "${STEPS[@]}"; do printf '  %-16s %s\n' "$s" "$(DESCRIBE "$s")"; done; exit 0 ;;
    -h|--help)     usage; exit 0 ;;
    *)             printf 'Unknown option: %s\n\n' "$1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
export DRY_RUN ASSUME_YES

for s in ${FROM:-} ${ONLY:-} ${UNTIL:-}; do SCRIPT_FOR "$s" >/dev/null || die "Unknown step '$s'. Run --list to see them."; done
[ "$FRESH" = "1" ] && rm -f "$STATE_FILE"

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/deploy-$(date -u '+%Y%m%dT%H%M%SZ').log"
printf 'Logging to %s\n' "${LOG_FILE#"$REPO_ROOT"/}"

{
printf '\n%s\n' "${C_BLD}Global Gold Payment → AWS${C_OFF}"
printf '%s\n' "${C_DIM}$(date -u '+%Y-%m-%d %H:%M:%SZ') · environment $(tfvar environment staging) · region $(aws_region)${C_OFF}"
[ "$DRY_RUN" = "1" ] && printf '%s\n' "${C_YEL}DRY RUN — nothing will be created or changed.${C_OFF}"

# Never leave a card processor's secrets in a shell history file by accident.
umask 077

started=0; skipped=0; TIMINGS=()
overall_start=$(date +%s)

for step in "${STEPS[@]}"; do
  if [ -n "$ONLY" ] && [ "$step" != "$ONLY" ]; then continue; fi
  if [ -z "$ONLY" ] && [ -n "$FROM" ] && [ "$started" = "0" ]; then
    if [ "$step" = "$FROM" ]; then started=1; else
      printf '%s\n' "  ${C_DIM}skip $step (before --from $FROM)${C_OFF}"; continue
    fi
  fi
  # Only the genuinely one-time steps are memoised. Everything else is idempotent
  # and re-runs cheaply, so a second deploy still picks up config and code changes.
  case "$step" in
    state-backend|terraform-init|registry)
      if [ -z "$ONLY" ] && [ -z "$FROM" ] && step_is_done "$step"; then
        printf '%s\n' "  ${C_GRN}✓${C_OFF} ${C_DIM}$step already done (--fresh to redo)${C_OFF}"
        skipped=$((skipped+1)); continue
      fi ;;
  esac

  t0=$(date +%s)
  rc=0
  bash "$HERE/deploy/$(SCRIPT_FOR "$step")" || rc=$?
  if [ "$rc" = "3" ]; then
    printf '\n%s\n' "${C_YEL}Stopped at step '$step' at your request. Nothing further was changed.${C_OFF}"
    printf '%s\n' "  Continue later with: ./scripts/deploy-aws.sh --from $step"
    exit 3
  fi
  if [ "$rc" != "0" ]; then
    printf '\n%s\n' "${C_RED}✗ Step '$step' failed.${C_OFF}" >&2
    printf '%s\n' "  Fix the cause, then continue with: ./scripts/deploy-aws.sh --from $step" >&2
    printf '%s\n' "  Full log: ${LOG_FILE#"$REPO_ROOT"/}" >&2
    exit 1
  fi
  TIMINGS+=("$(printf '  %-16s %ss' "$step" "$(( $(date +%s) - t0 ))")")
  if [ -n "$UNTIL" ] && [ "$step" = "$UNTIL" ]; then
    printf '%s\n' "  ${C_DIM}stopping after $step (--until)${C_OFF}"
    break
  fi
done

printf '\n%s\n' "${C_BLD}── Summary ${C_OFF}"
for t in "${TIMINGS[@]:-}"; do [ -n "$t" ] && printf '%s\n' "$t"; done
[ "$skipped" -gt 0 ] && printf '  %s\n' "${C_DIM}$skipped step(s) were already done${C_OFF}"
printf '  %-16s %ss\n' "total" "$(( $(date +%s) - overall_start ))"

URL="$(tf_out app_url)"
if [ -n "$URL" ] && [ -z "$ONLY" ]; then
  printf '\n%s\n\n' "${C_GRN}${C_BLD}Live: $URL${C_OFF}"
  printf '  %-22s %s\n' "Customer wallet"    "$URL/wallet"
  printf '  %-22s %s\n' "Business dashboard" "$URL/dashboard"
  printf '  %-22s %s\n' "Admin panel"        "$URL/admin"
  printf '\n%s\n' "Next:"
  printf '  1. Confirm the CloudWatch alarm email from AWS SNS.\n'
  printf '  2. Set the GitHub Actions variables so pushes to main deploy themselves (DEPLOY.md step 4).\n'
  printf '  3. Work through the production checklist in DEPLOY.md before real money: sponsor bank, PCI DSS, licensing.\n'
  printf '\n%s\n' "${C_YEL}This deployment is still test mode: the card network is simulated and no real money moves.${C_OFF}"
fi
} 2>&1 | tee "$LOG_FILE"

exit "${PIPESTATUS[0]}"
