/**
 * Cards, clicked through in a real browser.
 *
 * The API is covered by test/cards.test.ts. This exists because an API that
 * works and a page nobody can use is exactly the failure the password reset
 * had — the endpoints were fine and no screen ever called them.
 *
 * WARNING: wipes the target database's public schema.
 */
import crypto from 'node:crypto';
import type { AddressInfo } from 'node:net';
import { chromium } from 'playwright';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'cards-check';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'full';
process.env.AUTH_RATE_LIMIT = '10000';
process.env.CARD_RATE_LIMIT = '10000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { acct, postJournal } = await import('../src/ledger/ledger.js');
const { authorize } = await import('../src/cards/authorize.js');

await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
await migrate();
const server = createApp().listen(0);
await new Promise((r) => server.once('listening', r));
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

const PW = 'a-long-password-123';
const who = crypto.randomBytes(3).toString('hex');
const email = `cards-${who}@test.local`;

const su = await (await fetch(`${base}/v1/wallet/signup`, {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ email, name: 'Card Holder', password: PW, country: 'US' }),
})).json() as any;

// Approve identity and fund the wallet, so cards have something to spend.
await pool.query(`UPDATE users SET kyc_status='approved' WHERE id=$1`, [su.user.id]);
{
  const c = await pool.connect();
  await c.query('BEGIN');
  await postJournal(c as any, 'usd', { type: 'test_fund', id: su.user.id }, 'test funding', [
    { account: acct.bankCash, debit: 250_00 },
    { account: acct.wallet(su.user.id), credit: 250_00 },
  ]);
  await c.query('COMMIT'); c.release();
}

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const p = await browser.newPage({ viewport: { width: 900, height: 1300 }, deviceScaleFactor: 2 });
const errs: string[] = [];
p.on('pageerror', (e) => errs.push(e.message));

await p.goto(base + '/wallet');
await p.fill('#email', email);
await p.fill('#password', PW);
await p.click('#authForm button[type=submit]');
await p.waitForSelector('[data-panel="send"]', { timeout: 10_000 });
console.log('  signed in');

await p.click('[role=tab][data-tab="cards"]');
await p.waitForSelector('#issuedCards', { state: 'visible' });
console.log('  cards tab:', (await p.textContent('#issuedCards'))?.trim().slice(0, 60));

// ── a virtual card with limits ─────────────────────────────────────────────
await p.click('#vcForm >> xpath=ancestor::details >> summary');
await p.fill('#vcNick', 'Subscriptions');
await p.fill('#vcPerAuth', '25');
await p.fill('#vcDaily', '50');
await p.click('#vcForm button[type=submit]');
await p.waitForSelector('#issuedCards .panel', { timeout: 8000 });
await p.waitForTimeout(500);
console.log('  virtual card:', (await p.textContent('#issuedCards .panel'))?.replace(/\s+/g, ' ').trim().slice(0, 90));

// Reveal shows a number in the non-routable test range.
await p.getByRole('button', { name: 'Show number' }).first().click();
await p.waitForSelector('#toast', { timeout: 8000 });
const shown = (await p.textContent('#toast'))?.trim() ?? '';
console.log('  reveal:', shown);
if (!shown.replace(/\s/g, '').startsWith('400000')) throw new Error('revealed PAN is not a test BIN');

// ── a physical card ────────────────────────────────────────────────────────
await p.click('#pcForm >> xpath=ancestor::details >> summary');
await p.fill('#pcNick', 'Everyday');
await p.fill('#pcName', 'Card Holder');
await p.fill('#pcLine1', '1 Test Street');
await p.fill('#pcCity', 'Columbus');
await p.fill('#pcRegion', 'OH');
await p.fill('#pcPostal', '43004');
await p.click('#pcForm button[type=submit]');
await p.waitForSelector('#toast:has-text("ordered")', { timeout: 8000 });
await p.waitForTimeout(600);
const cards = await (await fetch(`${base}/v1/cards`, { headers: { authorization: `Bearer ${su.token}` } })).json() as any;
const physical = cards.data.find((c: any) => c.kind === 'physical');
console.log('  physical card:', physical.status, '· number issued:', physical.last4 !== null);

// Produce it, then the cardholder activates it from the page.
const { producePhysicalCard } = await import('../src/cards/cards.js');
await producePhysicalCard(physical.id);
await p.reload();
await p.click('[role=tab][data-tab="cards"]');
await p.getByRole('button', { name: 'Activate' }).first().click();
await p.waitForTimeout(700);
console.log('  after activate:', (await p.locator('#issuedCards .panel').nth(0).textContent())?.replace(/\s+/g, ' ').slice(0, 80));

// ── spend it, and be declined ──────────────────────────────────────────────
const virtual = cards.data.find((c: any) => c.kind === 'virtual');
const a1 = await authorize({ cardId: virtual.id, amount: 20_00, currency: 'usd', merchantName: 'Coffee Shop' });
const a2 = await authorize({ cardId: virtual.id, amount: 30_00, currency: 'usd', merchantName: 'Electronics' });
console.log(`  $20 at Coffee Shop → ${a1.status}`);
console.log(`  $30 over the $25 limit → ${a2.status} (${a2.decline_reason})`);

await p.reload();
await p.click('[role=tab][data-tab="cards"]');
await p.waitForSelector('#issuedActivity li', { timeout: 8000 });
const activity = await p.locator('#issuedActivity li').allTextContents();
console.log('  activity shown to the cardholder:');
for (const line of activity.slice(0, 3)) console.log('    ·', line.replace(/\s+/g, ' ').trim());

await p.screenshot({ path: '/mnt/user-data/outputs/cards-wallet.png', fullPage: true });
const over = await p.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
console.log('  horizontal overflow:', over > 1 ? `${over}px — FIX` : 'none');
console.log(errs.length ? '  PAGE ERRORS: ' + errs.join(' | ') : '  no page errors');

await browser.close();
server.close();
await pool.end();
