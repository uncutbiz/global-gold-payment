#!/usr/bin/env bash
#
#  Global Gold Payment — the whole setup, one command.
#
#      bash scripts/setup.sh
#
#  It walks seven phases in order and stops at the first one that needs you.
#  When it stops it prints exactly what to do. Run the same command again and it
#  picks up from there — finished phases are skipped, and every phase is safe to
#  repeat.
#
#      bash scripts/setup.sh --status       what is done, what is left
#      bash scripts/setup.sh --dry-run      print everything, change nothing
#      bash scripts/setup.sh --yes          no prompts (for an unattended run)
#      bash scripts/setup.sh --from deploy  start at a named phase
#
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/deploy/lib.sh"

PHASES=(tools aws-signin domain square deploy secrets verify)
DESCRIBE() {
  case "$1" in
    tools)      printf 'command-line tools: aws, terraform, docker, node, jq' ;;
    aws-signin) printf 'an AWS account this machine can use' ;;
    domain)     printf 'a domain in Route 53, and the config written from it' ;;
    square)     printf 'a Square application: app id, secret, webhook key' ;;
    deploy)     printf 'build and deploy the whole stack to AWS' ;;
    secrets)    printf 'put the Square keys into AWS Secrets Manager' ;;
    verify)     printf 'check the live site and run the end-to-end test' ;;
  esac
}

FROM=''; ONLY=''; STATUS=0
usage() { sed -n '2,18p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; }
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run|-n) DRY_RUN=1 ;;
    --yes|-y)     ASSUME_YES=1 ;;
    --from)       FROM="${2:-}"; shift ;;
    --only)       ONLY="${2:-}"; shift ;;
    --status)     STATUS=1 ;;
    -h|--help)    usage; exit 0 ;;
    *) printf 'Unknown option: %s\n\n' "$1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
export DRY_RUN ASSUME_YES

ENVFILE="$REPO_ROOT/.env"

# ---------------------------------------------------------------- what's done

have_tools()   { for c in aws terraform docker node jq; do command -v "$c" >/dev/null || return 1; done; }
have_aws()     { aws sts get-caller-identity >/dev/null 2>&1; }
have_domain()  { [ -f "$TFVARS" ] && [ -n "$(tfvar route53_zone_id)" ] && [ "$(tfvar route53_zone_id)" != "ZXXXXXXXXXXXXXXXXXXXX" ]; }
env_value()    { [ -f "$ENVFILE" ] && sed -n "s/^$1=\(.*\)$/\1/p" "$ENVFILE" | head -1 | tr -d '\r'; }
have_square()  {
  local id secret key
  id="${SQUARE_APP_ID:-$(env_value SQUARE_APP_ID)}"
  secret="${SQUARE_APP_SECRET:-$(env_value SQUARE_APP_SECRET)}"
  key="${SQUARE_WEBHOOK_SIGNATURE_KEY:-$(env_value SQUARE_WEBHOOK_SIGNATURE_KEY)}"
  [ -n "$id" ] && [ -n "$secret" ] && [ -n "$key" ]
}
have_deploy()  { [ -n "$(tf_out app_url)" ] && [ -n "$(tf_out ecs_service)" ]; }
have_secrets() {
  local arn; arn="$(tf_out app_secret_arn)"
  [ -n "$arn" ] || return 1
  [ -n "$(secret_field "$arn" SQUARE_APP_ID)" ]
}
have_verify()  {
  local url; url="$(tf_out app_url)"
  [ -n "$url" ] && [ "$(curl -sS -o /dev/null -w "%{http_code}" --max-time 10 "$url/health" 2>/dev/null)" = "200" ]
}

satisfied() {
  case "$1" in
    tools) have_tools ;; aws-signin) have_aws ;; domain) have_domain ;;
    square) have_square ;; deploy) have_deploy ;; secrets) have_secrets ;;
    verify) have_verify ;;
  esac
}

show_status() {
  printf '\n%s\n' "${C_BLD}Setup status${C_OFF}"
  local i=0
  for p in "${PHASES[@]}"; do
    i=$((i+1))
    if satisfied "$p"; then printf '  %s %d. %-11s %s\n' "${C_GRN}done${C_OFF}" "$i" "$p" "$(DESCRIBE "$p")"
    else                    printf '  %s %d. %-11s %s\n' "${C_YEL}todo${C_OFF}" "$i" "$p" "$(DESCRIBE "$p")"; fi
  done
  printf '\n'
}

[ "$STATUS" = "1" ] && { show_status; exit 0; }

# --------------------------------------------------------- the manual phases
# Each prints precisely what to do, then exits 3 so a re-run resumes here.

need_human() {
  printf '\n%s\n' "${C_YEL}${C_BLD}$1${C_OFF}"
  shift
  while [ $# -gt 0 ]; do printf '  %s\n' "$1"; shift; done
  printf '\n%s\n\n' "Then run this again: ${C_BLD}bash scripts/setup.sh${C_OFF}"
  exit 3
}

phase_tools() {
  heading "Phase 1/7 · Command-line tools"
  if have_tools; then ok "aws, terraform, docker, node and jq are all installed"; return; fi
  if [ -f /etc/debian_version ] && [ "$DRY_RUN" != "1" ]; then
    log "Installing what is missing"
    run bash "$HERE/wsl-setup.sh" || true
  fi
  have_tools || need_human "Some tools are still missing." \
    "Run:  bash scripts/wsl-setup.sh" \
    "That installs the AWS CLI, Terraform, Node 22, jq and make." \
    "Docker comes from Docker Desktop on Windows — start it, then turn on" \
    "Settings → Resources → WSL integration → Ubuntu."
  ok "Tools ready"
}

phase_aws_signin() {
  heading "Phase 2/7 · AWS account"
  if have_aws; then
    ok "Signed in to AWS account $(aws sts get-caller-identity --query Account --output text)"
    return
  fi
  need_human "AWS is not signed in on this machine." \
    "1. If you have no AWS account yet: https://aws.amazon.com → Create an AWS account." \
    "   Turn on MFA for the root user, then make yourself an admin user in IAM." \
    "2. Get credentials: IAM → Users → your user → Security credentials →" \
    "   Create access key → Command Line Interface." \
    "3. Run:  aws login        (browser sign-in, temporary keys — preferred)" \
    "   or:   aws configure    (paste the access key; region us-east-2, output json)" \
    "" \
    "Your keys stay in ~/.aws on this machine. Never paste them into a chat."
}

phase_domain() {
  heading "Phase 3/7 · Domain and configuration"
  if have_domain; then
    ok "Configured for $(tfvar domain_name) in hosted zone $(tfvar route53_zone_id)"
    return
  fi
  local suggested="${GGP_DOMAIN:-globalgoldpay.com}"
  if [ "$DRY_RUN" = "1" ]; then
    info "would run: bash scripts/register-domain.sh $suggested"
    return
  fi
  log "No domain configured yet"
  info "scripts/register-domain.sh checks availability, shows the price, and only"
  info "charges after you type YES. It then writes infra/aws/terraform.tfvars."
  if confirm "Register or configure $suggested now?"; then
    bash "$HERE/register-domain.sh" "$suggested"
  else
    need_human "A domain is needed before anything can be deployed." \
      "Run:  bash scripts/register-domain.sh yourdomain.com" \
      "Or, if you already own one in Route 53, copy infra/aws/terraform.tfvars.staging.example" \
      "to infra/aws/terraform.tfvars and fill in domain_name and route53_zone_id."
  fi
  have_domain || need_human "The domain configuration still is not in place." \
    "Check infra/aws/terraform.tfvars has a real domain_name and route53_zone_id."
  ok "Domain configured"
}

phase_square() {
  heading "Phase 4/7 · Square application"
  if have_square; then ok "Square app id, secret and webhook signature key are all set"; return; fi

  # The URLs depend on the domain, so this phase runs after the domain is known.
  local domain host
  domain="$(tfvar domain_name)"
  host="https://${domain:-your-domain}"

  need_human "Square is not configured yet. This is the one part I cannot do for you." \
    "Open https://developer.squareup.com/apps → Create app → \"Global Gold Payment\"." \
    "Work in Sandbox first; production is the same form again." \
    "" \
    "OAuth → Redirect URL:" \
    "    $host/v1/connect/square/callback" \
    "" \
    "Webhooks → Add subscription → Notification URL:" \
    "    $host/v1/webhooks/square" \
    "  Events: payment.updated, refund.updated, oauth.authorization.revoked" \
    "" \
    "Request the PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS permission for the app." \
    "Without it payments work but your platform fee is never collected." \
    "" \
    "Then put these three into $ENVFILE (create it if needed):" \
    "    SQUARE_APP_ID=..." \
    "    SQUARE_APP_SECRET=..." \
    "    SQUARE_WEBHOOK_SIGNATURE_KEY=..." \
    "" \
    "SETUP-ACCOUNTS.md has the same steps with more detail — and section 4," \
    "for Stripe, which is how you reach the countries Square will not onboard" \
    "(Nigeria, Kenya, Ghana, India, Brazil, Mexico, South Africa). Both can run" \
    "at once; this phase only checks the Square keys, so add Stripe afterwards."
}

phase_deploy() {
  heading "Phase 5/7 · Deploy to AWS"
  # Stop before the live checks: the site cannot pass them until the Square keys
  # are in place, which is the next phase. Phase 7 verifies once, at the end.
  local args=(--yes --until first-admin)
  [ "$DRY_RUN" = "1" ] && args+=(--dry-run)
  # deploy-aws.sh is itself resumable and skips what it has already done.
  bash "$HERE/deploy-aws.sh" "${args[@]}" || {
    warn "The deploy stopped. Its own log is in .deploy-logs/."
    exit 1
  }
  ok "Deployed"
}

phase_secrets() {
  heading "Phase 6/7 · Square keys into Secrets Manager"
  local arn; arn="$(tf_out app_secret_arn)"
  if [ -z "$arn" ]; then
    [ "$DRY_RUN" = "1" ] && { info "would merge the SQUARE_* keys into the app secret"; return; }
    die "No app secret yet — the deploy phase has to finish first."
  fi
  if have_secrets; then ok "Square keys are already in the app secret"; return; fi
  if [ "$DRY_RUN" = "1" ]; then info "would merge SQUARE_APP_ID, SQUARE_APP_SECRET and SQUARE_WEBHOOK_SIGNATURE_KEY into $arn"; return; fi

  local id secret key region tmp
  id="${SQUARE_APP_ID:-$(env_value SQUARE_APP_ID)}"
  secret="${SQUARE_APP_SECRET:-$(env_value SQUARE_APP_SECRET)}"
  key="${SQUARE_WEBHOOK_SIGNATURE_KEY:-$(env_value SQUARE_WEBHOOK_SIGNATURE_KEY)}"
  region="$(aws_region)"

  # The keys go straight from here into the secret; nothing is echoed.
  tmp="$(mktemp)"; chmod 600 "$tmp"
  trap 'shred -u "$tmp" 2>/dev/null || rm -f "$tmp"' RETURN

  log "Merging the Square keys into the app secret"
  aws secretsmanager get-secret-value --secret-id "$arn" --region "$region" \
    --query SecretString --output text \
    | node -e '
        let s=""; process.stdin.on("data",(d)=>s+=d).on("end",()=>{
          const cur = JSON.parse(s);
          const next = { ...cur,
            PAYMENT_PROVIDER: "square",
            SQUARE_ENV: process.env.SQUARE_ENV || "production",
            SQUARE_APP_ID: process.argv[1],
            SQUARE_APP_SECRET: process.argv[2],
            SQUARE_WEBHOOK_SIGNATURE_KEY: process.argv[3],
            PLATFORM_FEE_BPS: process.env.PLATFORM_FEE_BPS || "50",
            WALLET_MODE: process.env.WALLET_MODE || "off",
          };
          process.stdout.write(JSON.stringify(next));
        });' "$id" "$secret" "$key" > "$tmp"

  aws secretsmanager put-secret-value --secret-id "$arn" --region "$region" \
    --secret-string "file://$tmp" --output text --query VersionId >/dev/null
  ok "Stored. The containers pick them up on the next release."

  log "Rolling the service so it reads the new secret"
  bash "$HERE/deploy/06-release.sh" >/dev/null 2>&1 || {
    local cluster service
    cluster="$(tf_out ecs_cluster)"; service="$(tf_out ecs_service)"
    run aws ecs update-service --region "$region" --cluster "$cluster" --service "$service" \
      --force-new-deployment --output text --query 'service.serviceName' >/dev/null
    run aws ecs wait services-stable --region "$region" --cluster "$cluster" --services "$service"
  }
  ok "Service restarted with Square configured"
}

phase_verify() {
  heading "Phase 7/7 · Verify"
  local args=(--only verify --yes)
  [ "$DRY_RUN" = "1" ] && args+=(--dry-run)
  bash "$HERE/deploy-aws.sh" "${args[@]}" || { warn "Some checks failed — see above."; exit 1; }

  local url; url="$(tf_out app_url)"
  if [ "$DRY_RUN" != "1" ] && [ -n "$url" ]; then
    log "Checking that Square agrees with what the server expects"
    local cfg; cfg="$(curl -sS --max-time 15 "$url/v1/connect/config" 2>/dev/null || echo '')"
    if [ -n "$cfg" ]; then
      printf '  %s\n' "${C_DIM}Paste these into the Square console if you have not already:${C_OFF}"
      printf '%s' "$cfg" | jq -r '"    redirect URL  " + .oauth_redirect_url, "    webhook URL   " + .webhook_url, "    provider      " + .provider + " (" + .environment + ")"' 2>/dev/null || true
    fi
  fi
}

# --------------------------------------------------------------------- run it

RUN() {
  case "$1" in
    tools) phase_tools ;; aws-signin) phase_aws_signin ;; domain) phase_domain ;;
    square) phase_square ;; deploy) phase_deploy ;; secrets) phase_secrets ;;
    verify) phase_verify ;;
  esac
}

for p in ${FROM:-} ${ONLY:-}; do
  printf '%s\n' "${PHASES[@]}" | grep -qx "$p" || die "Unknown phase '$p'. Try --status."
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/setup-$(date -u '+%Y%m%dT%H%M%SZ').log"

{
printf '\n%s\n' "${C_BLD}Global Gold Payment — setup${C_OFF}"
printf '%s\n' "${C_DIM}$(date -u '+%Y-%m-%d %H:%M:%SZ')${C_OFF}"
[ "$DRY_RUN" = "1" ] && printf '%s\n' "${C_YEL}DRY RUN — nothing will be created or changed.${C_OFF}"
show_status

started=0
for phase in "${PHASES[@]}"; do
  if [ -n "$ONLY" ] && [ "$phase" != "$ONLY" ]; then continue; fi
  if [ -z "$ONLY" ] && [ -n "$FROM" ] && [ "$started" = "0" ]; then
    if [ "$phase" = "$FROM" ]; then started=1; else continue; fi
  fi
  RUN "$phase"
done

printf '\n%s\n' "${C_BLD}── All phases complete ${C_OFF}"
URL="$(tf_out app_url)"
if [ -n "$URL" ]; then
  printf '\n%s\n\n' "${C_GRN}${C_BLD}Live: $URL${C_OFF}"
  printf '  %-22s %s\n' "Business dashboard" "$URL/dashboard"
  printf '  %-22s %s\n' "Admin panel"        "$URL/admin"
  printf '\n%s\n' "Day to day:"
  printf '  make release   ship a code change\n'
  printf '  make verify    re-run the live checks\n'
  printf '  make logs      tail the container logs\n'
  printf '  make outputs   URLs, cluster, secret ARN\n'
fi
} 2>&1 | tee "$LOG_FILE"

exit "${PIPESTATUS[0]}"
