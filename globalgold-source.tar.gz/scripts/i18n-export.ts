/**
 * Write the translator sheets: one CSV per language, three columns.
 *
 *   npx tsx scripts/i18n-export.ts [outdir]
 *
 * Round-trips with i18n-import.ts. Any translation already in a catalogue is
 * pre-filled, so a sheet sent out a second time shows the translator what is
 * done and what is left rather than starting them over.
 */
import fs from 'node:fs/promises';
import path from 'node:path';

const LANGS: Array<[string, string]> = [
  ['es', 'spanish'], ['ht', 'haitian-creole'], ['sw', 'swahili'], ['zh', 'chinese'],
];
const PUBLIC = path.join(import.meta.dirname, '..', 'public');
const OUT = process.argv[2] ?? path.join(import.meta.dirname, '..', 'i18n-sheets');

const en: Record<string, string> = JSON.parse(await fs.readFile(path.join(PUBLIC, 'i18n', 'en.json'), 'utf8'));
const rows = Object.entries(en);
await fs.mkdir(OUT, { recursive: true });

const q = (s: string) => '"' + String(s).replace(/"/g, '""') + '"';

for (const [code, name] of LANGS) {
  let existing: Record<string, string> = {};
  try { existing = JSON.parse(await fs.readFile(path.join(PUBLIC, 'i18n', `${code}.json`), 'utf8')); } catch { /* none yet */ }
  const lines = [`key,english,${code}_translation`];
  for (const [k, v] of rows) lines.push([q(k), q(v), q(existing[k] ?? '')].join(','));
  // BOM + CRLF so Excel opens it as UTF-8 without being asked.
  await fs.writeFile(path.join(OUT, `${code}-${name}.csv`), '﻿' + lines.join('\r\n') + '\r\n');
  const done = Object.values(existing).filter((x) => x).length;
  console.log(`  ${code}-${name}.csv   ${rows.length} rows, ${done} already translated`);
}
console.log(`\n  sheets in ${OUT}`);
