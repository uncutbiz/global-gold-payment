#!/usr/bin/env python3
"""Offline schema check for the Terraform files: every resource type and every
argument name is verified against the real AWS/random provider schemas (taken
from the @cdktf/provider-aws typings, which are generated from those schemas)."""
import glob, os, re, sys

LIB = {
    'aws': '/tmp/tfcheck/node_modules/@cdktf/provider-aws/lib',
}
META = {'count', 'for_each', 'depends_on', 'lifecycle', 'provider', 'providers', 'create_before_destroy',
        'ignore_changes', 'prevent_destroy', 'replace_triggered_by', 'precondition', 'postcondition',
        'condition', 'error_message', 'timeouts', 'create', 'update', 'delete', 'read', 'default_tags',
        'connection', 'triggers', 'when', 'source', 'version', 'value', 'description', 'type', 'sensitive',
        'default', 'validation', 'alias'}

def camel(s):
    parts = s.split('_')
    return parts[0] + ''.join(p.title() for p in parts[1:])

def index_provider(lib_dir):
    """map ('resource'|'data', terraform type) -> typings file"""
    types = {}
    for d in sorted(os.listdir(lib_dir)):
        p = os.path.join(lib_dir, d)
        dts = os.path.join(p, 'index.d.ts')
        js = os.path.join(p, 'index.js')
        if not (os.path.isfile(dts) and os.path.isfile(js)):
            continue
        src = open(js, encoding='utf8', errors='ignore').read()
        kind = 'data' if d.startswith('data-') else 'resource'
        for pat in (r'terraformResourceType\s*=\s*"([a-z0-9_]+)"', r'tfResourceType\s*=\s*"([a-z0-9_]+)"'):
            for m in re.finditer(pat, src):
                types.setdefault((kind, m.group(1)), dts)
    return types

def props(dts_path, cache={}):
    if dts_path not in cache:
        src = open(dts_path, encoding='utf8', errors='ignore').read()
        cache[dts_path] = set(re.findall(r'readonly\s+([A-Za-z0-9_]+)\??\s*:', src))
    return cache[dts_path]

def parse_tf(path):
    """yields (kind, type, arg, line) for top-level arguments of resource/data blocks"""
    current = None
    depth = 0
    for n, raw in enumerate(open(path, encoding='utf8'), 1):
        line = raw.split('#')[0]
        s = line.strip()
        if not s:
            continue
        m = re.match(r'(resource|data)\s+"([a-z0-9_]+)"\s+"[-A-Za-z0-9_]+"\s*\{', s)
        if m and current is None:
            current, depth = (m.group(1), m.group(2)), 1
            continue
        if current is None:
            continue
        m = re.match(r'([a-z][a-z0-9_]*)\s*(=|\{)', s)
        if m and depth == 1 and m.group(1) not in META:
            yield (current[0], current[1], m.group(1), n)
        depth += s.count('{') - s.count('}')
        if depth <= 0:
            current, depth = None, 0

def main(tf_dir):
    types = index_provider(LIB['aws'])
    print(f'AWS provider schema: {len(types)} resource/data types indexed')
    problems = []
    checked_types, checked_args = set(), 0
    for f in sorted(glob.glob(os.path.join(tf_dir, '*.tf'))):
        for kind, ttype, arg, line in parse_tf(f):
            if ttype.startswith('random_'):
                continue  # random provider: tiny, checked by hand
            key = (kind, ttype)
            if key not in types:
                problems.append(f'{os.path.basename(f)}:{line}  unknown {kind} type "{ttype}"')
                continue
            checked_types.add(ttype)
            checked_args += 1
            if camel(arg) not in props(types[key]):
                problems.append(f'{os.path.basename(f)}:{line}  {ttype} has no argument "{arg}"')
    print(f'checked {checked_args} arguments across {len(checked_types)} AWS resource types')
    for p in problems:
        print('  PROBLEM', p)
    print('OK: every resource type and argument exists in the provider schema' if not problems else f'{len(problems)} problem(s)')
    return 1 if problems else 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else '/home/claude/global-gold-payment/infra/aws'))
