/**
 * Screenshots of the merchant dashboard, for looking at.
 *
 * Not a test — it asserts nothing. It exists because the palette validator
 * checks colour and the unit tests check behaviour, and neither of them can
 * see a label colliding with an axis or a card overflowing its column. The
 * only way to catch that is to render the page and look.
 *
 *   npx tsx scripts/shots.ts [outdir]
 *
 * WARNING: wipes the target database's public schema.
 */
import crypto from 'node:crypto';
import http from 'node:http';
import fs from 'node:fs/promises';
import type { AddressInfo } from 'node:net';
import { chromium } from 'playwright';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'shots-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.CARD_RATE_LIMIT = '100000';
process.env.AUTH_RATE_LIMIT = '100000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

const OUT = process.argv[2] ?? '/mnt/user-data/outputs/merchant-account';
const PW = 'correct horse battery staple';
let base = '';

async function api(method: string, path: string, key: string | null, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: {
      'content-type': 'application/json',
      ...(key ? { authorization: `Bearer ${key}` } : {}),
      ...(method === 'POST' ? { 'idempotency-key': crypto.randomUUID() } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const b: any = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`${method} ${path}: ${b.error?.message ?? r.status}`);
  return b;
}

let seq = 0;
function card() {
  const body = ('4000' + String(100000000000 + (seq += 13))).slice(0, 15);
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    let d = Number(body[body.length - 1 - i]);
    if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return { number: body + String((10 - (sum % 10)) % 10), exp_month: 12, exp_year: 2040, cvc: '123' };
}

await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
await migrate();
const server = createApp().listen(0);
await new Promise((r) => server.once('listening', r));
base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

// ── a business with a week of trading behind it ──────────────────────────
const who = crypto.randomBytes(3).toString('hex');
const email = `owner-${who}@fieldnotes.test`;
const su = await api('POST', '/v1/business/signup', null, {
  business_name: 'Fieldnotes Coffee Co.', name: 'Yvon Adams', email, password: PW,
  country: 'US', business_type: 'company', website: 'https://fieldnotes.test',
  description: 'Single-origin coffee, wholesale and retail',
});
await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [su.merchant_id]);
const key = su.token as string;

const DESCS = ['Bag · Ethiopia Guji', 'Wholesale · 12kg', 'Subscription · monthly', 'Bag · Colombia Huila',
  'Brew kit', 'Wholesale · 6kg', 'Cafe order #4412', 'Gift set'];

// Spread the week: a busy Thursday, a dead Sunday, declines scattered through.
const PLAN = [
  { back: 6, ok: 3, bad: 1 }, { back: 5, ok: 5, bad: 2 }, { back: 4, ok: 4, bad: 0 },
  { back: 3, ok: 8, bad: 3 }, { back: 2, ok: 6, bad: 1 }, { back: 1, ok: 0, bad: 0 },
  { back: 0, ok: 5, bad: 2 },
];

for (const day of PLAN) {
  const made: string[] = [];
  for (let i = 0; i < day.ok + day.bad; i++) {
    const fail = i >= day.ok;
    // Amounts ending in 51 cents are the test acquirer's decline trigger.
    const amount = fail ? 1000 + Math.floor(Math.random() * 40) * 100 + 51
                        : 1200 + Math.floor(Math.random() * 90) * 100;
    const pi = await api('POST', '/v1/payment_intents', key, {
      amount, currency: 'usd', description: DESCS[(seq + i) % DESCS.length],
    });
    const tok = await api('POST', '/v1/tokens', key, { card: card() });
    await api('POST', `/v1/payment_intents/${pi.id}/confirm`, key, { payment_token: tok.id })
      .catch(() => {});                                   // a decline is the point
    made.push(pi.id);
  }
  if (day.back) {
    // Backdate the intents AND their attempts together — the chart reads the
    // attempts, the tables read the intents, and they must tell one story.
    await pool.query(
      `UPDATE payment_intents SET created_at = created_at - make_interval(days => $2),
                                  updated_at = updated_at - make_interval(days => $2)
        WHERE id = ANY($1)`, [made, day.back]);
    await pool.query(
      `UPDATE payment_attempts SET created_at = created_at - make_interval(days => $2)
        WHERE payment_intent_id = ANY($1)`, [made, day.back]);
  }
}

// A refund, so the payments table shows one.
const recent = await api('GET', '/v1/payment_intents?limit=20', key);
const paid = recent.data.find((p: any) => p.status === 'succeeded');
if (paid) await api('POST', '/v1/refunds', key, { payment_intent: paid.id, amount: 500 });

// Customers, an invoice, links — so no tab is empty.
const people = [
  ['Marguerite Okonjo', 'm.okonjo@example.com', '+1 415 555 0142'],
  ['Teodor Lindqvist', 'teo@example.com', '+1 206 555 0188'],
  ['Amara Silva', 'amara.silva@example.com', ''],
];
let firstCustomer = '';
for (const [name, mail, phone] of people) {
  const c = await api('POST', '/v1/customers', key, { name, email: mail, phone: phone || undefined });
  firstCustomer ||= c.id;
}
const inv = await api('POST', '/v1/invoices', key, {
  customer: firstCustomer, currency: 'usd', title: 'September wholesale',
  note: 'Thank you — payable within 14 days.',
  due_at: new Date(Date.now() + 9 * 86_400_000).toISOString(),
  lines: [
    { description: 'Ethiopia Guji · 12kg', quantity: 2, unit_amount: 24_000, tax_bps: 875 },
    { description: 'Delivery', quantity: 1, unit_amount: 3_500, tax_bps: 0 },
  ],
});
await api('POST', `/v1/invoices/${inv.id}/send`, key, {});
await api('POST', '/v1/invoices', key, {
  customer: firstCustomer, currency: 'usd', title: 'October wholesale (draft)',
  lines: [{ description: 'Colombia Huila · 6kg', quantity: 1, unit_amount: 13_500, tax_bps: 875 }],
});
for (const [title, amount] of [['Bag of the month', 2_400], ['Tasting flight ticket', 3_500]] as const) {
  await api('POST', '/v1/payment_links', key, { title, amount, currency: 'usd' });
}
await api('POST', '/v1/payment_links', key, { title: 'Tip the roasters', min_amount: 200, currency: 'usd' });

// Settled balance plus an expense card, so the Cards section shows something
// real rather than an empty state.
{
  const { pool } = await import('../src/db.js');
  const { acct, postJournal } = await import('../src/ledger/ledger.js');
  const c = await pool.connect();
  await c.query('BEGIN');
  await postJournal(c as any, 'usd', { type: 'demo_settle', id: su.merchant_id }, 'demo settlement', [
    { account: acct.bankCash, debit: 2_500_00 },
    { account: acct.available(su.merchant_id), credit: 2_500_00 },
  ]);
  await c.query('COMMIT'); c.release();
  const { createBusinessVirtualCard } = await import('../src/cards/cards.js');
  const { authorize } = await import('../src/cards/authorize.js');
  const m = { id: su.merchant_id, name: 'Fieldnotes Coffee Co.', status: 'active' };
  const adCard = await createBusinessVirtualCard(m, {
    currency: 'usd', nickname: 'Ads spend', cardholder_name: 'Yvon Adams',
    per_auth_limit: 500_00, monthly_limit: 1_000_00,
  });
  await createBusinessVirtualCard(m, {
    currency: 'usd', nickname: 'Packaging supplier', cardholder_name: 'Dayo Bello',
    per_auth_limit: 150_00, blocked_mcc: ['7995'],
  });
  await authorize({ cardId: adCard.id, amount: 240_00, currency: 'usd', merchantName: 'Meta Ads', mcc: '7311' });
  await authorize({ cardId: adCard.id, amount: 620_00, currency: 'usd', merchantName: 'Trade Show Stand', mcc: '7311' });
}

// Two refund requests a customer has asked for: one waiting, one already
// answered, so the queue shows both states rather than an empty table.
{
  const { requestRefund, declineRequest } = await import('../src/payments/refund-requests.js');
  const m = { id: su.merchant_id, name: 'Fieldnotes Coffee Co.', status: 'active' } as any;
  const settled = (await pool.query(
    `SELECT id FROM payment_intents
      WHERE merchant_id = $1 AND status = 'succeeded' AND amount_refunded = 0
      ORDER BY created_at DESC LIMIT 2`, [su.merchant_id])).rows;
  if (settled[0]) {
    await requestRefund({
      paymentIntentId: settled[0].id, asker: { email: 'marguerite@example.com' },
      reason: 'not_received', note: 'Ordered on the 3rd, tracking has not moved since.',
    });
  }
  if (settled[1]) {
    const r = await requestRefund({
      paymentIntentId: settled[1].id, asker: { email: 'teo@example.com' },
      reason: 'not_as_described', note: 'I wanted the decaf.',
    });
    await declineRequest(m, r.id, 'The order confirmation lists the regular roast — happy to swap it if you post it back.');
  }
}

// ── shoot ────────────────────────────────────────────────────────────────
// Cleared first, so a section that has been renamed does not leave its old
// screenshot behind looking current.
await fs.rm(OUT, { recursive: true, force: true });
await fs.mkdir(OUT, { recursive: true });
const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
const SECTIONS = ['home', 'payments', 'invoices', 'customers', 'subs', 'links', 'cards', 'refunds', 'disputes', 'reports', 'settings'];

for (const [tag, viewport] of [['', { width: 1400, height: 1000 }], ['-phone', { width: 390, height: 844 }]] as const) {
  const p = await browser.newPage({ viewport, deviceScaleFactor: 2 });
  const problems: string[] = [];
  p.on('pageerror', (e) => problems.push(`${e.message}`));
  p.on('console', (m) => { if (m.type() === 'error') problems.push(m.text()); });

  await p.goto(base + '/dashboard');
  await p.fill('#uEmail', email);
  await p.fill('#uPassword', PW);
  await p.click('#authBtn');
  await p.waitForSelector('#app:not([hidden])', { timeout: 10_000 });
  await p.waitForSelector('.chart', { timeout: 10_000 });

  for (const [i, sec] of SECTIONS.entries()) {
    await p.click(`#sections button[data-sec="${sec}"]`);
    await p.waitForTimeout(700);
    if (sec === 'home' && !tag) {
      // Park the pointer mid-chart so the crosshair and tooltip are in shot,
      // and say out loud whether the hover layer actually came up — a chart
      // that silently lost its tooltip looks fine in a still.
      const box = await p.locator('.chart').boundingBox();
      if (box) await p.mouse.move(box.x + box.width * 0.55, box.y + box.height * 0.5);
      await p.waitForTimeout(300);
      const tip = p.locator('.tip');
      console.log('hover tooltip:', await tip.count()
        ? (await tip.evaluate((n: any) => n.hidden) ? 'HIDDEN — hover layer is not working' : `"${(await tip.textContent())?.trim()}"`)
        : 'MISSING');
      await p.screenshot({ path: `${OUT}/00-home-hover.png`, clip: { x: 0, y: 0, width: viewport.width, height: 760 } });
    }
    // A page wider than the viewport means something in it refuses to shrink,
    // which on a phone shows up as sideways scrolling. Worth shouting about:
    // a full-page screenshot quietly widens to fit and hides the problem.
    const over = await p.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    if (over > 1) console.log(`  ${sec}${tag}: OVERFLOWS by ${over}px`);
    await p.screenshot({
      path: `${OUT}/${String(i + 1).padStart(2, '0')}-${sec}${tag}.png`,
      fullPage: true,
    });
  }
  console.log(`${tag || 'desktop'}: ${problems.length ? 'PAGE ERRORS → ' + problems.join(' | ') : 'no page errors'}`);
  await p.close();
}

await browser.close();
server.close();
await pool.end();
console.log('screenshots in ' + OUT);
