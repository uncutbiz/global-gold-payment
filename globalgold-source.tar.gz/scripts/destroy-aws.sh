#!/usr/bin/env bash
#
#  Tears down everything scripts/deploy-aws.sh created.
#  Deliberately noisy and slow to confirm: this deletes the database.
#
#    ./scripts/destroy-aws.sh
#
set -Eeuo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/deploy/lib.sh"

ENVIRONMENT="$(tfvar environment staging)"
URL="$(tf_out app_url)"
DB="$(tf_out db_endpoint)"

heading "Destroy the $ENVIRONMENT deployment"
printf '  %-22s %s\n' "Site"     "${URL:-(none)}"
printf '  %-22s %s\n' "Database" "${DB:-(none)}"
printf '\n%s\n' "${C_RED}${C_BLD}This permanently deletes the database, all merchants, wallets, ledger entries and audit logs.${C_OFF}"

if [ "$ENVIRONMENT" = "production" ]; then
  warn "environment = production, so RDS has deletion protection and Terraform will refuse."
  info "To really delete production: set environment = \"staging\" or turn off deletion_protection, apply, then destroy."
fi

printf '\n%s' "Type the environment name ($ENVIRONMENT) to confirm: "
typed=''
{ read -r typed <&9; } 2>/dev/null 9</dev/tty || read -r typed || typed=''
[ "$typed" = "$ENVIRONMENT" ] || die "Did not match. Nothing was deleted."

log "Emptying the ECR repository (Terraform cannot delete a repository with images)"
REPO="$(tf_out ecr_repository_url)"
if [ -n "$REPO" ]; then
  IDS="$(aws ecr list-images --region "$(aws_region)" --repository-name "${REPO##*/}" \
    --query 'imageIds[*]' --output json 2>/dev/null || echo '[]')"
  [ "$IDS" = "[]" ] || aws ecr batch-delete-image --region "$(aws_region)" \
    --repository-name "${REPO##*/}" --image-ids "$IDS" >/dev/null
  ok "Images deleted"
fi

DESTROY=(destroy -input=false -var "image_tag=$(cat "$REPO_ROOT/.deploy-image-tag" 2>/dev/null || echo latest)")
[ "$ASSUME_YES" = "1" ] && DESTROY+=(-auto-approve)
tf "${DESTROY[@]}"

rm -f "$STATE_FILE" "$REPO_ROOT/.deploy-image-tag"
ok "Destroyed. The Terraform state bucket and its history were kept on purpose — delete it by hand if you are done for good."
