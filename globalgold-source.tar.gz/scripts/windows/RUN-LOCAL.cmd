@echo off
rem ===========================================================
rem  Global Gold Payment - run the whole platform on this PC
rem
rem  Double-click this. It starts the database, creates demo
rem  data, starts the app, and opens your browser on it.
rem
rem  Nothing to configure. Nothing is sent anywhere. The card
rem  network is simulated, so no real money is involved.
rem ===========================================================
setlocal EnableDelayedExpansion

set "PROJ="
if exist "%USERPROFILE%\Documents\GlobalGoldPayment\package.json" set "PROJ=%USERPROFILE%\Documents\GlobalGoldPayment"
if exist "%USERPROFILE%\Desktop\GlobalGoldPayment\package.json"   set "PROJ=%USERPROFILE%\Desktop\GlobalGoldPayment"
if exist "%~dp0..\..\package.json"                                set "PROJ=%~dp0..\.."
for %%I in ("%PROJ%") do set "PROJ=%%~fI"

if not defined PROJ (
  echo.
  echo   Could not find the project folder.
  echo   Run "1 - START GLOBAL GOLD SETUP" first.
  echo.
  pause
  exit /b 1
)

docker version >nul 2>&1
if %errorlevel% neq 0 (
  echo.
  echo   Docker Desktop is not running.
  echo   Start Docker Desktop, wait for the whale icon to stop animating,
  echo   then double-click this again.
  echo.
  pause
  exit /b 1
)

cd /d "%PROJ%"

echo.
echo   Starting Global Gold Payment.
echo   The first run builds the image and takes a few minutes.
echo   After that it is about twenty seconds.
echo.

docker compose -f docker-compose.demo.yml up -d --build
if %errorlevel% neq 0 (
  echo.
  echo   Something went wrong starting the containers. The output above says what.
  echo   A common cause is Docker Desktop still finishing its own start-up.
  echo.
  pause
  exit /b 1
)

echo.
echo   Waiting for the app to answer...

rem The seed job runs first, so the app can take a moment to appear.
set "READY="
for /l %%i in (1,1,90) do (
  if not defined READY (
    rem -f so an error page does not count as ready.
    curl -sf -o nul -m 3 http://localhost:8080/health && set "READY=1"
    if not defined READY timeout /t 2 /nobreak >nul
  )
)

if not defined READY (
  echo.
  echo   The app has not answered yet. It may still be starting.
  echo   Check what the containers are doing with:
  echo       docker compose -f docker-compose.demo.yml logs -f
  echo.
  pause
  exit /b 1
)

echo   Ready.
echo.
echo   ----------------------------------------------------------
echo    Global Gold Payment is running on this PC
echo.
echo      Home page          http://localhost:8080/
echo      Customer wallet    http://localhost:8080/wallet
echo      Business dashboard http://localhost:8080/dashboard
echo      Admin panel        http://localhost:8080/admin
echo.
echo    To stop it:
echo        docker compose -f docker-compose.demo.yml down
echo    To stop it and wipe the demo data:
echo        docker compose -f docker-compose.demo.yml down -v
echo   ----------------------------------------------------------
echo.

start "" http://localhost:8080/

rem The seed job prints the sign-in details on every start, including repeat
rem starts, so this works whether the data was just created or already existed.
echo   Sign-in details for the demo accounts:
docker compose -f docker-compose.demo.yml logs --no-log-prefix seed 2>nul
echo.
echo   (To see this again later, run:)
echo       docker compose -f docker-compose.demo.yml logs --no-log-prefix seed
echo.
pause
