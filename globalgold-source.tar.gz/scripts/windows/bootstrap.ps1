# Global Gold Payment — one-time Windows setup
#
# Installs everything the deployment needs, then hands off to Ubuntu (WSL2),
# where the deploy scripts run. You run this once.
#
#   1. Press Start, type "PowerShell"
#   2. Right-click "Windows PowerShell" → Run as administrator
#   3. Paste this and press Enter:
#
#        Set-ExecutionPolicy -Scope Process Bypass -Force
#        cd "$HOME\Documents\GlobalGoldPayment"
#        .\scripts\windows\bootstrap.ps1
#
# It is safe to run again — anything already installed is skipped.

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

function Say  ($m) { Write-Host "▸ $m" -ForegroundColor Cyan }
function Good ($m) { Write-Host "✓ $m" -ForegroundColor Green }
function Warn ($m) { Write-Host "! $m" -ForegroundColor Yellow }
function Die  ($m) { Write-Host "✗ $m" -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "Global Gold Payment — Windows setup" -ForegroundColor White
Write-Host "-----------------------------------"

# --- winget -----------------------------------------------------------------
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
  Die "winget is missing. Install 'App Installer' from the Microsoft Store, then run this again."
}
Good "winget present"

# --- Docker Desktop and Git -------------------------------------------------
$packages = @(
  @{ Id = 'Git.Git';               Name = 'Git' },
  @{ Id = 'Docker.DockerDesktop';  Name = 'Docker Desktop' }
)
foreach ($p in $packages) {
  $installed = (winget list --id $p.Id --exact 2>$null) -match $p.Id
  if ($installed) { Good "$($p.Name) already installed" ; continue }
  Say "Installing $($p.Name) (this can take a few minutes)"
  winget install --id $p.Id --exact --accept-package-agreements --accept-source-agreements --silent
  if ($LASTEXITCODE -ne 0) { Warn "$($p.Name) installer returned $LASTEXITCODE — check it in the Start menu before continuing." }
  else { Good "$($p.Name) installed" }
}

# --- WSL2 + Ubuntu ----------------------------------------------------------
# Docker Desktop needs WSL2 anyway, and the deploy scripts are bash, so Ubuntu
# is where they run. The project folder stays on Windows, visible in both.
$wslOk = $false
try { wsl --status *>$null; $wslOk = ($LASTEXITCODE -eq 0) } catch { $wslOk = $false }

if (-not $wslOk) {
  Say "Enabling WSL2 (needs one reboot)"
  wsl --install --no-distribution
  Warn "Reboot Windows now, then run this script again to finish."
  exit 0
}
Good "WSL2 enabled"

$distros = (wsl --list --quiet) -replace "`0", ''
if ($distros -match 'Ubuntu') {
  Good "Ubuntu already installed"
} else {
  Say "Installing Ubuntu"
  wsl --install -d Ubuntu --no-launch
  Warn "Open Ubuntu once from the Start menu to create your Linux username and password, then run this script again."
  exit 0
}

wsl --set-default Ubuntu 2>$null | Out-Null
wsl --set-version Ubuntu 2 2>$null | Out-Null

# --- hand off to Ubuntu -----------------------------------------------------
$projectWin = (Resolve-Path "$PSScriptRoot\..\..").Path
$drive      = $projectWin.Substring(0,1).ToLower()
$projectWsl = "/mnt/$drive" + $projectWin.Substring(2).Replace('\','/')

Write-Host ""
Good "Windows side is ready."
Write-Host ""
Write-Host "Next, in Ubuntu:" -ForegroundColor White
Write-Host ""
Write-Host "  wsl" -ForegroundColor Yellow
Write-Host "  cd '$projectWsl'" -ForegroundColor Yellow
Write-Host "  bash scripts/wsl-setup.sh" -ForegroundColor Yellow
Write-Host ""
Write-Host "Before that, start Docker Desktop once and turn on:" -ForegroundColor White
Write-Host "  Settings → Resources → WSL integration → Ubuntu"
Write-Host ""
