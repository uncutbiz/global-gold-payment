@echo off
rem Opens the project folder in File Explorer.
setlocal
set "PROJ="
if exist "%USERPROFILE%\Documents\GlobalGoldPayment\package.json" set "PROJ=%USERPROFILE%\Documents\GlobalGoldPayment"
if exist "%USERPROFILE%\Desktop\GlobalGoldPayment\package.json"   set "PROJ=%USERPROFILE%\Desktop\GlobalGoldPayment"
if exist "%~dp0..\..\package.json"                                set "PROJ=%~dp0..\.."
for %%I in ("%PROJ%") do set "PROJ=%%~fI"

if not defined PROJ (
  echo.
  echo   Could not find the project folder.
  echo   Unpack GlobalGoldPayment.zip into your Documents folder.
  echo.
  pause
  exit /b 1
)

start "" explorer.exe "%PROJ%"
