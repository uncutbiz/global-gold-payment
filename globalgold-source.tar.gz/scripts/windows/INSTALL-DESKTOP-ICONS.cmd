@echo off
rem ===========================================================
rem  Puts the five Global Gold Payment shortcuts on your Desktop.
rem  Safe to run again; it overwrites them.
rem ===========================================================
setlocal EnableDelayedExpansion

set "HERE=%~dp0"
set "DESK=%USERPROFILE%\Desktop"

if not exist "%HERE%RUN-ME-FIRST.cmd" (
  echo.
  echo   Run this from inside the project, at
  echo     GlobalGoldPayment\scripts\windows\
  echo.
  pause
  exit /b 1
)

rem Each shortcut is a one-line .cmd that calls the real script, so the icons
rem keep working when the project folder moves.
call :icon "1 - START GLOBAL GOLD SETUP"        "RUN-ME-FIRST.cmd"
call :icon "2 - OPEN UBUNTU AND INSTALL"        "STEP-2-UBUNTU.cmd"
call :icon "3 - OPEN PROJECT FOLDER"            "OPEN-PROJECT.cmd"
call :icon "4 - RUN SETUP (repeat until done)"  "RUN-SETUP.cmd"
call :icon "5 - RUN THE APP ON THIS PC"         "RUN-LOCAL.cmd"

echo.
echo   Five shortcuts are on your Desktop.
echo.
echo     1, 2  install the tools    - once, in that order
echo     3     open the folder
echo     4     deploy to AWS        - repeat until it says done
echo     5     run it on this PC    - no AWS account needed
echo.
pause
exit /b 0

:icon
set "NAME=%~1"
set "TARGET=%HERE%%~2"
if not exist "%TARGET%" (
  echo   skipped "%NAME%" - missing %~2
  exit /b 0
)
> "%DESK%\%NAME%.cmd" echo @echo off
>>"%DESK%\%NAME%.cmd" echo call "%TARGET%" %%*
echo   installed "%NAME%"
exit /b 0
