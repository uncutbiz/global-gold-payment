@echo off
rem ===========================================================
rem  Global Gold Payment - Step 1
rem  Double-click this file. It asks for administrator rights
rem  itself, then installs Git, Docker Desktop and WSL2 Ubuntu.
rem  Safe to run again.
rem ===========================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"

rem Find the project folder whether this file sits in it or beside it.
set "PROJ="
if exist "%USERPROFILE%\Documents\GlobalGoldPayment\package.json" set "PROJ=%USERPROFILE%\Documents\GlobalGoldPayment"
if exist "%USERPROFILE%\Desktop\GlobalGoldPayment\package.json"   set "PROJ=%USERPROFILE%\Desktop\GlobalGoldPayment"
if exist "%~dp0..\..\package.json"                                set "PROJ=%~dp0..\.."
if exist "%~dp0GlobalGoldPayment\package.json"                    set "PROJ=%~dp0GlobalGoldPayment"
if exist "%~dp0package.json"                                      set "PROJ=%~dp0"

if not defined PROJ (
  echo.
  echo   Could not find the GlobalGoldPayment project folder.
  echo   Put this file in your Documents folder, next to GlobalGoldPayment,
  echo   or inside the project itself.
  echo.
  pause
  exit /b 1
)

for %%I in ("%PROJ%") do set "PROJ=%%~fI"
set "BOOTSTRAP=%PROJ%\scripts\windows\bootstrap.ps1"

if not exist "%BOOTSTRAP%" (
  echo.
  echo   Missing: %BOOTSTRAP%
  echo   Unpack GlobalGoldPayment.zip first.
  echo.
  pause
  exit /b 1
)

rem Already administrator?
net session >nul 2>&1
if %errorlevel% equ 0 goto :run

echo.
echo   Asking Windows for administrator rights...
echo   Click Yes on the prompt.
echo.
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b 0

:run
set "LOG=%USERPROFILE%\Documents\ggp-step1-log.txt"
echo.
echo   Installing Git, Docker Desktop and WSL2 Ubuntu.
echo   This takes a while. Leave the window open.
echo.
echo   A copy of everything below is saved to:
echo     %LOG%
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { & '%BOOTSTRAP%' } *>&1 | Tee-Object -FilePath '%LOG%'"
echo.
echo   ----------------------------------------------------
echo   Step 1 finished. Read the messages above:
echo     - if it asked you to REBOOT, reboot and run this again
echo     - if it asked you to OPEN UBUNTU once, do that, then run this again
echo     - otherwise, start Docker Desktop, turn on
echo       Settings ^> Resources ^> WSL integration ^> Ubuntu,
echo       then double-click STEP-2-UBUNTU.cmd
echo   ----------------------------------------------------
echo.
pause
