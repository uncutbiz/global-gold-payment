@echo off
rem ===========================================================
rem  Global Gold Payment - Step 2
rem  Double-click this file. It opens Ubuntu inside the project
rem  and installs the AWS CLI, Terraform, Node, jq and make.
rem  When it finishes you are left at an Ubuntu prompt, in the
rem  right folder, ready for the remaining commands.
rem ===========================================================
setlocal EnableDelayedExpansion

set "PROJ="
if exist "%USERPROFILE%\Documents\GlobalGoldPayment\package.json" set "PROJ=%USERPROFILE%\Documents\GlobalGoldPayment"
if exist "%USERPROFILE%\Desktop\GlobalGoldPayment\package.json"   set "PROJ=%USERPROFILE%\Desktop\GlobalGoldPayment"
if exist "%~dp0..\..\package.json"                                set "PROJ=%~dp0..\.."
if exist "%~dp0GlobalGoldPayment\package.json"                    set "PROJ=%~dp0GlobalGoldPayment"
if exist "%~dp0package.json"                                      set "PROJ=%~dp0"

if not defined PROJ (
  echo   Could not find the GlobalGoldPayment project folder.
  pause
  exit /b 1
)
for %%I in ("%PROJ%") do set "PROJ=%%~fI"

where wsl >nul 2>&1
if %errorlevel% neq 0 (
  echo.
  echo   WSL is not installed yet. Run RUN-ME-FIRST.cmd first.
  echo.
  pause
  exit /b 1
)

wsl -l -q 2>nul | findstr /i "Ubuntu" >nul
if %errorlevel% neq 0 (
  echo.
  echo   Ubuntu is not installed yet. Run RUN-ME-FIRST.cmd first,
  echo   then open Ubuntu once from the Start menu to create your
  echo   Linux username and password.
  echo.
  pause
  exit /b 1
)

echo.
echo   Project: %PROJ%
echo   Opening Ubuntu and installing the toolchain.
echo   You will be asked for your Linux password (sudo).
echo.

echo   A copy of the output is saved to:
echo     %USERPROFILE%\Documents\ggp-step2-log.txt
echo.

wsl -d Ubuntu --cd "%PROJ%" -- bash -lc "bash scripts/wsl-setup.sh 2>&1 | tee \"$(wslpath '%USERPROFILE%')/Documents/ggp-step2-log.txt\"; echo; echo 'You are now in Ubuntu, in the project folder.'; echo 'Next: aws login   (or: aws configure)'; exec bash -l"
