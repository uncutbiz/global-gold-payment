@echo off
rem ===========================================================
rem  Global Gold Payment - Step 4
rem  Runs the setup inside Ubuntu. It stops at the first thing
rem  only you can do, tells you what, and carries on from there
rem  the next time. Double-click it again until it says done.
rem ===========================================================
setlocal EnableDelayedExpansion

set "PROJ="
if exist "%USERPROFILE%\Documents\GlobalGoldPayment\package.json" set "PROJ=%USERPROFILE%\Documents\GlobalGoldPayment"
if exist "%USERPROFILE%\Desktop\GlobalGoldPayment\package.json"   set "PROJ=%USERPROFILE%\Desktop\GlobalGoldPayment"
if exist "%~dp0..\..\package.json"                                set "PROJ=%~dp0..\.."
for %%I in ("%PROJ%") do set "PROJ=%%~fI"

if not defined PROJ (
  echo.
  echo   Could not find the project folder. Unpack GlobalGoldPayment.zip
  echo   into your Documents folder first.
  echo.
  pause
  exit /b 1
)

wsl -e true >nul 2>&1
if %errorlevel% neq 0 (
  echo.
  echo   Ubuntu is not installed yet, or needs its first start.
  echo   Double-click "1 - START GLOBAL GOLD SETUP", then
  echo   "2 - OPEN UBUNTU AND INSTALL".
  echo.
  pause
  exit /b 1
)

rem Hand Ubuntu the Windows path; it mounts C: under /mnt/c.
set "WPATH=%PROJ%"
set "LPATH=%WPATH::=%"
set "LPATH=/mnt/%LPATH:\=/%"
set "LPATH=%LPATH:/C/=/c/%"

echo.
echo   Project: %PROJ%
echo   Running the setup. Answer anything it asks.
echo.

wsl -e bash -lc "cd '%LPATH%' && bash scripts/setup.sh"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
  echo   ----------------------------------------------------
  echo   Setup is complete. Nothing left to do.
  echo   ----------------------------------------------------
) else if "%RC%"=="3" (
  echo   ----------------------------------------------------
  echo   It needs something from you - read the message above.
  echo   Do that, then double-click this again.
  echo   ----------------------------------------------------
) else (
  echo   ----------------------------------------------------
  echo   It stopped with an error. The message above says which
  echo   step and why. Fix that, then double-click this again.
  echo   ----------------------------------------------------
)
echo.
echo   To see what is done and what is left:
echo     wsl -e bash -lc "cd '%LPATH%' && bash scripts/setup.sh --status"
echo.
pause
