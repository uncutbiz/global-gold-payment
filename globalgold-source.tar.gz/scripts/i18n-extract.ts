/**
 * Find the translatable text in the pages, tag it with keys, and write the
 * catalogues a translator fills in.
 *
 *   npx tsx scripts/i18n-extract.ts          # annotate + write catalogues
 *   npx tsx scripts/i18n-extract.ts --check  # fail if anything is untagged
 *
 * Idempotent: keys are derived from the English text, so re-running after an
 * edit re-tags the changed string and leaves the rest alone. Run it again
 * whenever the copy changes and the new strings appear in the catalogues as
 * empty values.
 *
 * WHAT IT DELIBERATELY DOES NOT TOUCH
 *
 *   <script> <style> <code> <pre>   code is not prose
 *   anything already carrying data-i18n
 *   elements with mixed content       a paragraph with a <b> inside it has
 *                                     several text nodes; replacing the whole
 *                                     element's textContent would destroy the
 *                                     markup, so those are reported and left
 *                                     for a human to split
 *
 * AND THE BIG ONE: strings built in JavaScript are invisible to this. Much of
 * this app's interface is assembled with el() calls, and those need t() by
 * hand. The --check mode counts them so the size of that job is known rather
 * than guessed.
 */
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const PAGES = ['index.html', 'checkout.html', 'pay.html', 'wallet.html', 'dashboard.html', 'admin.html'];
const LANGS = ['es', 'ht', 'sw', 'zh'];
const PUBLIC = path.join(import.meta.dirname, '..', 'public');
const OUT = path.join(PUBLIC, 'i18n');

/** Elements whose text is prose worth translating. */
const TEXT_TAGS = ['h1', 'h2', 'h3', 'h4', 'p', 'button', 'label', 'span', 'a', 'li', 'summary', 'th', 'td', 'option', 'legend', 'strong', 'b', 'em'];

/**
 * A key a translator can read, plus four hex of the text so two different
 * strings that slugify the same do not collide.
 */
function keyFor(text: string): string {
  const slug = text.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 42);
  const hash = crypto.createHash('sha1').update(text).digest('hex').slice(0, 4);
  return `${slug || 'text'}_${hash}`;
}

/** Text that is not prose: numbers, symbols, code-ish tokens, single chars. */
function translatable(text: string): boolean {
  const t = text.trim();
  if (t.length < 2) return false;
  if (!/[a-zA-Z]/.test(t)) return false;              // numbers, punctuation, ¢
  if (/^[\d\s.,$%+()–—·•/-]+$/.test(t)) return false;
  if (/^(sk_|pk_|whsec_|acct_|https?:|\/v1\/|\.\/)/.test(t)) return false;
  if (/^[a-z_]+\.[a-z_.]+$/.test(t)) return false;    // event names like invoice.paid
  return true;
}

interface Found { key: string; text: string; page: string }

/** Mask the regions we must not touch, so the tag pass cannot see inside them. */
function maskedRegions(html: string): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (const tag of ['script', 'style', 'code', 'pre', 'textarea']) {
    const re = new RegExp(`<${tag}\\b[\\s\\S]*?</${tag}>`, 'gi');
    let m: RegExpExecArray | null;
    while ((m = re.exec(html))) out.push([m.index, m.index + m[0].length]);
  }
  return out;
}

function inMasked(pos: number, masked: Array<[number, number]>): boolean {
  return masked.some(([a, b]) => pos >= a && pos < b);
}

async function processPage(file: string, write: boolean) {
  const full = path.join(PUBLIC, file);
  let html = await fs.readFile(full, 'utf8');
  const found: Found[] = [];
  const mixed: string[] = [];
  const masked = maskedRegions(html);

  // <tag ...>text</tag> where text has no angle brackets: a pure-text element.
  const re = new RegExp(`<(${TEXT_TAGS.join('|')})(\\s[^>]*)?>([^<>]+)</\\1>`, 'g');
  html = html.replace(re, (whole, tag, attrs = '', text, offset: number) => {
    if (inMasked(offset, masked)) return whole;
    if (/data-i18n/.test(attrs)) return whole;
    if (!translatable(text)) return whole;
    const key = keyFor(text.trim());
    found.push({ key, text: text.trim(), page: file });
    return `<${tag}${attrs} data-i18n="${key}">${text}</${tag}>`;
  });

  /*
   * The commonest shape in this codebase, and the one that matters most:
   *
   *   <label class="field">Email<input id="email"></label>
   *
   * That is mixed content, so the pass above skipped it — and a form label is
   * exactly what somebody who cannot read English needs translated. The
   * leading text is wrapped in a span so it becomes taggable without moving
   * anything: a bare text node in a flex container is already an anonymous
   * flex item, so an explicit span renders identically.
   */
  html = html.replace(
    /(<label\b[^>]*>)([^<>]*[a-zA-Z]{2}[^<>]*)(<(?:input|select|textarea)\b)/g,
    (whole, open_, text, rest, offset: number) => {
      if (inMasked(offset, masked)) return whole;
      if (/data-i18n/.test(open_)) return whole;
      if (!translatable(text)) return whole;
      const key = keyFor(text.trim());
      found.push({ key, text: text.trim(), page: file });
      // Trailing whitespace is kept outside the span so spacing is unchanged.
      const trailing = text.match(/\s*$/)?.[0] ?? '';
      return `${open_}<span data-i18n="${key}">${text.trimEnd()}</span>${trailing}${rest}`;
    });

  // Attributes people read: placeholders, titles, aria labels.
  html = html.replace(/<(input|select|textarea|button|a|img)\b([^>]*)>/g, (whole, tag, attrs, offset: number) => {
    if (inMasked(offset, masked)) return whole;
    if (/data-i18n-attr/.test(attrs)) return whole;
    const pairs: string[] = [];
    for (const attr of ['placeholder', 'title', 'aria-label', 'alt']) {
      const m = attrs.match(new RegExp(`${attr}="([^"]+)"`));
      if (!m || !translatable(m[1])) continue;
      const key = keyFor(m[1]);
      found.push({ key, text: m[1], page: file });
      pairs.push(`${attr}:${key}`);
    }
    if (!pairs.length) return whole;
    return `<${tag}${attrs} data-i18n-attr="${pairs.join(', ')}">`;
  });

  // Elements with mixed content: reported, never rewritten.
  const mixedRe = new RegExp(`<(${TEXT_TAGS.join('|')})(\\s[^>]*)?>([^<>]*[a-zA-Z]{3}[^<>]*)<[a-z]`, 'g');
  let mm: RegExpExecArray | null;
  while ((mm = mixedRe.exec(html))) {
    if (inMasked(mm.index, masked)) continue;
    if (translatable(mm[3])) mixed.push(mm[3].trim().slice(0, 60));
  }

  // The runtime, once per page, before the page's own script runs.
  if (!html.includes('/static/i18n.js')) {
    html = html.replace('</head>', '  <script src="/static/i18n.js"></script>\n</head>');
  }

  if (write) await fs.writeFile(full, html);

  /*
   * The catalogue is read back out of the finished file, not taken from what
   * this run happened to insert.
   *
   * The first version returned `found` — only the newly tagged strings — so a
   * second run over an already-tagged page found almost nothing and wrote an
   * en.json with 71 keys instead of 270, silently dropping everything tagged
   * earlier. The file on disk is the truth; `found` is only news.
   */
  const catalogue: Found[] = [];
  for (const m of html.matchAll(/<([a-z0-9]+)[^>]*\sdata-i18n="([^"]+)"[^>]*>([^<>]*)</g)) {
    const text = m[3].trim();
    if (text) catalogue.push({ key: m[2], text, page: file });
  }
  // Attribute strings: the key is in data-i18n-attr, the English in the attribute.
  for (const m of html.matchAll(/<[a-z0-9]+[^>]*\sdata-i18n-attr="([^"]+)"[^>]*>/g)) {
    const tag = m[0];
    for (const pair of m[1].split(',')) {
      const [attr, key] = pair.split(':').map((x) => x.trim());
      if (!attr || !key) continue;
      const v = tag.match(new RegExp(`\\s${attr}="([^"]*)"`));
      if (v?.[1]) catalogue.push({ key, text: v[1], page: file });
    }
  }

  /*
   * The strings i18n-js.ts wrapped, read back out of the same file.
   *
   * This script is the ONLY writer of the catalogues, and it must therefore
   * see every key, not just the ones it put there itself. The first version
   * did not: it rewrote en.json from the markup alone, which silently deleted
   * the 131 keys the JS pass had added — the same clobbering mistake as
   * building the catalogue from `found`, one layer up. Two writers over one
   * file is the bug; there is now one writer that reads both sources.
   */
  for (const m of html.matchAll(/\bi18n\.t\('([a-z0-9_]+)',\s*'([^'\\\n]+)'\)/g)) {
    catalogue.push({ key: m[1], text: m[2], page: file });
  }

  return { found, mixed, catalogue };
}

const check = process.argv.includes('--check');
const all: Found[] = [];
const newlyTagged: Found[] = [];
const allMixed: Record<string, string[]> = {};

for (const page of PAGES) {
  const { found, mixed, catalogue } = await processPage(page, !check);
  all.push(...catalogue);
  newlyTagged.push(...found);
  if (mixed.length) allMixed[page] = mixed;
  console.log(`  ${page.padEnd(16)} ${String(catalogue.length).padStart(4)} tagged` +
              (found.length ? `  (+${found.length} new)` : '') +
              (mixed.length ? `  ·  ${mixed.length} mixed-content left for a human` : ''));
}

// One English source of truth, plus an empty file per language. Sorted, so a
// translator's diff shows only what actually changed.
const en: Record<string, string> = {};
for (const f of all) en[f.key] = f.text;
const sorted = Object.fromEntries(Object.keys(en).sort().map((k) => [k, en[k]]));

if (!check) {
  await fs.mkdir(OUT, { recursive: true });
  await fs.writeFile(path.join(OUT, 'en.json'), JSON.stringify(sorted, null, 2) + '\n');
  for (const lang of LANGS) {
    const file = path.join(OUT, `${lang}.json`);
    // Never overwrite work already done: existing translations are kept and
    // only new keys are added, empty.
    let existing: Record<string, string> = {};
    try { existing = JSON.parse(await fs.readFile(file, 'utf8')); } catch { /* first run */ }
    const merged: Record<string, string> = {};
    for (const k of Object.keys(sorted)) merged[k] = existing[k] ?? '';
    const done = Object.values(merged).filter((v) => v).length;
    await fs.writeFile(file, JSON.stringify(merged, null, 2) + '\n');
    console.log(`  ${lang}.json          ${done}/${Object.keys(merged).length} translated`);
  }
}

// How much of the interface is built in JavaScript and therefore still needs
// t() by hand. Counted rather than estimated.
let jsStrings = 0;
for (const page of PAGES) {
  const html = await fs.readFile(path.join(PUBLIC, page), 'utf8');
  const scripts = html.match(/<script>[\s\S]*?<\/script>/g) ?? [];
  for (const s of scripts) {
    for (const m of s.matchAll(/textContent:\s*'([^']{4,})'|textContent:\s*"([^"]{4,})"|toast\('([^']{4,})'\)/g)) {
      const text = m[1] ?? m[2] ?? m[3];
      if (text && translatable(text) && !text.includes('${')) jsStrings++;
    }
  }
}

console.log(`\n  ${Object.keys(sorted).length} unique strings in the markup`);
console.log(`  ~${jsStrings} more are built in JavaScript and need t() by hand`);
if (Object.keys(allMixed).length) {
  console.log('\n  Mixed-content elements a human should split (a sample):');
  for (const [page, list] of Object.entries(allMixed)) {
    console.log(`    ${page}: ${list.slice(0, 3).map((s) => JSON.stringify(s)).join(', ')}`);
  }
}
if (check && newlyTagged.length) {
  console.error(`\n  ${newlyTagged.length} untagged strings. Run without --check to tag them.`);
  process.exit(1);
}
