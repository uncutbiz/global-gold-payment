/**
 * Turn a translator's filled-in CSV back into a catalogue.
 *
 *   npx tsx scripts/i18n-import.ts es ~/Downloads/es-spanish.csv
 *   npm run i18n:import -- es ~/Downloads/es-spanish.csv
 *
 * The CSV goes out with three columns — key, english, <lang>_translation — and
 * comes back with the third filled in. This reads it, keeps only the rows whose
 * key is still in en.json, and writes public/i18n/<lang>.json.
 *
 * WHY A SCRIPT AND NOT A ONE-LINER
 *
 * The obvious regex over each line is wrong, and I shipped it wrong first:
 * these strings contain commas ("Send money anywhere, fast"), apostrophes, and
 * — once a translator has been near them — doubled quotes. A line-at-a-time
 * regex mangles all three, and a long sentence with a comma in it silently
 * becomes two broken columns. So this is a real CSV parser: quoted fields,
 * doubled quotes, embedded commas and newlines.
 *
 * It never deletes: a key the CSV leaves blank keeps whatever the catalogue
 * already had, so re-importing a partly-filled sheet cannot wipe finished work.
 */
import fs from 'node:fs/promises';
import path from 'node:path';

const LANGS = ['es', 'ht', 'sw', 'zh'];

/** RFC4180-ish: quoted fields, "" for a literal quote, commas and newlines inside them. */
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], field = '', quoted = false, i = 0;
  if (text.charCodeAt(0) === 0xfeff) i = 1;                 // Excel's BOM
  for (; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }      // escaped quote
        else quoted = false;
      } else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((f) => f.trim()));        // drop blank lines
}

const [lang, file] = process.argv.slice(2);
if (!lang || !file) {
  console.error('usage: tsx scripts/i18n-import.ts <lang> <file.csv>');
  console.error(`       lang is one of: ${LANGS.join(', ')}`);
  process.exit(2);
}
if (!LANGS.includes(lang)) {
  console.error(`  "${lang}" is not one of the shipped languages (${LANGS.join(', ')}).`);
  console.error('  Add it to SUPPORTED in public/i18n.js and to LANGS in the i18n scripts first.');
  process.exit(2);
}

const PUBLIC = path.join(import.meta.dirname, '..', 'public');
const en: Record<string, string> = JSON.parse(await fs.readFile(path.join(PUBLIC, 'i18n', 'en.json'), 'utf8'));
const target = path.join(PUBLIC, 'i18n', `${lang}.json`);
let current: Record<string, string> = {};
try { current = JSON.parse(await fs.readFile(target, 'utf8')); } catch { /* first import */ }

const rows = parseCsv(await fs.readFile(file, 'utf8'));
const header = rows.shift();
if (!header || header[0].trim().toLowerCase() !== 'key') {
  console.error(`  ${file} does not look like one of our sheets — the first column should be "key".`);
  console.error(`  Got: ${JSON.stringify(header?.slice(0, 3))}`);
  process.exit(1);
}

const out: Record<string, string> = {};
for (const k of Object.keys(en)) out[k] = current[k] ?? '';

let filled = 0, unchanged = 0, unknown: string[] = [], englishEdited: string[] = [];
for (const [key, english, translation] of rows) {
  const k = key?.trim();
  if (!k) continue;
  if (!(k in en)) { unknown.push(k); continue; }
  // A translator who "fixed" the English column is telling us something, but
  // this script only writes the translation — so say it rather than ignore it.
  if (english != null && english.trim() && english.trim() !== en[k].trim()) englishEdited.push(k);
  const v = (translation ?? '').trim();
  if (!v) { unchanged++; continue; }
  out[k] = v;
  filled++;
}

const sorted = Object.fromEntries(Object.keys(out).sort().map((k) => [k, out[k]]));
await fs.writeFile(target, JSON.stringify(sorted, null, 2) + '\n');

const done = Object.values(sorted).filter((v) => v).length;
console.log(`  ${filled} translations read from ${path.basename(file)}`);
console.log(`  ${unchanged} rows left blank — those stay as they were, and show English`);
console.log(`  public/i18n/${lang}.json now ${done}/${Object.keys(sorted).length} translated`);
if (unknown.length) {
  console.log(`\n  ${unknown.length} keys in the CSV are no longer in the app and were ignored:`);
  for (const k of unknown.slice(0, 5)) console.log(`    ${k}`);
  console.log('  (the copy changed since the sheet went out — re-export to get a current one)');
}
if (englishEdited.length) {
  console.log(`\n  ${englishEdited.length} rows had the English column edited. Not imported —`);
  console.log('  change the English in the page, then re-run "npm run i18n". Affected keys:');
  for (const k of englishEdited.slice(0, 5)) console.log(`    ${k}`);
}
console.log('\n  Reload the page and pick the language — no rebuild or restart needed.');
