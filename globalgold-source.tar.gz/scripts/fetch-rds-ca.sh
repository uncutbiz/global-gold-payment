#!/bin/sh
# Downloads the Amazon RDS certificate bundle into certs/ so the image can verify
# TLS to the database. Run it before building for AWS (CI does this automatically).
#   npm run fetch-rds-ca
set -eu
URL="${RDS_CA_URL:-https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem}"
OUT="$(dirname "$0")/../certs/rds-global-bundle.pem"
echo "Downloading $URL"
if command -v curl >/dev/null 2>&1; then curl -fsS -o "$OUT" "$URL"; else wget -qO "$OUT" "$URL"; fi
grep -q "BEGIN CERTIFICATE" "$OUT" || { echo "Downloaded file is not a certificate bundle" >&2; exit 1; }
echo "Saved $OUT ($(grep -c 'BEGIN CERTIFICATE' "$OUT") certificates)"
