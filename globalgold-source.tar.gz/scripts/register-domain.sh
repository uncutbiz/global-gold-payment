#!/usr/bin/env bash
#
#  Registers a domain in Route 53 and writes infra/aws/terraform.tfvars from it.
#
#    bash scripts/register-domain.sh globalgoldpay.com
#
#  It checks availability and the price first, shows you both, and only charges
#  your AWS account after you type YES. If the domain is already yours it skips
#  straight to writing the config.
#
#  Route 53's registrant details are a legal requirement (ICANN). The script asks
#  you for them; nothing is pre-filled. Privacy protection is switched on, so your
#  address does not appear in public WHOIS.
#
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

C_B=$'\033[36m'; C_G=$'\033[32m'; C_Y=$'\033[33m'; C_R=$'\033[31m'; C_D=$'\033[2m'; C_O=$'\033[0m'
say()  { printf '%s\n' "${C_B}▸${C_O} $*"; }
good() { printf '%s\n' "${C_G}✓${C_O} $*"; }
warn() { printf '%s\n' "${C_Y}!${C_O} $*"; }
die()  { printf '%s\n' "${C_R}✗ $*${C_O}" >&2; exit 1; }
# shellcheck disable=SC2034  # `out` is a nameref: assigning it writes the caller's variable
ask()  { # ask <prompt> <varname> [default] — keeps asking until it gets something
  local prompt="$1" default="${3:-}" value=''
  local -n out="$2"
  while [ -z "$value" ]; do
    if [ -n "$default" ]; then printf '  %s [%s]: ' "$prompt" "$default"; else printf '  %s: ' "$prompt"; fi
    read -r value || true
    [ -z "$value" ] && value="$default"
  done
  out="$value"
}

DOMAIN="${1:-}"
[ -n "$DOMAIN" ] || die "Usage: bash scripts/register-domain.sh yourdomain.com"
case "$DOMAIN" in *.*) ;; *) die "That does not look like a domain name: $DOMAIN" ;; esac
TLD="${DOMAIN##*.}"

# Route 53 domain registration lives only in us-east-1.
R53_REGION=us-east-1

command -v aws >/dev/null || die "The AWS CLI is not installed. Run: bash scripts/wsl-setup.sh"
command -v jq  >/dev/null || die "jq is not installed. Run: sudo apt-get install -y jq"
aws sts get-caller-identity >/dev/null 2>&1 || die "AWS is not signed in. Run: aws configure"
ACCOUNT="$(aws sts get-caller-identity --query Account --output text)"

printf '\nRegistering %s in AWS account %s\n\n' "$DOMAIN" "$ACCOUNT"

# ── already ours? ───────────────────────────────────────────────────────────
if aws route53domains get-domain-detail --region "$R53_REGION" --domain-name "$DOMAIN" >/dev/null 2>&1; then
  good "$DOMAIN is already registered in this account — skipping registration"
else

  say "Checking availability"
  AVAIL="$(aws route53domains check-domain-availability --region "$R53_REGION" \
    --domain-name "$DOMAIN" --query Availability --output text)"
  case "$AVAIL" in
    AVAILABLE) good "$DOMAIN is available" ;;
    UNAVAILABLE|UNAVAILABLE_PREMIUM|UNAVAILABLE_RESTRICTED)
      printf '\n'
      warn "$DOMAIN is not available ($AVAIL)."
      say "Suggestions"
      aws route53domains get-domain-suggestions --region "$R53_REGION" \
        --domain-name "$DOMAIN" --suggestion-count 8 --only-available \
        --query 'SuggestionsList[].DomainName' --output text 2>/dev/null | tr '\t' '\n' | sed 's/^/    /'
      die "Pick one and run this script again with it."
      ;;
    *) die "Could not determine availability (got: $AVAIL). Check your IAM permissions for route53domains." ;;
  esac

  say "Price"
  PRICE="$(aws route53domains list-prices --region "$R53_REGION" --tld "$TLD" \
    --query 'Prices[0].RegistrationPrice.[Price,Currency]' --output text 2>/dev/null || echo '')"
  if [ -n "$PRICE" ]; then
    printf '  %s per year, renewing automatically\n' "$(printf '%s' "$PRICE" | awk '{print $1" "$2}')"
  else
    warn "Could not read the price. A .com is normally about USD 14/year."
  fi

  # ── registrant details (ICANN requires real ones) ─────────────────────────
  printf '\n%sYour registrant details. ICANN requires these to be accurate; privacy\n' "$C_D"
  printf 'protection hides them from public WHOIS.%s\n\n' "$C_O"

  ask "First name"            REG_FIRST
  ask "Last name"             REG_LAST
  ask "Email"                 REG_EMAIL
  ask "Phone (e.g. +14155550123)" REG_PHONE
  ask "Street address"        REG_ADDR
  ask "City"                  REG_CITY
  ask "State/Province code (e.g. NY)" REG_STATE
  ask "Country code (e.g. US)" REG_COUNTRY US
  ask "Postal code"           REG_ZIP
  printf '  Is this for a company? Leave blank for personal.\n'
  printf '  Organization name []: '; read -r REG_ORG || REG_ORG=''

  CONTACT_TYPE=PERSON
  [ -n "$REG_ORG" ] && CONTACT_TYPE=COMPANY

  CONTACT="$(jq -nc \
    --arg first "$REG_FIRST" --arg last "$REG_LAST" --arg org "$REG_ORG" \
    --arg email "$REG_EMAIL" --arg phone "$REG_PHONE" --arg addr "$REG_ADDR" \
    --arg city "$REG_CITY" --arg state "$REG_STATE" --arg country "$REG_COUNTRY" \
    --arg zip "$REG_ZIP" --arg ctype "$CONTACT_TYPE" '
    {FirstName:$first, LastName:$last, ContactType:$ctype,
     AddressLine1:$addr, City:$city, State:$state, CountryCode:$country,
     ZipCode:$zip, PhoneNumber:$phone, Email:$email}
    | if $org != "" then .OrganizationName = $org else . end')"

  printf '\n%s──────────────────────────────────────────%s\n' "$C_Y" "$C_O"
  printf '  Domain:     %s\n' "$DOMAIN"
  printf '  Registrant: %s %s%s\n' "$REG_FIRST" "$REG_LAST" "$([ -n "$REG_ORG" ] && printf ' (%s)' "$REG_ORG")"
  printf '  Email:      %s\n' "$REG_EMAIL"
  printf '  Auto-renew: on      Privacy: on\n'
  printf '  This charges your AWS account %s.\n' "$ACCOUNT"
  printf '%s──────────────────────────────────────────%s\n\n' "$C_Y" "$C_O"
  printf 'Type YES to register: '
  read -r CONFIRM || CONFIRM=''
  [ "$CONFIRM" = "YES" ] || die "Not registered. Nothing was charged."

  say "Registering (AWS usually finishes in a few minutes)"
  OP="$(aws route53domains register-domain --region "$R53_REGION" --cli-input-json "$(jq -nc \
    --arg d "$DOMAIN" --argjson c "$CONTACT" '
    {DomainName:$d, DurationInYears:1, AutoRenew:true,
     AdminContact:$c, RegistrantContact:$c, TechContact:$c,
     PrivacyProtectAdminContact:true, PrivacyProtectRegistrantContact:true,
     PrivacyProtectTechContact:true}')" \
    --query OperationId --output text)" || die "Registration was refused. The error above says why."
  good "Submitted (operation $OP)"

  say "Waiting for AWS to complete it"
  for _ in $(seq 1 60); do
    STATUS="$(aws route53domains get-operation-detail --region "$R53_REGION" \
      --operation-id "$OP" --query Status --output text 2>/dev/null || echo PENDING)"
    case "$STATUS" in
      SUCCESSFUL) good "Registered" ; break ;;
      FAILED|ERROR)
        MSG="$(aws route53domains get-operation-detail --region "$R53_REGION" --operation-id "$OP" --query Message --output text 2>/dev/null)"
        die "Registration failed: $MSG" ;;
      *) printf '  %swaiting… (%s)%s\n' "$C_D" "$STATUS" "$C_O"; sleep 20 ;;
    esac
  done
  [ "${STATUS:-}" = "SUCCESSFUL" ] || warn "Still pending. AWS will email you; re-run this script afterwards to write the config."
fi

# ── hosted zone ─────────────────────────────────────────────────────────────
say "Finding the hosted zone"
ZONE_ID=''
for _ in $(seq 1 15); do
  ZONE_ID="$(aws route53 list-hosted-zones-by-name --dns-name "$DOMAIN." \
    --query "HostedZones[?Name=='$DOMAIN.'].Id | [0]" --output text 2>/dev/null || echo '')"
  [ -n "$ZONE_ID" ] && [ "$ZONE_ID" != "None" ] && break
  sleep 10; ZONE_ID=''
done
[ -n "$ZONE_ID" ] && [ "$ZONE_ID" != "None" ] \
  || die "No hosted zone for $DOMAIN yet. Wait a minute and run this script again."
ZONE_ID="${ZONE_ID##*/}"
good "Hosted zone $ZONE_ID"

# ── write terraform.tfvars ──────────────────────────────────────────────────
TFVARS=infra/aws/terraform.tfvars
if [ -f "$TFVARS" ]; then
  cp "$TFVARS" "$TFVARS.bak.$(date -u '+%Y%m%d%H%M%S')"
  warn "Existing $TFVARS backed up"
fi

ALARM_EMAIL="${REG_EMAIL:-}"
if [ -z "$ALARM_EMAIL" ]; then
  printf '  Email for infrastructure alarms: '
  read -r ALARM_EMAIL || ALARM_EMAIL=''
fi

sed \
  -e "s|^domain_name .*|domain_name     = \"staging.$DOMAIN\"|" \
  -e "s|^route53_zone_id .*|route53_zone_id = \"$ZONE_ID\"|" \
  -e "s|^alarm_email .*|alarm_email     = \"$ALARM_EMAIL\"|" \
  infra/aws/terraform.tfvars.staging.example >"$TFVARS"

good "Wrote $TFVARS"
printf '\n'
grep -E '^(region|environment|domain_name|route53_zone_id|alarm_email|db_|app_desired|single_nat)' "$TFVARS" | sed 's/^/    /'
printf '\n'
printf '%sNext:%s\n' "$C_Y" "$C_O"
printf '    make deploy-dry     # every command, nothing changed\n'
printf '    make deploy         # about 20-30 minutes\n\n'
printf 'Staging will be at %shttps://staging.%s%s\n' "$C_G" "$DOMAIN" "$C_O"
printf 'Production later: copy the tfvars, set environment = "production" and domain_name = "%s".\n\n' "$DOMAIN"
