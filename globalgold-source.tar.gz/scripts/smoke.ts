/**
 * Post-deploy smoke test. Runs the core journeys against a live (TEST-MODE)
 * deployment through its public API and prints a pass/fail line for each.
 *
 *   BASE_URL=https://pay.example.com ADMIN_TOKEN=... npm run smoke
 *   add SMOKE_SETTLE=1 to also run settlement and a payout
 *
 * It creates uniquely named test accounts and never deletes data.
 */
import crypto from 'node:crypto';

const BASE = (process.env.BASE_URL ?? 'http://localhost:4000').replace(/\/$/, '');
const ADMIN = process.env.ADMIN_TOKEN;
if (!ADMIN) { console.error('Set ADMIN_TOKEN (the bootstrap owner token) to run the smoke test.'); process.exit(2); }

const id = crypto.randomBytes(3).toString('hex');
const PNG = 'data:image/png;base64,' + Buffer.concat([Buffer.from('89504e470d0a1a0a', 'hex'), crypto.randomBytes(300)]).toString('base64');
/** true = passed, false = failed, null = skipped because the feature is off. */
const results: [string, boolean | null, string][] = [];

async function call(method: string, path: string, key?: string | null, body?: unknown) {
  const r = await fetch(BASE + path, { method, headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  if (!r.ok) throw new Error(`${method} ${path} → ${r.status} ${json?.error?.message ?? ''}`);
  return json;
}
async function step<T>(name: string, fn: () => Promise<T>): Promise<T | undefined> {
  const t = Date.now();
  try { const v = await fn(); results.push([name, true, `${Date.now() - t} ms`]); return v; }
  catch (e: any) { results.push([name, false, e.message]); return undefined; }
}

/**
 * A step for a feature that may be switched off. Testing a disabled feature and
 * calling it a failure would make every wallet-off deployment look broken, so
 * these are reported as skipped instead.
 */
async function optionalStep<T>(name: string, enabled: boolean, fn: () => Promise<T>): Promise<T | undefined> {
  if (!enabled) { results.push([name, null, 'feature is switched off']); return undefined; }
  return step(name, fn);
}
const must = (c: unknown, msg: string) => { if (!c) throw new Error(msg); };

await step('health check', async () => must((await call('GET', '/health')).ok, 'not ok'));

// What is switched on here? A deployment with WALLET_MODE=off has no stored
// value by design, so those journeys are skipped rather than counted as failures.
const platform = await step('platform reports what it supports', async () => call('GET', '/v1/platform'));
const F = platform?.features ?? { wallet_balances: true, person_to_person: true, pay_with_wallet: true, withdrawals: true };
console.log(`      provider ${platform?.provider ?? '?'} \u00b7 wallet ${platform?.wallet_mode ?? '?'} \u00b7 platform fee ${(platform?.platform_fee?.bps ?? 0) / 100}%`);
await step('home, wallet, business and admin pages load', async () => {
  for (const p of ['/', '/wallet', '/dashboard', '/admin']) {
    const r = await fetch(BASE + p); must(r.ok && (await r.text()).includes('Global'), `${p} failed`);
  }
});

const biz = await step('business signs up (pending review)', async () => {
  const s = await call('POST', '/v1/business/signup', null, { business_name: `Smoke Shop ${id}`, name: 'Smoke', email: `smoke-biz-${id}@example.com`, password: 'smoke-password', country: 'US', business_type: 'company' });
  must((await call('GET', '/v1/account', s.token)).status === 'pending_review', 'not pending');
  return s;
});
await step('staff approve the business', async () => {
  await call('POST', `/v1/admin/merchants/${biz!.merchant_id}/status`, ADMIN, { status: 'active' });
  must((await call('GET', '/v1/account', biz!.token)).status === 'active', 'not active');
});

const signup = (name: string, country: string) => call('POST', '/v1/wallet/signup', null, { email: `smoke-${name}-${id}@example.com`, name: `Smoke ${name}`, password: 'smoke-password', country });
const verify = async (u: any, country: string) => {
  const k = await call('POST', '/v1/wallet/kyc', u.token, { legal_name: u.user.name, date_of_birth: '1990-01-01', address_line: '1 Test St', city: 'Test', postal_code: '1000', country, id_type: 'passport', id_number: `SMK${id}${country}`, document: PNG });
  await call('POST', `/v1/admin/kyc/${k.id}/approve`, ADMIN, { note: 'smoke test' });
};
const payer = await step('customer signs up and passes identity check', async () => { const u = await signup('us', 'US'); await verify(u, 'US'); return u; });
const payee = await step('second customer (Nigeria) signs up and passes identity check', async () => { const u = await signup('ng', 'NG'); await verify(u, 'NG'); return u; });

await optionalStep('customer adds money by card', F.wallet_balances, async () => {
  const c = await call('POST', '/v1/wallet/cards', payer!.token, { card: { number: '4242424242424242', exp_month: 12, exp_year: 2040, cvc: '123' } });
  must((await call('POST', '/v1/wallet/top_ups', payer!.token, { amount: 50000, card: c.id })).balance === 50000, 'balance wrong');
});
await optionalStep('declined card is refused', F.wallet_balances, async () => {
  const c = await call('POST', '/v1/wallet/cards', payer!.token, { card: { number: '4000000000009995', exp_month: 12, exp_year: 2040, cvc: '123' } });
  try { await call('POST', '/v1/wallet/top_ups', payer!.token, { amount: 1000, card: c.id }); throw new Error('was accepted'); }
  catch (e: any) { must(/402/.test(e.message), e.message); }
});
await optionalStep('international transfer with a locked quote', F.person_to_person, async () => {
  const q = await call('POST', '/v1/wallet/transfer_quotes', payer!.token, { to: payee!.user.email, amount: 5000 });
  must(q.international && q.receive.currency === 'ngn', 'bad quote');
  const t = await call('POST', '/v1/wallet/transfers', payer!.token, { to: payee!.user.email, amount: 5000, quote: q.quote });
  must(t.recipient_received.amount === q.receive.amount, 'amount mismatch');
});
await optionalStep('currency conversion', F.wallet_balances, async () => must((await call('POST', '/v1/wallet/conversions', payee!.token, { from: 'ngn', to: 'usd', amount: 500000 })).to.amount > 0, 'no amount'));

const walletPi = await optionalStep('customer pays the business with Pay with Global Gold', F.pay_with_wallet, async () => {
  const pi = await call('POST', '/v1/payment_intents', biz!.token, { amount: 2500, currency: 'usd', description: 'smoke wallet' });
  must((await call('POST', `/v1/checkout/${pi.id}/pay_with_wallet`, payer!.token, { client_secret: pi.client_secret })).status === 'succeeded', 'not paid');
  return pi;
});
await step('card payment through hosted checkout', async () => {
  const pi = await call('POST', '/v1/payment_intents', biz!.token, { amount: 3000, currency: 'usd', description: 'smoke card' });
  must((await call('POST', `/v1/checkout/${pi.id}/pay`, null, { client_secret: pi.client_secret, card: { number: '4242424242424242', exp_month: 1, exp_year: 2041, cvc: '123' } })).status === 'succeeded', 'not paid');
});
await step('authorize now, capture part later', async () => {
  const keys = await call('POST', '/v1/account/keys/roll', biz!.token, {});
  const tok = await call('POST', '/v1/tokens', keys.publishable, { card: { number: '4242424242424242', exp_month: 1, exp_year: 2041, cvc: '123' } });
  const pi = await call('POST', '/v1/payment_intents', keys.secret, { amount: 4000, currency: 'usd', capture_method: 'manual', payment_token: tok.id, confirm: true });
  must(pi.status === 'requires_capture', pi.status);
  must((await call('POST', `/v1/payment_intents/${pi.id}/capture`, keys.secret, { amount_to_capture: 3000 })).amount_captured === 3000, 'capture');
});
await optionalStep('refund goes back to the wallet', F.pay_with_wallet, async () => {
  await call('POST', '/v1/refunds', biz!.token, { payment_intent: walletPi!.id, amount: 500 });
  must((await call('GET', '/v1/wallet/activity', payer!.token)).data[0].type === 'refund', 'no refund in activity');
});
await step('admin sees the transactions and alerts', async () => {
  // With the wallet switched off a customer has no wallet history, so check the
  // thing that is actually true either way: staff can see the payments taken.
  const path = F.wallet_balances
    ? `/v1/admin/transactions?user=${payer!.user.id}`
    : '/v1/admin/transactions?limit=50';
  const t = await call('GET', path, ADMIN);
  const need = F.wallet_balances ? 3 : 2;
  must(t.data.length >= need, `only ${t.data.length} rows, expected at least ${need}`);
  await call('GET', '/v1/admin/alerts?status=open', ADMIN);
});
if (process.env.SMOKE_SETTLE) {
  await step(F.wallet_balances ? 'settlement and payout to a wallet' : 'settlement and payout to a bank', async () => {
    // Paying out to a wallet needs the wallet; otherwise settle to the bank.
    if (F.wallet_balances) {
      await call('POST', '/v1/account', biz!.token, { payout_method: 'wallet', payout_wallet_email: payee!.user.email });
    } else {
      await call('POST', '/v1/account', biz!.token, { payout_method: 'bank' });
    }
    await call('POST', '/v1/admin/settlements/run', ADMIN, {});
    const po = await call('POST', '/v1/payouts', biz!.token, { currency: 'usd' });
    // A wallet payout is instant and lands as 'paid'; a bank payout leaves our
    // settlement account and sits 'in_transit' until the bank confirms it.
    if (F.wallet_balances) {
      must(po.destination === 'wallet' && po.status === 'paid', `expected a paid wallet payout, got ${po.destination}/${po.status}`);
    } else {
      must(po.destination === 'bank' && po.status === 'in_transit', `expected a bank payout in transit, got ${po.destination}/${po.status}`);
    }
  });
}
await step('ledger is balanced', async () => must((await call('GET', '/v1/admin/ledger/trial-balance', ADMIN)).balanced, 'OUT OF BALANCE'));

const width = Math.max(...results.map((r) => r[0].length));
for (const [name, ok, info] of results) {
  const mark = ok === null ? 'SKIP' : ok ? 'PASS' : 'FAIL';
  console.log(`${mark}  ${name.padEnd(width)}  ${info}`);
}
const failed = results.filter((r) => r[1] === false).length;
const skipped = results.filter((r) => r[1] === null).length;
const ran = results.length - skipped;
console.log(`\n${ran - failed}/${ran} checks passed against ${BASE}` +
  (skipped ? ` (${skipped} skipped: those features are switched off)` : ''));
process.exit(failed ? 1 : 0);
