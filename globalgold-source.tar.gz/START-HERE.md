# Start here

## Just want to see it working?

No AWS account, no domain, no keys. Double-click
**5 - RUN THE APP ON THIS PC** on your Desktop (or `make demo`). It starts the
database, fills it with demo businesses, customers and payments, opens your
browser, and prints the sign-in details. Start Docker Desktop first.

That is the whole platform running on your machine, with a simulated card
network — `4242 4242 4242 4242` approves and no money moves.

If the Desktop icons are not there yet, run
`scripts\windows\INSTALL-DESKTOP-ICONS.cmd` once.

## Want it on a server?

Two routes, and you can change your mind later:

- **One EC2 box** — `make ami` builds a machine image with everything already
  installed; launch it and it boots with the platform running. Cheapest and
  simplest; see `infra/ami/README.md`.
- **The full deployment** — load balancer, managed database, autoscaling, WAF.
  That is what the rest of this file is about.

---

**The short version:** install the toolchain once, then run one command and keep
running it until it says you are done.

```bash
bash scripts/setup.sh
```

It stops whenever it needs something only you can do — an AWS sign-in, a domain,
a Square application — tells you exactly what, and resumes when you run it
again. `bash scripts/setup.sh --status` shows what is left at any time.

The rest of this file is the longer walkthrough, starting from a fresh Windows
machine.

The deploy scripts are bash, and Docker Desktop already needs WSL2, so the work
happens inside Ubuntu with this folder mounted. Nothing moves off your machine,
and your AWS keys stay in `~/.aws`.

---

## 1. Windows setup — once

Press **Start**, type **PowerShell**, right-click **Windows PowerShell** → **Run as administrator**:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
cd "$HOME\Documents\GlobalGoldPayment"
.\scripts\windows\bootstrap.ps1
```

Installs Git, Docker Desktop and WSL2 Ubuntu. It may ask you to reboot, or to open
Ubuntu once to pick a Linux username — do that, then run it again. Safe to repeat.

Then start **Docker Desktop** once and turn on **Settings → Resources → WSL
integration → Ubuntu**.

## 2. Ubuntu toolchain — once

```bash
wsl
cd /mnt/c/Users/$USER/Documents/GlobalGoldPayment    # the path bootstrap.ps1 printed
bash scripts/wsl-setup.sh
```

Installs the AWS CLI, Terraform, Node 22, jq and make, then type-checks the project.

## 3. Sign in to AWS and register the domain

Get an access key: AWS console → **IAM → Users → your user → Security credentials
→ Create access key → Command Line Interface**. Then:

```bash
aws configure            # region us-east-2, output json
bash scripts/register-domain.sh globalgoldpay.com
```

Checks the domain is free, shows the price, asks for your registrant details, and
only charges after you type `YES`. It then finds the hosted zone and writes
`infra/aws/terraform.tfvars` for you. Re-running it is safe.

## 4. Run the setup

```bash
bash scripts/setup.sh
```

One command for everything that follows. It walks seven phases in order —
tools, AWS sign-in, domain, Square, deploy, secrets, verify — and stops at the
first one that needs you, printing exactly what to do. Run the same command
again and it carries on from there. Nothing is repeated, nothing is skipped.

```bash
bash scripts/setup.sh --status    # what is done, what is left
bash scripts/setup.sh --dry-run   # print everything, change nothing
```

`make deploy` still runs just the AWS part if you would rather drive it yourself:
nine steps in order — preflight, state bucket, registry, image, infrastructure,
release, admin login, live verification — stopping at the first problem.

It finishes by printing your URLs and an admin password, shown once.

---

## Afterwards

```bash
make release     # ship a code change
make verify      # re-run the live checks and the end-to-end smoke test
make logs        # tail the container logs
make outputs     # URLs, cluster, secret ARN
make destroy     # tear it down
make help        # everything
```

## Going to production

```bash
cp infra/aws/terraform.tfvars infra/aws/terraform.tfvars.staging   # keep a copy
```

Then edit `terraform.tfvars`: `environment = "production"`,
`domain_name = "globalgoldpay.com"`, `db_multi_az = true`,
`db_instance_class = "db.r7g.large"`, `app_desired_count = 2`,
`single_nat_gateway = false`. Run `make deploy` again.

## What this is not, yet

Test mode. The card network is simulated — `4242 4242 4242 4242` approves and no
money moves. Before you can charge a real card you need a sponsor bank or PayFac
agreement, a PCI DSS assessment by a QSA, and money-transmitter licensing for the
wallet. `DEPLOY.md` has the full checklist. A working staging deployment is what
you show a sponsor bank when you apply, but it does not shorten that path.

## If something goes wrong

Every deploy is logged to `.deploy-logs/`. Resume from where it stopped:

```bash
./scripts/deploy-aws.sh --from <step>     # ./scripts/deploy-aws.sh --list
```

Common ones: **Docker not reachable** — start Docker Desktop and enable WSL
integration. **Certificate stuck pending** — the domain must be in the Route 53
zone from step 3. **Elastic IP limit** — a NAT gateway needs one; the default
account limit is 5.
