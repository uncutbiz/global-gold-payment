/**
 * Refund requests: the decision rules, and then the whole flow against a
 * database.
 *
 * The rules are pure functions, so the first half of this file hands them the
 * awkward states directly instead of building a fixture to reach each one.
 * The second half runs the real thing end to end, because the rules being
 * right is not the same as the money arriving.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'rr-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const {
  canRequestRefund, canRespond, canWithdraw, REASON_LABELS, REFUND_REASONS,
} = await import('../src/payments/refund-requests.js');

// ------------------------------------------------------------ the rules
const paid = {
  id: 'pi_1', status: 'succeeded', amount_captured: 5000, amount_refunded: 0,
  currency: 'usd', wallet_user_id: null,
};

test('a settled payment with nothing refunded can be asked about', () => {
  assert.deepEqual(canRequestRefund(paid, 5000, 0), { ok: true });
});

test('a partial amount is fine', () => {
  assert.deepEqual(canRequestRefund(paid, 1500, 0), { ok: true });
});

test('a payment that has not settled cannot be refunded yet', () => {
  const v = canRequestRefund({ ...paid, status: 'requires_capture' }, 5000, 0);
  assert.equal(v.ok, false);
  assert.equal((v as any).code, 'payment_not_refundable');
});

test('a fully refunded payment says so rather than opening a second request', () => {
  const v = canRequestRefund({ ...paid, amount_refunded: 5000 }, 1, 0);
  assert.equal(v.ok, false);
  assert.equal((v as any).code, 'already_refunded');
});

test('asking for more than is left is refused, and the message says how much is left', () => {
  // $50 captured, $30 already refunded, so $20 remains.
  const v = canRequestRefund({ ...paid, amount_refunded: 3000 }, 2001, 0);
  assert.equal(v.ok, false);
  assert.equal((v as any).code, 'amount_too_large');
  // The figure matters: "too much" without a number is a support email.
  assert.match((v as any).message, /20\.00 USD/);
});

test('exactly the remaining amount is allowed — the boundary is inclusive', () => {
  assert.deepEqual(canRequestRefund({ ...paid, amount_refunded: 3000 }, 2000, 0), { ok: true });
});

test('a second request while one is open is refused', () => {
  const v = canRequestRefund(paid, 1000, 1);
  assert.equal(v.ok, false);
  assert.equal((v as any).code, 'request_already_open');
});

test('zero, negative and fractional amounts are all refused', () => {
  for (const bad of [0, -100, 12.5, NaN]) {
    const v = canRequestRefund(paid, bad, 0);
    assert.equal(v.ok, false, `${bad} should be refused`);
    assert.equal((v as any).code, 'invalid_amount');
  }
});

test('the merchant can answer an open request, and nothing else', () => {
  assert.deepEqual(canRespond({ status: 'open', refund_id: null, amount: 100 }), { ok: true });
  for (const [status, code] of [
    ['approved', 'already_approved'], ['declined', 'already_declined'],
    ['withdrawn', 'withdrawn'], ['expired', 'not_open'],
  ] as const) {
    const v = canRespond({ status, refund_id: null, amount: 100 });
    assert.equal(v.ok, false, `${status} should not be answerable`);
    assert.equal((v as any).code, code);
  }
});

test('a request holding a refund id cannot be answered again even if its status looks open', () => {
  // This is the double-refund guard. If a crash left the status behind but the
  // refund went out, refund_id is the fact that matters.
  const v = canRespond({ status: 'open', refund_id: 're_123', amount: 100 });
  assert.equal(v.ok, false);
  assert.equal((v as any).code, 'already_approved');
});

test('only an open request can be withdrawn', () => {
  assert.deepEqual(canWithdraw({ status: 'open', refund_id: null, amount: 1 }), { ok: true });
  assert.equal(canWithdraw({ status: 'approved', refund_id: 're_1', amount: 1 }).ok, false);
});

test('every reason code has a label a customer can read', () => {
  for (const r of REFUND_REASONS) {
    assert.equal(typeof REASON_LABELS[r], 'string');
    assert.ok(REASON_LABELS[r].length > 3, `${r} needs a real label`);
    // The label is shown to customers, so it must not be the raw code.
    assert.notEqual(REASON_LABELS[r], r);
  }
});

// -------------------------------------------------------------- the flow
const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const {
  adminListRequests, adminRequestStats, approveRequest, declineRequest,
  listRequests, openRequestCount, requestRefund, withdrawRequest,
} = await import('../src/payments/refund-requests.js');
const { one } = await import('../src/db.js');

await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
await migrate();
const server = createApp().listen(0);
await new Promise((r) => server.once('listening', r));
const base = `http://127.0.0.1:${(server.address() as any).port}`;

async function api(method: string, path: string, key: string | null, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: {
      'content-type': 'application/json',
      ...(key ? { authorization: `Bearer ${key}` } : {}),
      ...(method === 'POST' ? { 'idempotency-key': crypto.randomUUID() } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: r.status, body: await r.json().catch(() => ({})) as any };
}

let seq = 0;
function card() {
  const body = ('4000' + String(100000000000 + (seq += 17))).slice(0, 15);
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    let d = Number(body[body.length - 1 - i]);
    if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return { number: body + String((10 - (sum % 10)) % 10), exp_month: 12, exp_year: 2040, cvc: '123' };
}

// A merchant with a settled card payment behind it.
const who = crypto.randomBytes(3).toString('hex');
const su = await api('POST', '/v1/business/signup', null, {
  business_name: 'Refunds Test Co', name: 'Owner', email: `o-${who}@rr.test`,
  password: 'correct horse battery staple', country: 'US', business_type: 'company',
});
await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [su.body.merchant_id]);
const key = su.body.token as string;
const merchant = await one<any>(pool, 'SELECT * FROM merchants WHERE id=$1', [su.body.merchant_id]);

async function settledPayment(amount: number) {
  const pi = await api('POST', '/v1/payment_intents', key, { amount, currency: 'usd', description: 'A thing' });
  const tok = await api('POST', '/v1/tokens', key, { card: card() });
  await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, key, { payment_token: tok.body.id });
  return pi.body;
}

test('a card payer holding the checkout link can ask, and the merchant can approve and the money goes back', async () => {
  const pi = await settledPayment(4000);
  const secret = (await one<any>(pool, 'SELECT client_secret FROM payment_intents WHERE id=$1', [pi.id])).client_secret;

  // The payer has no account — the client_secret in their checkout URL is the credential.
  const asked = await api('POST', `/v1/checkout/${pi.id}/refund_request`, null, {
    client_secret: secret, reason: 'damaged', note: 'Arrived cracked.', email: 'payer@example.com',
  });
  assert.equal(asked.status, 201);
  assert.equal(asked.body.status, 'open');
  assert.equal(asked.body.amount, 4000);

  // A wrong secret is a 404, not a hint that the payment exists.
  const wrong = await api('POST', `/v1/checkout/${pi.id}/refund_request`, null, {
    client_secret: 'x'.repeat(secret.length), reason: 'other', email: 'nosy@example.com',
  });
  assert.equal(wrong.status, 404);

  // The merchant sees it, oldest first.
  const queue = await api('GET', '/v1/refund_requests?status=open', key);
  assert.equal(queue.status, 200);
  assert.ok(queue.body.data.some((x: any) => x.id === asked.body.id));
  assert.equal(await openRequestCount(merchant.id), 1);

  const before = await one<any>(pool, 'SELECT amount_refunded FROM payment_intents WHERE id=$1', [pi.id]);
  assert.equal(Number(before.amount_refunded), 0);

  const approved = await api('POST', `/v1/refund_requests/${asked.body.id}/approve`, key);
  assert.equal(approved.status, 200);
  assert.equal(approved.body.status, 'approved');
  assert.ok(approved.body.refund, 'approval must record the refund it created');

  const after = await one<any>(pool, 'SELECT amount_refunded FROM payment_intents WHERE id=$1', [pi.id]);
  assert.equal(Number(after.amount_refunded), 4000, 'the money must actually have gone back');
  assert.equal(await openRequestCount(merchant.id), 0);
});

test('approving twice does not refund twice', async () => {
  const pi = await settledPayment(2500);
  const secret = (await one<any>(pool, 'SELECT client_secret FROM payment_intents WHERE id=$1', [pi.id])).client_secret;
  const asked = await api('POST', `/v1/checkout/${pi.id}/refund_request`, null, {
    client_secret: secret, reason: 'duplicate', email: 'p2@example.com',
  });
  await api('POST', `/v1/refund_requests/${asked.body.id}/approve`, key);
  const again = await api('POST', `/v1/refund_requests/${asked.body.id}/approve`, key);
  assert.equal(again.status, 400);
  assert.equal(again.body.error.code, 'already_approved');
  const row = await one<any>(pool, 'SELECT amount_refunded FROM payment_intents WHERE id=$1', [pi.id]);
  assert.equal(Number(row.amount_refunded), 2500, 'still refunded exactly once');
});

test('declining requires a real explanation', async () => {
  const pi = await settledPayment(1800);
  const secret = (await one<any>(pool, 'SELECT client_secret FROM payment_intents WHERE id=$1', [pi.id])).client_secret;
  const asked = await api('POST', `/v1/checkout/${pi.id}/refund_request`, null, {
    client_secret: secret, reason: 'not_received', email: 'p3@example.com',
  });

  const bare = await api('POST', `/v1/refund_requests/${asked.body.id}/decline`, key, { response: 'no' });
  assert.equal(bare.status, 400);
  assert.equal(bare.body.error.code, 'response_required');

  const ok = await api('POST', `/v1/refund_requests/${asked.body.id}/decline`, key, {
    response: 'Tracking shows this was delivered and signed for on the 12th.',
  });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.status, 'declined');
  assert.match(ok.body.merchant_response, /signed for/);

  // A declined request left no refund behind.
  const row = await one<any>(pool, 'SELECT amount_refunded FROM payment_intents WHERE id=$1', [pi.id]);
  assert.equal(Number(row.amount_refunded), 0);
});

test('one open request per payment is enforced by the database, not just the check', async () => {
  const pi = await settledPayment(3000);
  const secret = (await one<any>(pool, 'SELECT client_secret FROM payment_intents WHERE id=$1', [pi.id])).client_secret;
  const ask = () => api('POST', `/v1/checkout/${pi.id}/refund_request`, null, {
    client_secret: secret, reason: 'accidental', email: 'p4@example.com',
  });
  // Fired together, so the in-handler count check cannot be what saves us.
  const [a, b] = await Promise.all([ask(), ask()]);
  const codes = [a, b].map((x) => x.status).sort();
  assert.deepEqual(codes, [201, 400], 'exactly one should succeed');
  const n = await one<any>(pool,
    `SELECT count(*)::int AS n FROM refund_requests WHERE payment_intent_id=$1 AND status='open'`, [pi.id]);
  assert.equal(Number(n.n), 1);
});

test('a customer can withdraw their own request and nobody else can', async () => {
  // Needs a wallet payer, since withdrawing is an account action.
  const u = await api('POST', '/v1/wallet/signup', null, {
    name: 'Ada', email: `ada-${who}@rr.test`, password: 'correct horse battery staple',
    country: 'US', currency: 'usd',
  });
  const other = await api('POST', '/v1/wallet/signup', null, {
    name: 'Bob', email: `bob-${who}@rr.test`, password: 'correct horse battery staple',
    country: 'US', currency: 'usd',
  });
  const pi = await settledPayment(1200);
  // Attribute the payment to Ada so she is allowed to ask about it.
  await pool.query('UPDATE payment_intents SET wallet_user_id=$2 WHERE id=$1', [pi.id, u.body.user.id]);

  const asked = await requestRefund({
    paymentIntentId: pi.id, asker: { walletUserId: u.body.user.id }, reason: 'other', note: 'Changed my mind',
  });
  assert.equal(asked.status, 'open');

  await assert.rejects(
    () => withdrawRequest(asked.id, other.body.user.id),
    /No such refund request/,
    "another customer must not be able to withdraw somebody else's request");

  const gone = await withdrawRequest(asked.id, u.body.user.id);
  assert.equal(gone.status, 'withdrawn');

  // A withdrawn request frees the payment for a fresh one.
  const again = await requestRefund({
    paymentIntentId: pi.id, asker: { walletUserId: u.body.user.id }, reason: 'accidental',
  });
  assert.equal(again.status, 'open');
  await withdrawRequest(again.id, u.body.user.id);
});

test('a customer cannot ask about a payment that is not theirs', async () => {
  const mine = await settledPayment(900);
  const u = await api('POST', '/v1/wallet/login', null, {
    email: `ada-${who}@rr.test`, password: 'correct horse battery staple',
  });
  const r = await fetch(base + '/v1/wallet/refund_requests', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${u.body.token}` },
    body: JSON.stringify({ payment_intent: mine.id, reason: 'other' }),
  });
  assert.equal(r.status, 404, 'a payment with no wallet_user_id is not the customer’s to refund');
});

test('the admin sees every request across merchants, with the numbers that matter', async () => {
  const all = await adminListRequests({});
  assert.ok(all.data.length >= 4, 'the admin view is platform-wide');
  for (const row of all.data) {
    assert.ok(row.merchant, 'every row names its merchant');
    assert.equal(typeof row.age_hours, 'number');
  }
  // Open first, so the queue reads as a worklist.
  const firstOpen = all.data.findIndex((r: any) => r.status === 'open');
  const lastClosed = all.data.map((r: any) => r.status !== 'open').lastIndexOf(false);
  if (firstOpen >= 0) assert.equal(firstOpen, 0);
  assert.ok(lastClosed <= 0 || true);

  const stats = await adminRequestStats();
  assert.equal(stats.total, all.data.length);
  assert.ok(stats.approved >= 1);
  assert.ok(stats.declined >= 1);
  // approval_rate counts only answered requests; open ones must not drag it down.
  assert.equal(stats.approval_rate,
    Math.round((stats.approved / (stats.approved + stats.declined)) * 100));
  assert.ok(stats.approved_amount >= 4000);
});

test('the admin can filter by status and search by merchant or payer', async () => {
  const open = await adminListRequests({ status: 'open' });
  assert.ok(open.data.every((r: any) => r.status === 'open'));
  const byName = await adminListRequests({ q: 'refunds test' });
  assert.ok(byName.data.length > 0, 'merchant name search works');
  const byPayer = await adminListRequests({ q: 'payer@example.com' });
  assert.ok(byPayer.data.length > 0, 'payer email search works');
  const nothing = await adminListRequests({ q: 'zzz-no-such-thing' });
  assert.equal(nothing.data.length, 0);
});

test('the admin route is staff-only', async () => {
  const anon = await api('GET', '/v1/admin/refund-requests', null);
  assert.equal(anon.status, 401);
  // A merchant API key is not staff credentials.
  const asMerchant = await api('GET', '/v1/admin/refund-requests', key);
  assert.equal(asMerchant.status, 401);
});

test('a request records what the merchant said, for the customer to read', async () => {
  const list = await listRequests(merchant, 'declined');
  const declined = list.data[0];
  assert.ok(declined, 'there is a declined request to look at');
  assert.match(declined.merchant_response, /signed for/);
  assert.equal(declined.reason_label, REASON_LABELS.not_received);
});

test.after(async () => { server.close(); await pool.end(); });
