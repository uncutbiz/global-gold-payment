/**
 * The pages must work over plain HTTP.
 *
 * A handful of browser APIs exist ONLY in a "secure context" — HTTPS, or
 * localhost. On a server reached by bare IP over http://, they are simply
 * undefined, and calling one throws.
 *
 * This bit twice in one page: `crypto.randomUUID()` built the idempotency key
 * for every POST from the merchant dashboard, so on a plain-HTTP server every
 * write failed before the request was sent — the dashboard looked completely
 * broken while the API behind it was fine.
 *
 * What makes this worth a dedicated test is that the OBVIOUS test does not
 * catch it: a browser test drives the page on http://127.0.0.1, and localhost
 * is a secure context, so randomUUID is there and everything passes. The bug
 * only appears on a real server. So this checks the source instead, and it
 * also covers pages nobody has written yet.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';

const PUBLIC = path.join(import.meta.dirname, '..', 'public');

/**
 * APIs that are undefined outside a secure context, with the evidence that a
 * given use of one has been guarded. A guard is either a feature test or an
 * explicit `window.isSecureContext` check on the same or a nearby line.
 */
const RESTRICTED = [
  { api: 'crypto.randomUUID', guards: ["typeof crypto.randomUUID === 'function'", 'crypto.randomUUID &&'] },
  { api: 'crypto.subtle', guards: ["typeof crypto.subtle", 'crypto.subtle &&', 'window.isSecureContext'] },
  { api: 'navigator.clipboard', guards: ['navigator.clipboard &&', 'window.isSecureContext'] },
  { api: 'navigator.credentials', guards: ['navigator.credentials &&', 'window.isSecureContext'] },
  { api: 'navigator.geolocation', guards: ['navigator.geolocation &&', 'window.isSecureContext'] },
];

async function pages() {
  const names = (await fs.readdir(PUBLIC)).filter((f) => f.endsWith('.html'));
  return Promise.all(names.map(async (name) => ({
    name, text: await fs.readFile(path.join(PUBLIC, name), 'utf8'),
  })));
}

describe('pages served over plain http', () => {
  it('never calls a secure-context-only API without a guard', async () => {
    const problems: string[] = [];

    for (const page of await pages()) {
      const lines = page.text.split('\n');
      for (const { api, guards } of RESTRICTED) {
        lines.forEach((line, i) => {
          // A comment explaining the problem is not the problem.
          const code = line.replace(/\/\/.*$/, '').replace(/^\s*\*.*$/, '');
          if (!code.includes(api)) return;

          // Guarded on this line, or within the three lines above it.
          const near = lines.slice(Math.max(0, i - 3), i + 1).join('\n');
          if (guards.some((g) => near.includes(g))) return;

          problems.push(`${page.name}:${i + 1}  ${api}  ->  ${line.trim().slice(0, 90)}`);
        });
      }
    }

    assert.deepEqual(problems, [],
      'These only exist on HTTPS or localhost, so they are undefined on a plain-http server:\n'
      + problems.join('\n'));
  });

  it('the dashboard can still make an idempotency key without randomUUID', async () => {
    const src = (await pages()).find((p) => p.name === 'dashboard.html')!.text;
    const fn = src.match(/function uuid\(\)[\s\S]*?\n\}/)?.[0];
    assert.ok(fn, 'dashboard.html should define uuid()');

    // Run it with randomUUID missing, which is exactly what a plain-http
    // server gives the page.
    const insecure = {
      getRandomValues: (a: Uint8Array) => { for (let i = 0; i < a.length; i++) a[i] = (i * 37 + 11) & 0xff; return a; },
    };
    const make = new Function('crypto', 'Uint8Array', `${fn}; return uuid;`)(insecure, Uint8Array);
    const id = make();

    assert.match(id, /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/,
      `expected a v4 UUID without randomUUID, got ${id}`);
  });

  it('produces different keys each time, or idempotency would collapse', async () => {
    const src = (await pages()).find((p) => p.name === 'dashboard.html')!.text;
    const fn = src.match(/function uuid\(\)[\s\S]*?\n\}/)?.[0]!;
    // Real randomness this time, still with randomUUID absent.
    const nodeCrypto = await import('node:crypto');
    const insecure = { getRandomValues: (a: Uint8Array) => { nodeCrypto.randomFillSync(a); return a; } };
    const make = new Function('crypto', 'Uint8Array', `${fn}; return uuid;`)(insecure, Uint8Array);

    const seen = new Set<string>();
    for (let i = 0; i < 500; i++) seen.add(make());
    assert.equal(seen.size, 500, 'every idempotency key must be distinct');
  });
});
