/**
 * Disputes and invoices.
 *
 * The dispute tests matter most. A chargeback moves money before anyone here
 * knows about it, the notification arrives by webhook, and processors retry
 * webhooks — so "the reversal happens exactly once, whatever arrives and in
 * whatever order" is the property under test, and it is tested against the
 * ledger rather than against a status column.
 *
 * The invoice tests are mostly about arithmetic that cannot be influenced from
 * outside: totals come from the lines, tax rounds per line, and a sent invoice
 * cannot be edited underneath the customer who agreed to it.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-dispinv';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'off';
process.env.CARD_RATE_LIMIT = '1000';
process.env.AUTH_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { handleProviderEvent } = await import('../src/webhooks/provider-events.js');
const { normaliseStatus } = await import('../src/payments/disputes.js');

let base = '';
let server: http.Server;

async function api(method: string, path: string, key?: string, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: {
      'content-type': 'application/json',
      ...(key ? { authorization: `Bearer ${key}` } : {}),
      ...(method === 'POST' ? { 'idempotency-key': crypto.randomUUID() } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json, text };
}

/** A fresh valid card each time — the risk engine blocks a reused one. */
let cardSeq = 0;
function testCard() {
  const body = ('4000' + String(100000000000 + (cardSeq += 7))).slice(0, 15);
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    let d = Number(body[body.length - 1 - i]);
    if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return { number: body + String((10 - (sum % 10)) % 10), exp_month: 12, exp_year: 2040, cvc: '123' };
}

async function business() {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await api('POST', '/v1/business/signup', undefined, {
    business_name: `Shop ${who}`, name: 'Owner', email: `di-${who}@test.com`,
    password: 'a-long-password-123', country: 'US', business_type: 'company',
  });
  await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [r.body.merchant_id]);
  return { key: r.body.token as string, id: r.body.merchant_id as string };
}

async function customer(key: string) {
  const r = await api('POST', '/v1/customers', key,
    { email: `c-${crypto.randomBytes(4).toString('hex')}@test.com`, name: 'Ada' });
  return r.body.id as string;
}

/** A completed payment, with a processor payment id so a dispute can find it. */
async function paidIntent(key: string, amount: number, providerPaymentId: string) {
  const pi = await api('POST', '/v1/payment_intents', key, { amount, currency: 'usd' });
  const tok = await api('POST', '/v1/tokens', key, { card: testCard() });
  const done = await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, key,
    { payment_token: tok.body.id });
  assert.equal(done.body.status, 'succeeded', done.text);
  await pool.query('UPDATE payment_intents SET provider_payment_id=$2 WHERE id=$1',
    [pi.body.id, providerPaymentId]);
  return pi.body.id as string;
}

/**
 * Everything the ledger says this merchant is owed — pending AND available.
 *
 * Reading only `available` would miss a fresh payment, which sits in `pending`
 * until settlement runs. A chargeback is debited from `available` and is
 * allowed to take it negative, which is the honest representation: the
 * merchant owes that money back.
 */
async function merchantPosition(merchantId: string, currency = 'usd') {
  const r = await pool.query(
    `SELECT coalesce(sum(credit) - sum(debit), 0)::bigint AS bal
       FROM ledger_lines WHERE account = ANY($1) AND currency = $2`,
    [[`merchant:${merchantId}:available`, `merchant:${merchantId}:pending`], currency]);
  return Number(r.rows[0].bal);
}

function stripeDisputeEvent(id: string, paymentId: string, amount: number, status: string) {
  return {
    id: `evt_${crypto.randomBytes(6).toString('hex')}`,
    type: 'charge.dispute.created',
    data: { object: {
      id, payment_intent: paymentId, amount, currency: 'usd', status,
      reason: 'fraudulent',
      evidence_details: { due_by: Math.floor(Date.now() / 1000) + 10 * 86400 },
    } },
  };
}

let shop: { key: string; id: string };

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  shop = await business();
});

after(async () => { server?.close(); await pool.end(); });

describe('dispute status names', () => {
  it('maps both processors onto the same five words', async () => {
    assert.equal(normaliseStatus('square', 'EVIDENCE_REQUIRED'), 'needs_response');
    assert.equal(normaliseStatus('square', 'PROCESSING'), 'under_review');
    assert.equal(normaliseStatus('square', 'WON'), 'won');
    assert.equal(normaliseStatus('square', 'LOST'), 'lost');
    assert.equal(normaliseStatus('stripe', 'needs_response'), 'needs_response');
    assert.equal(normaliseStatus('stripe', 'under_review'), 'under_review');
    assert.equal(normaliseStatus('stripe', 'won'), 'won');
    // Unknown must not be dropped: it still needs a human before a deadline.
    assert.equal(normaliseStatus('stripe', 'something_new'), 'needs_response');
    assert.equal(normaliseStatus('square', ''), 'needs_response');
  });
});

describe('a chargeback', () => {
  it('takes the money back once, and records the deadline', async () => {
    const pid = `pay_${crypto.randomBytes(5).toString('hex')}`;
    const intent = await paidIntent(shop.key, 40_000, pid);
    const before = await merchantPosition(shop.id);
    assert.ok(before > 0, 'the payment should have credited the merchant');

    const r = await handleProviderEvent('stripe', 'charge.dispute.created',
      stripeDisputeEvent('dp_1', pid, 40_000, 'needs_response'));
    assert.equal(r.handled, true);

    const list = await api('GET', '/v1/disputes', shop.key);
    assert.equal(list.body.data.length, 1);
    const d = list.body.data[0];
    assert.equal(d.amount, 40_000);
    assert.equal(d.status, 'needs_response');
    assert.equal(d.reason, 'fraudulent');
    assert.equal(d.money_taken_back, true);
    assert.ok(d.evidence_due_by, 'the deadline is the whole point');

    const after = await merchantPosition(shop.id);
    assert.ok(after < before, `balance should have fallen: ${before} -> ${after}`);

    // The payment itself is marked, so it does not look untouched.
    const pi = await api('GET', `/v1/payment_intents/${intent}`, shop.key);
    assert.equal(pi.status, 200);
  });

  it('does not take it back twice when the webhook is retried', async () => {
    const pid = `pay_${crypto.randomBytes(5).toString('hex')}`;
    await paidIntent(shop.key, 25_000, pid);
    const before = await merchantPosition(shop.id);

    const ev = stripeDisputeEvent('dp_retry', pid, 25_000, 'needs_response');
    await handleProviderEvent('stripe', 'charge.dispute.created', ev);
    const once = await merchantPosition(shop.id);

    // Same dispute, delivered four more times — as a processor does.
    for (let i = 0; i < 4; i++) {
      await handleProviderEvent('stripe', 'charge.dispute.updated', ev);
    }
    const after = await merchantPosition(shop.id);

    assert.equal(after, once, 'the reversal must not repeat');
    assert.ok(once < before);

    const rows = await pool.query(`SELECT count(*)::int AS n FROM disputes WHERE provider_dispute_id='dp_retry'`);
    assert.equal(rows.rows[0].n, 1, 'one dispute row, not five');

    const j = await pool.query(
      `SELECT count(*)::int AS n FROM journals WHERE ref_type='dispute' AND ref_id=(
         SELECT id FROM disputes WHERE provider_dispute_id='dp_retry')`);
    assert.equal(j.rows[0].n, 1, 'one ledger entry, not five');
  });

  it('gives the money back when it is won, and only once', async () => {
    const pid = `pay_${crypto.randomBytes(5).toString('hex')}`;
    await paidIntent(shop.key, 30_000, pid);
    const start = await merchantPosition(shop.id);

    await handleProviderEvent('stripe', 'charge.dispute.created',
      stripeDisputeEvent('dp_won', pid, 30_000, 'needs_response'));
    const taken = await merchantPosition(shop.id);
    assert.ok(taken < start);

    const won = { ...stripeDisputeEvent('dp_won', pid, 30_000, 'won'), type: 'charge.dispute.closed' };
    await handleProviderEvent('stripe', 'charge.dispute.closed', won);
    const back = await merchantPosition(shop.id);
    assert.equal(back, start, 'winning restores the merchant to where they were');

    // Repeated "won" deliveries must not keep crediting.
    for (let i = 0; i < 3; i++) await handleProviderEvent('stripe', 'charge.dispute.closed', won);
    assert.equal(await merchantPosition(shop.id), start, 'no repeated credit');
  });

  it('will not let a late webhook reopen a decided dispute', async () => {
    const pid = `pay_${crypto.randomBytes(5).toString('hex')}`;
    await paidIntent(shop.key, 12_000, pid);

    await handleProviderEvent('stripe', 'charge.dispute.created',
      stripeDisputeEvent('dp_order', pid, 12_000, 'needs_response'));
    await handleProviderEvent('stripe', 'charge.dispute.closed',
      stripeDisputeEvent('dp_order', pid, 12_000, 'lost'));
    // An out-of-order redelivery of the earlier state.
    await handleProviderEvent('stripe', 'charge.dispute.updated',
      stripeDisputeEvent('dp_order', pid, 12_000, 'needs_response'));

    const d = (await api('GET', '/v1/disputes', shop.key)).body.data
      .find((x: any) => x.id && x.amount === 12_000);
    assert.equal(d.status, 'lost', 'a decided dispute stays decided');
  });

  it('lets the merchant answer it, or give up', async () => {
    const pid = `pay_${crypto.randomBytes(5).toString('hex')}`;
    await paidIntent(shop.key, 8_000, pid);
    await handleProviderEvent('stripe', 'charge.dispute.created',
      stripeDisputeEvent('dp_eviq', pid, 8_000, 'needs_response'));
    const id = (await pool.query(`SELECT id FROM disputes WHERE provider_dispute_id='dp_eviq'`)).rows[0].id;

    const ev = await api('POST', `/v1/disputes/${id}/evidence`, shop.key,
      { receipt: 'Signed delivery note', customer_email: 'they collected it in person' });
    assert.equal(ev.status, 200, ev.text);
    assert.equal(ev.body.status, 'under_review');
    assert.equal(ev.body.evidence_submitted, true);

    // Once it is under review, evidence cannot be sent again.
    assert.equal((await api('POST', `/v1/disputes/${id}/evidence`, shop.key, { more: 'x' })).status, 400);
  });

  it('refuses evidence after the deadline', async () => {
    const pid = `pay_${crypto.randomBytes(5).toString('hex')}`;
    await paidIntent(shop.key, 9_000, pid);
    await handleProviderEvent('stripe', 'charge.dispute.created',
      stripeDisputeEvent('dp_late', pid, 9_000, 'needs_response'));
    await pool.query(
      `UPDATE disputes SET evidence_due_by = now() - interval '1 day' WHERE provider_dispute_id='dp_late'`);
    const id = (await pool.query(`SELECT id FROM disputes WHERE provider_dispute_id='dp_late'`)).rows[0].id;

    const r = await api('POST', `/v1/disputes/${id}/evidence`, shop.key, { receipt: 'too late' });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'dispute_expired');
  });

  it('refuses to invent a merchant for an unmatched dispute', async () => {
    // Deliberately loud rather than silent. A dispute we cannot attach to a
    // payment is either a payment from before this platform or a bug, and
    // both need a human — dropping it quietly is how a real chargeback goes
    // unanswered until the deadline passes. The webhook route catches this,
    // logs it, and still answers 200 so the processor stops retrying; the
    // stored event is the replay path.
    await assert.rejects(
      () => handleProviderEvent('stripe', 'charge.dispute.created',
        stripeDisputeEvent('dp_orphan', 'pay_not_here', 5_000, 'needs_response')),
      /does not match any payment/);
  });

  it('shows a stranger nothing', async () => {
    const other = await business();
    assert.equal((await api('GET', '/v1/disputes', other.key)).body.data.length, 0);
  });
});

describe('invoices', () => {
  it('computes its own totals, taxing each line', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd', title: 'September work',
      lines: [
        { description: 'Design, 7.5 hours', quantity: 7.5, unit_amount: 12_000, tax_bps: 2000 },
        { description: 'Hosting', unit_amount: 3_000 },
      ],
    });
    assert.equal(inv.status, 201, inv.text);
    // 7.5 x 120.00 = 900.00, +20% tax = 180.00 ; hosting 30.00 untaxed
    assert.equal(inv.body.subtotal, 93_000);
    assert.equal(inv.body.tax_total, 18_000);
    assert.equal(inv.body.total, 111_000);
    assert.equal(inv.body.status, 'draft');
    assert.equal(inv.body.payment_url, null, 'a draft is not payable');
    assert.match(inv.body.number, /^INV-\d{4}$/);
  });

  it('rounds tax per line, not on the total', async () => {
    // Two lines of 3.33 at 10%. Per line: round(33.3) = 33 each, so 66.
    // Taxing the sum instead: round(66.6) = 67. One penny, every invoice,
    // and it is the penny an accountant reconciles against the printed lines.
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd',
      lines: [
        { description: 'A', unit_amount: 333, tax_bps: 1000 },
        { description: 'B', unit_amount: 333, tax_bps: 1000 },
      ],
    });
    assert.equal(inv.body.subtotal, 666);
    assert.equal(inv.body.tax_total, 66, 'per-line rounding gives 66; taxing the total gives 67');
    assert.equal(inv.body.total, 732);
    // And the printed lines must add up to the printed total.
    const lineTax = inv.body.lines.reduce((n: number, l: any) => n + l.tax, 0);
    assert.equal(lineTax, inv.body.tax_total, 'the column of numbers must equal the total');
  });

  it('numbers per merchant, so a customer cannot infer platform volume', async () => {
    const a = await business(); const b = await business();
    const ca = await customer(a.key); const cb = await customer(b.key);
    const line = [{ description: 'x', unit_amount: 1_000 }];
    const ia = await api('POST', '/v1/invoices', a.key, { customer: ca, currency: 'usd', lines: line });
    const ib = await api('POST', '/v1/invoices', b.key, { customer: cb, currency: 'usd', lines: line });
    assert.equal(ia.body.number, 'INV-0001');
    assert.equal(ib.body.number, 'INV-0001', 'each merchant starts at one');
  });

  it('recomputes when lines change, and ignores any total sent by the caller', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd',
      lines: [{ description: 'One', unit_amount: 5_000 }],
      // If this were trusted, anyone could bill a customer for a penny.
      total: 1, subtotal: 1,
    } as any);
    assert.equal(inv.body.total, 5_000);

    const added = await api('POST', `/v1/invoices/${inv.body.id}/lines`, shop.key,
      { description: 'Two', unit_amount: 2_500, tax_bps: 1000 });
    assert.equal(added.body.total, 7_500 + 250);

    const lineId = added.body.lines[1].id;
    const removed = await api('DELETE', `/v1/invoices/${inv.body.id}/lines/${lineId}`, shop.key);
    assert.equal(removed.body.total, 5_000);
  });

  it('becomes payable when sent, and paying it settles the invoice', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd',
      lines: [{ description: 'Consulting', unit_amount: 45_000 }],
    });
    const sent = await api('POST', `/v1/invoices/${inv.body.id}/send`, shop.key);
    assert.equal(sent.body.status, 'open');
    assert.ok(sent.body.payment_url, 'sending creates the payment link');

    const code = sent.body.payment_url.split('/').pop();
    const made = await api('POST', `/v1/pay/${code}/intent`, undefined, {});
    assert.equal(made.status, 201, made.text);
    const paid = await api('POST', `/v1/checkout/${made.body.payment_intent}/pay`, undefined, {
      client_secret: made.body.client_secret, card: testCard(),
    });
    assert.equal(paid.body.status, 'succeeded', paid.text);

    const after = await api('GET', `/v1/invoices/${inv.body.id}`, shop.key);
    assert.equal(after.body.status, 'paid');
    assert.equal(after.body.amount_paid, 45_000);
    assert.equal(after.body.amount_due, 0);
    assert.ok(after.body.paid_at);
  });

  it('cannot be edited once the customer has it', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd', lines: [{ description: 'Work', unit_amount: 10_000 }],
    });
    await api('POST', `/v1/invoices/${inv.body.id}/send`, shop.key);
    const r = await api('POST', `/v1/invoices/${inv.body.id}/lines`, shop.key,
      { description: 'Surprise extra', unit_amount: 50_000 });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'invoice_not_editable');
  });

  it('voids without deleting, and the link stops working', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd', lines: [{ description: 'Cancelled job', unit_amount: 20_000 }],
    });
    const sent = await api('POST', `/v1/invoices/${inv.body.id}/send`, shop.key);
    const code = sent.body.payment_url.split('/').pop();

    const v = await api('POST', `/v1/invoices/${inv.body.id}/void`, shop.key);
    assert.equal(v.body.status, 'void');
    // The number is kept — a gap in the sequence is what an auditor asks about.
    assert.equal(v.body.number, inv.body.number);
    assert.equal((await api('GET', `/v1/pay/${code}`)).status, 410, 'nobody can still pay it');
  });

  it('refuses to send an empty invoice', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, { customer: cus, currency: 'usd' });
    const r = await api('POST', `/v1/invoices/${inv.body.id}/send`, shop.key);
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'invoice_empty');
  });

  it('will not void one that has been paid', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd', lines: [{ description: 'Done', unit_amount: 6_000 }],
    });
    const sent = await api('POST', `/v1/invoices/${inv.body.id}/send`, shop.key);
    const code = sent.body.payment_url.split('/').pop();
    const made = await api('POST', `/v1/pay/${code}/intent`, undefined, {});
    await api('POST', `/v1/checkout/${made.body.payment_intent}/pay`, undefined, {
      client_secret: made.body.client_secret, card: testCard(),
    });
    const r = await api('POST', `/v1/invoices/${inv.body.id}/void`, shop.key);
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'invoice_paid');
  });

  it('lists what is overdue', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd', due_at: new Date(Date.now() + 86_400_000).toISOString(),
      lines: [{ description: 'Late one', unit_amount: 15_000 }],
    });
    await api('POST', `/v1/invoices/${inv.body.id}/send`, shop.key);
    assert.equal((await api('GET', '/v1/invoices/overdue', shop.key)).body.data
      .some((x: any) => x.id === inv.body.id), false);

    await pool.query(`UPDATE invoices SET due_at = now() - interval '2 days' WHERE id=$1`, [inv.body.id]);
    const due = await api('GET', '/v1/invoices/overdue', shop.key);
    assert.equal(due.body.data.some((x: any) => x.id === inv.body.id), true);
    const got = await api('GET', `/v1/invoices/${inv.body.id}`, shop.key);
    assert.equal(got.body.overdue, true);
  });

  it('keeps one merchant out of another’s invoices', async () => {
    const cus = await customer(shop.key);
    const inv = await api('POST', '/v1/invoices', shop.key, {
      customer: cus, currency: 'usd', lines: [{ description: 'Private', unit_amount: 1_000 }],
    });
    const stranger = await business();
    assert.equal((await api('GET', `/v1/invoices/${inv.body.id}`, stranger.key)).status, 404);
    assert.equal((await api('POST', `/v1/invoices/${inv.body.id}/send`, stranger.key)).status, 404);
    assert.equal((await api('POST', `/v1/invoices/${inv.body.id}/void`, stranger.key)).status, 404);
  });
});
