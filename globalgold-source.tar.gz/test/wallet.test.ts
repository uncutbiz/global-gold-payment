/**
 * Wallet: accounts, top-ups, domestic + international transfers, FX, merchant payments.
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.CARD_RATE_LIMIT = '1000';
process.env.AUTH_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

let base = '';
let server: http.Server;

async function call(method: string, path: string, key: string | null, body?: unknown) {
  const res = await fetch(base + path, {
    method,
    headers: { ...(key ? { authorization: `Bearer ${key}` } : {}), 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() as any };
}

async function user(name: string, country: string) {
  const email = `${name.toLowerCase()}.${crypto.randomBytes(3).toString('hex')}@example.com`;
  const r = await call('POST', '/v1/wallet/signup', null, { email, name, password: 'correct horse battery', country });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return { token: r.body.token as string, email, ...r.body.user };
}

// 1x1 PNG, enough to pass document validation.
export const PNG = 'data:image/png;base64,' + Buffer.concat([Buffer.from('89504e470d0a1a0a', 'hex'), crypto.randomBytes(200)]).toString('base64');

async function verify(u: { token: string; name: string; country: string }) {
  const k = await call('POST', '/v1/wallet/kyc', u.token, {
    legal_name: u.name, date_of_birth: '1990-04-12', address_line: '1 Main St', city: 'Springfield', postal_code: '12345',
    country: u.country, id_type: 'passport', id_number: 'P' + crypto.randomBytes(4).toString('hex'), document: PNG,
  });
  assert.equal(k.status, 201, JSON.stringify(k.body));
  const a = await call('POST', `/v1/admin/kyc/${k.body.id}/approve`, 'test-admin', {});
  assert.equal(a.status, 200, JSON.stringify(a.body));
  u.token = (await call('POST', '/v1/wallet/login', null, { email: (u as any).email, password: 'correct horse battery' })).body.token;
}

async function fund(u: { token: string }, amount: number, number = '4242424242424242') {
  const card = await call('POST', '/v1/wallet/cards', u.token, { card: { number, exp_month: 12, exp_year: 2040, cvc: '123' } });
  assert.equal(card.status, 201, JSON.stringify(card.body));
  return call('POST', '/v1/wallet/top_ups', u.token, { amount, card: card.body.id });
}

const bal = async (u: { token: string }, cur: string) =>
  ((await call('GET', '/v1/wallet', u.token)).body.balances.find((b: any) => b.currency === cur)?.amount ?? 0);

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(async () => {
  server.close();
  await pool.end();
});

describe('accounts', () => {
  it('signs up with a home currency from the country, and logs in', async () => {
    const u = await user('Ngozi', 'NG');
    assert.equal(u.currency, 'ngn');
    const dup = await call('POST', '/v1/wallet/signup', null, { email: u.email, name: 'X', password: 'another long pw', country: 'NG' });
    assert.equal(dup.status, 409);
    assert.equal((await call('POST', '/v1/wallet/login', null, { email: u.email, password: 'wrong password!' })).status, 401);
    const ok = await call('POST', '/v1/wallet/login', null, { email: u.email.toUpperCase(), password: 'correct horse battery' });
    assert.equal(ok.status, 200);
    assert.match(ok.body.token, /^ggs_/);
    assert.equal((await call('GET', '/v1/wallet', 'ggs_invalid')).status, 401);
    assert.equal((await call('POST', '/v1/wallet/signup', null, { email: 'x@example.com', name: 'X', password: 'long enough pw', country: 'ZZ' })).status, 400);
  });
});

describe('money movement', () => {
  it('tops up from a card and rejects declined cards without crediting', async () => {
    const u = await user('Ada', 'US');
    const ok = await fund(u, 50000);
    assert.equal(ok.status, 201, JSON.stringify(ok.body));
    assert.equal(ok.body.balance, 50000);
    const bad = await fund(u, 1000, '4000000000009995');
    assert.equal(bad.status, 402);
    assert.equal(await bal(u, 'usd'), 50000);
    const act = (await call('GET', '/v1/wallet/activity', u.token)).body.data;
    assert.deepEqual(act.map((a: any) => a.status).sort(), ['completed', 'failed']);
  });

  it('sends domestically for free and never lets a balance go negative', async () => {
    const a = await user('Ben', 'US');
    const b = await user('Cara', 'US');
    await fund(a, 10000);
    const q = await call('POST', '/v1/wallet/transfer_quotes', a.token, { to: b.email, amount: 2500 });
    assert.equal(q.body.international, false);
    assert.equal(q.body.fee.amount, 0);
    assert.equal(q.body.receive.amount, 2500);
    const r = await call('POST', '/v1/wallet/transfers', a.token, { to: b.email, amount: 2500, note: 'Dinner' });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    assert.equal(await bal(a, 'usd'), 7500);
    assert.equal(await bal(b, 'usd'), 2500);

    // Five concurrent sends of $20 against $75: at most three can succeed.
    const results = await Promise.all([1, 2, 3, 4, 5].map(() => call('POST', '/v1/wallet/transfers', a.token, { to: b.email, amount: 2000 })));
    assert.equal(results.filter((x) => x.status === 201).length, 3);
    assert.equal(results.filter((x) => x.status === 402).length, 2);
    assert.equal(await bal(a, 'usd'), 1500);
    assert.equal((await call('POST', '/v1/wallet/transfers', a.token, { to: a.email, amount: 100 })).status, 400);
    assert.equal((await call('POST', '/v1/wallet/transfers', a.token, { to: 'nobody@example.com', amount: 100 })).status, 404);
  });

  it('sends internationally with a locked quote: fee in USD, recipient paid in NGN', async () => {
    const us = await user('Dan', 'US');
    const ng = await user('Emeka', 'NG');
    await verify(us);
    await fund(us, 40000);
    const q = await call('POST', '/v1/wallet/transfer_quotes', us.token, { to: ng.email, amount: 10000 });
    assert.equal(q.status, 200, JSON.stringify(q.body));
    assert.equal(q.body.international, true);
    assert.equal(q.body.recipient.currency, 'ngn');
    assert.equal(q.body.fee.amount, 100);                 // 1% of $100 = $1.00
    assert.equal(q.body.receive.amount, 15267500);        // $100 * 1550 * 0.985 = ₦152,675.00
    const r = await call('POST', '/v1/wallet/transfers', us.token, { to: ng.email, amount: 10000, quote: q.body.quote, note: 'School fees' });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    assert.equal(r.body.recipient_received.amount, 15267500);
    assert.equal(await bal(us, 'usd'), 40000 - 10000 - 100);
    assert.equal(await bal(ng, 'ngn'), 15267500);

    // A quote can only be used once.
    const again = await call('POST', '/v1/wallet/transfers', us.token, { to: ng.email, amount: 10000, quote: q.body.quote });
    assert.equal(again.status, 400);
    assert.equal(again.body.error.code, 'quote_invalid');

    const inbound = (await call('GET', '/v1/wallet/activity', ng.token)).body.data[0];
    assert.equal(inbound.type, 'transfer_in');
    assert.equal(inbound.international, true);
    assert.equal(inbound.counter_currency, 'usd');
  });

  it('caps the international fee and converts between own balances', async () => {
    const gb = await user('Fiona', 'GB');
    const in_ = await user('Priya', 'IN');
    await verify(gb);
    await fund(gb, 150000);  // £1,500
    const q = await call('POST', '/v1/wallet/transfer_quotes', gb.token, { to: in_.email, amount: 100000 });
    assert.equal(q.body.fee.amount, 389);   // capped at $4.99 ≈ £3.89

    const conv = await call('POST', '/v1/wallet/conversions', gb.token, { from: 'gbp', to: 'eur', amount: 10000 });
    assert.equal(conv.status, 201, JSON.stringify(conv.body));
    assert.equal(await bal(gb, 'gbp'), 140000);
    assert.equal(await bal(gb, 'eur'), conv.body.to.amount);
    assert.ok(conv.body.to.amount > 11000 && conv.body.to.amount < 11800);

    const w = await call('POST', '/v1/wallet/withdrawals', gb.token, { amount: 5000, currency: 'eur' });
    assert.equal(w.status, 201, JSON.stringify(w.body));
    assert.equal(await bal(gb, 'eur'), conv.body.to.amount - 5000);
  });

  it('pays a merchant from the wallet (converting if needed), refunds to the wallet, and keeps the ledger balanced', async () => {
    const m = (await call('POST', '/v1/admin/merchants', 'test-admin', { name: 'Lagos Cafe', email: 'cafe@example.com' })).body;
    const buyer = await user('Grace', 'CA');
    await fund(buyer, 30000); // CA$300

    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 10000, currency: 'usd', description: 'Catering' })).body;
    const preview = await call('GET', `/v1/checkout/${pi.id}/wallet_preview?client_secret=${pi.client_secret}`, buyer.token);
    assert.equal(preview.body.converted, true);
    assert.equal(preview.body.pay_from.currency, 'cad');

    const pay = await call('POST', `/v1/checkout/${pi.id}/pay_with_wallet`, buyer.token, { client_secret: 'wrong' });
    assert.equal(pay.status, 404);
    const paid = await call('POST', `/v1/checkout/${pi.id}/pay_with_wallet`, buyer.token, { client_secret: pi.client_secret });
    assert.equal(paid.status, 200, JSON.stringify(paid.body));
    assert.equal(paid.body.status, 'succeeded');
    assert.equal(paid.body.paid_from.amount, preview.body.pay_from.amount);
    assert.equal(await bal(buyer, 'cad'), 30000 - paid.body.paid_from.amount);

    const full = (await call('GET', `/v1/payment_intents/${pi.id}`, m.api_keys.secret)).body;
    assert.deepEqual(full.payment_method, { type: 'global_gold_wallet' });
    assert.equal(full.fee, 320);

    const re = await call('POST', '/v1/refunds', m.api_keys.secret, { payment_intent: pi.id, amount: 4000 });
    assert.equal(re.status, 201, JSON.stringify(re.body));
    assert.equal(await bal(buyer, 'usd'), 4000);   // refunded in the payment's currency

    // Paying twice is impossible.
    const twice = await call('POST', `/v1/checkout/${pi.id}/pay_with_wallet`, buyer.token, { client_secret: pi.client_secret });
    assert.equal(twice.status, 400);

    // Settlement: wallet payment settles to the merchant; top-ups are funded by the bank.
    const run = await call('POST', '/v1/admin/settlements/run', 'test-admin', {});
    assert.equal(run.status, 200, JSON.stringify(run.body));
    const b = (await call('GET', '/v1/balance', m.api_keys.secret)).body.balances[0];
    assert.deepEqual(b, { currency: 'usd', pending: 0, available: 10000 - 320 - 4000 });

    const tb = await call('GET', '/v1/admin/ledger/trial-balance', 'test-admin');
    assert.equal(tb.body.balanced, true, JSON.stringify(tb.body));

    // After settlement, the receivable is fully funded in every currency.
    const recv = await pool.query(`SELECT currency, SUM(debit) - SUM(credit) AS open FROM ledger_lines WHERE account = 'platform:settlement_receivable' GROUP BY currency`);
    assert.ok(recv.rows.every((r) => Number(r.open) === 0), JSON.stringify(recv.rows));
  });
});
