// The calculator's arithmetic, lifted out of the page and checked against the
// figures in the pricing doc. If these drift apart, the quote a merchant sees
// disagrees with the case we made to them.
const PLATFORM_BPS = 50, PLATFORM_CAP = 4900, CARD_BPS = 290, CARD_FIXED = 30, AVG = 5000;
function model(volumeDollars: number, nowSwDollars: number) {
  const volume = volumeDollars * 100, nowSw = nowSwDollars * 100;
  const payments = Math.max(1, Math.round(volume / AVG));
  const processing = Math.round((volume * CARD_BPS) / 10000) + payments * CARD_FIXED;
  let ours = Math.round((volume * PLATFORM_BPS) / 10000);
  const capped = PLATFORM_CAP > 0 && ours > PLATFORM_CAP;
  if (capped) ours = PLATFORM_CAP;
  return { processing, ours, capped, diff: (processing + nowSw) - (processing + ours) };
}
import { test } from 'node:test';
import assert from 'node:assert/strict';
const is = (got: unknown, want: unknown, what: string) => test(what, () => assert.equal(got, want));
// The florist in the doc: $4,000/mo, on Square Plus at $49.
const f = model(4000, 49);
is(f.processing, 14000, 'florist processing is $140.00');
is(f.ours, 2000, 'our fee on $4,000 is $20.00');
is(f.diff, 2900, 'florist saves $29.00 a month');
// A merchant on Square's free plan pays us MORE — the calculator must say so.
is(model(4000, 0).diff, -2000, 'free-plan merchant is $20.00 worse off');
// Break-even against Square Plus sits just under $10k of volume.
is(model(9800, 49).diff, 0, '$9,800 is exactly level with Square Plus');
is(model(9700, 49).diff > 0, true, 'below $9,800 we are cheaper');
// Above the break-even the cap takes over, so we never become the expensive
// option for a merchant paying for Square Plus. Without the cap we would.
for (const v of [9900, 20000, 50000, 250000]) {
  is(model(v, 49).diff >= 0, true, `at $${v.toLocaleString()} we are still never worse than Square Plus`);
}
// The cap must bite, and must make us cheaper than Square Plus at any size.
const big = model(50000, 49);
is(big.capped, true, '$50,000 volume hits the cap');
is(big.ours, 4900, 'capped at $49.00');
is(big.diff, 0, 'with the cap, a big merchant is never worse off than Square Plus');
is(model(0, 49).ours, 0, 'zero volume costs nothing');
