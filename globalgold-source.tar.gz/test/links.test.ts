/**
 * Payment links.
 *
 * A payment link is the one part of this system a stranger can reach with no
 * credential at all — the code in the URL is the whole of the authorisation.
 * So most of what is tested here is what the server refuses: an expired link, a
 * switched-off one, a used-up one, one belonging to a different merchant, and
 * above all a buyer who edits the amount before sending it.
 *
 * Runs on the simulated provider, so a payment can be completed end to end
 * without a processor. What that exercises is the link's own behaviour —
 * resolution, caps, counting — which is provider-independent by design.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-links';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'off';
process.env.CARD_RATE_LIMIT = '1000';
process.env.AUTH_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

let base = '';
let server: http.Server;

async function api(method: string, path: string, key?: string, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: {
      'content-type': 'application/json',
      ...(key ? { authorization: `Bearer ${key}` } : {}),
      ...(method === 'POST' ? { 'idempotency-key': crypto.randomUUID() } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json, text };
}

/** A signed-up, staff-approved business ready to take payments. */
async function business() {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await api('POST', '/v1/business/signup', undefined, {
    business_name: `Seller ${who}`, name: 'Owner', email: `l-${who}@test.com`,
    password: 'a-long-password-123', country: 'US', business_type: 'company',
  });
  assert.equal(r.status, 201, r.text);
  await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [r.body.merchant_id]);
  return { key: r.body.token as string, id: r.body.merchant_id as string };
}

/** Open a link the way a buyer does, and pay it with a test card. */
async function payLink(code: string, amount?: number) {
  const made = await api('POST', `/v1/pay/${code}/intent`, undefined,
    amount === undefined ? {} : { amount });
  if (made.status !== 201) return { started: made, paid: null as any };
  const pay = await api('POST', `/v1/checkout/${made.body.payment_intent}/pay`, undefined, {
    client_secret: made.body.client_secret,
    card: { number: '4242 4242 4242 4242', exp_month: '12', exp_year: '40', cvc: '123' },
  });
  return { started: made, paid: pay };
}

let seller: { key: string; id: string };

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  seller = await business();
});

after(async () => { server?.close(); await pool.end(); });

describe('creating payment links', () => {
  it('creates a fixed-price link with a shareable code', async () => {
    const r = await api('POST', '/v1/payment_links', seller.key,
      { title: 'October deposit', amount: 25_000, currency: 'usd' });
    assert.equal(r.status, 201, r.text);
    assert.equal(r.body.amount, 25_000);
    assert.equal(r.body.paid_count, 0);
    assert.equal(r.body.uses_left, null, 'no cap means no limit');
    assert.equal(r.body.url, `/pay/${r.body.code}`);
    // Readable down a phone: Crockford's alphabet drops I, L, O and U.
    assert.match(r.body.code, /^[0-9ABCDEFGHJKMNPQRSTVWXYZ]{10}$/);
  });

  it('refuses a link that is neither fixed nor open, or both at once', async () => {
    const neither = await api('POST', '/v1/payment_links', seller.key, { title: 'x', currency: 'usd' });
    assert.equal(neither.status, 400);
    const both = await api('POST', '/v1/payment_links', seller.key,
      { title: 'x', currency: 'usd', amount: 1000, min_amount: 500 });
    assert.equal(both.status, 400);
  });

  it('refuses an expiry in the past', async () => {
    const r = await api('POST', '/v1/payment_links', seller.key,
      { title: 'x', amount: 1000, currency: 'usd', expires_at: new Date(Date.now() - 60_000).toISOString() });
    assert.equal(r.status, 400);
  });

  it('will not create links for an account that is not approved yet', async () => {
    const who = crypto.randomBytes(4).toString('hex');
    const s = await api('POST', '/v1/business/signup', undefined, {
      business_name: `Pending ${who}`, name: 'Owner', email: `p-${who}@test.com`,
      password: 'a-long-password-123', country: 'US', business_type: 'company',
    });
    const r = await api('POST', '/v1/payment_links', s.body.token, { title: 'x', amount: 1000, currency: 'usd' });
    assert.equal(r.status, 403);
  });
});

describe('paying a link', () => {
  it('charges the merchant’s price, not the amount the buyer sends', async () => {
    const l = await api('POST', '/v1/payment_links', seller.key,
      { title: 'Fixed', amount: 25_000, currency: 'usd' });

    // The buyer controls this request completely. If the server trusted it,
    // anyone could pay one cent for a $250 booking.
    const { started, paid } = await payLink(l.body.code, 1);
    assert.equal(started.status, 201, started.text);
    assert.equal(paid.body.status, 'succeeded', paid.text);
    assert.equal(paid.body.amount, 25_000, 'the link’s price must win');
  });

  it('lets the buyer choose within the range, and only within it', async () => {
    const l = await api('POST', '/v1/payment_links', seller.key,
      { title: 'Tip', min_amount: 500, max_amount: 5_000, currency: 'usd' });
    const code = l.body.code;

    assert.equal((await api('POST', `/v1/pay/${code}/intent`, undefined, { amount: 499 })).status, 400);
    assert.equal((await api('POST', `/v1/pay/${code}/intent`, undefined, { amount: 5_001 })).status, 400);
    assert.equal((await api('POST', `/v1/pay/${code}/intent`, undefined, {})).status, 400, 'must name an amount');

    const ok = await payLink(code, 2_500);
    assert.equal(ok.paid.body.status, 'succeeded', ok.paid.text);
    assert.equal(ok.paid.body.amount, 2_500);
  });

  it('counts only completed payments against a capped link', async () => {
    const l = await api('POST', '/v1/payment_links', seller.key,
      { title: 'Two seats', amount: 1_000, currency: 'usd', max_uses: 2 });
    const code = l.body.code;

    // Someone opens it and walks away. That must not burn a seat.
    const abandoned = await api('POST', `/v1/pay/${code}/intent`, undefined, {});
    assert.equal(abandoned.status, 201);
    assert.equal((await api('GET', `/v1/payment_links/${l.body.id}`, seller.key)).body.paid_count, 0);

    assert.equal((await payLink(code)).paid.body.status, 'succeeded');
    assert.equal((await payLink(code)).paid.body.status, 'succeeded');

    const after = await api('GET', `/v1/payment_links/${l.body.id}`, seller.key);
    assert.equal(after.body.paid_count, 2);
    assert.equal(after.body.uses_left, 0);

    // Sold out, for the page and for the intent endpoint alike.
    assert.equal((await api('GET', `/v1/pay/${code}`)).status, 410);
    assert.equal((await api('POST', `/v1/pay/${code}/intent`, undefined, {})).status, 410);
  });

  it('reports what each link has collected', async () => {
    const l = await api('POST', '/v1/payment_links', seller.key,
      { title: 'Earnings', amount: 7_500, currency: 'usd' });
    await payLink(l.body.code);
    await payLink(l.body.code);
    const got = await api('GET', '/v1/payment_links', seller.key);
    const mine = got.body.data.find((x: any) => x.id === l.body.id);
    assert.equal(mine.collected, 15_000);
  });
});

describe('links that should not take money', () => {
  it('turns off and back on, and refuses payment while off', async () => {
    const l = await api('POST', '/v1/payment_links', seller.key,
      { title: 'Toggle', amount: 1_000, currency: 'usd' });
    const code = l.body.code;

    await api('POST', `/v1/payment_links/${l.body.id}/deactivate`, seller.key);
    assert.equal((await api('GET', `/v1/pay/${code}`)).status, 410);
    assert.equal((await api('POST', `/v1/pay/${code}/intent`, undefined, {})).status, 410);

    await api('POST', `/v1/payment_links/${l.body.id}/activate`, seller.key);
    assert.equal((await api('GET', `/v1/pay/${code}`)).status, 200);
  });

  it('stops at the expiry', async () => {
    const l = await api('POST', '/v1/payment_links', seller.key,
      { title: 'Expiring', amount: 1_000, currency: 'usd',
        expires_at: new Date(Date.now() + 3_600_000).toISOString() });
    assert.equal((await api('GET', `/v1/pay/${l.body.code}`)).status, 200);

    await pool.query(`UPDATE payment_links SET expires_at = now() - interval '1 second' WHERE id=$1`, [l.body.id]);
    assert.equal((await api('GET', `/v1/pay/${l.body.code}`)).status, 410);
    assert.equal((await api('POST', `/v1/pay/${l.body.code}/intent`, undefined, {})).status, 410);
  });

  it('stops when the business is suspended', async () => {
    const other = await business();
    const l = await api('POST', '/v1/payment_links', other.key,
      { title: 'Suspended', amount: 1_000, currency: 'usd' });
    await pool.query(`UPDATE merchants SET status='suspended' WHERE id=$1`, [other.id]);
    assert.equal((await api('GET', `/v1/pay/${l.body.code}`)).status, 410);
    assert.equal((await api('POST', `/v1/pay/${l.body.code}/intent`, undefined, {})).status, 410);
  });

  it('gives a stranger nothing to probe with', async () => {
    const r = await api('GET', '/v1/pay/ZZZZZZZZZZ');
    assert.equal(r.status, 404);
    assert.equal(r.body.error.code, 'resource_missing');
  });
});

describe('one merchant cannot touch another’s links', () => {
  it('hides them from reads, lists and the off switch', async () => {
    const mine = await api('POST', '/v1/payment_links', seller.key,
      { title: 'Private', amount: 1_000, currency: 'usd' });
    const stranger = await business();

    assert.equal((await api('GET', `/v1/payment_links/${mine.body.id}`, stranger.key)).status, 404);
    assert.equal((await api('POST', `/v1/payment_links/${mine.body.id}/deactivate`, stranger.key)).status, 404);

    const theirs = await api('GET', '/v1/payment_links', stranger.key);
    assert.equal(theirs.body.data.some((x: any) => x.id === mine.body.id), false);

    // …and the attempt left it working.
    assert.equal((await api('GET', `/v1/pay/${mine.body.code}`)).status, 200);
  });

  it('needs a key at all', async () => {
    assert.equal((await api('GET', '/v1/payment_links')).status, 401);
    assert.equal((await api('POST', '/v1/payment_links', undefined,
      { title: 'x', amount: 1000, currency: 'usd' })).status, 401);
  });
});
