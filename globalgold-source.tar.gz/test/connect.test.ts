/**
 * Connecting a merchant's Square account.
 *
 * Runs the real server with PAYMENT_PROVIDER=square and Square's HTTP replaced
 * by a stub, so the whole flow is exercised without a Square sandbox: start the
 * connection, come back through the callback, store the tokens, charge with
 * them, and receive webhooks.
 *
 * The security properties this file is really here to pin down:
 *   - the OAuth `state` is single-use, so a replayed callback cannot re-attach
 *   - one Square account cannot be attached to two of our merchants
 *   - tokens are encrypted at rest, and bound to their merchant, so a row
 *     copied between merchants fails to decrypt rather than quietly working
 *   - an unsigned or mis-signed webhook is rejected, and a replay is not
 *     processed twice
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

const PUBLIC_URL = 'https://pay.globalgoldpay.test';
const SIG_KEY = 'whsec-test-signature-key';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-connect';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.PUBLIC_URL = PUBLIC_URL;
process.env.PAYMENT_PROVIDER = 'square';
process.env.SQUARE_ENV = 'sandbox';
process.env.SQUARE_APP_ID = 'sq0idp-test-app';
process.env.SQUARE_APP_SECRET = 'sq0csp-test-secret';
process.env.SQUARE_WEBHOOK_SIGNATURE_KEY = SIG_KEY;
process.env.PLATFORM_FEE_BPS = '50';
process.env.WALLET_MODE = 'off';

// ---- Square's HTTP, replaced ------------------------------------------------
// Queue a reply per expected call; every request is recorded for assertions.
type Reply = { status?: number; body: unknown };
const squareCalls: Array<{ url: string; method: string; token?: string; body: any }> = [];
let replies: Reply[] = [];
const realFetch = globalThis.fetch;

globalThis.fetch = (async (url: any, init: any) => {
  const u = String(url);
  if (!u.includes('squareup')) return realFetch(url, init);   // let local calls through
  const headers = (init?.headers ?? {}) as Record<string, string>;
  squareCalls.push({
    url: u,
    method: init?.method ?? 'GET',
    token: headers.Authorization?.replace('Bearer ', ''),
    body: init?.body ? JSON.parse(init.body) : undefined,
  });
  const reply = replies.shift() ?? { body: {} };
  return new Response(JSON.stringify(reply.body), {
    status: reply.status ?? 200,
    headers: { 'content-type': 'application/json' },
  });
}) as typeof fetch;

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { providerMerchant } = await import('../src/merchants/connect.js');
const { providerNamed, ourFee } = await import('../src/providers/index.js');
const provider = providerNamed('square');

let base = '';
let server: http.Server;

const oauthOk = (merchantId = 'MLSQUARE1', token = 'EAAA-access-1') => [
  { body: { access_token: token, refresh_token: 'rt-1', merchant_id: merchantId, expires_at: '2027-06-01T00:00:00Z' } },
  { body: { locations: [{ id: 'LOC1', status: 'ACTIVE', business_name: 'Test Seller', currency: 'USD', country: 'US' }] } },
];

async function api(method: string, path: string, key?: string, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json, text };
}

async function business(country = 'US') {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await api('POST', '/v1/business/signup', undefined, {
    business_name: `Seller ${who}`, name: 'Owner', email: `c-${who}@test.com`,
    password: 'a-long-password-123', country, business_type: 'company',
  });
  assert.equal(r.status, 201, r.text);
  return { key: r.body.token as string, id: r.body.merchant_id as string };
}

/** Pull the state value out of the URL we hand the merchant. */
const stateOf = (url: string) => new URL(url).searchParams.get('state')!;

const sign = (body: string, url = `${PUBLIC_URL}/v1/webhooks/square`, key = SIG_KEY) =>
  crypto.createHmac('sha256', key).update(url + body).digest('base64');

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(async () => {
  server?.close();
  await pool.end();
  globalThis.fetch = realFetch;
});

describe('the values you paste into the Square console', () => {
  it('prints the redirect and webhook URLs, so nothing is guessed', async () => {
    const r = await api('GET', '/v1/connect/config');
    assert.equal(r.status, 200);
    const sq = r.body.providers.find((p: any) => p.provider === 'square');
    assert.ok(sq, 'square is listed');
    assert.equal(sq.environment, 'sandbox');
    assert.equal(sq.oauth_redirect_url, `${PUBLIC_URL}/v1/connect/square/callback`);
    assert.equal(sq.webhook_url, `${PUBLIC_URL}/v1/webhooks/square`);
    assert.equal(sq.tokenizes_in_browser, true, 'card data must never reach us');
    assert.equal(r.body.platform_fee.bps, 50);
  });
});

describe('starting a connection', () => {
  it('sends the merchant to Square with the permissions app fees need', async () => {
    const b = await business();
    const r = await api('POST', '/v1/connect/start', b.key);
    assert.equal(r.status, 200, r.text);
    const u = new URL(r.body.url);
    assert.equal(u.host, 'squareupsandbox.com');
    assert.equal(u.searchParams.get('redirect_uri'), `${PUBLIC_URL}/v1/connect/square/callback`);
    const scopes = (u.searchParams.get('scope') ?? '').split(' ');
    assert.ok(scopes.includes('PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS'), 'app fees need this scope');
  });

  it('refuses a country Square cannot serve, before the merchant wastes time', async () => {
    const ng = await business('NG');
    const r = await api('POST', '/v1/connect/start', ng.key);
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'country_not_supported');
    assert.match(r.body.error.message, /different processor/i);
  });

  it('reports the connection as required and not yet done', async () => {
    const b = await business();
    const r = await api('GET', '/v1/connect/status', b.key);
    assert.equal(r.body.required, true);
    assert.equal(r.body.connected, false);
    assert.equal(r.body.country_supported, true);
  });
});

describe('coming back from Square', () => {
  it('stores the tokens, and stores them encrypted', async () => {
    const b = await business();
    const start = await api('POST', '/v1/connect/start', b.key);
    const state = stateOf(start.body.url);

    replies = oauthOk('MLSELLER-A', 'EAAA-seller-A');
    const cb = await fetch(`${base}/v1/connect/square/callback?code=sq0cgb-code&state=${encodeURIComponent(state)}`);
    const html = await cb.text();
    assert.equal(cb.status, 200, html);
    assert.match(html, /Square connected/);
    assert.match(html, /Test Seller/);

    // The exchange used our client secret, and looked up locations as the seller.
    const token = squareCalls.find((c) => c.url.endsWith('/oauth2/token'))!;
    assert.equal(token.body.client_secret, 'sq0csp-test-secret');
    assert.equal(token.body.grant_type, 'authorization_code');

    const row = await pool.query(
      `SELECT provider, provider_account_id, provider_location_id,
              provider_access_ct, provider_refresh_ct, provider_connected_at
         FROM merchants WHERE id = $1`, [b.id]);
    const m = row.rows[0];
    assert.equal(m.provider, 'square');
    assert.equal(m.provider_account_id, 'MLSELLER-A');
    assert.equal(m.provider_location_id, 'LOC1');
    assert.ok(m.provider_connected_at);
    assert.ok(Buffer.isBuffer(m.provider_access_ct), 'the token is stored as bytes, not text');
    assert.ok(!m.provider_access_ct.toString('utf8').includes('EAAA'), 'no plaintext token in the database');
    assert.ok(Buffer.isBuffer(m.provider_refresh_ct));

    const status = await api('GET', '/v1/connect/status', b.key);
    assert.equal(status.body.connected, true);
    assert.equal(status.body.account_id, 'MLSELLER-A');
  });

  it('refuses a replayed callback, so a link cannot be used twice', async () => {
    const b = await business();
    const start = await api('POST', '/v1/connect/start', b.key);
    const state = stateOf(start.body.url);

    replies = oauthOk('MLSELLER-B', 'EAAA-seller-B');
    const first = await fetch(`${base}/v1/connect/square/callback?code=code-1&state=${encodeURIComponent(state)}`);
    assert.match(await first.text(), /Square connected/);

    replies = oauthOk('MLSELLER-EVIL', 'EAAA-evil');
    const second = await fetch(`${base}/v1/connect/square/callback?code=code-2&state=${encodeURIComponent(state)}`);
    const html = await second.text();
    assert.equal(second.status, 400);
    assert.match(html, /expired or was already used/i);

    // And the merchant still points at the original Square account.
    const row = await pool.query('SELECT provider_account_id FROM merchants WHERE id = $1', [b.id]);
    assert.equal(row.rows[0].provider_account_id, 'MLSELLER-B');
  });

  it('refuses an unknown or forged state outright', async () => {
    const r = await fetch(`${base}/v1/connect/square/callback?code=sq0cgb-real-length-code&state=not-a-real-state`);
    assert.equal(r.status, 400);
    assert.match(await r.text(), /expired or was already used/i);
    assert.equal(squareCalls.filter((c) => c.body?.code === 'c').length, 0, 'never contacted Square');
  });

  it('will not attach one Square account to two businesses', async () => {
    const first = await business();
    const s1 = stateOf((await api('POST', '/v1/connect/start', first.key)).body.url);
    replies = oauthOk('MLSHARED', 'EAAA-1');
    assert.match(await (await fetch(`${base}/v1/connect/square/callback?code=sq0cgb-code-one&state=${encodeURIComponent(s1)}`)).text(), /Square connected/);

    const second = await business();
    const s2 = stateOf((await api('POST', '/v1/connect/start', second.key)).body.url);
    replies = oauthOk('MLSHARED', 'EAAA-2');
    const cb = await fetch(`${base}/v1/connect/square/callback?code=sq0cgb-code-two&state=${encodeURIComponent(s2)}`);
    const html = await cb.text();
    assert.equal(cb.status, 400);
    assert.match(html, /already connected to another business/i);
  });

  it('rejects an incomplete link without contacting Square', async () => {
    squareCalls.length = 0;
    const r = await fetch(`${base}/v1/connect/square/callback?code=xx`);
    assert.equal(r.status, 400);
    assert.match(await r.text(), /Something is missing/);
    assert.equal(squareCalls.length, 0);
  });

  it('tells the merchant plainly when they cancel on Square', async () => {
    const r = await fetch(`${base}/v1/connect/square/callback?error=access_denied&state=x`);
    assert.equal(r.status, 400);
    assert.match(await r.text(), /Connection cancelled/);
  });
});

describe('using the stored token', () => {
  it('charges as the merchant, with our fee attached', async () => {
    const b = await business();
    const state = stateOf((await api('POST', '/v1/connect/start', b.key)).body.url);
    replies = oauthOk('MLCHARGE', 'EAAA-charge-token');
    await fetch(`${base}/v1/connect/square/callback?code=sq0cgb-real-length-code&state=${encodeURIComponent(state)}`);

    const pm = await providerMerchant(pool, b.id);
    assert.equal(pm.accessToken, 'EAAA-charge-token', 'decrypted back to the original token');
    assert.equal(pm.locationId, 'LOC1');

    squareCalls.length = 0;
    replies = [{ body: { payment: { id: 'sqpay_1', status: 'COMPLETED', app_fee_money: { amount: 50, currency: 'USD' } } } }];
    const out = await provider.charge({
      amount: 10_000, currency: 'usd', capture: true,
      source: { kind: 'provider_token', token: 'cnon:ok' },
      merchant: pm, platformFee: ourFee(10_000), idempotencyKey: 'test-charge-1',
    });
    assert.equal(out.approved, true);
    const call = squareCalls[0]!;
    assert.equal(call.token, 'EAAA-charge-token', 'charged with the seller’s own token');
    assert.deepEqual(call.body.app_fee_money, { amount: 50, currency: 'USD' }, '0.5% of $100');
    assert.equal(call.body.location_id, 'LOC1');
  });

  it('will not hand back a token copied from another merchant', async () => {
    const a = await business();
    const sa = stateOf((await api('POST', '/v1/connect/start', a.key)).body.url);
    replies = oauthOk('MLAAD-A', 'EAAA-aad-a');
    await fetch(`${base}/v1/connect/square/callback?code=sq0cgb-real-length-code&state=${encodeURIComponent(sa)}`);

    const victim = await business();
    // Copy A's encrypted token straight into the victim's row, the way a
    // compromised backup or a careless migration might.
    await pool.query(
      `UPDATE merchants v SET
         provider = a.provider, provider_account_id = 'MLAAD-STOLEN',
         provider_location_id = a.provider_location_id, provider_key_id = a.provider_key_id,
         provider_access_iv = a.provider_access_iv, provider_access_ct = a.provider_access_ct,
         provider_access_tag = a.provider_access_tag
       FROM merchants a WHERE v.id = $1 AND a.id = $2`, [victim.id, a.id]);

    // The ciphertext is bound to merchant A's id, so it must not open for anyone else.
    await assert.rejects(() => providerMerchant(pool, victim.id),
      (e: unknown) => /unable to authenticate|unsupported state|bad decrypt/i.test((e as Error).message),
      'a copied token must fail to decrypt, not work');
  });

  it('refuses to charge a merchant that never connected', async () => {
    const b = await business();
    await assert.rejects(() => providerMerchant(pool, b.id),
      (e: any) => e?.code === 'merchant_not_connected');
  });

  it('forgets the account on disconnect', async () => {
    const b = await business();
    const state = stateOf((await api('POST', '/v1/connect/start', b.key)).body.url);
    replies = oauthOk('MLGONE', 'EAAA-gone');
    await fetch(`${base}/v1/connect/square/callback?code=sq0cgb-real-length-code&state=${encodeURIComponent(state)}`);
    await api('POST', '/v1/connect/disconnect', b.key);
    const s = await api('GET', '/v1/connect/status', b.key);
    assert.equal(s.body.connected, false);
    await assert.rejects(() => providerMerchant(pool, b.id), (e: any) => e?.code === 'merchant_not_connected');
  });
});

describe('Square webhooks', () => {
  const body = (id: string) => JSON.stringify({
    event_id: id, type: 'payment.updated', merchant_id: 'MLSELLER-A',
    data: { object: { payment: { id: 'sqpay_9', status: 'COMPLETED' } } },
  });

  it('accepts a correctly signed notification', async () => {
    const b = body('evt-1');
    const r = await fetch(base + '/v1/webhooks/square', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-square-hmacsha256-signature': sign(b) },
      body: b,
    });
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { received: true, duplicate: false });

    const row = await pool.query('SELECT type, merchant_id FROM provider_events WHERE event_id = $1', ['evt-1']);
    assert.equal(row.rows[0].type, 'payment.updated');
    assert.ok(row.rows[0].merchant_id, 'resolved to the merchant that owns that Square account');
  });

  it('answers a retry without processing it twice', async () => {
    const b = body('evt-dup');
    const send = () => fetch(base + '/v1/webhooks/square', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-square-hmacsha256-signature': sign(b) },
      body: b,
    });
    assert.deepEqual(await (await send()).json(), { received: true, duplicate: false });
    assert.deepEqual(await (await send()).json(), { received: true, duplicate: true });
    const n = await pool.query('SELECT count(*)::int AS n FROM provider_events WHERE event_id = $1', ['evt-dup']);
    assert.equal(n.rows[0].n, 1, 'stored once');
  });

  it('rejects a missing, wrong and tampered signature', async () => {
    const b = body('evt-bad');
    const post = (headers: Record<string, string>) => fetch(base + '/v1/webhooks/square', {
      method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: b,
    });
    assert.equal((await post({})).status, 401, 'no signature');
    assert.equal((await post({ 'x-square-hmacsha256-signature': 'nonsense' })).status, 401, 'garbage signature');
    assert.equal((await post({ 'x-square-hmacsha256-signature': sign(b, `${PUBLIC_URL}/v1/webhooks/square`, 'wrong-key') })).status, 401, 'wrong key');
    assert.equal((await post({ 'x-square-hmacsha256-signature': sign(body('other')) })).status, 401, 'signature of a different body');

    const stored = await pool.query('SELECT count(*)::int AS n FROM provider_events WHERE event_id = $1', ['evt-bad']);
    assert.equal(stored.rows[0].n, 0, 'nothing unverified is ever stored');
  });

  it('ignores a notification addressed to another provider', async () => {
    const r = await fetch(base + '/v1/webhooks/stripe', { method: 'POST', body: '{}' });
    assert.equal(r.status, 404);
  });
});
