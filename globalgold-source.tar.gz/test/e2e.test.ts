/**
 * End-to-end tests against a real PostgreSQL database.
 *   TEST_DATABASE_URL=postgres://... npm test
 * WARNING: the test wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.CARD_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { deliverDue, verify } = await import('../src/webhooks/webhooks.js');
const iso = await import('../src/acquirer/iso8583.js');

let base = '';
let server: http.Server;
let hookServer: http.Server;
const received: { body: string; sig: string }[] = [];

async function call(method: string, path: string, key: string, body?: unknown, headers: Record<string, string> = {}) {
  const res = await fetch(base + path, {
    method,
    headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json', ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() as any, headers: res.headers };
}

async function newMerchant(extra: Record<string, unknown> = {}) {
  const r = await call('POST', '/v1/admin/merchants', 'test-admin', { name: 'Test Shop', email: 'shop@example.com', ...extra });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return r.body;
}

async function token(pk: string, number = '4242424242424242') {
  const r = await call('POST', '/v1/tokens', pk, { card: { number, exp_month: 12, exp_year: new Date().getFullYear() + 2, cvc: '123' } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return r.body.id as string;
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  hookServer = http.createServer((req, res) => {
    let b = '';
    req.on('data', (c) => (b += c));
    req.on('end', () => { received.push({ body: b, sig: String(req.headers['globalgold-signature']) }); res.end('ok'); });
  }).listen(0);
  await new Promise((r) => hookServer.once('listening', r));
});

after(async () => {
  server.close();
  hookServer.close();
  await pool.end();
});

describe('ISO 8583 codec', () => {
  it('round-trips a message and sets the right bitmap', () => {
    const msg = { mti: '0100', fields: { 2: '4242424242424242', 3: '000000', 4: '1999', 11: '000123', 41: 'TERM1', 49: '840' } };
    const raw = iso.encode(msg);
    assert.equal(raw.slice(0, 4), '0100');
    assert.equal(raw.slice(4, 20), '7020000000808000'); // fields 2,3,4,11,41,49
    const back = iso.decode(raw);
    assert.deepEqual(back.fields, { 2: '4242424242424242', 3: '000000', 4: '000000001999', 11: '000123', 41: 'TERM1', 49: '840' });
    assert.equal(iso.redact(back).fields[2], '424242******4242');
  });
});

describe('payments', () => {
  let m: any;
  before(async () => { m = await newMerchant(); });

  it('rejects bad keys and wrong key types', async () => {
    assert.equal((await call('GET', '/v1/balance', 'sk_test_nope')).status, 401);
    assert.equal((await call('POST', '/v1/payment_intents', m.api_keys.publishable, { amount: 1000, currency: 'usd' })).status, 403);
  });

  it('rejects invalid cards at tokenization', async () => {
    const r = await call('POST', '/v1/tokens', m.api_keys.publishable, { card: { number: '4242424242424241', exp_month: 1, exp_year: 2099, cvc: '1' } });
    assert.equal(r.status, 402);
    assert.equal(r.body.error.code, 'invalid_number');
  });

  it('charges automatically, posts fees to the ledger, and never stores the PAN in plaintext', async () => {
    const tok = await token(m.api_keys.publishable);
    const r = await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 10000, currency: 'usd', payment_token: tok, confirm: true });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    assert.equal(r.body.status, 'succeeded');
    assert.equal(r.body.fee, 320); // 2.9% + 30
    assert.equal(r.body.payment_method.last4, '4242');
    assert.match(r.body.network.auth_code, /^[0-9A-F]{6}$/);

    const bal = await call('GET', '/v1/balance', m.api_keys.secret);
    assert.deepEqual(bal.body.balances, [{ currency: 'usd', pending: 9680, available: 0 }]);

    const dump = await pool.query(`SELECT string_agg(ciphertext::text || card_tokens::text, '') AS s FROM card_tokens`);
    assert.ok(!dump.rows[0].s.includes('4242424242424242'));
  });

  it('declines with the mapped network response code and allows a retry', async () => {
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 2500, currency: 'usd' })).body;
    const bad = await token(m.api_keys.publishable, '4000000000009995');
    const r1 = await call('POST', `/v1/payment_intents/${pi.id}/confirm`, m.api_keys.secret, { payment_token: bad });
    assert.equal(r1.body.status, 'requires_payment_method');
    assert.equal(r1.body.last_payment_error.code, 'insufficient_funds');

    const good = await token(m.api_keys.publishable, '5555555555554444');
    const r2 = await call('POST', `/v1/payment_intents/${pi.id}/confirm`, m.api_keys.secret, { payment_token: good });
    assert.equal(r2.body.status, 'succeeded');
    assert.equal(r2.body.payment_method.brand, 'mastercard');
    assert.equal(r2.body.last_payment_error, null);
  });

  it('supports manual capture (partial) and cancel', async () => {
    const tok = await token(m.api_keys.publishable);
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 5000, currency: 'usd', capture_method: 'manual', payment_token: tok, confirm: true })).body;
    assert.equal(pi.status, 'requires_capture');
    assert.equal(pi.amount_capturable, 5000);

    const tooMuch = await call('POST', `/v1/payment_intents/${pi.id}/capture`, m.api_keys.secret, { amount_to_capture: 6000 });
    assert.equal(tooMuch.status, 400);
    const cap = await call('POST', `/v1/payment_intents/${pi.id}/capture`, m.api_keys.secret, { amount_to_capture: 4000 });
    assert.equal(cap.body.status, 'succeeded');
    assert.equal(cap.body.amount_captured, 4000);
    assert.equal(cap.body.fee, 146); // 116 + 30

    const tok2 = await token(m.api_keys.publishable);
    const pi2 = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 5000, currency: 'usd', capture_method: 'manual', payment_token: tok2, confirm: true })).body;
    const cancel = await call('POST', `/v1/payment_intents/${pi2.id}/cancel`, m.api_keys.secret, {});
    assert.equal(cancel.body.status, 'canceled');
    assert.equal((await call('POST', `/v1/payment_intents/${pi2.id}/capture`, m.api_keys.secret, {})).status, 400);
  });

  it('refunds partially and blocks over-refunds, including concurrent ones', async () => {
    const tok = await token(m.api_keys.publishable);
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 3000, currency: 'usd', payment_token: tok, confirm: true })).body;
    const r1 = await call('POST', '/v1/refunds', m.api_keys.secret, { payment_intent: pi.id, amount: 1000 });
    assert.equal(r1.status, 201);
    const results = await Promise.all([1, 2, 3].map(() => call('POST', '/v1/refunds', m.api_keys.secret, { payment_intent: pi.id, amount: 1500 })));
    assert.equal(results.filter((r) => r.status === 201).length, 1);
    const after = (await call('GET', `/v1/payment_intents/${pi.id}`, m.api_keys.secret)).body;
    assert.equal(after.amount_refunded, 2500);
  });

  it('replays idempotent requests and rejects key reuse with different params', async () => {
    const h = { 'idempotency-key': 'order-42' };
    const a = await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 1234, currency: 'usd' }, h);
    const b = await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 1234, currency: 'usd' }, h);
    assert.equal(a.body.id, b.body.id);
    assert.equal(b.headers.get('idempotent-replayed'), 'true');
    const c = await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 9999, currency: 'usd' }, h);
    assert.equal(c.status, 422);
  });

  it('blocks amounts above the merchant limit via risk rules', async () => {
    const small = await newMerchant({ max_amount: 1000 });
    const tok = await token(small.api_keys.publishable);
    const r = await call('POST', '/v1/payment_intents', small.api_keys.secret, { amount: 5000, currency: 'usd', payment_token: tok, confirm: true });
    assert.equal(r.body.status, 'requires_payment_method');
    assert.equal(r.body.last_payment_error.code, 'risk_blocked');
  });

  it('lets the hosted checkout confirm only with the client secret', async () => {
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 777, currency: 'usd' })).body;
    const tok = await token(m.api_keys.publishable);
    const wrong = await call('POST', `/v1/payment_intents/${pi.id}/confirm`, m.api_keys.publishable, { payment_token: tok, client_secret: 'secret_wrong' });
    assert.equal(wrong.status, 404);
    const ok = await call('POST', `/v1/payment_intents/${pi.id}/confirm`, m.api_keys.publishable, { payment_token: tok, client_secret: pi.client_secret });
    assert.equal(ok.body.status, 'succeeded');
    assert.equal(ok.body.client_secret, undefined);
  });

  it('pays through the hosted checkout endpoints', async () => {
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 4900, currency: 'usd', description: 'Order #1' })).body;
    const bad = await fetch(`${base}/v1/checkout/${pi.id}?client_secret=nope`);
    assert.equal(bad.status, 404);
    const info = await (await fetch(`${base}/v1/checkout/${pi.id}?client_secret=${pi.client_secret}`)).json() as any;
    assert.equal(info.merchant, 'Test Shop');
    assert.equal(info.status, 'requires_payment_method');
    const pay = await fetch(`${base}/v1/checkout/${pi.id}/pay`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ client_secret: pi.client_secret, card: { number: '4242 4242 4242 4242', exp_month: '12', exp_year: '40', cvc: '123' } }),
    });
    const paid = await pay.json() as any;
    assert.equal(paid.status, 'succeeded');
    assert.equal(paid.payment_method.last4, '4242');
  });

  it('isolates merchants from each other', async () => {
    const other = await newMerchant();
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 1000, currency: 'usd' })).body;
    assert.equal((await call('GET', `/v1/payment_intents/${pi.id}`, other.api_keys.secret)).status, 404);
    const foreignTok = await token(other.api_keys.publishable);
    const r = await call('POST', `/v1/payment_intents/${pi.id}/confirm`, m.api_keys.secret, { payment_token: foreignTok });
    assert.equal(r.status, 400);
  });
});

describe('settlement, payouts and ledger integrity', () => {
  it('settles pending to available, pays out, and keeps the ledger balanced', async () => {
    const m = await newMerchant();
    const tok = await token(m.api_keys.publishable);
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 20000, currency: 'usd', payment_token: tok, confirm: true })).body;
    await call('POST', '/v1/refunds', m.api_keys.secret, { payment_intent: pi.id, amount: 5000 });

    const run = await call('POST', '/v1/admin/settlements/run', 'test-admin', {});
    assert.equal(run.status, 200);
    assert.ok(run.body.data.length >= 1);

    const bal = (await call('GET', '/v1/balance', m.api_keys.secret)).body.balances[0];
    // 20000 - fee 610 - refund 5000
    assert.deepEqual(bal, { currency: 'usd', pending: 0, available: 14390 });

    assert.equal((await call('POST', '/v1/payouts', m.api_keys.secret, { currency: 'usd', amount: 99999 })).status, 400);
    const po = await call('POST', '/v1/payouts', m.api_keys.secret, { currency: 'usd' });
    assert.equal(po.status, 201);
    assert.equal(po.body.amount, 14390);
    const bal2 = (await call('GET', '/v1/balance', m.api_keys.secret)).body.balances[0];
    assert.equal(bal2.available, 0);

    const tb = await call('GET', '/v1/admin/ledger/trial-balance', 'test-admin');
    assert.equal(tb.body.balanced, true);

    // A second run has nothing new to clear.
    const again = await call('POST', '/v1/admin/settlements/run', 'test-admin', {});
    assert.equal(again.body.data.length, 0);
  });

  it('refuses unbalanced journals and edits at the database level', async () => {
    const c = await pool.connect();
    try {
      await c.query('BEGIN');
      await c.query(`INSERT INTO journals (id, ref_type, ref_id, description) VALUES ('jnl_bad','test','x','bad')`);
      await c.query(`INSERT INTO ledger_lines (journal_id, account, currency, debit) VALUES ('jnl_bad','a','usd',100)`);
      await assert.rejects(c.query('COMMIT'), /unbalanced/);
    } finally {
      c.release();
    }
    await assert.rejects(pool.query('UPDATE ledger_lines SET debit = debit + 1'), /append-only/);
  });
});

describe('webhooks', () => {
  it('delivers signed events that verify with the merchant secret', async () => {
    const port = (hookServer.address() as AddressInfo).port;
    const m = await newMerchant({ webhook_url: `http://127.0.0.1:${port}/hooks` });
    const tok = await token(m.api_keys.publishable);
    await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 1500, currency: 'usd', payment_token: tok, confirm: true });
    received.length = 0;
    await deliverDue(100);
    const types = received.map((r) => JSON.parse(r.body).type);
    assert.deepEqual(types.sort(), ['payment_intent.created', 'payment_intent.succeeded']);
    for (const r of received) {
      assert.ok(verify(m.webhook_secret, r.body, r.sig));
      assert.ok(!verify('whsec_wrong', r.body, r.sig));
    }
    const d = await pool.query(`SELECT status FROM webhook_deliveries WHERE merchant_id=$1`, [m.id]);
    assert.ok(d.rows.every((x) => x.status === 'delivered'));
  });
});
