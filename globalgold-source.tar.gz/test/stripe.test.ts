/**
 * Stripe provider, and routing between providers.
 *
 * Stripe's HTTP is stubbed, so the real request shape is asserted without a
 * Stripe account: the form encoding, the Stripe-Account header that makes it a
 * direct charge on the merchant, and application_fee_amount — our cut.
 *
 * The second half is the point of having two providers at all: a merchant in
 * Lagos must be routed to Stripe, because Square cannot onboard them.
 */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { describe, it } from 'node:test';
import { StripeProvider } from '../src/providers/stripe.js';
import { SquareProvider } from '../src/providers/square.js';
import { ProviderError } from '../src/providers/provider.js';

const APP = { secretKey: 'sk_test_platform', clientId: 'ca_test_client' };

function stub(replies: Array<{ status?: number; body: unknown }>) {
  const calls: Array<{ url: string; method: string; headers: Record<string, string>; form: URLSearchParams }> = [];
  const fetchImpl = (async (url: any, init: any) => {
    const reply = replies.shift() ?? { body: {} };
    calls.push({
      url: String(url),
      method: init?.method ?? 'GET',
      headers: init?.headers ?? {},
      form: new URLSearchParams(init?.body ?? ''),
    });
    return new Response(JSON.stringify(reply.body), {
      status: reply.status ?? 200,
      headers: { 'content-type': 'application/json' },
    });
  }) as unknown as typeof fetch;
  return { calls, fetchImpl };
}

const seller = { id: 'acct_local_1', accountId: 'acct_1StripeSeller' };
const succeeded = (over: Record<string, unknown> = {}) => ({
  id: 'pi_3abc', object: 'payment_intent', status: 'succeeded',
  application_fee_amount: 50,
  latest_charge: {
    id: 'ch_1', payment_method_details: { card: { authorization_code: 'A1B2C3' } },
    balance_transaction: { fee: 320 },
  },
  ...over,
});

describe('Stripe: charging on behalf of a connected account', () => {
  it('makes a direct charge on the merchant with our application fee', async () => {
    const { calls, fetchImpl } = stub([{ body: succeeded() }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });

    const out = await sp.charge({
      amount: 10_000, currency: 'usd', capture: true,
      source: { kind: 'provider_token', token: 'pm_card_visa' },
      merchant: seller, platformFee: 50, reference: 'pi_local_9', note: 'Order 5512',
      idempotencyKey: 'order_5512',
    });

    const c = calls[0]!;
    assert.equal(c.url, 'https://api.stripe.com/v1/payment_intents');
    assert.equal(c.headers['Stripe-Account'], 'acct_1StripeSeller', 'charges on the merchant, not the platform');
    assert.equal(c.headers.Authorization, 'Bearer sk_test_platform', 'authenticated with OUR key');
    assert.equal(c.headers['Idempotency-Key'], 'order_5512');
    assert.equal(c.headers['Stripe-Version'], '2026-08-27.basil', 'API version is pinned');
    assert.equal(c.headers['Content-Type'], 'application/x-www-form-urlencoded');

    assert.equal(c.form.get('amount'), '10000');
    assert.equal(c.form.get('currency'), 'usd');
    assert.equal(c.form.get('payment_method'), 'pm_card_visa');
    assert.equal(c.form.get('confirm'), 'true');
    assert.equal(c.form.get('capture_method'), 'automatic');
    assert.equal(c.form.get('application_fee_amount'), '50', 'our 0.5% travels with the payment');
    assert.equal(c.form.get('metadata[global_gold_id]'), 'pi_local_9');
    assert.equal(c.form.get('automatic_payment_methods[allow_redirects]'), 'never',
      'a server-side confirm must never try to redirect the shopper');

    assert.equal(out.approved, true);
    assert.equal(out.providerPaymentId, 'pi_3abc');
    assert.equal(out.authCode, 'A1B2C3');
    assert.equal(out.platformFee, 50);
    assert.equal(out.providerFee, 320, 'Stripe’s own fee is reported back');
  });

  it('authorises without capturing when asked', async () => {
    const { calls, fetchImpl } = stub([{ body: succeeded({ status: 'requires_capture' }) }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    const out = await sp.charge({
      amount: 2_500, currency: 'usd', capture: false,
      source: { kind: 'provider_token', token: 'pm_x' }, merchant: seller, idempotencyKey: 'k1',
    });
    assert.equal(calls[0]!.form.get('capture_method'), 'manual');
    assert.equal(out.approved, true, 'requires_capture is an approval');
    assert.equal(out.status, 'requires_capture');
  });

  it('refuses a raw card number outright', async () => {
    const { calls, fetchImpl } = stub([{ body: succeeded() }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    await assert.rejects(
      () => sp.charge({
        amount: 100, currency: 'usd', capture: true,
        source: { kind: 'pan', pan: '4242424242424242', exp_month: 12, exp_year: 2030 },
        merchant: seller, idempotencyKey: 'k2',
      }),
      (e: unknown) => e instanceof ProviderError && e.code === 'raw_card_not_accepted');
    assert.equal(calls.length, 0, 'a card number never reaches the network');
  });

  it('will not charge a merchant that has not connected Stripe', async () => {
    const { fetchImpl } = stub([{ body: succeeded() }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    await assert.rejects(
      () => sp.charge({
        amount: 100, currency: 'usd', capture: true,
        source: { kind: 'provider_token', token: 'pm_x' },
        merchant: { id: 'acct_none' }, idempotencyKey: 'k3',
      }),
      (e: unknown) => e instanceof ProviderError && e.code === 'merchant_not_connected');
  });

  it('turns a decline into a readable message, not an exception', async () => {
    const { fetchImpl } = stub([{ status: 402, body: { error: { code: 'card_declined', decline_code: 'insufficient_funds', message: 'Your card has insufficient funds.' } } }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    const out = await sp.charge({
      amount: 5_000, currency: 'usd', capture: true,
      source: { kind: 'provider_token', token: 'pm_declined' }, merchant: seller, idempotencyKey: 'k4',
    });
    assert.equal(out.approved, false);
    assert.equal(out.declineCode, 'insufficient_funds');
    assert.match(out.declineMessage!, /insufficient funds/i);
  });

  it('marks a 500 retryable and a 400 not', async () => {
    const boom = new StripeProvider({ ...APP, fetchImpl: stub([{ status: 500, body: { error: { type: 'api_error', message: 'oops' } } }]).fetchImpl });
    await assert.rejects(
      () => boom.charge({ amount: 1, currency: 'usd', capture: true, source: { kind: 'provider_token', token: 't' }, merchant: seller, idempotencyKey: 'k5' }),
      (e: unknown) => e instanceof ProviderError && e.retryable === true);

    const bad = new StripeProvider({ ...APP, fetchImpl: stub([{ status: 400, body: { error: { type: 'invalid_request_error', code: 'parameter_missing', message: 'bad' } } }]).fetchImpl });
    await assert.rejects(
      () => bad.charge({ amount: 1, currency: 'usd', capture: true, source: { kind: 'provider_token', token: 't' }, merchant: seller, idempotencyKey: 'k6' }),
      (e: unknown) => e instanceof ProviderError && e.retryable === false);
  });
});

describe('Stripe: capture, cancel and refund', () => {
  it('captures, optionally for less than was authorised', async () => {
    const { calls, fetchImpl } = stub([{ body: succeeded() }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    await sp.capture({ providerPaymentId: 'pi_3abc', merchant: seller, amount: 1_500, currency: 'usd', idempotencyKey: 'c1' });
    assert.equal(calls[0]!.url, 'https://api.stripe.com/v1/payment_intents/pi_3abc/capture');
    assert.equal(calls[0]!.form.get('amount_to_capture'), '1500');
    assert.equal(calls[0]!.headers['Stripe-Account'], 'acct_1StripeSeller');
  });

  it('cancels an authorisation', async () => {
    const { calls, fetchImpl } = stub([{ body: succeeded({ status: 'canceled' }) }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    const out = await sp.void({ providerPaymentId: 'pi_3abc', merchant: seller, currency: 'usd', idempotencyKey: 'v1' });
    assert.equal(calls[0]!.url, 'https://api.stripe.com/v1/payment_intents/pi_3abc/cancel');
    assert.equal(out.approved, false, 'a cancellation is not an approval');
  });

  it('refunds and claws our fee back in proportion', async () => {
    const { calls, fetchImpl } = stub([{ body: { id: 're_1', object: 'refund', status: 'succeeded' } }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    const out = await sp.refund({
      providerPaymentId: 'pi_3abc', merchant: seller, amount: 5_000, currency: 'usd',
      idempotencyKey: 'r1', platformFeeRefund: 25, reason: 'Customer changed their mind',
    });
    const c = calls[0]!;
    assert.equal(c.url, 'https://api.stripe.com/v1/refunds');
    assert.equal(c.form.get('payment_intent'), 'pi_3abc');
    assert.equal(c.form.get('amount'), '5000');
    assert.equal(c.form.get('refund_application_fee'), 'true');
    assert.equal(out.approved, true);
    assert.equal(out.providerPaymentId, 're_1');
  });

  it('leaves our fee alone when we are not clawing it back', async () => {
    const { calls, fetchImpl } = stub([{ body: { id: 're_2', status: 'pending' } }]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    const out = await sp.refund({ providerPaymentId: 'pi_x', merchant: seller, amount: 100, currency: 'usd', idempotencyKey: 'r2' });
    assert.equal(calls[0]!.form.get('refund_application_fee'), null);
    assert.equal(out.approved, true, 'pending counts as accepted');
  });
});

describe('Stripe: connecting an account', () => {
  it('builds the Connect authorize URL', () => {
    const sp = new StripeProvider({ ...APP, fetchImpl: stub([]).fetchImpl });
    const { url, state } = sp.startOnboarding('acct_9', 'https://pay.globalgoldpay.com/v1/connect/stripe/callback');
    const u = new URL(url);
    assert.equal(u.origin + u.pathname, 'https://connect.stripe.com/oauth/authorize');
    assert.equal(u.searchParams.get('client_id'), 'ca_test_client');
    assert.equal(u.searchParams.get('response_type'), 'code');
    assert.equal(u.searchParams.get('scope'), 'read_write');
    assert.ok(state.startsWith('acct_9.'), 'state ties the callback to this merchant');
  });

  it('exchanges the code and keeps only the account id', async () => {
    const { calls, fetchImpl } = stub([
      { body: { stripe_user_id: 'acct_1Seller', refresh_token: 'rt_1', livemode: false } },
      { body: { id: 'acct_1Seller', country: 'NG', default_currency: 'ngn', business_profile: { name: 'Lagos Juice' } } },
    ]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    const out = await sp.completeOnboarding('ac_code', 'https://pay/cb');

    assert.equal(calls[0]!.url, 'https://connect.stripe.com/oauth/token');
    assert.equal(calls[0]!.form.get('grant_type'), 'authorization_code');
    assert.equal(calls[0]!.form.get('code'), 'ac_code');

    assert.equal(out.accountId, 'acct_1Seller');
    assert.equal(out.accessToken, '', 'Stripe deprecated per-merchant tokens; there is no secret to store');
    assert.equal(out.businessName, 'Lagos Juice');
    assert.equal(out.country, 'NG');
  });

  it('still returns the account id if the account lookup fails', async () => {
    const { fetchImpl } = stub([
      { body: { stripe_user_id: 'acct_1Seller' } },
      { status: 500, body: { error: { message: 'down' } } },
    ]);
    const sp = new StripeProvider({ ...APP, fetchImpl });
    const out = await sp.completeOnboarding('ac_code', 'https://pay/cb');
    assert.equal(out.accountId, 'acct_1Seller');
  });
});

describe('Stripe: webhook signatures', () => {
  const SECRET = 'whsec_test_secret';
  const sp = () => new StripeProvider({ ...APP, webhookSecret: SECRET, fetchImpl: stub([]).fetchImpl });
  const now = () => Math.floor(Date.now() / 1000);
  const header = (body: string, t = now(), secret = SECRET) =>
    `t=${t},v1=${crypto.createHmac('sha256', secret).update(`${t}.${body}`).digest('hex')}`;

  it('accepts a correctly signed notification', () => {
    const body = JSON.stringify({ id: 'evt_1', type: 'payment_intent.succeeded' });
    assert.equal(sp().verifyWebhook(body, { 'stripe-signature': header(body) }, 'https://x'), true);
  });

  it('rejects a tampered body and a wrong secret', () => {
    const body = JSON.stringify({ id: 'evt_1', type: 'payment_intent.succeeded' });
    const sig = header(body);
    assert.equal(sp().verifyWebhook('{"id":"evt_EVIL"}', { 'stripe-signature': sig }, 'https://x'), false);
    assert.equal(sp().verifyWebhook(body, { 'stripe-signature': header(body, now(), 'whsec_other') }, 'https://x'), false);
  });

  it('rejects a replay from outside the tolerance window', () => {
    const body = '{"id":"evt_old"}';
    const old = now() - 3600;
    assert.equal(sp().verifyWebhook(body, { 'stripe-signature': header(body, old) }, 'https://x'), false,
      'an hour-old signature must not be accepted');
    const fresh = now() - 60;
    assert.equal(sp().verifyWebhook(body, { 'stripe-signature': header(body, fresh) }, 'https://x'), true,
      'a minute-old one is fine');
  });

  it('accepts one of several signatures during a secret rotation', () => {
    const body = '{"id":"evt_rot"}';
    const t = now();
    const good = crypto.createHmac('sha256', SECRET).update(`${t}.${body}`).digest('hex');
    const other = crypto.createHmac('sha256', 'whsec_old').update(`${t}.${body}`).digest('hex');
    assert.equal(sp().verifyWebhook(body, { 'stripe-signature': `t=${t},v1=${other},v1=${good}` }, 'https://x'), true);
  });

  it('rejects a missing header, a malformed one, and an unconfigured secret', () => {
    const body = '{"a":1}';
    assert.equal(sp().verifyWebhook(body, {}, 'https://x'), false);
    assert.equal(sp().verifyWebhook(body, { 'stripe-signature': 'nonsense' }, 'https://x'), false);
    assert.equal(sp().verifyWebhook(body, { 'stripe-signature': `t=${now()}` }, 'https://x'), false, 'no v1');
    const noSecret = new StripeProvider({ ...APP, fetchImpl: stub([]).fetchImpl });
    assert.equal(noSecret.verifyWebhook(body, { 'stripe-signature': header(body) }, 'https://x'), false);
  });
});

describe('choosing between providers', () => {
  const sq = new SquareProvider({ env: 'sandbox', appId: 'a', appSecret: 'b', fetchImpl: stub([]).fetchImpl });
  const st = new StripeProvider({ ...APP, fetchImpl: stub([]).fetchImpl });

  it('Stripe covers the corridors Square cannot', () => {
    for (const c of ['NG', 'KE', 'GH', 'IN', 'BR', 'MX', 'ZA']) {
      assert.ok(!sq.merchantCountries.includes(c as never), `Square cannot serve ${c}`);
      assert.ok(st.merchantCountries.includes(c as never), `Stripe can serve ${c}`);
    }
  });

  it('both cover the core markets, so either can take a US merchant', () => {
    for (const c of ['US', 'CA', 'GB', 'AU', 'IE', 'JP']) {
      assert.ok(sq.merchantCountries.includes(c as never), `Square serves ${c}`);
      assert.ok(st.merchantCountries.includes(c as never), `Stripe serves ${c}`);
    }
  });

  it('neither ever accepts a card number', () => {
    assert.equal(sq.tokenizesInBrowser, true);
    assert.equal(st.tokenizesInBrowser, true);
  });
});
