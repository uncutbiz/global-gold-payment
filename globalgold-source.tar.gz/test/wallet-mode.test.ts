/**
 * The wallet kill switch.
 *
 * WALLET_MODE decides how much regulated activity this deployment performs.
 * These tests run the real server in each mode and confirm the gate holds at the
 * HTTP layer — because a switch that can be bypassed by guessing a URL is not a
 * switch, and the thing being switched off here is unlicensed money transmission.
 *
 * Each mode needs its own process, since config is read once at start-up, so the
 * server is started as a child with the environment set.
 */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { spawn, type ChildProcess } from 'node:child_process';
import { after, before, describe, it } from 'node:test';

const DB = process.env.TEST_DATABASE_URL;

async function startServer(env: Record<string, string>): Promise<{ base: string; stop: () => Promise<void> }> {
  const port = 4100 + Math.floor(Math.random() * 400);
  const child: ChildProcess = spawn(process.execPath, ['--import', 'tsx', 'src/server.ts'], {
    env: {
      ...process.env,
      PORT: String(port),
      DATABASE_URL: DB,
      DATABASE_SSL: 'off',
      PUBLIC_URL: `http://127.0.0.1:${port}`,
      ADMIN_TOKEN: 'wallet-mode-test-token-0123456789',
      VAULT_KEY: crypto.randomBytes(32).toString('base64'),
      FINGERPRINT_KEY: crypto.randomBytes(32).toString('base64'),
      LOG_REQUESTS: 'off',
      WEBHOOK_WORKER: 'off',
      ...env,
    } as NodeJS.ProcessEnv,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stderr = '';
  child.stderr?.on('data', (d) => { stderr += d; });

  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 100; i++) {
    if (child.exitCode !== null) throw new Error(`server exited (${child.exitCode}):\n${stderr}`);
    try {
      const r = await fetch(base + '/health');
      if (r.ok) break;
    } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 200));
  }
  return {
    base,
    stop: () => new Promise<void>((resolve) => {
      if (child.exitCode !== null) return resolve();
      child.once('exit', () => resolve());
      child.kill('SIGTERM');
      setTimeout(() => { child.kill('SIGKILL'); resolve(); }, 4000).unref();
    }),
  };
}

/** A signed-in customer, created through the public API. */
async function customer(base: string) {
  const email = `mode-${crypto.randomBytes(4).toString('hex')}@test.com`;
  const r = await fetch(base + '/v1/wallet/signup', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name: 'Mode Tester', email, password: 'a-long-password-123', country: 'US' }),
  });
  assert.equal(r.status, 201, 'signing up always works — an account is not money movement');
  return { email, token: (await r.json()).token as string };
}

function call(base: string, token: string) {
  return (method: string, path: string, body?: unknown) =>
    fetch(base + path, {
      method,
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
}

describe('WALLET_MODE=off — no stored value, the only setting that needs no licence', { concurrency: false }, () => {
  if (!DB) { it('needs TEST_DATABASE_URL', { skip: true }, () => {}); return; }
  let s: Awaited<ReturnType<typeof startServer>>;
  let api: ReturnType<typeof call>;
  let me: Awaited<ReturnType<typeof customer>>;

  before(async () => {
    s = await startServer({ WALLET_MODE: 'off' });
    me = await customer(s.base);
    api = call(s.base, me.token);
  });
  after(async () => { await s?.stop(); });

  it('advertises the truth on /v1/platform', async () => {
    const p = await (await fetch(s.base + '/v1/platform')).json();
    assert.equal(p.wallet_mode, 'off');
    assert.equal(p.features.card_payments, true, 'cards still work — that is the business');
    assert.equal(p.features.wallet_balances, false);
    assert.equal(p.features.person_to_person, false);
    assert.equal(p.features.international_transfers, false);
  });

  it('blocks every money-movement endpoint with a clear reason', async () => {
    const blocked: Array<[string, string, unknown]> = [
      ['POST', '/v1/wallet/top_ups', { amount: 1000, card: 'card_x' }],
      ['POST', '/v1/wallet/transfers', { to: 'someone@test.com', amount: 1000 }],
      ['POST', '/v1/wallet/transfer_quotes', { to: 'someone@test.com', amount: 1000 }],
      ['POST', '/v1/wallet/conversions', { from: 'usd', to: 'eur', amount: 1000 }],
      ['POST', '/v1/wallet/conversion_quotes', { from: 'usd', to: 'eur', amount: 1000 }],
      ['POST', '/v1/wallet/withdrawals', { amount: 1000 }],
    ];
    for (const [method, path, body] of blocked) {
      const r = await api(method, path, body);
      assert.equal(r.status, 403, `${method} ${path} must be refused`);
      const j = await r.json();
      assert.match(j.error.code, /wallet_disabled|transfers_disabled/, `${path} says why`);
    }
  });

  it('blocks the recipient lookup, so nobody can probe who has an account', async () => {
    const r = await fetch(s.base + `/v1/wallet/recipients?email=${encodeURIComponent(me.email)}`);
    assert.equal(r.status, 403);
  });

  it('still lets a customer sign in and see their account', async () => {
    const r = await api('GET', '/v1/wallet');
    assert.equal(r.status, 200, 'the account itself is not gated');
  });
});

describe('WALLET_MODE=platform_only — balances, but no sending to other people', { concurrency: false }, () => {
  if (!DB) { it('needs TEST_DATABASE_URL', { skip: true }, () => {}); return; }
  let s: Awaited<ReturnType<typeof startServer>>;
  let api: ReturnType<typeof call>;

  before(async () => {
    s = await startServer({ WALLET_MODE: 'platform_only' });
    api = call(s.base, (await customer(s.base)).token);
  });
  after(async () => { await s?.stop(); });

  it('reports balances on but transfers off', async () => {
    const p = await (await fetch(s.base + '/v1/platform')).json();
    assert.equal(p.wallet_mode, 'platform_only');
    assert.equal(p.features.wallet_balances, true);
    assert.equal(p.features.pay_with_wallet, true);
    assert.equal(p.features.person_to_person, false);
    assert.equal(p.features.withdrawals, false);
  });

  it('refuses person-to-person transfers and withdrawals', async () => {
    for (const [method, path, body] of [
      ['POST', '/v1/wallet/transfers', { to: 'someone@test.com', amount: 1000 }],
      ['POST', '/v1/wallet/withdrawals', { amount: 1000 }],
    ] as Array<[string, string, unknown]>) {
      const r = await api(method, path, body);
      assert.equal(r.status, 403, `${path} must stay closed`);
      assert.equal((await r.json()).error.code, 'transfers_disabled');
    }
  });

  it('allows a top-up to be attempted (the gate is open, validation takes over)', async () => {
    const r = await api('POST', '/v1/wallet/top_ups', { amount: 1000, card: 'card_does_not_exist' });
    assert.notEqual(r.status, 403, 'not blocked by the wallet gate');
    assert.ok(r.status >= 400, 'but still rejected, because that card is not real');
  });
});

describe('WALLET_MODE=full — everything on, as used in development', { concurrency: false }, () => {
  if (!DB) { it('needs TEST_DATABASE_URL', { skip: true }, () => {}); return; }
  let s: Awaited<ReturnType<typeof startServer>>;

  before(async () => { s = await startServer({ WALLET_MODE: 'full' }); });
  after(async () => { await s?.stop(); });

  it('reports every feature on', async () => {
    const p = await (await fetch(s.base + '/v1/platform')).json();
    assert.equal(p.wallet_mode, 'full');
    assert.equal(p.features.person_to_person, true);
    assert.equal(p.features.international_transfers, true);
    assert.equal(p.features.withdrawals, true);
  });

  it('lets transfer quotes through the gate', async () => {
    const me = await customer(s.base);
    const r = await call(s.base, me.token)('POST', '/v1/wallet/transfer_quotes', { to: 'nobody@test.com', amount: 1000 });
    assert.notEqual(r.status, 403, 'the gate is open in full mode');
  });
});

describe('production refuses to run unlicensed money transmission', { concurrency: false }, () => {
  if (!DB) { it('needs TEST_DATABASE_URL', { skip: true }, () => {}); return; }

  it('will not start with WALLET_MODE=full in production unless the licence is declared', async () => {
    await assert.rejects(
      () => startServer({ WALLET_MODE: 'full', NODE_ENV: 'production', DATABASE_SSL: 'off', TRUST_PROXY: '0' }),
      (e: unknown) => {
        const msg = String((e as Error).message);
        assert.match(msg, /money-transmitter licensing|WALLET_MONEY_TRANSMITTER_LICENSED/,
          'the error must explain why it refused');
        return true;
      });
  });

  it('starts in production with WALLET_MODE=off', async () => {
    const s = await startServer({ WALLET_MODE: 'off', NODE_ENV: 'production', DATABASE_SSL: 'off', TRUST_PROXY: '0' });
    const p = await (await fetch(s.base + '/v1/platform')).json();
    assert.equal(p.wallet_mode, 'off');
    await s.stop();
  });
});
