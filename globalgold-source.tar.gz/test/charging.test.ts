/**
 * Charging a real processor, through the API a merchant actually calls.
 *
 * The provider layer was already tested in isolation. This file tests the thing
 * that matters commercially: that POST /v1/payment_intents/:id/confirm on a
 * merchant connected to Square ends up as a Square payment with our platform
 * fee attached — and the same for Stripe — rather than quietly going to the
 * built-in simulator.
 *
 * Both processor APIs are stubbed, so this runs offline and the request bodies
 * can be inspected. What is asserted is mostly *what we sent them*: the fee
 * field, the seller's token, the connected-account header, the idempotency key.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

const PUBLIC_URL = 'https://pay.globalgoldpay.test';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-charging';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.PUBLIC_URL = PUBLIC_URL;
process.env.WALLET_MODE = 'off';
process.env.PLATFORM_FEE_BPS = '50';        // our 0.5%

process.env.PAYMENT_PROVIDERS = 'square,stripe';
process.env.SQUARE_ENV = 'sandbox';
process.env.SQUARE_APP_ID = 'sq0idp-charging';
process.env.SQUARE_APP_SECRET = 'sq0csp-charging';
process.env.SQUARE_WEBHOOK_SIGNATURE_KEY = 'whsec-square';
process.env.STRIPE_SECRET_KEY = 'sk_test_platform';
process.env.STRIPE_CLIENT_ID = 'ca_test_client';
process.env.STRIPE_PUBLISHABLE_KEY = 'pk_test_publishable';
process.env.STRIPE_WEBHOOK_SECRET = 'whsec_stripe';

// ---- both processor APIs, stubbed ------------------------------------------
type Host = 'square' | 'stripe';
type Call = { host: Host; url: string; method: string; headers: Record<string, string>; body: string };
const calls: Call[] = [];
const queue: Record<Host, Array<{ status?: number; body: unknown }>> = { square: [], stripe: [] };
const realFetch = globalThis.fetch;

globalThis.fetch = (async (url: any, init: any) => {
  const u = String(url);
  const host: Host | null = u.includes('squareup') ? 'square' : u.includes('stripe.com') ? 'stripe' : null;
  if (!host) return realFetch(url, init);
  calls.push({
    host, url: u, method: init?.method ?? 'GET',
    headers: (init?.headers ?? {}) as Record<string, string>,
    body: typeof init?.body === 'string' ? init.body : '',
  });
  const reply = queue[host].shift() ?? { body: {} };
  return new Response(JSON.stringify(reply.body), {
    status: reply.status ?? 200, headers: { 'content-type': 'application/json' },
  });
}) as typeof fetch;

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

let base = '';
let server: http.Server;

async function api(method: string, path: string, key?: string, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json, text };
}

/** A business that has been approved, so it can take payments. */
async function business(country: string) {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await api('POST', '/v1/business/signup', undefined, {
    business_name: `Seller ${who}`, name: 'Owner', email: `c-${who}@test.com`,
    password: 'a-long-password-123', country, business_type: 'company',
  });
  assert.equal(r.status, 201, r.text);
  await pool.query(`UPDATE merchants SET status='active' WHERE id=$1`, [r.body.merchant_id]);
  return { key: r.body.token as string, id: r.body.merchant_id as string };
}

/** Walk a merchant through the processor's OAuth flow, with it stubbed. */
async function connect(b: { key: string }, want: Host, accountId: string) {
  const start = await api('POST', '/v1/connect/start', b.key, { provider: want });
  assert.equal(start.status, 200, start.text);
  queue[want] = want === 'square'
    ? [{ body: { access_token: `EAAA-${accountId}`, refresh_token: 'rt', merchant_id: accountId, expires_at: '2032-01-01T00:00:00Z' } },
       { body: { locations: [{ id: 'LOC-MAIN', status: 'ACTIVE', business_name: 'Sq Seller', currency: 'USD', country: 'US' }] } }]
    : [{ body: { stripe_user_id: accountId, refresh_token: 'rt' } },
       { body: { id: accountId, country: 'NG', default_currency: 'ngn', business_profile: { name: 'Lagos Juice' } } }];
  const state = new URL(start.body.url).searchParams.get('state')!;
  const cb = await fetch(`${base}/v1/connect/${want}/callback?code=authorization-code-long&state=${encodeURIComponent(state)}`);
  assert.equal(cb.status, 200, await cb.text());
}

const last = (host: Host) => [...calls].reverse().find((c) => c.host === host)!;
const paymentCalls = () => calls.filter((c) => c.host === 'square' && c.url.endsWith('/v2/payments'));

async function intent(key: string, amount: number, captureMethod?: 'manual') {
  const r = await api('POST', '/v1/payment_intents', key, {
    amount, currency: 'usd', ...(captureMethod ? { capture_method: captureMethod } : {}), description: 'A thing',
  });
  assert.equal(r.status, 201, r.text);
  return r.body;
}

/** Signed ledger balance of an account, in minor units. */
async function ledger(account: string, currency = 'usd') {
  const r = await pool.query(
    `SELECT COALESCE(SUM(credit - debit), 0)::bigint AS n FROM ledger_lines WHERE account=$1 AND currency=$2`,
    [account, currency]);
  return Number(r.rows[0].n);
}

let sq: { key: string; id: string };
let st: { key: string; id: string };

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  sq = await business('US');
  await connect(sq, 'square', 'MLSELLER1');
  st = await business('NG');
  await connect(st, 'stripe', 'acct_1Lagos');
});

after(async () => {
  server?.close();
  await pool.end();
  globalThis.fetch = realFetch;
});

describe('charging through Square', () => {
  it('sends the payment to Square with our platform fee attached', async () => {
    const pi = await intent(sq.key, 10_000);
    calls.length = 0;
    queue.square = [{ body: { payment: { id: 'sqpay_ok', status: 'COMPLETED', app_fee_money: { amount: 50, currency: 'USD' }, card_details: { auth_result_code: 'A1B2C3' } } } }];

    const r = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:card-nonce-ok' });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.body.status, 'succeeded');

    const c = last('square');
    assert.ok(c.url.endsWith('/v2/payments'), `called ${c.url}`);
    assert.equal(c.headers.Authorization, 'Bearer EAAA-MLSELLER1', "the seller's own token, not ours");
    const sent = JSON.parse(c.body);
    assert.equal(sent.source_id, 'cnon:card-nonce-ok');
    assert.deepEqual(sent.app_fee_money, { amount: 50, currency: 'USD' }, '0.5% of $100.00');
    assert.equal(sent.autocomplete, true, 'automatic capture');
    assert.equal(sent.location_id, 'LOC-MAIN');
    assert.equal(sent.reference_id, pi.id, 'so both sides can be reconciled');

    assert.equal(r.body.processor.provider, 'square');
    assert.equal(r.body.processor.payment_id, 'sqpay_ok');
    assert.equal(r.body.processor.platform_fee, 50);
    assert.equal(r.body.fee, 50, 'what the merchant is charged by us, not a 2.9% acquiring rate');
  });

  it('records the platform fee on our books and nothing of the merchant’s money', async () => {
    const before = {
      ourFees: await ledger('platform:fee_revenue'),
      owedByProcessor: await ledger('platform:provider_fee_receivable'),
      merchant: await ledger(`merchant:${sq.id}:pending`),
      ourSettlement: await ledger('platform:settlement_receivable'),
    };
    const pi = await intent(sq.key, 20_000);
    calls.length = 0;
    queue.square = [{ body: { payment: { id: 'sqpay_led', status: 'COMPLETED', app_fee_money: { amount: 100, currency: 'USD' } } } }];
    assert.equal((await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:ok' })).body.status, 'succeeded');

    // What we asked for and what we book are two different things, and both
    // matter: we ask for 0.5%, and we book whatever Square confirms it took.
    assert.deepEqual(JSON.parse(last('square').body).app_fee_money, { amount: 100, currency: 'USD' }, 'asked for 0.5% of $200');
    assert.equal(await ledger('platform:fee_revenue') - before.ourFees, 100, 'and booked what Square took');
    assert.equal(await ledger('platform:provider_fee_receivable') - before.owedByProcessor, -100,
      'and Square owes it to us (a debit balance)');
    assert.equal(await ledger(`merchant:${sq.id}:pending`), before.merchant,
      'the buyer’s money went to the merchant’s own Square account, so nothing here');
    assert.equal(await ledger('platform:settlement_receivable'), before.ourSettlement,
      'and none of it is ours to settle');
  });

  it('refuses a card number, because Square must never see one from us', async () => {
    const pi = await intent(sq.key, 5_000);
    const tok = await api('POST', '/v1/tokens', sq.key, {
      card: { number: '4242424242424242', exp_month: 12, exp_year: 2040, cvc: '123' },
    });
    assert.equal(tok.status, 201, tok.text);

    calls.length = 0;
    const r = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { payment_token: tok.body.id });
    assert.equal(r.status, 400, r.text);
    assert.equal(r.body.error.code, 'raw_card_not_accepted');
    assert.match(r.body.error.message, /provider_token/);
    assert.equal(calls.length, 0, 'Square was not contacted');

    const after = await api('GET', `/v1/payment_intents/${pi.id}`, sq.key);
    assert.equal(after.body.status, 'requires_payment_method', 'the intent is left usable');
  });

  it('rejects a request with both kinds of token, and one with neither', async () => {
    const pi = await intent(sq.key, 5_000);
    const both = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { payment_token: 'tok_x', provider_token: 'cnon:y' });
    assert.equal(both.status, 400);
    const neither = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, {});
    assert.equal(neither.status, 400);
  });

  it('keeps a declined payment retryable, and reuses the idempotency key only for the same card', async () => {
    const pi = await intent(sq.key, 7_500);
    calls.length = 0;

    // Square reports a decline as a 4xx with a card error.
    queue.square = [{ status: 402, body: { errors: [{ category: 'PAYMENT_METHOD_ERROR', code: 'CARD_DECLINED', detail: 'Declined' }] } }];
    const bad = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:declined' });
    assert.equal(bad.status, 200, bad.text);
    assert.equal(bad.body.status, 'requires_payment_method');
    assert.ok(bad.body.last_payment_error, 'the shopper is told why');

    // Retrying the SAME card must not be able to charge twice.
    queue.square = [{ status: 402, body: { errors: [{ category: 'PAYMENT_METHOD_ERROR', code: 'CARD_DECLINED', detail: 'Declined' }] } }];
    await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:declined' });

    // A different card is a different attempt and must be allowed through.
    queue.square = [{ body: { payment: { id: 'sqpay_second', status: 'COMPLETED', app_fee_money: { amount: 38, currency: 'USD' } } } }];
    const good = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:other-card' });
    assert.equal(good.body.status, 'succeeded', good.text);

    const keys = paymentCalls().map((c) => JSON.parse(c.body).idempotency_key);
    assert.equal(keys.length, 3);
    assert.equal(keys[0], keys[1], 'same intent, same card ⇒ same key, so a retry cannot double-charge');
    assert.notEqual(keys[0], keys[2], 'a different card is a new attempt');
  });

  it('never stores a card, because it never receives one', async () => {
    const pi = await intent(sq.key, 3_000);
    const cardsBefore = await pool.query('SELECT count(*)::int AS n FROM card_tokens');
    queue.square = [{ body: { payment: { id: 'sqpay_nocard', status: 'COMPLETED' } } }];
    await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:ok' });

    const cardsAfter = await pool.query('SELECT count(*)::int AS n FROM card_tokens');
    assert.equal(cardsAfter.rows[0].n, cardsBefore.rows[0].n, 'no new vault row');
    const row = await pool.query('SELECT token_id, provider FROM payment_intents WHERE id=$1', [pi.id]);
    assert.equal(row.rows[0].token_id, null);
    assert.equal(row.rows[0].provider, 'square');
    const att = await pool.query('SELECT fingerprint, provider, outcome FROM payment_attempts WHERE payment_intent_id=$1', [pi.id]);
    assert.equal(att.rows[0].fingerprint, null, 'nothing to fingerprint');
    assert.equal(att.rows[0].provider, 'square', 'but we know which processor took it');
  });

  it('authorises now and captures later against the Square payment id', async () => {
    const pi = await intent(sq.key, 12_000, 'manual');
    queue.square = [{ body: { payment: { id: 'sqpay_auth', status: 'APPROVED' } } }];
    const conf = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:ok' });
    assert.equal(conf.body.status, 'requires_capture', conf.text);
    assert.equal(JSON.parse(last('square').body).autocomplete, false, 'authorise only');

    calls.length = 0;
    queue.square = [{ body: { payment: { id: 'sqpay_auth', status: 'COMPLETED' } } }];
    const cap = await api('POST', `/v1/payment_intents/${pi.id}/capture`, sq.key, {});
    assert.equal(cap.status, 200, cap.text);
    assert.equal(cap.body.status, 'succeeded');
    assert.match(last('square').url, /\/v2\/payments\/sqpay_auth\/complete$/);
  });

  it('leaves the payment capturable when Square refuses the capture', async () => {
    const pi = await intent(sq.key, 9_000, 'manual');
    queue.square = [{ body: { payment: { id: 'sqpay_cap_fail', status: 'APPROVED' } } }];
    await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:ok' });

    queue.square = [{ status: 500, body: { errors: [{ category: 'API_ERROR', code: 'INTERNAL_SERVER_ERROR', detail: 'boom' }] } }];
    const cap = await api('POST', `/v1/payment_intents/${pi.id}/capture`, sq.key, {});
    assert.equal(cap.status, 502, cap.text);
    const after = await api('GET', `/v1/payment_intents/${pi.id}`, sq.key);
    assert.equal(after.body.status, 'requires_capture',
      'not stranded in processing — the authorisation is still good and can be retried');
  });

  it('cancels an authorisation at Square', async () => {
    const pi = await intent(sq.key, 4_000, 'manual');
    queue.square = [{ body: { payment: { id: 'sqpay_void', status: 'APPROVED' } } }];
    await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:ok' });

    calls.length = 0;
    queue.square = [{ body: { payment: { id: 'sqpay_void', status: 'CANCELED' } } }];
    const c = await api('POST', `/v1/payment_intents/${pi.id}/cancel`, sq.key, {});
    assert.equal(c.body.status, 'canceled', c.text);
    assert.match(last('square').url, /\/v2\/payments\/sqpay_void\/cancel$/);
  });

  it('refunds at Square and hands our fee back in proportion', async () => {
    const pi = await intent(sq.key, 10_000);
    queue.square = [{ body: { payment: { id: 'sqpay_ref', status: 'COMPLETED', app_fee_money: { amount: 50, currency: 'USD' } } } }];
    await api('POST', `/v1/payment_intents/${pi.id}/confirm`, sq.key, { provider_token: 'cnon:ok' });

    const feesBefore = await ledger('platform:fee_revenue');
    calls.length = 0;
    queue.square = [{ body: { refund: { id: 'sqref_1', status: 'COMPLETED', app_fee_money: { amount: 20, currency: 'USD' } } } }];
    const re = await api('POST', '/v1/refunds', sq.key, { payment_intent: pi.id, amount: 4_000 });
    assert.equal(re.status, 201, re.text);
    assert.equal(re.body.status, 'succeeded');

    const c = last('square');
    assert.ok(c.url.endsWith('/v2/refunds'), c.url);
    const sent = JSON.parse(c.body);
    assert.equal(sent.payment_id, 'sqpay_ref');
    assert.deepEqual(sent.amount_money, { amount: 4000, currency: 'USD' });
    assert.deepEqual(sent.app_fee_money, { amount: 20, currency: 'USD' }, '40% of the payment ⇒ 40% of our fee');

    assert.equal(await ledger('platform:fee_revenue') - feesBefore, -20, 'our revenue goes down by the same amount');
    assert.equal(re.body.provider, 'square');
    assert.equal(re.body.provider_refund_id, 'sqref_1');
  });

  it('gives the checkout page Square’s public keys and nothing else', async () => {
    const pi = await intent(sq.key, 2_500);
    const r = await fetch(`${base}/v1/checkout/${pi.id}/payment_config?client_secret=${encodeURIComponent(pi.client_secret)}`);
    const b = await r.json();
    assert.equal(r.status, 200, JSON.stringify(b));
    assert.equal(b.provider, 'square');
    assert.equal(b.tokenizes_in_browser, true);
    assert.equal(b.square.application_id, 'sq0idp-charging');
    assert.equal(b.square.location_id, 'LOC-MAIN');
    assert.match(b.square.sdk_url, /sandbox\.web\.squarecdn\.com/, 'the sandbox SDK, matching SQUARE_ENV');
    const text = JSON.stringify(b);
    assert.ok(!text.includes('sq0csp'), 'the application secret is not in there');
    assert.ok(!text.includes('EAAA'), "nor the seller's access token");
  });

  it('refuses the wrong client secret for the config', async () => {
    const pi = await intent(sq.key, 2_500);
    const r = await fetch(`${base}/v1/checkout/${pi.id}/payment_config?client_secret=wrong`);
    assert.equal(r.status, 404);
  });

  it('pays a hosted checkout with a browser token', async () => {
    const pi = await intent(sq.key, 6_000);
    queue.square = [{ body: { payment: { id: 'sqpay_hosted', status: 'COMPLETED', app_fee_money: { amount: 30, currency: 'USD' } } } }];
    const r = await api('POST', `/v1/checkout/${pi.id}/pay`, undefined, {
      client_secret: pi.client_secret, provider_token: 'cnon:from-the-sdk', verification_token: 'verf_123',
    });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.body.status, 'succeeded');
    assert.equal(JSON.parse(last('square').body).verification_token, 'verf_123', '3-D Secure result passed on');
  });

  it('refuses a raw card at the hosted checkout without vaulting it first', async () => {
    const pi = await intent(sq.key, 6_000);
    const cardsBefore = await pool.query('SELECT count(*)::int AS n FROM card_tokens');
    calls.length = 0;
    const r = await api('POST', `/v1/checkout/${pi.id}/pay`, undefined, {
      client_secret: pi.client_secret,
      card: { number: '4242424242424242', exp_month: 12, exp_year: 2040, cvc: '123' },
    });
    assert.equal(r.status, 400, r.text);
    assert.equal(r.body.error.code, 'raw_card_not_accepted');
    const cardsAfter = await pool.query('SELECT count(*)::int AS n FROM card_tokens');
    assert.equal(cardsAfter.rows[0].n, cardsBefore.rows[0].n,
      'the number was not stored on the way to being refused');
    assert.equal(calls.length, 0);
  });
});

describe('charging through Stripe', () => {
  it('creates the PaymentIntent on the connected account, with our fee', async () => {
    const pi = await api('POST', '/v1/payment_intents', st.key, { amount: 50_000, currency: 'ngn', description: 'Juice' });
    assert.equal(pi.status, 201, pi.text);
    calls.length = 0;
    queue.stripe = [{ body: { id: 'pi_stripe_ok', status: 'succeeded', application_fee_amount: 250, latest_charge: { payment_method_details: { card: { authorization_code: 'AUTH9' } } } } }];

    const r = await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, st.key, { provider_token: 'pm_card_visa' });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.body.status, 'succeeded');

    const c = last('stripe');
    assert.ok(c.url.endsWith('/v1/payment_intents'), c.url);
    assert.equal(c.headers['Stripe-Account'], 'acct_1Lagos', 'a direct charge on the merchant’s account');
    assert.equal(c.headers.Authorization, 'Bearer sk_test_platform', 'with our platform key');
    assert.match(c.body, /payment_method=pm_card_visa/);
    assert.match(c.body, /application_fee_amount=250/, '0.5% of ₦500.00');
    assert.equal(r.body.processor.provider, 'stripe');
    assert.equal(r.body.processor.payment_id, 'pi_stripe_ok');
    assert.equal(r.body.processor.platform_fee, 250);
  });

  it('reports a Stripe decline as a failed payment the shopper can retry', async () => {
    const pi = await api('POST', '/v1/payment_intents', st.key, { amount: 10_000, currency: 'ngn' });
    queue.stripe = [{ status: 402, body: { error: { type: 'card_error', code: 'card_declined', decline_code: 'insufficient_funds', message: 'Declined.' } } }];
    const r = await api('POST', `/v1/payment_intents/${pi.body.id}/confirm`, st.key, { provider_token: 'pm_declined' });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.body.status, 'requires_payment_method');
    assert.ok(r.body.last_payment_error.message);
  });

  it('gives the checkout page Stripe’s publishable key and the connected account', async () => {
    const pi = await api('POST', '/v1/payment_intents', st.key, { amount: 10_000, currency: 'ngn' });
    const r = await fetch(`${base}/v1/checkout/${pi.body.id}/payment_config?client_secret=${encodeURIComponent(pi.body.client_secret)}`);
    const b = await r.json();
    assert.equal(b.provider, 'stripe');
    assert.equal(b.stripe.publishable_key, 'pk_test_publishable');
    assert.equal(b.stripe.account, 'acct_1Lagos', 'tokenising on the account the charge lands on');
    assert.ok(!JSON.stringify(b).includes('sk_test'), 'the secret key stays here');
  });
});

describe('a merchant that has not connected a processor', () => {
  it('is told to connect one instead of being charged on the wrong rails', async () => {
    const orphan = await business('US');
    const pi = await intent(orphan.key, 5_000);
    calls.length = 0;
    const r = await api('POST', `/v1/payment_intents/${pi.id}/confirm`, orphan.key, { provider_token: 'cnon:ok' });
    assert.equal(r.status, 400, r.text);
    assert.equal(r.body.error.code, 'merchant_not_connected');
    assert.match(r.body.error.message, /square/);
    assert.equal(calls.length, 0, 'no processor was called');

    const after = await api('GET', `/v1/payment_intents/${pi.id}`, orphan.key);
    assert.equal(after.body.status, 'requires_payment_method', 'still confirmable once they connect');
  });
});
