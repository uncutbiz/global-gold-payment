/**
 * The whole platform working together: a business signs up and is approved by
 * staff, verified customers pay it by wallet and card, staff settle, the business
 * is paid out into a customer's wallet, and the books stay balanced throughout.
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.CARD_RATE_LIMIT = '1000';
process.env.AUTH_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

let base = '';
let server: http.Server;
const PNG = 'data:image/png;base64,' + Buffer.concat([Buffer.from('89504e470d0a1a0a', 'hex'), crypto.randomBytes(300)]).toString('base64');
const OWNER = 'test-admin';
let compliance = '';

async function call(method: string, path: string, key: string | null, body?: unknown) {
  const res = await fetch(base + path, {
    method,
    headers: { ...(key ? { authorization: `Bearer ${key}` } : {}), 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() as any };
}
const ok = (r: { status: number; body: any }, status = 200) => { assert.equal(r.status, status, JSON.stringify(r.body)); return r.body; };

async function customer(name: string, country: string) {
  const email = `${name.split(' ')[0].toLowerCase()}.${crypto.randomBytes(3).toString('hex')}@example.com`;
  const s = ok(await call('POST', '/v1/wallet/signup', null, { email, name, password: 'correct horse battery', country }), 201);
  return { token: s.token as string, email, name, country, id: s.user.id as string };
}
async function verify(u: { token: string; name: string; country: string }) {
  const k = ok(await call('POST', '/v1/wallet/kyc', u.token, {
    legal_name: u.name, date_of_birth: '1985-06-01', address_line: '1 Main St', city: 'Town', postal_code: '1000',
    country: u.country, id_type: 'passport', id_number: 'X' + crypto.randomBytes(4).toString('hex'), document: PNG,
  }), 201);
  ok(await call('POST', `/v1/admin/kyc/${k.id}/approve`, compliance, {}));
}
const walletBal = async (token: string, cur: string) =>
  (ok(await call('GET', '/v1/wallet', token)).balances.find((b: any) => b.currency === cur)?.amount ?? 0);

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  ok(await call('POST', '/v1/admin/staff', OWNER, { email: 'ada@globalgold.test', name: 'Ada Compliance', password: 'staff-password-123', role: 'compliance' }), 201);
  compliance = ok(await call('POST', '/v1/admin/login', null, { email: 'ada@globalgold.test', password: 'staff-password-123' })).token;
});

after(async () => {
  server.close();
  await pool.end();
});

describe('full platform journey', () => {
  let biz = '';            // business dashboard session
  let merchantId = '';
  let ada: Awaited<ReturnType<typeof customer>>;   // US customer who pays
  let emeka: Awaited<ReturnType<typeof customer>>; // NG customer who receives business payouts

  it('1. a business signs up and waits for approval', async () => {
    const s = ok(await call('POST', '/v1/business/signup', null, {
      business_name: 'Dripline Mobile IV', name: 'Yvon Owner', email: 'yvon@dripline.test', password: 'business-password',
      country: 'US', business_type: 'company', website: 'https://dripline.example', description: 'Mobile IV hydration',
    }), 201);
    biz = s.token; merchantId = s.merchant_id;
    assert.match(biz, /^ggm_/);

    const acct = ok(await call('GET', '/v1/account', biz));
    assert.equal(acct.status, 'pending_review');
    assert.equal(acct.api_keys.length, 2);
    assert.equal((await call('POST', '/v1/payment_intents', biz, { amount: 1000, currency: 'usd' })).status, 403);

    // Duplicate signup and wrong password are refused; correct login works.
    assert.equal((await call('POST', '/v1/business/signup', null, { business_name: 'Copycat', name: 'X', email: 'yvon@dripline.test', password: 'business-password', country: 'US', business_type: 'company' })).status, 409);
    assert.equal((await call('POST', '/v1/business/login', null, { email: 'yvon@dripline.test', password: 'nope' })).status, 401);
    ok(await call('POST', '/v1/business/login', null, { email: 'YVON@dripline.test', password: 'business-password' }));

    // Staff see it in the queue and on the alerts list.
    const list = ok(await call('GET', '/v1/admin/merchants', compliance));
    assert.equal(list.data[0].id, merchantId);
    assert.equal(list.data[0].owner_name, 'Yvon Owner');
    const alerts = ok(await call('GET', '/v1/admin/alerts?status=open', compliance));
    assert.ok(alerts.data.some((a: any) => a.rule === 'business_review' && a.subject_id === merchantId));
    assert.equal(ok(await call('GET', '/v1/admin/overview', compliance)).merchants.pending_review, 1);
  });

  it('2. staff approve the business, which can then take payments', async () => {
    ok(await call('POST', `/v1/admin/merchants/${merchantId}/status`, compliance, { status: 'active' }));
    assert.equal(ok(await call('GET', '/v1/account', biz)).status, 'active');
    const alerts = ok(await call('GET', '/v1/admin/alerts?status=open', compliance));
    assert.ok(!alerts.data.some((a: any) => a.subject_id === merchantId), 'review alert closed automatically');
  });

  it('3. customers sign up and get verified', async () => {
    ada = await customer('Ada Lovelace', 'US');
    emeka = await customer('Emeka Obi', 'NG');
    await verify(ada);
    const card = ok(await call('POST', '/v1/wallet/cards', ada.token, { card: { number: '4242424242424242', exp_month: 12, exp_year: 2040, cvc: '123' } }), 201);
    ok(await call('POST', '/v1/wallet/top_ups', ada.token, { amount: 50000, card: card.id }), 201);
  });

  it('4. the business can only pay out to a verified wallet', async () => {
    const bad = await call('POST', '/v1/account', biz, { payout_method: 'wallet', payout_wallet_email: emeka.email });
    assert.equal(bad.body.error.code, 'wallet_not_verified');
    await verify(emeka);
    const good = ok(await call('POST', '/v1/account', biz, { payout_method: 'wallet', payout_wallet_email: emeka.email }));
    assert.equal(good.payout_wallet.name, 'Emeka Obi');
  });

  let walletPi: any, cardPi: any;
  it('5. customers pay the business with a wallet and with a card', async () => {
    walletPi = ok(await call('POST', '/v1/payment_intents', biz, { amount: 14900, currency: 'usd', description: 'Hydration package' }), 201);
    const paid = ok(await call('POST', `/v1/checkout/${walletPi.id}/pay_with_wallet`, ada.token, { client_secret: walletPi.client_secret }));
    assert.equal(paid.status, 'succeeded');
    assert.equal(await walletBal(ada.token, 'usd'), 50000 - 14900);

    cardPi = ok(await call('POST', '/v1/payment_intents', biz, { amount: 8900, currency: 'usd', description: 'Recovery drip' }), 201);
    const card = ok(await (async () => {
      const r = await fetch(`${base}/v1/checkout/${cardPi.id}/pay`, { method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ client_secret: cardPi.client_secret, card: { number: '5555555555554444', exp_month: 1, exp_year: 2041, cvc: '321' } }) });
      return { status: r.status, body: await r.json() };
    })());
    assert.equal(card.status, 'succeeded');

    const list = ok(await call('GET', '/v1/payment_intents', biz)).data;
    assert.deepEqual(list.find((p: any) => p.id === walletPi.id).payment_method, { type: 'global_gold_wallet' });
    assert.equal(list.find((p: any) => p.id === cardPi.id).payment_method.brand, 'mastercard');
  });

  it('6. the business refunds part of the wallet payment straight back to the wallet', async () => {
    ok(await call('POST', '/v1/refunds', biz, { payment_intent: walletPi.id, amount: 1900 }), 201);
    assert.equal(await walletBal(ada.token, 'usd'), 50000 - 14900 + 1900);
    const act = ok(await call('GET', '/v1/wallet/activity', ada.token)).data;
    assert.equal(act[0].type, 'refund');
    assert.equal(act[0].counterparty, 'Dripline Mobile IV');
  });

  it('7. staff run settlement and the business is paid out into a wallet', async () => {
    assert.equal((await call('POST', '/v1/admin/settlements/run', compliance, {})).status, 403);   // owner only
    ok(await call('POST', '/v1/admin/settlements/run', OWNER, {}));
    const expected = (14900 - 462) + (8900 - 288) - 1900;
    assert.deepEqual(ok(await call('GET', '/v1/balance', biz)).balances, [{ currency: 'usd', pending: 0, available: expected }]);

    const po = ok(await call('POST', '/v1/payouts', biz, { currency: 'usd' }), 201);
    assert.equal(po.destination, 'wallet');
    assert.equal(po.status, 'paid');
    assert.equal(await walletBal(emeka.token, 'usd'), expected);
    const act = ok(await call('GET', '/v1/wallet/activity', emeka.token)).data;
    assert.equal(act[0].type, 'business_payout');

    // Emeka converts the payout to naira and withdraws some of it.
    const conv = ok(await call('POST', '/v1/wallet/conversions', emeka.token, { from: 'usd', to: 'ngn', amount: expected }), 201);
    ok(await call('POST', '/v1/wallet/withdrawals', emeka.token, { amount: Math.floor(conv.to.amount / 2), currency: 'ngn' }), 201);
    assert.equal(await walletBal(emeka.token, 'usd'), 0);
  });

  it('8. staff see every step in one place, and the books balance', async () => {
    const txs = ok(await call('GET', '/v1/admin/transactions?limit=200', compliance)).data;
    const kinds = new Set(txs.map((t: any) => t.kind));
    for (const k of ['payment', 'refund', 'payout', 'top_up', 'conversion', 'withdrawal']) assert.ok(kinds.has(k), `missing ${k}`);
    const payout = txs.find((t: any) => t.kind === 'payout');
    assert.equal(payout.to_label, 'Emeka Obi (wallet)');
    const walletPayment = txs.find((t: any) => t.id === walletPi.id);
    assert.equal(walletPayment.from_label, 'Ada Lovelace');
    assert.equal(walletPayment.method, 'Global Gold wallet');

    const user = ok(await call('GET', `/v1/admin/users/${emeka.id}`, compliance));
    assert.ok(user.transactions.some((t: any) => t.kind === 'payout'));

    const o = ok(await call('GET', '/v1/admin/overview', compliance));
    assert.equal(o.ledger.balanced, true);
    assert.equal(o.merchants.active, 1);

    const recv = await pool.query(`SELECT COALESCE(SUM(debit) - SUM(credit), 0)::bigint AS open FROM ledger_lines WHERE account = 'platform:settlement_receivable'`);
    assert.equal(Number(recv.rows[0].open), 0, 'everything captured has been funded');

    const audit = ok(await call('GET', '/v1/admin/audit', OWNER)).data.map((a: any) => a.action);
    for (const a of ['merchant.active', 'kyc.approve', 'settlement.run']) assert.ok(audit.includes(a), `audit missing ${a}`);
  });

  it('9. suspending the business stops payments and payouts, and it sees why', async () => {
    ok(await call('POST', `/v1/admin/merchants/${merchantId}/status`, compliance, { status: 'suspended', reason: 'Unusual refund pattern' }));
    const acct = ok(await call('GET', '/v1/account', biz));
    assert.equal(acct.status, 'suspended');
    assert.equal(acct.review_note, 'Unusual refund pattern');
    assert.equal((await call('POST', '/v1/payment_intents', biz, { amount: 1000, currency: 'usd' })).status, 403);
    assert.equal((await call('POST', '/v1/payouts', biz, { currency: 'usd', amount: 1 })).status, 403);
    ok(await call('POST', `/v1/admin/merchants/${merchantId}/status`, compliance, { status: 'active' }));
  });

  it('10. rolling API keys retires the old ones', async () => {
    const first = ok(await call('POST', '/v1/account/keys/roll', biz, {}), 201);
    ok(await call('GET', '/v1/balance', first.secret));
    const second = ok(await call('POST', '/v1/account/keys/roll', first.secret, {}), 201);
    assert.equal((await call('GET', '/v1/balance', first.secret)).status, 401);
    ok(await call('GET', '/v1/balance', second.secret));
    ok(await call('GET', '/v1/balance', biz));   // dashboard session unaffected
  });
});
