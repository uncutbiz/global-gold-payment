/**
 * Phone verification and forgotten passwords by SMS.
 *
 * A reset flow exists to let in someone who cannot prove who they are the
 * usual way, so nearly all of this is about what it REFUSES: an unverified
 * number, a wrong code, an expired one, a reused one, a guessed one, and —
 * the one people forget — answering differently for a number that has an
 * account than for one that does not.
 *
 * The SMS provider is replaced rather than stubbed at the network, so the code
 * that actually goes out is the code under test.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, beforeEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-sms';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'off';
process.env.AUTH_RATE_LIMIT = '1000';
process.env.RESET_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { setSmsProvider, toE164, maskPhone } = await import('../src/notify/sms.js');

/** Every message the platform tried to send, with the code still in it. */
const outbox: Array<{ to: string; body: string }> = [];
let sendFails = false;

setSmsProvider({
  name: 'test',
  async send(to, body) {
    if (sendFails) return { sent: false, error: 'carrier rejected it' };
    outbox.push({ to, body });
    return { sent: true, id: `test_${outbox.length}` };
  },
});

const lastCode = () => outbox[outbox.length - 1]?.body.match(/\b(\d{6})\b/)?.[1];

let base = '';
let server: http.Server;

async function api(method: string, path: string, key?: string, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json, text };
}

let seq = 5550000;
function freshPhone() { return `+1555${String(++seq).slice(-7)}`; }

async function business(password = 'a-long-password-123') {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await api('POST', '/v1/business/signup', undefined, {
    business_name: `SMS ${who}`, name: 'Owner', email: `sms-${who}@test.com`,
    password, country: 'US', business_type: 'company',
  });
  assert.equal(r.status, 201, r.text);
  return { key: r.body.token as string, email: `sms-${who}@test.com`, password };
}

/** A business with a verified number on it, ready to be recovered. */
async function withPhone() {
  const b = await business();
  const phone = freshPhone();
  const s = await api('POST', '/v1/account/phone', b.key, { phone });
  assert.equal(s.status, 200, s.text);
  const v = await api('POST', '/v1/account/phone/verify', b.key, { code: lastCode() });
  assert.equal(v.status, 200, v.text);
  return { ...b, phone };
}

/** Skip the one-minute resend gap without waiting for it. */
async function allowResend(phone: string) {
  await pool.query(
    `UPDATE otp_codes SET created_at = created_at - interval '5 minutes' WHERE phone = $1`, [phone]);
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

beforeEach(() => { outbox.length = 0; sendFails = false; });
after(async () => { server?.close(); await pool.end(); });

describe('phone numbers', () => {
  it('normalises what people actually type', async () => {
    assert.equal(toE164('+1 (555) 010-1234'), '+15550101234');
    assert.equal(toE164('555-010-1234'), '+15550101234');
    assert.equal(toE164('15550101234'), '+15550101234');
    assert.equal(toE164('+44 7700 900123'), '+447700900123');
    assert.equal(toE164('0044 7700 900123'), '+447700900123');
    // Rejected rather than guessed at: a wrong number becomes an account's
    // only way back in, and the mistake surfaces months later.
    assert.equal(toE164('12345'), null);
    assert.equal(toE164('not a phone'), null);
    assert.equal(toE164(''), null);
  });

  it('never shows the whole number back', async () => {
    const m = maskPhone('+15550101234');
    assert.ok(!m.includes('0101'), `masked form still leaks digits: ${m}`);
    assert.match(m, /^\+15••••34$/);
  });

  it('verifies a number with a code, and refuses a wrong one', async () => {
    const b = await business();
    const phone = freshPhone();
    const s = await api('POST', '/v1/account/phone', b.key, { phone });
    assert.equal(s.status, 200, s.text);
    assert.equal(outbox.length, 1);
    assert.equal(outbox[0].to, phone);
    assert.match(lastCode()!, /^\d{6}$/);

    assert.equal((await api('POST', '/v1/account/phone/verify', b.key, { code: '000000' })).status, 400);
    const ok = await api('POST', '/v1/account/phone/verify', b.key, { code: lastCode() });
    assert.equal(ok.status, 200, ok.text);
    assert.equal(ok.body.verified, true);
    assert.ok(!ok.body.phone.includes(phone.slice(4)), 'the reply must not echo the number');
  });

  it('refuses a number already verified elsewhere', async () => {
    const a = await withPhone();
    const b = await business();
    const r = await api('POST', '/v1/account/phone', b.key, { phone: a.phone });
    assert.equal(r.status, 409);
  });

  it('tells the caller when the carrier refused, rather than pretending', async () => {
    const b = await business();
    sendFails = true;
    const r = await api('POST', '/v1/account/phone', b.key, { phone: freshPhone() });
    assert.equal(r.status, 502);
    assert.equal(r.body.error.code, 'sms_failed');
  });
});

describe('forgotten password', () => {
  it('walks the whole way through and signs the account out', async () => {
    const b = await withPhone();
    const signedIn = await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: b.password });
    assert.equal(signedIn.status, 200);
    outbox.length = 0;
    await allowResend(b.phone);

    assert.equal((await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone })).status, 200);
    assert.equal(outbox.length, 1, 'a code goes out');

    const v = await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code: lastCode() });
    assert.equal(v.status, 200, v.text);
    assert.ok(v.body.ticket?.startsWith('rst_'));

    const done = await api('POST', '/v1/business/forgot_password/reset', undefined,
      { ticket: v.body.ticket, new_password: 'brand-new-password-9' });
    assert.equal(done.status, 200, done.text);

    assert.equal((await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: b.password })).status, 401, 'the old password is dead');
    assert.equal((await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: 'brand-new-password-9' })).status, 200);
    assert.equal((await api('GET', '/v1/account', signedIn.body.token)).status, 401,
      'the session that existed before the reset must be gone');
  });

  it('answers a number with no account exactly as one with an account', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    const real = await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const fake = await api('POST', '/v1/business/forgot_password', undefined, { phone: freshPhone() });
    const junk = await api('POST', '/v1/business/forgot_password', undefined, { phone: 'not a number' });

    // If these differed, the endpoint would be a tool for finding out which
    // numbers bank here, one number at a time.
    assert.equal(real.status, fake.status);
    assert.deepEqual(real.body, fake.body);
    assert.deepEqual(real.body, junk.body);
  });

  it('will not reset an account whose number was never verified', async () => {
    const b = await business();
    const phone = freshPhone();
    await api('POST', '/v1/account/phone', b.key, { phone });   // sent, never confirmed
    outbox.length = 0;
    await allowResend(phone);

    const r = await api('POST', '/v1/business/forgot_password', undefined, { phone });
    assert.equal(r.status, 200, 'still the same answer');
    assert.equal(outbox.length, 0, 'but no code is actually sent');
  });

  it('gives up after a handful of wrong codes', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const right = lastCode()!;

    for (let i = 0; i < 5; i++) {
      const r = await api('POST', '/v1/business/forgot_password/verify', undefined,
        { phone: b.phone, code: String(100000 + i) });
      assert.equal(r.status, 400, `guess ${i + 1} should be rejected`);
    }
    // Six digits is one in a million only if the guesses run out.
    const after = await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code: right });
    assert.equal(after.status, 429, 'the real code must not work after the cap');
  });

  it('will not accept a code twice', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const code = lastCode()!;
    assert.equal((await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code })).status, 200);
    assert.equal((await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code })).status, 400);
  });

  it('will not accept an expired code', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const code = lastCode()!;
    await pool.query(`UPDATE otp_codes SET expires_at = now() - interval '1 minute' WHERE phone=$1`, [b.phone]);
    assert.equal((await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code })).status, 400);
  });

  it('retires the previous code when a new one is sent', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const first = lastCode()!;
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const second = lastCode()!;
    assert.notEqual(first, second);

    assert.equal((await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code: first })).status, 400, 'two live codes would double the guessing surface');
    assert.equal((await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code: second })).status, 200);
  });

  it('will not spend a ticket twice, or accept an invented one', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const v = await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code: lastCode() });

    assert.equal((await api('POST', '/v1/business/forgot_password/reset', undefined,
      { ticket: v.body.ticket, new_password: 'first-new-password-1' })).status, 200);
    assert.equal((await api('POST', '/v1/business/forgot_password/reset', undefined,
      { ticket: v.body.ticket, new_password: 'second-new-password-2' })).status, 400);
    assert.equal((await api('POST', '/v1/business/forgot_password/reset', undefined,
      { ticket: 'rst_madeupmadeupmadeupmadeup', new_password: 'third-new-password-33' })).status, 400);

    assert.equal((await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: 'first-new-password-1' })).status, 200);
    assert.equal((await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: 'second-new-password-2' })).status, 401);
  });

  it('refuses a new password that is too short, changing nothing', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const v = await api('POST', '/v1/business/forgot_password/verify', undefined,
      { phone: b.phone, code: lastCode() });
    assert.equal((await api('POST', '/v1/business/forgot_password/reset', undefined,
      { ticket: v.body.ticket, new_password: 'short' })).status, 400);
    assert.equal((await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: b.password })).status, 200, 'the old password still works');
  });

  it('stops someone burning through SMS on one number', async () => {
    const b = await withPhone();
    let limited = false;
    for (let i = 0; i < 8; i++) {
      await allowResend(b.phone);
      const r = await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
      if (r.status === 429) { limited = true; break; }
    }
    assert.ok(limited, 'an unmetered SMS endpoint is someone else’s phone bill');
  });

  it('holds off an immediate resend', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    assert.equal((await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone })).status, 200);
    const again = await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    assert.equal(again.status, 429);
    assert.equal(again.body.error.code, 'code_just_sent');
  });

  it('stores no code in readable form', async () => {
    const b = await withPhone();
    await allowResend(b.phone);
    await api('POST', '/v1/business/forgot_password', undefined, { phone: b.phone });
    const code = lastCode()!;
    const rows = await pool.query('SELECT code_hash FROM otp_codes WHERE phone=$1', [b.phone]);
    for (const r of rows.rows) {
      assert.ok(!String(r.code_hash).includes(code),
        'a database read must not hand over live codes');
      assert.match(String(r.code_hash), /^[0-9a-f]{64}$/);
    }
  });
});

describe('changing a password while signed in', () => {
  it('needs the current one, and ends the other sessions', async () => {
    const b = await business();
    const other = await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: b.password });

    assert.equal((await api('POST', '/v1/account/password', b.key,
      { current_password: 'wrong', new_password: 'a-new-password-here' })).status, 401);

    const ok = await api('POST', '/v1/account/password', b.key,
      { current_password: b.password, new_password: 'a-new-password-here' });
    assert.equal(ok.status, 200, ok.text);

    assert.equal((await api('GET', '/v1/account', other.body.token)).status, 401,
      'the other session must be gone');
    assert.equal((await api('POST', '/v1/business/login', undefined,
      { email: b.email, password: 'a-new-password-here' })).status, 200);
  });
});
