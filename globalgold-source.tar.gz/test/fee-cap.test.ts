/**
 * The monthly platform-fee cap.
 *
 * The cap is a promise made to a merchant in a sales conversation — "never
 * more than $49 a month" — so the thing worth testing is not that it usually
 * works, but that it cannot be beaten. Two ways it could be:
 *
 *   1. A race. Two payments confirming at the same instant both read the same
 *      remaining room and both spend it. This is the test that matters, and
 *      it is why the allowance lives in a row that can be locked rather than
 *      in a SUM over payment_intents.
 *   2. Month leakage. A refund crediting the wrong month would hand a merchant
 *      room in a month they never earned it in.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-cap';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.PLATFORM_FEE_CAP_MONTHLY = '4900';       // $49.00

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { reserveFeeRoom, releaseFeeRoom } = await import('../src/payments/service.js');

const CAP = 4900;
let n = 0;

/** A merchant row, which is all the cap table needs to exist. */
async function merchant(): Promise<string> {
  const id = `acct_cap_${n++}_${crypto.randomBytes(3).toString('hex')}`;
  await pool.query(
    `INSERT INTO merchants (id, name, email, status, webhook_secret)
     VALUES ($1, 'Cap Test', $2, 'active', 'whsec_x')`,
    [id, `${id}@test.local`]);
  return id;
}

const charged = async (id: string, month = 'now') => {
  const r = await pool.query(
    `SELECT coalesce(sum(charged), 0)::bigint AS c FROM platform_fee_months
      WHERE merchant_id = $1 ${month === 'now' ? "AND month = date_trunc('month', now() AT TIME ZONE 'UTC')::date" : ''}`,
    [id]);
  return Number(r.rows[0].c);
};

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
});
after(async () => { await pool.end(); });

describe('monthly platform fee cap', () => {
  it('grants what is asked for while there is room', async () => {
    const m = await merchant();
    assert.equal(await reserveFeeRoom(m, 1_000), 1_000);
    assert.equal(await reserveFeeRoom(m, 2_000), 2_000);
    assert.equal(await charged(m), 3_000);
  });

  it('grants only the remainder at the boundary, then nothing', async () => {
    const m = await merchant();
    assert.equal(await reserveFeeRoom(m, 4_000), 4_000);
    // Asking for 2,000 when 900 is left must hand back 900, not 2,000 and not 0.
    assert.equal(await reserveFeeRoom(m, 2_000), 900);
    assert.equal(await reserveFeeRoom(m, 1), 0, 'a full month grants nothing more');
    assert.equal(await charged(m), CAP);
  });

  it('cannot be beaten by concurrent payments', async () => {
    const m = await merchant();
    // Twenty payments confirming at once, each wanting a fifth of the cap.
    // Summed naively that is four caps' worth. Only one may be granted.
    const want = CAP / 5;
    const granted = await Promise.all(
      Array.from({ length: 20 }, () => reserveFeeRoom(m, want)));
    const total = granted.reduce((a, b) => a + b, 0);
    assert.equal(total, CAP, `granted ${total}, cap is ${CAP} — the race is not closed`);
    assert.equal(await charged(m), CAP);
    assert.ok(granted.every((g) => g >= 0), 'no negative grants');
  });

  it('gives room back when a payment is refunded', async () => {
    const m = await merchant();
    await reserveFeeRoom(m, CAP);
    assert.equal(await reserveFeeRoom(m, 500), 0, 'full');
    await releaseFeeRoom(pool, m, 2_000);
    assert.equal(await charged(m), 2_900);
    assert.equal(await reserveFeeRoom(m, 2_000), 2_000, 'the room came back');
  });

  it('never releases below zero', async () => {
    const m = await merchant();
    await reserveFeeRoom(m, 100);
    await releaseFeeRoom(pool, m, 999_999);
    assert.equal(await charged(m), 0);
  });

  it('keeps months separate, and refunds an old payment against its own month', async () => {
    const m = await merchant();
    const lastMonth = new Date();
    lastMonth.setUTCMonth(lastMonth.getUTCMonth() - 1, 15);

    await reserveFeeRoom(m, CAP, lastMonth);      // last month, full
    assert.equal(await charged(m), 0, 'this month is untouched');
    assert.equal(await reserveFeeRoom(m, 1_000), 1_000, 'this month starts empty');

    // A refund of the OLD payment must free the OLD month.
    await releaseFeeRoom(pool, m, 4_000, lastMonth);
    assert.equal(await charged(m), 1_000, 'this month is unaffected by last month’s refund');
    assert.equal(await reserveFeeRoom(m, 4_000, lastMonth), 4_000, 'last month has room again');
  });

  it('charges in full when the cap is switched off', async () => {
    const { config } = await import('../src/config.js');
    const m = await merchant();
    const saved = config.platformFeeCapMonthly;
    (config as any).platformFeeCapMonthly = 0;
    try {
      assert.equal(await reserveFeeRoom(m, 50_000), 50_000);
      assert.equal(await charged(m), 0, 'nothing is recorded when there is no cap to track');
    } finally {
      (config as any).platformFeeCapMonthly = saved;
    }
  });

  it('ignores a zero or negative request', async () => {
    const m = await merchant();
    assert.equal(await reserveFeeRoom(m, 0), 0);
    assert.equal(await reserveFeeRoom(m, -100), 0);
    assert.equal(await charged(m), 0);
  });
});
