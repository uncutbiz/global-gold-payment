/**
 * Provider layer tests.
 *
 * The Square tests run against a stub of Square's HTTP API that asserts the
 * request we actually send: the endpoint, the pinned API version, the seller's
 * OAuth token, the idempotency key and app_fee_money. That catches the mistakes
 * that matter — charging the wrong party, dropping our fee, double-charging on a
 * retry — without needing a Square sandbox to be reachable.
 */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { describe, it } from 'node:test';
import { SquareProvider } from '../src/providers/square.js';
import { platformFee, ProviderError } from '../src/providers/provider.js';

const APP = { env: 'sandbox' as const, appId: 'sq0idp-test', appSecret: 'sq0csp-secret' };

/** Records every call and replies with whatever the test queues up. */
function stub(replies: Array<{ status?: number; body: unknown }>) {
  const calls: Array<{ url: string; method: string; headers: Record<string, string>; body: any }> = [];
  const fetchImpl = (async (url: any, init: any) => {
    const reply = replies.shift() ?? { body: {} };
    calls.push({
      url: String(url),
      method: init?.method ?? 'GET',
      headers: init?.headers ?? {},
      body: init?.body ? JSON.parse(init.body) : undefined,
    });
    return new Response(JSON.stringify(reply.body), {
      status: reply.status ?? 200,
      headers: { 'content-type': 'application/json' },
    });
  }) as unknown as typeof fetch;
  return { calls, fetchImpl };
}

const seller = { id: 'acct_1', accessToken: 'EAAA-seller-token', locationId: 'L123' };
const completed = (over: Record<string, unknown> = {}) => ({
  payment: {
    id: 'sqpay_abc', status: 'COMPLETED', app_fee_money: { amount: 50, currency: 'USD' },
    card_details: { auth_result_code: 'A1B2C3' },
    processing_fee: [{ amount_money: { amount: 329, currency: 'USD' } }],
    ...over,
  },
});

describe('platform fee arithmetic', () => {
  it('rounds half-up and honours a fixed component', () => {
    assert.equal(platformFee(10_000, 50), 50);          // 0.5% of $100.00 = 50¢
    assert.equal(platformFee(1_000_000, 50), 5_000);    // 0.5% of $10,000 = $50
    assert.equal(platformFee(199, 50), 1);              // 0.995¢ rounds to 1
    assert.equal(platformFee(100, 50, 30), 31);         // 0.5% + 30¢ fixed
    assert.equal(platformFee(0, 50), 0);
    assert.equal(platformFee(-5, 50), 0, 'never a negative fee');
  });

  it('0.5% of a million dollars a month is five thousand dollars', () => {
    assert.equal(platformFee(100_000_000, 50), 500_000);
  });
});

describe('Square: charging on behalf of a seller', () => {
  it('sends the right request and keeps our app fee', async () => {
    const { calls, fetchImpl } = stub([{ body: completed() }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });

    const out = await sq.charge({
      amount: 10_000, currency: 'usd', capture: true,
      source: { kind: 'provider_token', token: 'cnon:card-nonce-ok' },
      merchant: seller, platformFee: 50, reference: 'pi_123', note: 'Order 5512',
      idempotencyKey: 'order_5512',
    });

    const c = calls[0]!;
    assert.equal(c.url, 'https://connect.squareupsandbox.com/v2/payments');
    assert.equal(c.method, 'POST');
    assert.equal(c.headers.Authorization, 'Bearer EAAA-seller-token', 'charges the seller, not the platform');
    assert.equal(c.headers['Square-Version'], '2026-09-16', 'API version is pinned');
    assert.deepEqual(c.body.amount_money, { amount: 10_000, currency: 'USD' });
    assert.deepEqual(c.body.app_fee_money, { amount: 50, currency: 'USD' }, 'our 0.5% travels with the payment');
    assert.equal(c.body.source_id, 'cnon:card-nonce-ok');
    assert.equal(c.body.idempotency_key, 'order_5512');
    assert.equal(c.body.autocomplete, true);
    assert.equal(c.body.location_id, 'L123');
    assert.equal(c.body.reference_id, 'pi_123');

    assert.equal(out.approved, true);
    assert.equal(out.providerPaymentId, 'sqpay_abc');
    assert.equal(out.authCode, 'A1B2C3');
    assert.equal(out.platformFee, 50);
    assert.equal(out.providerFee, 329, 'Square’s own fee is reported back');
  });

  it('authorises without capturing when asked', async () => {
    const { calls, fetchImpl } = stub([{ body: completed({ status: 'APPROVED' }) }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.charge({
      amount: 2_500, currency: 'usd', capture: false,
      source: { kind: 'provider_token', token: 'cnon:x' },
      merchant: seller, idempotencyKey: 'k1',
    });
    assert.equal(calls[0]!.body.autocomplete, false);
    assert.equal(out.approved, true);
    assert.equal(out.status, 'APPROVED');
  });

  it('refuses a raw card number outright', async () => {
    const { calls, fetchImpl } = stub([{ body: completed() }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    await assert.rejects(
      () => sq.charge({
        amount: 100, currency: 'usd', capture: true,
        source: { kind: 'pan', pan: '4242424242424242', exp_month: 12, exp_year: 2030 },
        merchant: seller, idempotencyKey: 'k2',
      }),
      (e: unknown) => e instanceof ProviderError && e.code === 'raw_card_not_accepted');
    assert.equal(calls.length, 0, 'a card number never reaches the network');
  });

  it('will not charge a merchant that has not connected Square', async () => {
    const { fetchImpl } = stub([{ body: completed() }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    await assert.rejects(
      () => sq.charge({
        amount: 100, currency: 'usd', capture: true,
        source: { kind: 'provider_token', token: 'cnon:x' },
        merchant: { id: 'acct_none' }, idempotencyKey: 'k3',
      }),
      (e: unknown) => e instanceof ProviderError && e.code === 'merchant_not_connected');
  });

  it('turns a card decline into a readable message, not an exception', async () => {
    const { fetchImpl } = stub([{ status: 402, body: { errors: [{ code: 'INSUFFICIENT_FUNDS', detail: 'Insufficient funds.' }] } }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.charge({
      amount: 5_000, currency: 'usd', capture: true,
      source: { kind: 'provider_token', token: 'cnon:declined' },
      merchant: seller, idempotencyKey: 'k4',
    });
    assert.equal(out.approved, false);
    assert.equal(out.declineCode, 'INSUFFICIENT_FUNDS');
    assert.match(out.declineMessage!, /insufficient funds/i);
  });

  it('marks a server error retryable and a bad request not', async () => {
    const boom = new SquareProvider({ ...APP, fetchImpl: stub([{ status: 500, body: { errors: [{ code: 'INTERNAL_SERVER_ERROR', detail: 'oops' }] } }]).fetchImpl });
    await assert.rejects(
      () => boom.charge({ amount: 1, currency: 'usd', capture: true, source: { kind: 'provider_token', token: 't' }, merchant: seller, idempotencyKey: 'k5' }),
      (e: unknown) => e instanceof ProviderError && e.retryable === true);

    const bad = new SquareProvider({ ...APP, fetchImpl: stub([{ status: 400, body: { errors: [{ code: 'INVALID_REQUEST_ERROR', detail: 'bad' }] } }]).fetchImpl });
    await assert.rejects(
      () => bad.charge({ amount: 1, currency: 'usd', capture: true, source: { kind: 'provider_token', token: 't' }, merchant: seller, idempotencyKey: 'k6' }),
      (e: unknown) => e instanceof ProviderError && e.retryable === false);
  });

  it('shortens an over-long idempotency key instead of letting Square reject it', async () => {
    const { calls, fetchImpl } = stub([{ body: completed() }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    await sq.charge({
      amount: 100, currency: 'usd', capture: true,
      source: { kind: 'provider_token', token: 't' }, merchant: seller,
      idempotencyKey: 'x'.repeat(120),
    });
    assert.ok(calls[0]!.body.idempotency_key.length <= 45);
    assert.ok(calls[0]!.body.idempotency_key.length > 0);
  });
});

describe('Square: capture, void and refund', () => {
  it('captures a delayed payment', async () => {
    const { calls, fetchImpl } = stub([{ body: completed() }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.capture({ providerPaymentId: 'sqpay_abc', merchant: seller, currency: 'usd', idempotencyKey: 'c1' });
    assert.equal(calls[0]!.url, 'https://connect.squareupsandbox.com/v2/payments/sqpay_abc/complete');
    assert.equal(out.approved, true);
  });

  it('cancels an authorisation', async () => {
    const { calls, fetchImpl } = stub([{ body: completed({ status: 'CANCELED' }) }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.void({ providerPaymentId: 'sqpay_abc', merchant: seller, currency: 'usd', idempotencyKey: 'v1' });
    assert.equal(calls[0]!.url, 'https://connect.squareupsandbox.com/v2/payments/sqpay_abc/cancel');
    assert.equal(out.approved, false, 'CANCELED is not an approval');
    assert.equal(out.status, 'CANCELED');
  });

  it('refunds and gives back our fee in proportion', async () => {
    const { calls, fetchImpl } = stub([{ body: { refund: { id: 'sqref_1', status: 'COMPLETED', app_fee_money: { amount: 25, currency: 'USD' } } } }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.refund({
      providerPaymentId: 'sqpay_abc', merchant: seller, amount: 5_000, currency: 'usd',
      idempotencyKey: 'r1', platformFeeRefund: 25, reason: 'Customer changed their mind',
    });
    const c = calls[0]!;
    assert.equal(c.url, 'https://connect.squareupsandbox.com/v2/refunds');
    assert.equal(c.body.payment_id, 'sqpay_abc');
    assert.deepEqual(c.body.amount_money, { amount: 5_000, currency: 'USD' });
    assert.deepEqual(c.body.app_fee_money, { amount: 25, currency: 'USD' });
    assert.equal(out.approved, true);
    assert.equal(out.providerPaymentId, 'sqref_1');
  });

  it('omits app_fee_money when we are not clawing our fee back', async () => {
    const { calls, fetchImpl } = stub([{ body: { refund: { id: 'sqref_2', status: 'PENDING' } } }]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.refund({ providerPaymentId: 'p', merchant: seller, amount: 100, currency: 'usd', idempotencyKey: 'r2' });
    assert.equal('app_fee_money' in calls[0]!.body, false);
    assert.equal(out.approved, true, 'PENDING counts as accepted');
  });
});

describe('Square: connecting a seller', () => {
  it('builds an authorize URL with the permissions app fees need', () => {
    const sq = new SquareProvider({ ...APP, fetchImpl: stub([]).fetchImpl });
    const { url, state } = sq.startOnboarding('acct_9', 'https://pay.globalgoldpay.com/v1/connect/square/callback');
    const u = new URL(url);
    assert.equal(u.origin + u.pathname, 'https://squareupsandbox.com/oauth2/authorize');
    assert.equal(u.searchParams.get('client_id'), 'sq0idp-test');
    const scopes = (u.searchParams.get('scope') ?? '').split(' ');
    for (const need of ['PAYMENTS_WRITE', 'PAYMENTS_READ', 'PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS']) {
      assert.ok(scopes.includes(need), `scope ${need}`);
    }
    assert.ok(state.startsWith('acct_9.'), 'state ties the callback to this merchant');
    assert.ok(state.length > 'acct_9.'.length + 10, 'state carries a nonce against CSRF');
  });

  it('exchanges the code for tokens and finds the seller’s location', async () => {
    const { calls, fetchImpl } = stub([
      { body: { access_token: 'EAAA-new', refresh_token: 'rt_1', merchant_id: 'MLS123', expires_at: '2027-01-01T00:00:00Z' } },
      { body: { locations: [{ id: 'LOC9', status: 'ACTIVE', business_name: 'Obi Coffee', currency: 'USD', country: 'US' }] } },
    ]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.completeOnboarding('sq0cgb-code', 'https://pay.globalgoldpay.com/cb');

    assert.equal(calls[0]!.url, 'https://connect.squareupsandbox.com/oauth2/token');
    assert.equal(calls[0]!.body.grant_type, 'authorization_code');
    assert.equal(calls[0]!.body.client_secret, 'sq0csp-secret');
    assert.equal(calls[1]!.headers.Authorization, 'Bearer EAAA-new', 'looks up locations as the seller');

    assert.equal(out.accountId, 'MLS123');
    assert.equal(out.accessToken, 'EAAA-new');
    assert.equal(out.refreshToken, 'rt_1');
    assert.equal(out.locationId, 'LOC9');
    assert.equal(out.businessName, 'Obi Coffee');
    assert.equal(out.currency, 'usd');
    assert.ok(out.expiresAt instanceof Date);
  });

  it('keeps the tokens even if the location lookup fails', async () => {
    const { fetchImpl } = stub([
      { body: { access_token: 'EAAA-new', merchant_id: 'MLS123' } },
      { status: 500, body: { errors: [{ code: 'INTERNAL_SERVER_ERROR' }] } },
    ]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.completeOnboarding('code', 'https://x/cb');
    assert.equal(out.accessToken, 'EAAA-new');
    assert.equal(out.locationId, undefined);
  });

  it('refreshes an expiring access token', async () => {
    const { calls, fetchImpl } = stub([
      { body: { access_token: 'EAAA-refreshed', refresh_token: 'rt_2', merchant_id: 'MLS123' } },
      { body: { locations: [] } },
    ]);
    const sq = new SquareProvider({ ...APP, fetchImpl });
    const out = await sq.refreshAccess('rt_1');
    assert.equal(calls[0]!.body.grant_type, 'refresh_token');
    assert.equal(calls[0]!.body.refresh_token, 'rt_1');
    assert.equal(out.accessToken, 'EAAA-refreshed');
  });
});

describe('Square: webhook signatures', () => {
  const KEY = 'whsec-signature-key';
  const URL_ = 'https://pay.globalgoldpay.com/v1/webhooks/square';
  const sq = () => new SquareProvider({ ...APP, webhookSignatureKey: KEY, fetchImpl: stub([]).fetchImpl });
  const sign = (body: string, url = URL_, key = KEY) =>
    crypto.createHmac('sha256', key).update(url + body).digest('base64');

  it('accepts a correctly signed notification', () => {
    const body = JSON.stringify({ type: 'payment.updated', data: { id: 'sqpay_abc' } });
    assert.equal(sq().verifyWebhook(body, { 'x-square-hmacsha256-signature': sign(body) }, URL_), true);
  });

  it('rejects a tampered body', () => {
    const body = JSON.stringify({ type: 'payment.updated', data: { id: 'sqpay_abc' } });
    const sig = sign(body);
    const tampered = JSON.stringify({ type: 'payment.updated', data: { id: 'sqpay_EVIL' } });
    assert.equal(sq().verifyWebhook(tampered, { 'x-square-hmacsha256-signature': sig }, URL_), false);
  });

  it('rejects a signature computed for a different URL', () => {
    const body = '{"a":1}';
    const sig = sign(body, 'https://evil.example.com/hook');
    assert.equal(sq().verifyWebhook(body, { 'x-square-hmacsha256-signature': sig }, URL_), false);
  });

  it('rejects the wrong key, a missing header, and an unconfigured key', () => {
    const body = '{"a":1}';
    assert.equal(sq().verifyWebhook(body, { 'x-square-hmacsha256-signature': sign(body, URL_, 'other-key') }, URL_), false);
    assert.equal(sq().verifyWebhook(body, {}, URL_), false);
    const noKey = new SquareProvider({ ...APP, fetchImpl: stub([]).fetchImpl });
    assert.equal(noKey.verifyWebhook(body, { 'x-square-hmacsha256-signature': sign(body) }, URL_), false);
  });

  it('does not throw on a signature of the wrong length', () => {
    assert.equal(sq().verifyWebhook('{}', { 'x-square-hmacsha256-signature': 'too-short' }, URL_), false);
  });
});

describe('Square: country limits', () => {
  it('lists only countries where app fees work, and excludes the corridors Square cannot serve', () => {
    const sq = new SquareProvider({ ...APP, fetchImpl: stub([]).fetchImpl });
    for (const c of ['US', 'CA', 'GB', 'AU', 'JP']) {
      assert.ok(sq.merchantCountries.includes(c as never), `${c} supported`);
    }
    for (const c of ['NG', 'KE', 'GH', 'IN', 'PH', 'BR', 'MX', 'ZA']) {
      assert.ok(!sq.merchantCountries.includes(c as never),
        `${c} must NOT be offered on Square — it needs another provider`);
    }
  });

  it('never accepts card data', () => {
    const sq = new SquareProvider({ ...APP, fetchImpl: stub([]).fetchImpl });
    assert.equal(sq.tokenizesInBrowser, true);
  });
});
