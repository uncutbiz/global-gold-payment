/**
 * Two processors, live at once.
 *
 * This is the point of the provider layer: a merchant in Brooklyn goes to
 * Square, a merchant in Lagos goes to Stripe, and neither knows the other
 * exists. The server runs with PAYMENT_PROVIDERS=square,stripe and both APIs
 * stubbed, so the routing, the two OAuth flows and the two webhook formats are
 * all exercised together.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

const PUBLIC_URL = 'https://pay.globalgoldpay.test';
const SQ_KEY = 'whsec-square-key';
const ST_KEY = 'whsec_stripe_secret';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-routing';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.PUBLIC_URL = PUBLIC_URL;
process.env.WALLET_MODE = 'off';
process.env.PLATFORM_FEE_BPS = '50';

// Both processors enabled. Square is listed first, so it wins where both can serve.
process.env.PAYMENT_PROVIDERS = 'square,stripe';
process.env.SQUARE_ENV = 'sandbox';
process.env.SQUARE_APP_ID = 'sq0idp-test';
process.env.SQUARE_APP_SECRET = 'sq0csp-test';
process.env.SQUARE_WEBHOOK_SIGNATURE_KEY = SQ_KEY;
process.env.STRIPE_SECRET_KEY = 'sk_test_platform';
process.env.STRIPE_CLIENT_ID = 'ca_test_client';
process.env.STRIPE_WEBHOOK_SECRET = ST_KEY;

// ---- both APIs, stubbed -----------------------------------------------------
type Reply = { status?: number; body: unknown };
const calls: Array<{ host: 'square' | 'stripe'; url: string; headers: Record<string, string>; body: string }> = [];
const queue: Record<'square' | 'stripe', Reply[]> = { square: [], stripe: [] };
const realFetch = globalThis.fetch;

globalThis.fetch = (async (url: any, init: any) => {
  const u = String(url);
  const host = u.includes('squareup') ? 'square' : u.includes('stripe.com') ? 'stripe' : null;
  if (!host) return realFetch(url, init);
  const headers = (init?.headers ?? {}) as Record<string, string>;
  calls.push({ host, url: u, headers, body: init?.body ?? '' });
  const reply = queue[host].shift() ?? { body: {} };
  return new Response(JSON.stringify(reply.body), {
    status: reply.status ?? 200, headers: { 'content-type': 'application/json' },
  });
}) as typeof fetch;

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');
const { providerMerchant } = await import('../src/merchants/connect.js');
const { ourFee } = await import('../src/providers/index.js');

let base = '';
let server: http.Server;

async function api(method: string, path: string, key?: string, body?: unknown) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json, text };
}

async function business(country: string) {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await api('POST', '/v1/business/signup', undefined, {
    business_name: `Seller ${who}`, name: 'Owner', email: `r-${who}@test.com`,
    password: 'a-long-password-123', country, business_type: 'company',
  });
  assert.equal(r.status, 201, r.text);
  return { key: r.body.token as string, id: r.body.merchant_id as string };
}

const stateOf = (url: string) => new URL(url).searchParams.get('state')!;

/** Walk a merchant all the way through a provider's connect flow. */
async function connect(b: { key: string }, want: string | undefined, accountId: string) {
  const start = await api('POST', '/v1/connect/start', b.key, want ? { provider: want } : {});
  assert.equal(start.status, 200, start.text);
  const which = start.body.provider as 'square' | 'stripe';
  queue[which] = which === 'square'
    ? [{ body: { access_token: `EAAA-${accountId}`, refresh_token: 'rt', merchant_id: accountId, expires_at: '2027-01-01T00:00:00Z' } },
       { body: { locations: [{ id: 'LOC1', status: 'ACTIVE', business_name: 'Sq Seller', currency: 'USD', country: 'US' }] } }]
    : [{ body: { stripe_user_id: accountId, refresh_token: 'rt' } },
       { body: { id: accountId, country: 'NG', default_currency: 'ngn', business_profile: { name: 'Lagos Juice' } } }];
  const cb = await fetch(`${base}/v1/connect/${which}/callback?code=authorization-code-long&state=${encodeURIComponent(stateOf(start.body.url))}`);
  const html = await cb.text();
  assert.equal(cb.status, 200, html);
  return { provider: which, html };
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(async () => {
  server?.close();
  await pool.end();
  globalThis.fetch = realFetch;
});

describe('what this deployment offers', () => {
  it('lists both processors, each with its own URLs', async () => {
    const r = await api('GET', '/v1/connect/config');
    const names = r.body.providers.map((p: any) => p.provider);
    assert.deepEqual(names, ['square', 'stripe'], 'in configured order');
    const sq = r.body.providers.find((p: any) => p.provider === 'square');
    const st = r.body.providers.find((p: any) => p.provider === 'stripe');
    assert.equal(sq.oauth_redirect_url, `${PUBLIC_URL}/v1/connect/square/callback`);
    assert.equal(st.oauth_redirect_url, `${PUBLIC_URL}/v1/connect/stripe/callback`);
    assert.equal(sq.webhook_url, `${PUBLIC_URL}/v1/webhooks/square`);
    assert.equal(st.webhook_url, `${PUBLIC_URL}/v1/webhooks/stripe`);
    assert.notEqual(sq.oauth_redirect_url, st.oauth_redirect_url, 'each provider has its own callback');
  });

  it('answers which processors can serve a given country', async () => {
    const us = await api('GET', '/v1/connect/providers?country=US');
    assert.deepEqual(us.body.data.map((d: any) => d.provider), ['square', 'stripe']);

    const ng = await api('GET', '/v1/connect/providers?country=NG');
    assert.deepEqual(ng.body.data.map((d: any) => d.provider), ['stripe'], 'Square cannot serve Nigeria');
  });

  it('reports the platform as multi-provider', async () => {
    const p = await api('GET', '/v1/platform');
    assert.deepEqual(p.body.providers, ['square', 'stripe']);
  });
});

describe('routing a merchant to a processor that can serve them', () => {
  it('sends a US business to Square', async () => {
    const b = await business('US');
    const s = await api('GET', '/v1/connect/status', b.key);
    assert.equal(s.body.provider, 'square', 'the first provider that serves the US');
    assert.deepEqual(s.body.available_providers.map((p: any) => p.name), ['square', 'stripe'],
      'but both are offered, so the merchant can choose');

    const start = await api('POST', '/v1/connect/start', b.key);
    assert.equal(start.body.provider, 'square');
    assert.match(start.body.url, /squareupsandbox\.com/);
  });

  it('sends a Nigerian business to Stripe, because Square cannot take them', async () => {
    const b = await business('NG');
    const s = await api('GET', '/v1/connect/status', b.key);
    assert.equal(s.body.provider, 'stripe');
    assert.equal(s.body.country_supported, true, 'supported — just not by Square');
    assert.deepEqual(s.body.available_providers.map((p: any) => p.name), ['stripe']);

    const start = await api('POST', '/v1/connect/start', b.key);
    assert.equal(start.body.provider, 'stripe');
    assert.match(start.body.url, /connect\.stripe\.com/);
  });

  it('lets a US business pick Stripe instead', async () => {
    const b = await business('US');
    const start = await api('POST', '/v1/connect/start', b.key, { provider: 'stripe' });
    assert.equal(start.body.provider, 'stripe');
    assert.match(start.body.url, /connect\.stripe\.com/);
  });

  it('refuses a processor that cannot serve the country, and names one that can', async () => {
    const b = await business('NG');
    const r = await api('POST', '/v1/connect/start', b.key, { provider: 'square' });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'country_not_supported');
    assert.match(r.body.error.message, /Use stripe instead/i);
  });

  it('refuses a processor that is not enabled at all', async () => {
    const b = await business('US');
    const r = await api('POST', '/v1/connect/start', b.key, { provider: 'adyen' });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'unknown_provider');
    assert.match(r.body.error.message, /square, stripe/);
  });
});

describe('two merchants, two processors, at the same time', () => {
  it('connects one to each and keeps them apart', async () => {
    const brooklyn = await business('US');
    const lagos = await business('NG');

    const a = await connect(brooklyn, 'square', 'MLSQUARE-1');
    const c = await connect(lagos, undefined, 'acct_1Lagos');
    assert.equal(a.provider, 'square');
    assert.equal(c.provider, 'stripe');
    assert.match(a.html, /Square connected/);
    assert.match(c.html, /Stripe connected/);

    const us = await providerMerchant(pool, brooklyn.id);
    const ng = await providerMerchant(pool, lagos.id);
    assert.equal(us.provider.name, 'square');
    assert.equal(ng.provider.name, 'stripe');
    assert.equal(us.accessToken, 'EAAA-MLSQUARE-1', 'Square needs a per-seller token');
    assert.equal(ng.accessToken, '', 'Stripe does not — nothing secret to store');
    assert.equal(ng.accountId, 'acct_1Lagos');

    // A charge for each goes to the right API, with our fee attached.
    calls.length = 0;
    queue.square = [{ body: { payment: { id: 'sqpay_1', status: 'COMPLETED', app_fee_money: { amount: 50, currency: 'USD' } } } }];
    await us.provider.charge({
      amount: 10_000, currency: 'usd', capture: true,
      source: { kind: 'provider_token', token: 'cnon:ok' },
      merchant: us, platformFee: ourFee(10_000), idempotencyKey: 'sq-1',
    });

    queue.stripe = [{ body: { id: 'pi_1', status: 'succeeded', application_fee_amount: 50 } }];
    await ng.provider.charge({
      amount: 10_000, currency: 'ngn', capture: true,
      source: { kind: 'provider_token', token: 'pm_ok' },
      merchant: ng, platformFee: ourFee(10_000), idempotencyKey: 'st-1',
    });

    const sqCall = calls.find((x) => x.host === 'square')!;
    const stCall = calls.find((x) => x.host === 'stripe')!;
    assert.ok(sqCall, 'Square was called');
    assert.ok(stCall, 'Stripe was called');
    assert.equal(sqCall.headers.Authorization, 'Bearer EAAA-MLSQUARE-1', 'Square: the seller’s token');
    assert.equal(stCall.headers['Stripe-Account'], 'acct_1Lagos', 'Stripe: the connected account header');
    assert.equal(stCall.headers.Authorization, 'Bearer sk_test_platform', 'Stripe: our platform key');
    assert.match(sqCall.body, /"app_fee_money"/, 'our fee, Square’s spelling');
    assert.match(stCall.body, /application_fee_amount=50/, 'our fee, Stripe’s spelling');
  });

  it('will not redeem a Square state at the Stripe callback', async () => {
    const b = await business('US');
    const start = await api('POST', '/v1/connect/start', b.key, { provider: 'square' });
    const state = stateOf(start.body.url);
    calls.length = 0;
    const cb = await fetch(`${base}/v1/connect/stripe/callback?code=authorization-code-long&state=${encodeURIComponent(state)}`);
    assert.equal(cb.status, 400);
    assert.match(await cb.text(), /expired or was already used/i);
    assert.equal(calls.length, 0, 'neither processor was contacted');
  });
});

describe('two webhook formats on one server', () => {
  const sqSign = (body: string) =>
    crypto.createHmac('sha256', SQ_KEY).update(`${PUBLIC_URL}/v1/webhooks/square` + body).digest('base64');
  const stSign = (body: string, t = Math.floor(Date.now() / 1000)) =>
    `t=${t},v1=${crypto.createHmac('sha256', ST_KEY).update(`${t}.${body}`).digest('hex')}`;

  it('accepts a Square notification at the Square URL', async () => {
    const body = JSON.stringify({ event_id: 'sq-evt-1', type: 'payment.updated', merchant_id: 'MLSQUARE-1' });
    const r = await fetch(base + '/v1/webhooks/square', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-square-hmacsha256-signature': sqSign(body) }, body,
    });
    assert.deepEqual(await r.json(), { received: true, duplicate: false });
  });

  it('accepts a Stripe notification at the Stripe URL', async () => {
    const body = JSON.stringify({ id: 'st-evt-1', type: 'payment_intent.succeeded', account: 'acct_1Lagos' });
    const r = await fetch(base + '/v1/webhooks/stripe', {
      method: 'POST', headers: { 'content-type': 'application/json', 'stripe-signature': stSign(body) }, body,
    });
    assert.deepEqual(await r.json(), { received: true, duplicate: false });
    const row = await pool.query('SELECT provider, merchant_id FROM provider_events WHERE event_id = $1', ['st-evt-1']);
    assert.equal(row.rows[0].provider, 'stripe');
    assert.ok(row.rows[0].merchant_id, 'matched to the Lagos merchant by its Stripe account id');
  });

  it('rejects each provider’s notification at the other’s URL', async () => {
    const sqBody = JSON.stringify({ event_id: 'sq-evt-2', type: 'payment.updated' });
    const wrong1 = await fetch(base + '/v1/webhooks/stripe', {
      method: 'POST', headers: { 'x-square-hmacsha256-signature': sqSign(sqBody) }, body: sqBody,
    });
    assert.equal(wrong1.status, 401, 'a Square signature means nothing to Stripe');

    const stBody = JSON.stringify({ id: 'st-evt-2', type: 'payment_intent.succeeded' });
    const wrong2 = await fetch(base + '/v1/webhooks/square', {
      method: 'POST', headers: { 'stripe-signature': stSign(stBody) }, body: stBody,
    });
    assert.equal(wrong2.status, 401, 'and the reverse');

    const stored = await pool.query(
      "SELECT count(*)::int AS n FROM provider_events WHERE event_id IN ('sq-evt-2','st-evt-2')");
    assert.equal(stored.rows[0].n, 0, 'nothing unverified is stored');
  });

  it('ignores a processor that is not enabled', async () => {
    const r = await fetch(base + '/v1/webhooks/adyen', { method: 'POST', body: '{}' });
    assert.equal(r.status, 404);
  });
});
