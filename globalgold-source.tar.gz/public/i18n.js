/*
 * Translation, without a framework.
 *
 * Every translatable string in the HTML carries a key:
 *
 *   <h1 data-i18n="welcome_back_9f2a">Welcome back</h1>
 *   <input data-i18n-attr="placeholder:email_address_3c71">
 *
 * The English text stays in the markup. That is deliberate: the page is
 * readable and correct with this script disabled, with a missing catalogue, or
 * before the fetch lands. A payments page that renders blank because a JSON
 * file 404'd is worse than one that renders in English.
 *
 * A missing key falls back to whatever the markup says, per key rather than
 * per file — so a half-finished translation shows the translated half and
 * leaves the rest in English, instead of refusing to load.
 *
 * Strings built in JavaScript are NOT covered by the markup pass. Use t() for
 * those:  toast(t('payment_sent_a1b2', 'Payment sent'))
 */
(function () {
  'use strict';

  var SUPPORTED = {
    en: 'English',
    es: 'Español',
    ht: 'Kreyòl Ayisyen',
    sw: 'Kiswahili',
    zh: '中文',
  };
  var STORE_KEY = 'ggp_lang';
  var catalogue = {};
  var current = 'en';

  /*
   * Which language to start in.
   *
   * A choice the person made beats the browser's guess, every time — someone
   * on a borrowed laptop or a phone set to the wrong locale has already told
   * us what they want, and being overruled by navigator.language on the next
   * page is maddening.
   *
   * navigator.language is a full tag ("es-419", "zh-Hant-TW"), so only the
   * primary subtag is compared. Note "zh" covers both scripts here; splitting
   * Simplified from Traditional would need zh-Hans and zh-Hant catalogues.
   */
  function pick() {
    var saved = null;
    try { saved = localStorage.getItem(STORE_KEY); } catch (e) { /* private mode */ }
    if (saved && SUPPORTED[saved]) return saved;

    var tags = (navigator.languages && navigator.languages.length)
      ? navigator.languages
      : [navigator.language || navigator.userLanguage || 'en'];
    for (var i = 0; i < tags.length; i++) {
      var primary = String(tags[i] || '').toLowerCase().split('-')[0];
      if (SUPPORTED[primary]) return primary;
    }
    return 'en';
  }

  /** A translated string, or the fallback. Never undefined. */
  function t(key, fallback) {
    var hit = catalogue[key];
    return (typeof hit === 'string' && hit.length) ? hit : (fallback == null ? key : fallback);
  }

  /*
   * Apply the catalogue to the document.
   *
   * The original English is kept on the node the first time it is seen, so
   * switching back to English — or to a language with gaps — restores the real
   * text rather than leaving the previous language's words behind.
   */
  function apply(root) {
    var scope = root || document;

    var nodes = scope.querySelectorAll('[data-i18n]');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.getAttribute('data-i18n-en') === null) n.setAttribute('data-i18n-en', n.textContent);
      n.textContent = t(n.getAttribute('data-i18n'), n.getAttribute('data-i18n-en'));
    }

    // data-i18n-attr="placeholder:key, title:other_key"
    var attrNodes = scope.querySelectorAll('[data-i18n-attr]');
    for (var j = 0; j < attrNodes.length; j++) {
      var el = attrNodes[j];
      var pairs = el.getAttribute('data-i18n-attr').split(',');
      for (var k = 0; k < pairs.length; k++) {
        var bits = pairs[k].split(':');
        if (bits.length !== 2) continue;
        var attr = bits[0].trim(), key = bits[1].trim();
        var keep = 'data-i18n-en-' + attr;
        if (el.getAttribute(keep) === null) el.setAttribute(keep, el.getAttribute(attr) || '');
        el.setAttribute(attr, t(key, el.getAttribute(keep)));
      }
    }

    document.documentElement.lang = current;
  }

  function load(lang) {
    if (lang === 'en') { catalogue = {}; current = 'en'; apply(); return Promise.resolve(); }
    return fetch('/static/i18n/' + lang + '.json', { cache: 'no-cache' })
      .then(function (r) { return r.ok ? r.json() : {}; })
      .then(function (json) { catalogue = json || {}; current = lang; apply(); })
      .catch(function () {
        // A failed fetch leaves the page in English rather than breaking it.
        catalogue = {}; current = 'en'; apply();
      });
  }

  function setLanguage(lang) {
    if (!SUPPORTED[lang]) return Promise.resolve();
    try { localStorage.setItem(STORE_KEY, lang); } catch (e) { /* private mode */ }
    return load(lang);
  }

  /** Fill and wire any <select id="languageSelect"> on the page. */
  function mountPicker() {
    var sel = document.getElementById('languageSelect');
    if (!sel) return;
    if (!sel.options.length) {
      Object.keys(SUPPORTED).forEach(function (code) {
        var o = document.createElement('option');
        o.value = code; o.textContent = SUPPORTED[code];
        sel.appendChild(o);
      });
    }
    sel.value = current;
    sel.addEventListener('change', function () { setLanguage(sel.value); });
  }

  window.i18n = {
    t: t,
    apply: apply,
    setLanguage: setLanguage,
    get language() { return current; },
    supported: SUPPORTED,
  };
  // Shorthand, because JS-built strings are the common case in this app.
  window.t = t;

  function start() {
    current = pick();
    mountPicker();
    load(current).then(mountPicker);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
