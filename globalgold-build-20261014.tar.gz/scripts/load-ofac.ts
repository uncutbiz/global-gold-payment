/**
 * Load the OFAC Specially Designated Nationals list into watchlist_entries.
 *
 *   npx tsx scripts/load-ofac.ts                 # fetch from treasury.gov
 *   npx tsx scripts/load-ofac.ts ./sdn.csv       # from a file already here
 *
 * WHY OFAC SDN, AND WHY THIS IS NOT ENOUGH ON ITS OWN
 *
 * The SDN list is published by the US Treasury, free, and is the one list
 * almost every US programme is expected to screen against. Starting here means
 * screening works on day one instead of waiting on a vendor contract.
 *
 * It is also narrow. A real programme screens against the OFAC consolidated
 * list, EU and UN lists, the jurisdiction's own list, and PEP data — which is
 * commercial, because no government publishes a usable one. The source column
 * exists so those arrive beside this rather than replacing it, and a partner
 * bank will usually name the vendor they expect you to use.
 *
 * THE FILE FORMAT
 *
 * SDN.CSV is positional, quoted, and uses the literal string "-0-" where a
 * field is absent — not an empty field. Treating "-0-" as a value puts the
 * string "-0-" in the country column of thousands of rows, so it is mapped to
 * null here rather than at every read site.
 */
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import { pool } from '../src/db.js';
import { normalize } from '../src/compliance/screening.js';

const SDN_URL = 'https://www.treasury.gov/ofac/downloads/sdn.csv';

/** RFC4180 parse. The remarks field contains commas, quotes and newlines. */
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], field = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else quoted = false;
      } else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  return rows;
}

/** OFAC writes "-0-" for an absent field. It is not a value. */
const val = (s: string | undefined): string | null => {
  const t = (s ?? '').trim();
  return !t || t === '-0-' ? null : t;
};

const TYPE: Record<string, string> = {
  individual: 'individual', 'individual.': 'individual',
  entity: 'entity', vessel: 'vessel', aircraft: 'aircraft',
};

const src = process.argv[2];
let csv: string;

if (src) {
  csv = await fs.readFile(src, 'utf8');
  console.log(`  read ${src}`);
} else {
  console.log(`  fetching ${SDN_URL}`);
  const r = await fetch(SDN_URL);
  if (!r.ok) {
    console.error(`\n  Could not fetch the list: HTTP ${r.status}.`);
    console.error('  Download sdn.csv in a browser and pass the path instead.\n');
    process.exit(1);
  }
  csv = await r.text();
}

const rows = parseCsv(csv).filter((r) => r.length >= 2 && r[0]?.trim());
if (!rows.length) {
  console.error('  No rows parsed — is this the SDN.CSV file?');
  process.exit(1);
}

// The version is the hash of the file itself. Two loads of the same list
// produce the same version, so a screening record stays reproducible, and a
// changed list is visible as a changed version without trusting a date.
const version = 'ofac_sdn:' + crypto.createHash('sha256').update(csv).digest('hex').slice(0, 12);
console.log(`  ${rows.length} rows, version ${version}`);

let loaded = 0, skipped = 0;
const client = await pool.connect();
try {
  await client.query('BEGIN');
  for (const r of rows) {
    // ent_num, SDN_Name, SDN_Type, Program, Title, Call_Sign, Vess_type,
    // Tonnage, GRT, Vess_flag, Vess_owner, Remarks
    const [entNum, name, sdnType, program, , , , , , , , remarks] = r;
    const clean = val(name);
    if (!clean) { skipped++; continue; }

    await client.query(
      `INSERT INTO watchlist_entries
         (id, source, external_id, name, normalized_name, entity_type, program, remarks, list_version)
       VALUES ($1,'ofac_sdn',$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (source, external_id) WHERE external_id IS NOT NULL
       DO UPDATE SET name = EXCLUDED.name,
                     normalized_name = EXCLUDED.normalized_name,
                     entity_type = EXCLUDED.entity_type,
                     program = EXCLUDED.program,
                     remarks = EXCLUDED.remarks,
                     list_version = EXCLUDED.list_version,
                     loaded_at = now()`,
      ['wl_' + crypto.randomBytes(9).toString('base64url'), val(entNum) ?? name,
       clean, normalize(clean),
       TYPE[(sdnType ?? '').trim().toLowerCase()] ?? 'unknown',
       val(program), val(remarks), version]);
    loaded++;
  }

  // Entries that were on the previous list and are not on this one have been
  // delisted. They are removed rather than kept, because screening against a
  // stale list is how you block a customer who was cleared months ago — but
  // the screening_checks rows that cited them stay, so past decisions remain
  // explicable.
  const gone = await client.query(
    `DELETE FROM watchlist_entries
      WHERE source = 'ofac_sdn' AND list_version <> $1`, [version]);
  await client.query('COMMIT');
  console.log(`  loaded ${loaded}, skipped ${skipped}, delisted ${gone.rowCount}`);
} catch (e) {
  await client.query('ROLLBACK');
  throw e;
} finally {
  client.release();
}

const n = await pool.query(`SELECT count(*)::int AS n FROM watchlist_entries WHERE source='ofac_sdn'`);
console.log(`  watchlist now holds ${n.rows[0].n} OFAC entries`);
await pool.end();
