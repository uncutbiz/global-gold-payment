/**
 * Loyalty points.
 *
 * Points are money with a different name, so the tests are the same shape as
 * the ledger's: the arithmetic is pinned exactly, a retried earn does not pay
 * twice, and a balance cannot be taken below zero however the redemptions
 * race.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-loyalty';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const {
  pointsForAmount, redemptionValue, maxRedeemable,
  getProgram, setProgram, getAccount, earn, redeem, listTransactions,
} = await import('../src/merchants/loyalty.js');

let n = 0;
async function merchant() {
  const id = `acct_loy_${n++}_${crypto.randomBytes(3).toString('hex')}`;
  await pool.query(`INSERT INTO merchants (id, name, email, status, webhook_secret) VALUES ($1,$2,$3,'active','whsec_x')`,
    [id, 'Shop', `${id}@test.local`]);
  return id;
}
async function customer(merchantId: string) {
  const id = `cus_${crypto.randomBytes(4).toString('hex')}`;
  await pool.query(`INSERT INTO customers (id, merchant_id, name) VALUES ($1,$2,'Buyer')`, [id, merchantId]);
  return id;
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
});
after(async () => { await pool.end(); });

// ───────────────────────────────────────────── pure math
describe('loyalty arithmetic', () => {
  it('earns per whole unit spent, dropping the remainder', () => {
    assert.equal(pointsForAmount(499, { earn_points_per_unit: 1 }), 4, '$4.99 earns 4, not 5, not 4.99');
    assert.equal(pointsForAmount(1000, { earn_points_per_unit: 3 }), 30);
    assert.equal(pointsForAmount(99, { earn_points_per_unit: 10 }), 0, 'under one unit earns nothing');
  });
  it('earns nothing on a negative or non-integer amount', () => {
    assert.equal(pointsForAmount(-500, { earn_points_per_unit: 1 }), 0);
    assert.equal(pointsForAmount(1.5, { earn_points_per_unit: 1 }), 0);
  });
  it('values points at the redemption rate', () => {
    assert.equal(redemptionValue(100, { redeem_minor_per_point: 1 }), 100);
    assert.equal(redemptionValue(100, { redeem_minor_per_point: 2 }), 200);
    assert.equal(redemptionValue(-5, { redeem_minor_per_point: 1 }), 0);
  });
  it('caps a redemption by balance, by the bill, and by the minimum', () => {
    const p = { merchant_id: 'm', enabled: true, currency: 'usd', earn_points_per_unit: 1, redeem_minor_per_point: 1, min_redeem_points: 50 };
    assert.equal(maxRedeemable(1000, 300, p), 300, 'bounded by the bill');
    assert.equal(maxRedeemable(120, 10000, p), 120, 'bounded by balance');
    assert.equal(maxRedeemable(40, 10000, p), 0, 'below the minimum means zero, not 40');
    assert.equal(maxRedeemable(1000, 0, { ...p, redeem_minor_per_point: 0 }), 0, 'a zero rate never divides by zero');
  });
});

// ───────────────────────────────────────────── configure
describe('configuring a program', () => {
  it('defaults to disabled and can be turned on with rates', async () => {
    const m = await merchant();
    const before = await getProgram(m);
    assert.equal(before.enabled, false);
    const p = await setProgram(m, { enabled: true, earn_points_per_unit: 2, redeem_minor_per_point: 1, min_redeem_points: 100, currency: 'usd' });
    assert.equal(p.enabled, true);
    assert.equal(p.earn_points_per_unit, 2);
    assert.equal((await getProgram(m)).min_redeem_points, 100);
  });
  it('refuses a negative rate', async () => {
    const m = await merchant();
    await assert.rejects(() => setProgram(m, { earn_points_per_unit: -1 }), /whole number/);
  });
});

// ───────────────────────────────────────────── earn & redeem
describe('earning and redeeming', () => {
  it('earns on a purchase and reflects it in the balance', async () => {
    const m = await merchant(); const c = await customer(m);
    await setProgram(m, { enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 1 });
    const e = await earn(m, c, 2599, 'pay_1');     // $25.99 -> 25
    assert.equal(e.points, 25);
    assert.equal((await getAccount(m, c)).balance, 25);
  });

  it('the same source earns only once, so a retried webhook is harmless', async () => {
    const m = await merchant(); const c = await customer(m);
    await setProgram(m, { enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 1 });
    await earn(m, c, 1000, 'pay_dup');
    const second = await earn(m, c, 1000, 'pay_dup');
    assert.equal(second.points, 0);
    assert.equal((second as any).skipped, 'already_earned');
    assert.equal((await getAccount(m, c)).balance, 10, 'balance did not double');
  });

  it('earns nothing while the program is disabled', async () => {
    const m = await merchant(); const c = await customer(m);
    const e = await earn(m, c, 5000, 'x');
    assert.equal(e.points, 0);
    assert.equal((e as any).skipped, 'program_disabled');
  });

  it('redeems points for credit at the configured rate', async () => {
    const m = await merchant(); const c = await customer(m);
    await setProgram(m, { enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 2, min_redeem_points: 10 });
    await earn(m, c, 10_000, 'pay_big');    // 100 points
    const r = await redeem(m, c, 50);
    assert.equal(r.points, 50);
    assert.equal(r.value, 100, '50 points at 2 minor units each is 100');
    assert.equal(r.balance, 50);
  });

  it('refuses redeeming below the minimum or beyond the balance', async () => {
    const m = await merchant(); const c = await customer(m);
    await setProgram(m, { enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 1, min_redeem_points: 20 });
    await earn(m, c, 1500, 'p');  // 15 points
    await assert.rejects(() => redeem(m, c, 10), /minimum/);
    await assert.rejects(() => redeem(m, c, 25), /insufficient|15 points/);
  });

  it('cannot be taken negative by two redemptions racing', async () => {
    const m = await merchant(); const c = await customer(m);
    await setProgram(m, { enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 1 });
    await earn(m, c, 6000, 'p');  // 60 points
    // Fire two redemptions of 40 at once; exactly one must win.
    const results = await Promise.allSettled([redeem(m, c, 40), redeem(m, c, 40)]);
    const ok = results.filter((r) => r.status === 'fulfilled');
    const no = results.filter((r) => r.status === 'rejected');
    assert.equal(ok.length, 1, 'only one redemption of 40 can succeed against a 60 balance');
    assert.equal(no.length, 1);
    assert.equal((await getAccount(m, c)).balance, 20);
  });

  it('records a transaction history', async () => {
    const m = await merchant(); const c = await customer(m);
    await setProgram(m, { enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 1 });
    await earn(m, c, 5000, 'p1');
    await redeem(m, c, 10);
    const tx = await listTransactions(m, c);
    assert.equal(tx.length, 2);
    assert.equal(tx[0].type, 'redeem');
    assert.equal(tx[0].points, -10);
  });

  it('keeps one customer\'s points invisible to another merchant', async () => {
    const a = await merchant(); const b = await merchant();
    const c = await customer(a);
    await setProgram(a, { enabled: true });
    await earn(a, c, 1000, 'p');
    // b does not own customer c; it cannot touch the account.
    await assert.rejects(() => getAccount(b, c), /Customer not found/);
  });
});
