/**
 * The brand endpoints over real HTTP: upload a logo as raw bytes, read it back
 * publicly, change profile fields, and have every refusal come back as a clean
 * status rather than a stack trace.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-brand-api';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(40)]);

let base = '';
let server: http.Server;

async function signup() {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await fetch(base + '/v1/business/signup', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      business_name: `Seller ${who}`, name: 'Owner', email: `c-${who}@test.com`,
      password: 'a-long-password-123', country: 'US', business_type: 'company',
    }),
  });
  const b = await r.json();
  assert.equal(r.status, 201, JSON.stringify(b));
  return { key: b.token as string, id: b.merchant_id as string };
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  const app = createApp();
  server = app.listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(async () => { server?.close(); await pool.end(); });

describe('brand over HTTP', () => {
  it('reads a fresh brand, with no logo', async () => {
    const { key } = await signup();
    const r = await fetch(base + '/v1/brand', { headers: { authorization: `Bearer ${key}` } });
    const b = await r.json();
    assert.equal(r.status, 200);
    assert.equal(b.has_logo, false);
    assert.equal(b.logo_url, null);
  });

  it('refuses without a key', async () => {
    const r = await fetch(base + '/v1/brand');
    assert.equal(r.status, 401);
  });

  it('changes profile fields and normalises them', async () => {
    const { key } = await signup();
    const r = await fetch(base + '/v1/brand', {
      method: 'PATCH',
      headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ display_name: 'Acme Pay', brand_color: 'ABC', support_email: 'Help@Acme.CO' }),
    });
    const b = await r.json();
    assert.equal(r.status, 200, JSON.stringify(b));
    assert.equal(b.brand_color, '#aabbcc');
    assert.equal(b.support_email, 'help@acme.co');
  });

  it('rejects a bad colour with 400, not 500', async () => {
    const { key } = await signup();
    const r = await fetch(base + '/v1/brand', {
      method: 'PATCH',
      headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ brand_color: 'red; background:url(x)' }),
    });
    assert.equal(r.status, 400);
    assert.equal((await r.json()).error.code, 'invalid_color');
  });

  it('uploads a logo as raw bytes and serves it back publicly', async () => {
    const { key, id } = await signup();
    const up = await fetch(base + '/v1/brand/logo', {
      method: 'POST',
      headers: { authorization: `Bearer ${key}`, 'content-type': 'image/png' },
      body: PNG,
    });
    const b = await up.json();
    assert.equal(up.status, 201, JSON.stringify(b));
    assert.equal(b.has_logo, true);
    assert.ok(b.logo_url);

    // Public fetch of the image itself.
    const img = await fetch(base + b.logo_url);
    assert.equal(img.status, 200);
    assert.equal(img.headers.get('content-type'), 'image/png');
    const etag = img.headers.get('etag')!;
    assert.match(etag, /^"[0-9a-f]{32}"$/);
    const bytes = Buffer.from(await img.arrayBuffer());
    assert.ok(bytes.equals(PNG));

    // A conditional request with the etag is a 304.
    const again = await fetch(base + b.logo_url, { headers: { 'if-none-match': etag } });
    assert.equal(again.status, 304);

    // The public brand object exposes the logo and name.
    const pub = await (await fetch(base + `/v1/public/brand/${id}`)).json();
    assert.equal(pub.has_logo, true);
    assert.ok(pub.logo_url);
  });

  it('rejects a non-image upload with a clear 400', async () => {
    const { key } = await signup();
    const r = await fetch(base + '/v1/brand/logo', {
      method: 'POST',
      headers: { authorization: `Bearer ${key}`, 'content-type': 'image/png' },
      body: Buffer.from('this is definitely not a png'),
    });
    assert.equal(r.status, 400);
    assert.equal((await r.json()).error.code, 'unsupported_image');
  });

  it('a public logo request for a business with none is a 404', async () => {
    const { id } = await signup();
    const r = await fetch(base + `/v1/public/brand/${id}/logo`);
    assert.equal(r.status, 404);
  });
});
