/**
 * Items & orders.
 *
 * The pure order arithmetic gets the hardest tests, because a wrong total is
 * money. The database tests are mostly about isolation — one merchant's
 * catalogue and orders must be completely invisible to another — and about the
 * order status machine refusing moves that would misstate what was paid.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-catalog';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const {
  computeOrder, createItem, updateItem, getItem, listItems,
  createOrder, getOrder, listOrders, setOrderStatus, attachPaymentIntent,
  MAX_MINOR, MAX_QTY,
} = await import('../src/merchants/catalog.js');

let n = 0;
async function merchant() {
  const id = `acct_cat_${n++}_${crypto.randomBytes(3).toString('hex')}`;
  await pool.query(
    `INSERT INTO merchants (id, name, email, status, webhook_secret)
     VALUES ($1,$2,$3,'active','whsec_x')`,
    [id, 'Shop', `${id}@test.local`]);
  return id;
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
});
after(async () => { await pool.end(); });

// ───────────────────────────────────────────── computeOrder (pure)
describe('pricing an order', () => {
  it('sums line totals and applies a discount', () => {
    const o = computeOrder('usd', [
      { name: 'Widget', unit_price: 1000, quantity: 3 },   // 3000
      { name: 'Gadget', unit_price: 2550, quantity: 2 },   // 5100
    ], 600);
    assert.equal(o.subtotal, 8100);
    assert.equal(o.discount, 600);
    assert.equal(o.total, 7500);
    assert.equal(o.lines[0].line_total, 3000);
    assert.equal(o.lines[1].line_total, 5100);
  });

  it('a line total is price times quantity, not price plus quantity', () => {
    // Guards the one mutation that still sums to something plausible on qty 1.
    const o = computeOrder('usd', [{ name: 'x', unit_price: 500, quantity: 4 }]);
    assert.equal(o.lines[0].line_total, 2000);
    assert.equal(o.subtotal, 2000);
  });

  it('a zero-priced line is allowed; a free sample is a real line', () => {
    const o = computeOrder('usd', [{ name: 'Sample', unit_price: 0, quantity: 1 }]);
    assert.equal(o.total, 0);
  });

  it('refuses an empty order', () => {
    assert.throws(() => computeOrder('usd', []), /at least one line/);
  });

  it('refuses a non-integer or non-positive quantity', () => {
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 100, quantity: 0 }]), /quantity/);
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 100, quantity: 1.5 }]), /quantity/);
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 100, quantity: -2 }]), /quantity/);
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 100, quantity: MAX_QTY + 1 }]), /quantity/);
  });

  it('refuses a negative or non-integer price', () => {
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: -1, quantity: 1 }]), /price/);
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 9.99, quantity: 1 }]), /price/);
  });

  it('refuses a discount larger than the subtotal — an order can never be negative', () => {
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 100, quantity: 1 }], 101), /discount cannot be larger/);
  });

  it('refuses a discount that is not a whole number of minor units', () => {
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 100, quantity: 1 }], 1.5), /whole number/);
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: 100, quantity: 1 }], -5), /zero or more/);
  });

  it('refuses an order that would exceed the maximum amount', () => {
    assert.throws(() => computeOrder('usd', [{ name: 'x', unit_price: MAX_MINOR, quantity: 2 }]), /exceeds the maximum/);
  });

  it('refuses an unsupported currency and a nameless line', () => {
    assert.throws(() => computeOrder('xyz', [{ name: 'x', unit_price: 1, quantity: 1 }]), /currency/);
    assert.throws(() => computeOrder('usd', [{ name: '  ', unit_price: 1, quantity: 1 }]), /name/);
  });

  it('lowercases the currency it returns', () => {
    assert.equal(computeOrder('USD', [{ name: 'x', unit_price: 1, quantity: 1 }]).currency, 'usd');
  });
});

// ───────────────────────────────────────────── items
describe('the catalogue', () => {
  it('creates, reads and updates an item', async () => {
    const m = await merchant();
    const it = await createItem(m, { name: 'Coffee', price: 450, currency: 'usd', sku: 'CAFE-1' });
    assert.equal(it.price, 450);
    const got = await getItem(m, it.id);
    assert.equal(got.name, 'Coffee');
    const up = await updateItem(m, it.id, { price: 500, active: false });
    assert.equal(up.price, 500);
    assert.equal(up.active, false);
  });

  it('refuses a duplicate SKU within one merchant but allows it across merchants', async () => {
    const a = await merchant(); const b = await merchant();
    await createItem(a, { name: 'A', price: 100, currency: 'usd', sku: 'DUP' });
    await assert.rejects(() => createItem(a, { name: 'A2', price: 100, currency: 'usd', sku: 'DUP' }), /SKU/);
    // Same SKU under a different merchant is fine — the namespaces are separate.
    await assert.doesNotReject(() => createItem(b, { name: 'B', price: 100, currency: 'usd', sku: 'DUP' }));
  });

  it('listing filters by active and never shows another merchant\'s items', async () => {
    const a = await merchant(); const b = await merchant();
    await createItem(a, { name: 'A1', price: 1, currency: 'usd' });
    const a2 = await createItem(a, { name: 'A2', price: 1, currency: 'usd' });
    await updateItem(a, a2.id, { active: false });
    await createItem(b, { name: 'B1', price: 1, currency: 'usd' });

    assert.equal((await listItems(a)).length, 2);
    assert.equal((await listItems(a, { active: true })).length, 1);
    assert.equal((await listItems(b)).length, 1, 'b sees only its own');
  });

  it('cannot read an item through the wrong merchant', async () => {
    const a = await merchant(); const b = await merchant();
    const it = await createItem(a, { name: 'secret', price: 1, currency: 'usd' });
    await assert.rejects(() => getItem(b, it.id), /not found/);
  });
});

// ───────────────────────────────────────────── orders
describe('orders', () => {
  it('builds an order from catalogue items, snapshotting the price', async () => {
    const m = await merchant();
    const coffee = await createItem(m, { name: 'Coffee', price: 450, currency: 'usd' });
    const cake = await createItem(m, { name: 'Cake', price: 700, currency: 'usd' });
    const order = await createOrder(m, { items: [{ item_id: coffee.id, quantity: 2 }, { item_id: cake.id, quantity: 1 }], discount: 100 });
    assert.equal(order.subtotal, 1600);
    assert.equal(order.total, 1500);
    assert.equal(order.lines.length, 2);

    // Raise the catalogue price AFTER the order; the order must not move.
    await updateItem(m, coffee.id, { price: 999 });
    const re = await getOrder(m, order.id);
    assert.equal(re.lines.find((l: any) => l.name === 'Coffee')!.unit_price, 450,
      'the order keeps the price it was placed at');
    assert.equal(re.total, 1500);
  });

  it('refuses an inactive item and an item from another merchant', async () => {
    const a = await merchant(); const b = await merchant();
    const dormant = await createItem(a, { name: 'Old', price: 100, currency: 'usd' });
    await updateItem(a, dormant.id, { active: false });
    await assert.rejects(() => createOrder(a, { items: [{ item_id: dormant.id, quantity: 1 }] }), /not available/);

    const theirs = await createItem(b, { name: 'Theirs', price: 100, currency: 'usd' });
    await assert.rejects(() => createOrder(a, { items: [{ item_id: theirs.id, quantity: 1 }] }), /not found/);
  });

  it('refuses mixing currencies in one order', async () => {
    const m = await merchant();
    const usd = await createItem(m, { name: 'USD item', price: 100, currency: 'usd' });
    const eur = await createItem(m, { name: 'EUR item', price: 100, currency: 'eur' });
    await assert.rejects(() => createOrder(m, { items: [{ item_id: usd.id, quantity: 1 }, { item_id: eur.id, quantity: 1 }] }), /one currency/);
  });

  it('refuses attaching a customer that belongs to someone else', async () => {
    const a = await merchant(); const b = await merchant();
    const item = await createItem(a, { name: 'X', price: 100, currency: 'usd' });
    const cust = await pool.query(`INSERT INTO customers (id, merchant_id, name) VALUES ($1,$2,'Buyer') RETURNING id`,
      [`cus_${crypto.randomBytes(4).toString('hex')}`, b]);
    await assert.rejects(
      () => createOrder(a, { items: [{ item_id: item.id, quantity: 1 }], customer_id: cust.rows[0].id }),
      /Customer not found/);
  });

  it('walks the status machine and blocks illegal moves', async () => {
    const m = await merchant();
    const item = await createItem(m, { name: 'X', price: 100, currency: 'usd' });
    const o = await createOrder(m, { items: [{ item_id: item.id, quantity: 1 }] });
    assert.equal(o.status, 'open');

    const paid = await setOrderStatus(m, o.id, 'paid');
    assert.equal(paid.status, 'paid');
    // paid -> open is not a thing.
    await assert.rejects(() => setOrderStatus(m, o.id, 'open'), /cannot become open/);
    // paid -> canceled is not allowed; money has moved.
    await assert.rejects(() => setOrderStatus(m, o.id, 'canceled'), /cannot become canceled/);
    const done = await setOrderStatus(m, o.id, 'fulfilled');
    assert.equal(done.status, 'fulfilled');
  });

  it('lists a merchant\'s orders and no one else\'s, and attaches a payment intent', async () => {
    const a = await merchant(); const b = await merchant();
    const item = await createItem(a, { name: 'X', price: 100, currency: 'usd' });
    const o = await createOrder(a, { items: [{ item_id: item.id, quantity: 1 }] });
    assert.equal((await listOrders(a)).length, 1);
    assert.equal((await listOrders(b)).length, 0);

    // A fabricated payment-intent id can't be attached — the FK refuses it.
    await assert.rejects(() => attachPaymentIntent(a, o.id, 'pi_does_not_exist'));
  });
});
