/**
 * Items & orders over HTTP, including the one path that crosses modules:
 * turning an order into a payment intent for its exact total.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-catalog-api';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

let base = '';
let server: http.Server;

async function activeBusiness() {
  const who = crypto.randomBytes(4).toString('hex');
  const r = await fetch(base + '/v1/business/signup', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      business_name: `Shop ${who}`, name: 'Owner', email: `c-${who}@test.com`,
      password: 'a-long-password-123', country: 'US', business_type: 'company',
    }),
  });
  const b = await r.json();
  assert.equal(r.status, 201, JSON.stringify(b));
  // Payment intents need an active account; activate directly.
  await pool.query(`UPDATE merchants SET status = 'active' WHERE id = $1`, [b.merchant_id]);
  return { key: b.token as string, id: b.merchant_id as string };
}

function H(key: string) { return { authorization: `Bearer ${key}`, 'content-type': 'application/json' }; }

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(async () => { server?.close(); await pool.end(); });

describe('items & orders over HTTP', () => {
  it('creates an item, an order, and pays it for the exact total', async () => {
    const { key } = await activeBusiness();

    const item = await (await fetch(base + '/v1/items', {
      method: 'POST', headers: H(key),
      body: JSON.stringify({ name: 'Coffee', price: 450, currency: 'usd', sku: 'CAFE-1' }),
    })).json();
    assert.equal(item.price, 450);

    const order = await (await fetch(base + '/v1/orders', {
      method: 'POST', headers: H(key),
      body: JSON.stringify({ items: [{ item_id: item.id, quantity: 3 }], discount: 150 }),
    })).json();
    assert.equal(order.subtotal, 1350);
    assert.equal(order.total, 1200);
    assert.equal(order.status, 'open');

    const pay = await fetch(base + `/v1/orders/${order.id}/pay`, { method: 'POST', headers: H(key) });
    const pb = await pay.json();
    assert.equal(pay.status, 201, JSON.stringify(pb));
    assert.equal(pb.payment_intent.amount, 1200, 'the intent is for the order total, discount applied');
    assert.equal(pb.payment_intent.currency, 'usd');

    // The order now carries the intent, and cannot be paid twice.
    const reread = await (await fetch(base + `/v1/orders/${order.id}`, { headers: H(key) })).json();
    assert.equal(reread.payment_intent_id, pb.payment_intent.id);

    // Paying an open order again must return the SAME intent, never a second
    // one — otherwise a retry becomes a double charge.
    const again = await fetch(base + `/v1/orders/${order.id}/pay`, { method: 'POST', headers: H(key) });
    assert.equal(again.status, 200);
    const ab = await again.json();
    assert.equal(ab.payment_intent.id, pb.payment_intent.id, 'the same intent is returned, not a new one');
  });

  it('a duplicate SKU is a clean 409', async () => {
    const { key } = await activeBusiness();
    await fetch(base + '/v1/items', { method: 'POST', headers: H(key), body: JSON.stringify({ name: 'A', price: 1, currency: 'usd', sku: 'X' }) });
    const dup = await fetch(base + '/v1/items', { method: 'POST', headers: H(key), body: JSON.stringify({ name: 'B', price: 1, currency: 'usd', sku: 'X' }) });
    assert.equal(dup.status, 409);
    assert.equal((await dup.json()).error.code, 'sku_taken');
  });

  it('one business cannot order another\'s item', async () => {
    const a = await activeBusiness();
    const b = await activeBusiness();
    const item = await (await fetch(base + '/v1/items', { method: 'POST', headers: H(a.key), body: JSON.stringify({ name: 'A', price: 100, currency: 'usd' }) })).json();
    const r = await fetch(base + '/v1/orders', { method: 'POST', headers: H(b.key), body: JSON.stringify({ items: [{ item_id: item.id, quantity: 1 }] }) });
    assert.equal(r.status, 404);
  });
});

describe('order payment earns loyalty', () => {
  it('marking an order paid earns the customer points, exactly once', async () => {
    const { key, id } = await activeBusiness();
    // Turn on loyalty: 1 point per unit.
    await fetch(base + '/v1/loyalty/program', { method: 'POST', headers: H(key), body: JSON.stringify({ enabled: true, earn_points_per_unit: 1, redeem_minor_per_point: 1 }) });
    const cust = await pool.query(`INSERT INTO customers (id, merchant_id, name) VALUES ($1,$2,'Buyer') RETURNING id`,
      [`cus_${crypto.randomBytes(4).toString('hex')}`, id]);
    const customerId = cust.rows[0].id;
    const item = await (await fetch(base + '/v1/items', { method: 'POST', headers: H(key), body: JSON.stringify({ name: 'X', price: 2500, currency: 'usd' }) })).json();
    const order = await (await fetch(base + '/v1/orders', { method: 'POST', headers: H(key), body: JSON.stringify({ items: [{ item_id: item.id, quantity: 1 }], customer_id: customerId }) })).json();

    await fetch(base + `/v1/orders/${order.id}/status`, { method: 'POST', headers: H(key), body: JSON.stringify({ status: 'paid' }) });
    let acc = await (await fetch(base + `/v1/loyalty/accounts/${customerId}`, { headers: H(key) })).json();
    assert.equal(acc.balance, 25, '$25.00 earns 25 points');

    // Re-marking paid is a no-op (and a 409 from the state machine); points must not double.
    await fetch(base + `/v1/orders/${order.id}/status`, { method: 'POST', headers: H(key), body: JSON.stringify({ status: 'paid' }) });
    acc = await (await fetch(base + `/v1/loyalty/accounts/${customerId}`, { headers: H(key) })).json();
    assert.equal(acc.balance, 25, 'points did not double');
  });
});
