/**
 * The Remittance Transfer Rule arithmetic and clocks.
 *
 * Every test here is a way the rule gets broken in practice: a disclosed
 * figure that does not match what arrives, a cancellation window measured from
 * the wrong moment, fees at the far end quietly omitted.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

const {
  buildDisclosure, canCancel, cancellationDeadline, cancellationSecondsLeft,
  deliveryMatchesDisclosure, errorReportDeadline, investigationDeadline,
  CANCELLATION_WINDOW_MINUTES,
} = await import('../src/compliance/remittance.js');

const SENT = new Date('2026-10-13T12:00:00Z');
const AVAILABLE = new Date('2026-10-15T12:00:00Z');

const base = {
  sendAmount: 20_000,          // $200.00
  sendCurrency: 'usd',
  ourFee: 499,                 // $4.99
  exchangeRate: 132.5,         // USD -> HTG
  receiveCurrency: 'htg',
  recipientName: 'Marie Joseph',
  availableAt: AVAILABLE,
};

test('the disclosure states what the sender pays and what the recipient gets', () => {
  const d = buildDisclosure(base, SENT);
  assert.equal(d.transfer_amount, 20_000);
  assert.equal(d.our_fee, 499);
  assert.equal(d.total_paid, 20_499, 'total is what leaves the sender, fee included');
  assert.equal(d.gross_receive_amount, 2_650_000);
  assert.equal(d.recipient_receives, 2_650_000, 'with no far-end fees, gross and net agree');
  assert.equal(d.receive_currency, 'HTG');
});

test('fees charged at the receiving end are disclosed and deducted', () => {
  // The violation this prevents: telling a sender the recipient gets 26,500
  // HTG when the cash window takes 2,000 of it.
  const d = buildDisclosure({ ...base, recipientFees: 200_000 }, SENT);
  assert.equal(d.gross_receive_amount, 2_650_000);
  assert.equal(d.recipient_fees, 200_000);
  assert.equal(d.recipient_receives, 2_450_000, 'the disclosed figure is what actually lands');
});

test('rounding never promises more than will arrive', () => {
  // 100.5 units of receiving currency cannot be delivered, so the sender is
  // told 100. Being told 101 and receiving 100 is the error.
  const d = buildDisclosure({ ...base, sendAmount: 201, exchangeRate: 0.5 }, SENT);
  assert.equal(d.recipient_receives, 100);
});

test('a transfer that fees would consume entirely is refused, not disclosed', () => {
  assert.throws(
    () => buildDisclosure({ ...base, recipientFees: 99_999_999 }, SENT),
    /Nothing would reach the recipient/);
});

test('a zero or negative amount, or a missing rate, is refused', () => {
  assert.throws(() => buildDisclosure({ ...base, sendAmount: 0 }, SENT), /positive whole number/);
  assert.throws(() => buildDisclosure({ ...base, sendAmount: -5 }, SENT), /positive whole number/);
  assert.throws(() => buildDisclosure({ ...base, sendAmount: 10.5 }, SENT), /positive whole number/);
  assert.throws(() => buildDisclosure({ ...base, exchangeRate: 0 }, SENT), /exchange rate/);
});

test('the disclosure carries the rights the rule requires it to state', () => {
  const d = buildDisclosure(base, SENT);
  const all = d.disclosures.join(' ');
  assert.match(all, /cancel/i, 'cancellation right must be stated');
  assert.match(all, /180 days/, 'the error reporting window must be stated');
  assert.match(all, /Consumer Financial Protection Bureau/, 'the CFPB must be named');
});

test('the cancellation deadline is on the disclosure, measured from payment', () => {
  const d = buildDisclosure(base, SENT);
  assert.equal(d.cancellation_deadline, '2026-10-13T12:30:00.000Z');
});

// ─────────────────────────────────────────────────────── the clock
test('cancellation is allowed inside the window and refused after it', () => {
  const t = { sent_at: SENT };
  assert.equal(canCancel(t, new Date('2026-10-13T12:29:59Z')).ok, true);
  const late = canCancel(t, new Date('2026-10-13T12:30:01Z'));
  assert.equal(late.ok, false);
  assert.match((late as any).reason, new RegExp(`${CANCELLATION_WINDOW_MINUTES}-minute`));
});

test('money already collected cannot be cancelled, however early it is', () => {
  // The condition people forget. You cannot refund cash handed over a counter,
  // and the window being open does not change that.
  const r = canCancel(
    { sent_at: SENT, collected_at: new Date('2026-10-13T12:05:00Z') },
    new Date('2026-10-13T12:06:00Z'));
  assert.equal(r.ok, false);
  assert.match((r as any).reason, /already been collected/);
});

test('a transfer cannot be cancelled twice', () => {
  const r = canCancel({ sent_at: SENT, status: 'cancelled' }, new Date('2026-10-13T12:01:00Z'));
  assert.equal(r.ok, false);
});

test('the countdown shown to the sender runs to zero and stops', () => {
  assert.equal(cancellationSecondsLeft(SENT, new Date('2026-10-13T12:00:00Z')), 1800);
  assert.equal(cancellationSecondsLeft(SENT, new Date('2026-10-13T12:29:30Z')), 30);
  assert.equal(cancellationSecondsLeft(SENT, new Date('2026-10-13T13:00:00Z')), 0, 'never negative');
});

test('cancellation deadline is exactly thirty minutes', () => {
  assert.equal(cancellationDeadline(SENT).getTime() - SENT.getTime(), 30 * 60_000);
});

// ───────────────────────────────────────────── error resolution clocks
test('the consumer has 180 days to report, and we have 90 to answer', () => {
  assert.equal(errorReportDeadline(AVAILABLE).toISOString().slice(0, 10), '2027-04-13');
  assert.equal(investigationDeadline(new Date('2026-11-01T00:00:00Z')).toISOString().slice(0, 10), '2027-01-30');
});

// ──────────────────────────────── did we deliver what we promised?
test('delivering less than disclosed is an error, with the shortfall named', () => {
  const d = buildDisclosure(base, SENT);
  const r = deliveryMatchesDisclosure(d, { amount: 2_600_000, currency: 'htg' });
  assert.equal(r.ok, false);
  assert.equal((r as any).shortfall, 50_000);
  assert.match((r as any).reason, /less than the sender was told/);
});

test('delivering exactly or more than disclosed is not an error', () => {
  const d = buildDisclosure(base, SENT);
  assert.equal(deliveryMatchesDisclosure(d, { amount: 2_650_000, currency: 'htg' }).ok, true);
  assert.equal(deliveryMatchesDisclosure(d, { amount: 2_650_001, currency: 'HTG' }).ok, true,
    'the sender got what they were promised; more is not a violation');
});

test('delivering in the wrong currency is an error whatever the amount', () => {
  const d = buildDisclosure(base, SENT);
  const r = deliveryMatchesDisclosure(d, { amount: 9_999_999, currency: 'usd' });
  assert.equal(r.ok, false);
  assert.match((r as any).reason, /HTG was disclosed/);
});
