/**
 * A business's brand: logo, colour, display name, support contact.
 *
 * The tests that matter here are the refusals. A logo upload is an untrusted
 * file from the open internet, and almost everything this module does is
 * decide what not to store: a mislabelled file, an SVG, something too large,
 * a colour that is really a line of CSS.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-brand';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const {
  sniffImage, validateLogo, normalizeBrandColor, normalizeEmailish, presentBrand,
  setBrand, getBrand, setLogo, getLogo, deleteLogo, MAX_LOGO_BYTES,
} = await import('../src/merchants/brand.js');

// Smallest real headers for each accepted type, padded past the 12-byte floor.
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(16)]);
const JPEG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(16)]);
const GIF = Buffer.concat([Buffer.from('GIF89a', 'ascii'), Buffer.alloc(16)]);
const WEBP = Buffer.concat([Buffer.from('RIFF', 'ascii'), Buffer.alloc(4), Buffer.from('WEBP', 'ascii'), Buffer.alloc(8)]);

let n = 0;
async function merchant() {
  const id = `acct_brand_${n++}_${crypto.randomBytes(3).toString('hex')}`;
  await pool.query(
    `INSERT INTO merchants (id, name, email, status, webhook_secret)
     VALUES ($1,$2,$3,'active','whsec_x')`,
    [id, 'Acme Co', `${id}@test.local`]);
  return id;
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
});
after(async () => { await pool.end(); });

// ───────────────────────────────────────────── sniffing (pure)
describe('reading an image\'s real type from its bytes', () => {
  it('recognises each accepted format by signature', () => {
    assert.equal(sniffImage(PNG), 'image/png');
    assert.equal(sniffImage(JPEG), 'image/jpeg');
    assert.equal(sniffImage(GIF), 'image/gif');
    assert.equal(sniffImage(WEBP), 'image/webp');
  });

  it('a PNG header with one byte wrong is not a PNG', () => {
    const bad = Buffer.from(PNG); bad[3] = 0x00;
    assert.equal(sniffImage(bad), null);
  });

  it('refuses SVG — it is the format the whole module exists to keep out', () => {
    const svg = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
    assert.equal(sniffImage(svg), null);
  });

  it('too few bytes to carry a signature is null, not a crash', () => {
    assert.equal(sniffImage(Buffer.from([0x89, 0x50])), null);
    assert.equal(sniffImage(Buffer.alloc(0)), null);
  });
});

// ───────────────────────────────────────────── validateLogo (pure)
describe('validating an uploaded logo', () => {
  it('accepts a real raster image and returns its true type', () => {
    assert.deepEqual(validateLogo(PNG), { mime: 'image/png', byteLen: PNG.length });
  });

  it('rejects an empty file', () => {
    assert.throws(() => validateLogo(Buffer.alloc(0)), /empty/i);
  });

  it('rejects a file past the size cap, and the cap is not off by one', () => {
    assert.doesNotThrow(() => validateLogo(Buffer.concat([PNG, Buffer.alloc(MAX_LOGO_BYTES - PNG.length)])));
    assert.throws(() => validateLogo(Buffer.concat([PNG, Buffer.alloc(MAX_LOGO_BYTES)])), /smaller/i);
  });

  it('rejects a file whose bytes are not an accepted image, whatever it claims to be', () => {
    assert.throws(() => validateLogo(Buffer.from('%PDF-1.7\n....................')), /PNG, JPEG/);
  });
});

// ───────────────────────────────────────────── colour & email (pure)
describe('normalising a brand colour', () => {
  it('accepts hex with or without a hash, in any case', () => {
    assert.equal(normalizeBrandColor('#1A73E8'), '#1a73e8');
    assert.equal(normalizeBrandColor('1a73e8'), '#1a73e8');
  });
  it('expands three-digit shorthand', () => {
    assert.equal(normalizeBrandColor('#abc'), '#aabbcc');
  });
  it('refuses anything that is not a hex colour — this value goes into a style attribute', () => {
    assert.throws(() => normalizeBrandColor('red'), /hex/);
    assert.throws(() => normalizeBrandColor('#1a73e8; background:url(x)'), /hex/);
    assert.throws(() => normalizeBrandColor(''), /hex/);
  });
});

describe('normalising a support email', () => {
  it('lowercases and trims a plausible address', () => {
    assert.equal(normalizeEmailish('  Help@Acme.CO '), 'help@acme.co');
  });
  it('rejects something with no @ or no domain', () => {
    assert.throws(() => normalizeEmailish('5551234'), /email/);
    assert.throws(() => normalizeEmailish('help@acme'), /email/);
  });
});

// ───────────────────────────────────────────── presentBrand (pure)
describe('shaping the public brand object', () => {
  it('has no logo_url when there is no logo', () => {
    const b = presentBrand({ id: 'acct_1', name: 'Acme' });
    assert.equal(b.has_logo, false);
    assert.equal(b.logo_url, null);
  });
  it('builds a cache-busted logo_url from the mtime when a logo exists', () => {
    const when = new Date('2026-10-14T00:00:00Z');
    const b = presentBrand({ id: 'acct_1', name: 'Acme', logo_mime: 'image/png', logo_updated_at: when });
    assert.equal(b.has_logo, true);
    assert.equal(b.logo_url, `/v1/public/brand/acct_1/logo?v=${Math.floor(when.getTime() / 1000)}`);
  });
});

// ───────────────────────────────────────────── DB round-trip
describe('storing and reading a brand', () => {
  it('applies a partial update, clears a field with null, and leaves the rest alone', async () => {
    const id = await merchant();
    await setBrand(id, { display_name: 'Acme Payments', brand_color: 'ABC', support_email: 'Help@Acme.co' });
    let b = await getBrand(id);
    assert.equal(b.display_name, 'Acme Payments');
    assert.equal(b.brand_color, '#aabbcc');
    assert.equal(b.support_email, 'help@acme.co');

    // Touch only the colour; the name and email must survive.
    await setBrand(id, { brand_color: '#000000' });
    b = await getBrand(id);
    assert.equal(b.brand_color, '#000000');
    assert.equal(b.display_name, 'Acme Payments', 'an untouched field is not wiped');

    // null clears.
    await setBrand(id, { display_name: null });
    b = await getBrand(id);
    assert.equal(b.display_name, null);
  });

  it('stores a logo, serves it back with a matching etag, and replacing it moves the cache-buster', async () => {
    const id = await merchant();
    await setLogo(id, PNG);
    let b = await getBrand(id);
    assert.equal(b.has_logo, true);
    assert.match(b.logo_url!, /\/logo\?v=\d+$/);
    const firstUrl = b.logo_url!;

    const got = await getLogo(id);
    assert.ok(got);
    assert.equal(got!.mime, 'image/png');
    assert.ok(got!.bytes.equals(PNG));
    assert.match(got!.etag, /^"[0-9a-f]{32}"$/);

    // Replace with a JPEG a second later; the URL's stamp must change.
    await new Promise((r) => setTimeout(r, 1100));
    await setLogo(id, JPEG);
    b = await getBrand(id);
    assert.notEqual(b.logo_url, firstUrl, 'a changed logo must be a new URL or caches would serve the old one');
    assert.equal((await getLogo(id))!.mime, 'image/jpeg');
  });

  it('a bad upload changes nothing that was already stored', async () => {
    const id = await merchant();
    await setLogo(id, PNG);
    await assert.rejects(() => setLogo(id, Buffer.from('not an image at all')), /PNG, JPEG/);
    assert.equal((await getLogo(id))!.mime, 'image/png', 'the good logo is still there');
  });

  it('deleting a logo is idempotent', async () => {
    const id = await merchant();
    await setLogo(id, PNG);
    await deleteLogo(id);
    assert.equal(await getLogo(id), null);
    await deleteLogo(id); // again — must not throw
    const b = await getBrand(id);
    assert.equal(b.has_logo, false);
  });
});
