/**
 * Sanctions and PEP screening.
 *
 * Two halves, kept apart on purpose:
 *
 *   The MATCHING is pure. normalize() and score() take strings and return a
 *   string and a number. No database, no network, no clock. That is what makes
 *   the cases that actually matter testable — "Mohammed" against "Muhammad",
 *   "SMITH, JOHN" against "John Smith", a company against its own name with
 *   "Ltd." on the end — without constructing a fixture for each one.
 *
 *   The DECISION is recorded. Every screen writes a row, including the clear
 *   ones, naming the lists and the snapshot it ran against. An examiner's
 *   question is never "is this name on the list" — it is "show me what you did
 *   in March, and against which list as it stood then".
 *
 * WHAT THIS IS NOT
 *
 * This is name screening. It is not a sanctions compliance programme. It does
 * not do transaction monitoring against sanctioned jurisdictions, beneficial
 * ownership tracing, vessel or aircraft matching, or fuzzy transliteration of
 * non-Latin scripts beyond what normalize() strips. A real programme also has
 * a designated officer, written procedures, periodic independent testing and
 * staff training, none of which is code. Treat this as the engine a programme
 * runs on, not the programme.
 *
 * THE THRESHOLD IS A BUSINESS DECISION, NOT A TECHNICAL ONE
 *
 * Set it low and reviewers drown in false positives, stop reading carefully,
 * and wave through the real one. Set it high and you miss. 85 is a common
 * starting point for name-only matching and is deliberately exposed as config
 * rather than buried, because the right number depends on who your customers
 * are — a platform serving one country with common surnames needs a different
 * number than one serving fifty.
 */
import { pool, tx, one } from '../db.js';
import type { Db } from '../db.js';
import { newId } from '../util/common.js';

/** Score at or above which a human must look. Tunable; see the note above. */
export const MATCH_THRESHOLD = Number(process.env.SCREENING_THRESHOLD ?? 85);

export type SubjectType = 'user' | 'merchant' | 'beneficial_owner' | 'payout_counterparty';
export type CheckStatus = 'clear' | 'potential_match' | 'confirmed_match' | 'false_positive';

export interface WatchlistEntry {
  id: string;
  source: string;
  external_id?: string | null;
  name: string;
  entity_type?: string;
  program?: string | null;
  country?: string | null;
  date_of_birth?: string | null;
  remarks?: string | null;
}

export interface Match {
  entry_id: string;
  name: string;
  source: string;
  program?: string | null;
  country?: string | null;
  score: number;
  /** Why it scored what it did, so a reviewer is not staring at a bare number. */
  reason: string;
}

// ───────────────────────────────────────────────────────────── the pure half

/*
 * Titles and corporate suffixes carry no identifying information, and leaving
 * them in means "Acme Ltd" and "Acme Limited" score as different companies.
 * Deliberately NOT stripped: anything that could be part of a real given name.
 */
const NOISE = new Set([
  'mr', 'mrs', 'ms', 'miss', 'dr', 'prof', 'sir', 'madam', 'mme', 'herr',
  'ltd', 'limited', 'llc', 'inc', 'incorporated', 'corp', 'corporation',
  'co', 'company', 'plc', 'gmbh', 'sa', 'sarl', 'bv', 'nv', 'ag', 'pty',
  'the', 'and', 'of',
]);

/**
 * One canonical form for a name.
 *
 * Lowercased, accents folded, punctuation dropped, noise words removed, tokens
 * sorted. Sorting is what makes "SMITH, JOHN" and "John Smith" the same
 * string — surname-first is how most lists are published and almost never how
 * a customer types their own name.
 */
export function normalize(nameRaw: string): string {
  return (nameRaw ?? '')
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')      // strip combining accents
    .toLowerCase()
    // Apostrophes and full stops are DELETED, not spaced: "O'Brien" and
    // "OBrien" are one name, and spacing the apostrophe splits it into two
    // tokens that can never match the way a customer types it. Hyphens are
    // the opposite case — lists publish "AL-ASSAD" and people write "al
    // assad" — so those, and everything else, become a space.
    .replace(/['\u2019.]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t && !NOISE.has(t))
    .sort()
    .join(' ');
}

/** Levenshtein, iterative with two rows. Used per token, so the inputs are short. */
function editDistance(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  let cur = new Array<number>(b.length + 1);
  for (let i = 1; i <= a.length; i++) {
    cur[0] = i;
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(
        prev[j] + 1,
        cur[j - 1] + 1,
        prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    [prev, cur] = [cur, prev];
  }
  return prev[b.length];
}

/** 0..1 similarity for two single tokens. */
function tokenSim(a: string, b: string): number {
  if (a === b) return 1;
  const longer = Math.max(a.length, b.length);
  if (longer === 0) return 1;
  // A short token that differs at all is probably a different name: "ali" and
  // "all" are one edit apart and unrelated. Length-relative distance handles
  // this without a special case.
  return Math.max(0, 1 - editDistance(a, b) / longer);
}

/**
 * How alike two names are, 0..100.
 *
 * Token-set based: every token of the shorter name is matched to its best
 * partner in the longer one, and the score is the mean of those similarities,
 * penalised for tokens that found no partner at all.
 *
 * Why not a single whole-string distance: names differ by whole tokens far
 * more often than by letters. "John Smith" vs "John Michael Smith" is the same
 * person with a middle name; a whole-string comparison scores that as badly
 * as a genuinely different name, which is exactly backwards.
 */
export function score(aRaw: string, bRaw: string): number {
  const a = normalize(aRaw).split(' ').filter(Boolean);
  const b = normalize(bRaw).split(' ').filter(Boolean);
  if (!a.length || !b.length) return 0;

  const [short, long] = a.length <= b.length ? [a, b] : [b, a];
  const used = new Set<number>();
  let total = 0;

  for (const t of short) {
    let best = 0, bestAt = -1;
    for (let i = 0; i < long.length; i++) {
      if (used.has(i)) continue;
      const s = tokenSim(t, long[i]);
      if (s > best) { best = s; bestAt = i; }
    }
    if (bestAt >= 0) used.add(bestAt);
    total += best;
  }

  const mean = total / short.length;
  // Extra tokens on the longer name are mild evidence of a different party,
  // but only mild — middle names and patronymics are ordinary. A full token
  // of difference costs about 8 points, not a rejection.
  const extra = long.length - short.length;
  const penalty = extra * 0.08;
  return Math.max(0, Math.round((mean - penalty) * 100));
}

/**
 * Does a date of birth rule a match out?
 *
 * A name can be shared by thousands of people; a date of birth is the cheapest
 * discriminator there is. Only applied when BOTH sides have one — a missing
 * date is not evidence of anything, and treating it as such would clear real
 * matches.
 */
export function dobContradicts(subject?: string | null, entry?: string | null): boolean {
  if (!subject || !entry) return false;
  return subject.slice(0, 10) !== entry.slice(0, 10);
}

/**
 * Screen one name against a set of entries. Pure: no database.
 *
 * Exported separately from screenAndRecord so the decision logic can be tested
 * against a handcrafted list, which is the only practical way to cover the
 * cases that matter.
 */
export function evaluate(
  subject: { name: string; dateOfBirth?: string | null },
  entries: WatchlistEntry[],
  threshold = MATCH_THRESHOLD,
): { status: 'clear' | 'potential_match'; topScore: number; matches: Match[] } {
  const matches: Match[] = [];
  let topScore = 0;

  for (const e of entries) {
    const s = score(subject.name, e.name);
    if (s > topScore) topScore = s;
    if (s < threshold) continue;
    if (dobContradicts(subject.dateOfBirth, e.date_of_birth)) continue;

    matches.push({
      entry_id: e.id,
      name: e.name,
      source: e.source,
      program: e.program ?? null,
      country: e.country ?? null,
      score: s,
      reason: s === 100 ? 'exact name match after normalisation'
            : `fuzzy name match, score ${s}`,
    });
  }

  matches.sort((x, y) => y.score - x.score);
  return {
    status: matches.length ? 'potential_match' : 'clear',
    topScore,
    matches,
  };
}

// ────────────────────────────────────────────────────────── the recorded half

/*
 * The watchlist, held in memory.
 *
 * Rebuilt when the stored list version changes. Screening happens at
 * onboarding and at payout, not per transaction, so a few hundred milliseconds
 * to load is irrelevant and a stale cache would be a correctness bug.
 */
let CACHE: { version: string; entries: WatchlistEntry[] } | null = null;

export async function loadWatchlist(db: Db = pool): Promise<{ version: string; entries: WatchlistEntry[] }> {
  const v = await one<{ version: string | null; n: string }>(db,
    `SELECT max(list_version) AS version, count(*)::text AS n FROM watchlist_entries`);
  // The count is part of the key: a reload that removes entries without
  // bumping the version would otherwise serve the old set forever.
  const version = `${v?.version ?? 'none'}:${v?.n ?? '0'}`;
  if (CACHE && CACHE.version === version) return CACHE;

  const r = await db.query(
    `SELECT id, source, external_id, name, entity_type, program, country,
            to_char(date_of_birth, 'YYYY-MM-DD') AS date_of_birth, remarks
       FROM watchlist_entries`);
  CACHE = { version, entries: r.rows as WatchlistEntry[] };
  return CACHE;
}

/** Drop the cache. For tests, and after a list reload in the same process. */
export function resetWatchlistCache(): void { CACHE = null; }

/**
 * Screen a name and record what happened.
 *
 * Always writes a row, including when clear. A screening programme that only
 * records its hits cannot demonstrate that anybody else was screened at all,
 * which is the question actually asked in an examination.
 */
export async function screen(input: {
  subjectType: SubjectType;
  subjectId?: string | null;
  name: string;
  country?: string | null;
  dateOfBirth?: string | null;
}): Promise<{ id: string; status: CheckStatus; topScore: number; matches: Match[] }> {
  const { version, entries } = await loadWatchlist();
  const verdict = evaluate({ name: input.name, dateOfBirth: input.dateOfBirth }, entries);
  const sources = [...new Set(entries.map((e) => e.source))];

  const id = newId('scr');
  await pool.query(
    `INSERT INTO screening_checks
       (id, subject_type, subject_id, name_checked, country, date_of_birth,
        status, top_score, matches, sources_checked, list_version)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [id, input.subjectType, input.subjectId ?? null, input.name,
     input.country ?? null, input.dateOfBirth ?? null,
     verdict.status, verdict.topScore, JSON.stringify(verdict.matches),
     sources, version]);

  return { id, status: verdict.status, topScore: verdict.topScore, matches: verdict.matches };
}

/** What a reviewer still has to look at, oldest first. */
export async function reviewQueue(limit = 50) {
  const r = await pool.query(
    `SELECT * FROM screening_checks WHERE status = 'potential_match'
      ORDER BY created_at LIMIT $1`, [limit]);
  return { object: 'list', data: r.rows };
}

/**
 * A reviewer's decision.
 *
 * The finding is not overwritten — status moves from potential_match to
 * confirmed_match or false_positive, and the matches that were found stay on
 * the row. Clearing a hit by deleting it destroys the evidence that anyone
 * looked, which is the opposite of what this table is for.
 */
export async function review(
  checkId: string,
  decision: 'confirmed_match' | 'false_positive',
  staffId: string,
  note: string,
) {
  if (!note || note.trim().length < 10) {
    throw new Error('A review needs a written reason — it is the part an examiner reads.');
  }
  return tx(async (c) => {
    const row = await one<{ status: string }>(c,
      `SELECT status FROM screening_checks WHERE id = $1 FOR UPDATE`, [checkId]);
    if (!row) throw new Error('No such screening check.');
    if (row.status !== 'potential_match') {
      throw new Error(`This check is already ${row.status}.`);
    }
    return one(c,
      `UPDATE screening_checks
          SET status = $2, reviewed_by = $3, reviewed_at = now(), review_note = $4
        WHERE id = $1 RETURNING *`,
      [checkId, decision, staffId, note.trim()]);
  });
}

/** The most recent decision for a subject, for a gate to consult. */
export async function latestFor(subjectType: SubjectType, subjectId: string) {
  return one(pool,
    `SELECT * FROM screening_checks
      WHERE subject_type = $1 AND subject_id = $2
      ORDER BY created_at DESC LIMIT 1`, [subjectType, subjectId]);
}

/**
 * May this subject be approved?
 *
 * Pure, so the gate's behaviour is testable. The rule is deliberately strict
 * in one direction: an unscreened subject is not approvable. Defaulting to
 * "allow" when screening has not run is how an outage becomes an open door.
 */
export function approvalBlocked(
  check: { status: CheckStatus } | null | undefined,
): { blocked: true; reason: string } | { blocked: false } {
  if (!check) return { blocked: true, reason: 'This subject has not been screened yet.' };
  if (check.status === 'potential_match') {
    return { blocked: true, reason: 'A possible sanctions match is waiting for review.' };
  }
  if (check.status === 'confirmed_match') {
    return { blocked: true, reason: 'A sanctions match was confirmed on this name.' };
  }
  return { blocked: false };
}
