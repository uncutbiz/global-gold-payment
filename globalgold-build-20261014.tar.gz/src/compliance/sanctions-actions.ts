/**
 * What is done about a confirmed sanctions match, and who has to tell whom.
 *
 * The deadline arithmetic is a pure function, because "10 business days" is
 * the kind of thing that looks obvious and is wrong in four different ways:
 * weekends, federal holidays, the day the action happened counting or not,
 * and a holiday falling on a weekend being observed on an adjacent weekday.
 * A date that is quietly two days late is indistinguishable from a correct one
 * until a regulator checks it.
 */
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';

export type Action = 'blocked' | 'rejected';
export type Responsibility = 'processor' | 'principal' | 'self';

/**
 * Who files for a match found here.
 *
 * Default 'processor', which is the honest answer while card payments run on
 * Square's and Stripe's rails: for those transactions THEY are the financial
 * institution and the filing is theirs. This must be changed deliberately when
 * the structure changes, which is why it is configuration and not a guess made
 * at the call site.
 */
export const REPORTING_RESPONSIBILITY =
  (process.env.SANCTIONS_REPORTING ?? 'processor') as Responsibility;

/*
 * US federal holidays, which are not business days.
 *
 * Hard-coded per year rather than computed: the rules have exceptions (a
 * holiday on a Saturday is observed on the Friday before, on a Sunday the
 * Monday after) and Juneteenth only became federal in 2021. A table that runs
 * out is better than a formula that is subtly wrong — loudly so, see below.
 */
const HOLIDAYS: Record<number, string[]> = {
  2026: ['2026-01-01', '2026-01-19', '2026-02-16', '2026-05-25', '2026-06-19',
         '2026-07-03', '2026-09-07', '2026-10-12', '2026-11-11', '2026-11-26', '2026-12-25'],
  2027: ['2027-01-01', '2027-01-18', '2027-02-15', '2027-05-31', '2027-06-18',
         '2027-07-05', '2027-09-06', '2027-10-11', '2027-11-11', '2027-11-25', '2027-12-24'],
  2028: ['2028-01-03', '2028-01-17', '2028-02-21', '2028-05-29', '2028-06-19',
         '2028-07-04', '2028-09-04', '2028-10-09', '2028-11-10', '2028-11-23', '2028-12-25'],
};

/** The last year the holiday table covers. Beyond it, the count is unsafe. */
export const HOLIDAYS_THROUGH = Math.max(...Object.keys(HOLIDAYS).map(Number));

function isBusinessDay(d: Date): boolean {
  const day = d.getUTCDay();
  if (day === 0 || day === 6) return false;
  const iso = d.toISOString().slice(0, 10);
  return !(HOLIDAYS[d.getUTCFullYear()] ?? []).includes(iso);
}

/**
 * The date a report is due: `days` business days after `from`.
 *
 * The action date itself does not count — the clock starts the next business
 * day, which is the conservative reading and the one that cannot make a filing
 * late.
 *
 * Throws past the holiday table rather than silently counting weekends only.
 * A deadline computed without holidays runs early, which is harmless, but it
 * would also mean nobody noticed the table had expired — and the year it
 * matters is the year the count is wrong in the other direction.
 */
export function reportDueBy(from: Date, days = 10): Date {
  const d = new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate()));
  let counted = 0;
  while (counted < days) {
    d.setUTCDate(d.getUTCDate() + 1);
    if (d.getUTCFullYear() > HOLIDAYS_THROUGH) {
      throw new Error(
        `The federal holiday table stops at ${HOLIDAYS_THROUGH}; add the next year's dates ` +
        'to HOLIDAYS in src/compliance/sanctions-actions.ts before relying on this deadline.');
    }
    if (isBusinessDay(d)) counted++;
  }
  return d;
}

/**
 * Is this a block or a reject?
 *
 * Pure, and separated from the recording, because it is the decision most
 * likely to be got wrong and the one with liability on both sides. The rule:
 * a blockable interest means the property is frozen; anything else prohibited
 * is returned.
 *
 * This returns a RECOMMENDATION. A reviewer confirms it. The 50 Percent Rule —
 * an entity owned 50% or more by blocked persons is itself blocked, even
 * unlisted — cannot be decided from a name match, so anything that is not a
 * direct SDN hit is surfaced for a human rather than guessed.
 */
export function recommendAction(match: { source: string; program?: string | null }):
  { action: Action; certain: boolean; why: string } {
  const prog = (match.program ?? '').toUpperCase();
  const src = match.source.toLowerCase();

  if (src.startsWith('ofac') && prog && !prog.includes('NS-PLC') && !prog.includes('PEP')) {
    return {
      action: 'blocked', certain: true,
      why: `Listed on ${match.source} under ${match.program}: a blockable interest, so the funds are frozen and held, not returned.`,
    };
  }
  if (prog.includes('PEP')) {
    return {
      action: 'rejected', certain: false,
      why: 'A politically exposed person is not in itself a blocked party. This is a due-diligence escalation, not an automatic block — a reviewer decides.',
    };
  }
  return {
    action: 'rejected', certain: false,
    why: `Prohibited under ${match.source} but no blockable interest is established from the name alone. Returned to the originator unless a reviewer establishes one.`,
  };
}

/** How long is left, in days. Negative means overdue. */
export function daysUntilDue(due: Date | string, now = new Date()): number {
  const d = typeof due === 'string' ? new Date(due + 'T00:00:00Z') : due;
  return Math.ceil((d.getTime() - now.getTime()) / 86_400_000);
}

export async function recordAction(input: {
  screeningCheckId?: string | null;
  action: Action;
  subjectType: string;
  subjectId?: string | null;
  nameMatched: string;
  amount?: number | null;
  currency?: string | null;
  counterparty?: string | null;
  transactionDetail?: Record<string, unknown>;
  heldAccount?: string | null;
  note?: string | null;
  responsibility?: Responsibility;
}) {
  const responsibility = input.responsibility ?? REPORTING_RESPONSIBILITY;
  if (input.action === 'blocked' && responsibility === 'self' && input.amount && !input.heldAccount) {
    // Blocked funds that are not actually held are the worst of both worlds:
    // the customer has lost their money and there is no auditable account to
    // unblock it from later.
    throw new ApiError(400, 'hold_account_required',
      'Blocking funds requires the account they are held in — a block with no auditable hold cannot be unblocked with interest later.');
  }
  const due = reportDueBy(new Date());
  const id = newId('sanc');
  return one(pool,
    `INSERT INTO sanctions_actions
       (id, screening_check_id, action, subject_type, subject_id, name_matched,
        amount, currency, counterparty, transaction_detail, responsibility,
        report_due_by, held_account, note)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
    [id, input.screeningCheckId ?? null, input.action, input.subjectType,
     input.subjectId ?? null, input.nameMatched, input.amount ?? null,
     input.currency ?? null, input.counterparty ?? null,
     JSON.stringify(input.transactionDetail ?? {}), responsibility,
     due.toISOString().slice(0, 10), input.heldAccount ?? null, input.note ?? null]);
}

/** Everything still owed to somebody, soonest deadline first. */
export async function reportingQueue() {
  const r = await pool.query(
    `SELECT * FROM sanctions_actions
      WHERE reported_at IS NULL AND escalated_at IS NULL
      ORDER BY report_due_by`);
  return {
    object: 'list',
    data: r.rows.map((a) => ({
      ...a,
      days_until_due: daysUntilDue(a.report_due_by),
      overdue: daysUntilDue(a.report_due_by) < 0,
    })),
  };
}

/** Record that somebody else was told, when the obligation is theirs. */
export async function markEscalated(id: string, to: string, ref: string, staffId: string) {
  if (!to?.trim()) throw new ApiError(400, 'recipient_required', 'Name who was told.');
  return tx(async (c) => {
    const row = await one<{ escalated_at: Date | null; responsibility: string }>(c,
      `SELECT escalated_at, responsibility FROM sanctions_actions WHERE id = $1 FOR UPDATE`, [id]);
    if (!row) throw new ApiError(404, 'resource_missing', 'No such action.');
    if (row.escalated_at) throw new ApiError(400, 'already_escalated', 'This was already escalated.');
    if (row.responsibility === 'self') {
      throw new ApiError(400, 'not_escalatable',
        'This action is ours to file. Record the filing, not an escalation.');
    }
    return one(c,
      `UPDATE sanctions_actions
          SET escalated_at = now(), escalated_to = $2, escalation_ref = $3, note =
              COALESCE(note, '') || $4
        WHERE id = $1 RETURNING *`,
      [id, to.trim(), ref?.trim() || null, `\nEscalated by ${staffId}.`]);
  });
}

/**
 * Record that we filed it.
 *
 * Deliberately a record of a filing a person made, not a filing this code
 * performed. Nothing in this system transmits to OFAC.
 */
export async function markReported(id: string, reference: string, staffId: string) {
  if (!reference?.trim()) {
    throw new ApiError(400, 'reference_required',
      'Record the reference OFAC returned — without it there is no proof the report was filed.');
  }
  return tx(async (c) => {
    const row = await one<{ reported_at: Date | null; responsibility: string }>(c,
      `SELECT reported_at, responsibility FROM sanctions_actions WHERE id = $1 FOR UPDATE`, [id]);
    if (!row) throw new ApiError(404, 'resource_missing', 'No such action.');
    if (row.reported_at) throw new ApiError(400, 'already_reported', 'This was already reported.');
    if (row.responsibility !== 'self') {
      throw new ApiError(400, 'not_ours_to_file',
        `This action is the ${row.responsibility}'s to file. Record an escalation instead.`);
    }
    return one(c,
      `UPDATE sanctions_actions
          SET reported_at = now(), reported_by = $2, report_reference = $3
        WHERE id = $1 RETURNING *`, [id, staffId, reference.trim()]);
  });
}

/**
 * Blocked property still held, for the annual report due 30 September.
 *
 * Rejections are excluded: nothing was held, so there is nothing to report
 * annually. Released blocks are excluded for the same reason.
 */
export async function blockedPropertyReport(asOf = new Date()) {
  const r = await pool.query(
    `SELECT * FROM sanctions_actions
      WHERE action = 'blocked' AND released_at IS NULL AND created_at <= $1
      ORDER BY created_at`, [asOf]);
  return {
    as_of: asOf.toISOString().slice(0, 10),
    due_by: `${asOf.getUTCFullYear()}-09-30`,
    count: r.rowCount,
    data: r.rows,
  };
}
