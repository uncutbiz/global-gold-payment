/**
 * Consumer international transfers: the disclosures the law requires.
 *
 * The CFPB Remittance Transfer Rule (Regulation E, subpart B) governs consumer
 * transfers sent from the United States to recipients abroad. It is not a best
 * practice or a partner's requirement — it applies to the provider directly,
 * and a partner holding the money transmitter licences does not discharge it.
 *
 * WHAT IT REQUIRES, AND WHY EACH PIECE IS HERE
 *
 *   A disclosure BEFORE payment  the exact amount, every fee, the exchange
 *                                rate, and — the one that matters most —
 *                                what the recipient actually receives. Not an
 *                                estimate, not "about".
 *   A receipt AFTER payment      the same figures, plus when the money will be
 *                                available and how to complain.
 *   Thirty minutes to cancel     a full refund, no questions, for at least
 *                                thirty minutes after payment.
 *   Error resolution             a defined procedure with its own clock.
 *
 * WHY THE ARITHMETIC IS A PURE FUNCTION
 *
 * Because the rule is about the NUMBERS AGREEING. A disclosure that says the
 * recipient gets 4,500 HTG and a transfer that delivers 4,480 is a violation
 * even though both figures came from the same system — the sender was told a
 * number that turned out to be false. Separating the calculation from the
 * movement means the disclosed figures and the executed figures come from one
 * place and can be tested against each other without a database.
 *
 * WHAT THIS IS NOT
 *
 * This is the arithmetic and the clocks. It is not a compliance programme, and
 * the disclosure WORDING below is a plain-language draft, not approved text:
 * the rule prescribes specific language and formatting, and a lawyer should
 * set the final strings before a single consumer sees them.
 */
import { ApiError } from '../util/common.js';

/** Thirty minutes, the statutory minimum cancellation window. */
export const CANCELLATION_WINDOW_MINUTES = 30;

/** A consumer has 180 days from the promised availability date to report an error. */
export const ERROR_REPORT_DAYS = 180;

/** And the provider has 90 days from the report to investigate and answer. */
export const ERROR_INVESTIGATION_DAYS = 90;

export interface DisclosureInput {
  /** What the sender hands over, in the sending currency, in minor units. */
  sendAmount: number;
  sendCurrency: string;
  /** Our fee, in the sending currency. */
  ourFee: number;
  /** Taxes we collect, if any. Usually zero. */
  taxes?: number;
  /**
   * Fees charged at the far end by the delivery partner or the receiving
   * institution, in the RECEIVING currency.
   *
   * These must be disclosed even though somebody else takes them. A sender who
   * is told the recipient gets 4,500 HTG and watches 200 deducted at the cash
   * window was misled, whoever took the 200.
   */
  recipientFees?: number;
  /** Units of receiving currency per one unit of sending currency. */
  exchangeRate: number;
  receiveCurrency: string;
  recipientName: string;
  /** When the money is promised to be available. */
  availableAt: Date;
}

export interface Disclosure {
  transfer_amount: number;
  transfer_currency: string;
  our_fee: number;
  taxes: number;
  /** What the sender pays in total. transfer_amount + our_fee + taxes. */
  total_paid: number;
  exchange_rate: number;
  /** Before any fees deducted at the far end. */
  gross_receive_amount: number;
  recipient_fees: number;
  /** What actually lands. This is the number the sender cares about. */
  recipient_receives: number;
  receive_currency: string;
  recipient_name: string;
  available_at: string;
  cancellation_deadline: string;
  disclosures: string[];
}

function round(n: number): number {
  // Minor units are integers. Banker's rounding is not used: a half-unit is
  // rounded DOWN on what the recipient gets, so the disclosed figure is never
  // larger than what actually arrives. Promising more than is delivered is the
  // violation; delivering a unit more than promised is not.
  return Math.floor(n);
}

/**
 * Build the disclosure. Pure: same inputs, same figures, every time.
 *
 * `sentAt` is passed rather than read from the clock so the cancellation
 * deadline is reproducible — a receipt reprinted a month later must show the
 * deadline that applied, not one calculated from today.
 */
export function buildDisclosure(input: DisclosureInput, sentAt: Date): Disclosure {
  if (!Number.isInteger(input.sendAmount) || input.sendAmount <= 0) {
    throw new ApiError(400, 'invalid_amount', 'The amount to send must be a positive whole number of minor units.');
  }
  if (!(input.exchangeRate > 0)) {
    throw new ApiError(400, 'invalid_rate', 'An exchange rate is required, and must be greater than zero.');
  }

  const taxes = input.taxes ?? 0;
  const recipientFees = input.recipientFees ?? 0;
  const gross = round(input.sendAmount * input.exchangeRate);
  const receives = gross - recipientFees;

  if (receives <= 0) {
    // Not a rounding curiosity: it means the fees at the far end exceed the
    // transfer. Disclosing "the recipient receives -50" is absurd, and taking
    // the money anyway is worse.
    throw new ApiError(400, 'fees_exceed_amount',
      'Fees at the receiving end would consume the whole transfer. Nothing would reach the recipient.');
  }

  const deadline = cancellationDeadline(sentAt);

  return {
    transfer_amount: input.sendAmount,
    transfer_currency: input.sendCurrency.toUpperCase(),
    our_fee: input.ourFee,
    taxes,
    total_paid: input.sendAmount + input.ourFee + taxes,
    exchange_rate: input.exchangeRate,
    gross_receive_amount: gross,
    recipient_fees: recipientFees,
    recipient_receives: receives,
    receive_currency: input.receiveCurrency.toUpperCase(),
    recipient_name: input.recipientName,
    available_at: input.availableAt.toISOString(),
    cancellation_deadline: deadline.toISOString(),
    /*
     * Plain-language drafts. The rule prescribes specific wording and
     * formatting that counsel must set before a consumer sees any of it; these
     * exist so the shape is right and nothing is silently missing.
     */
    disclosures: [
      `You can cancel this transfer for a full refund within ${CANCELLATION_WINDOW_MINUTES} minutes, unless the money has already been collected.`,
      `If something goes wrong, you have ${ERROR_REPORT_DAYS} days to tell us. We will investigate and reply within ${ERROR_INVESTIGATION_DAYS} days.`,
      'You can contact the Consumer Financial Protection Bureau if you are not satisfied with how we handle a problem.',
    ],
  };
}

export function cancellationDeadline(sentAt: Date): Date {
  return new Date(sentAt.getTime() + CANCELLATION_WINDOW_MINUTES * 60_000);
}

/**
 * May this transfer still be cancelled?
 *
 * Two independent conditions, and the second is the one people forget: once
 * the recipient has the money, the window is irrelevant. You cannot refund
 * cash that has already been handed over a counter in Port-au-Prince.
 */
export function canCancel(
  transfer: { sent_at: Date | string; collected_at?: Date | string | null; status?: string },
  now = new Date(),
): { ok: true } | { ok: false; reason: string } {
  if (transfer.collected_at) {
    return { ok: false, reason: 'This transfer has already been collected by the recipient and cannot be cancelled.' };
  }
  if (transfer.status === 'cancelled') {
    return { ok: false, reason: 'This transfer was already cancelled.' };
  }
  const sent = typeof transfer.sent_at === 'string' ? new Date(transfer.sent_at) : transfer.sent_at;
  if (now.getTime() > cancellationDeadline(sent).getTime()) {
    return { ok: false, reason: `The ${CANCELLATION_WINDOW_MINUTES}-minute cancellation window has passed.` };
  }
  return { ok: true };
}

/** How long the sender still has, in whole seconds. Zero once it has passed. */
export function cancellationSecondsLeft(sentAt: Date | string, now = new Date()): number {
  const sent = typeof sentAt === 'string' ? new Date(sentAt) : sentAt;
  return Math.max(0, Math.floor((cancellationDeadline(sent).getTime() - now.getTime()) / 1000));
}

/** The last day a consumer may report a problem with this transfer. */
export function errorReportDeadline(availableAt: Date): Date {
  return new Date(availableAt.getTime() + ERROR_REPORT_DAYS * 86_400_000);
}

/** The day our investigation must be answered by. */
export function investigationDeadline(reportedAt: Date): Date {
  return new Date(reportedAt.getTime() + ERROR_INVESTIGATION_DAYS * 86_400_000);
}

/**
 * Does what was actually delivered match what was disclosed?
 *
 * The rule's substance in one function. A transfer that delivers less than the
 * sender was promised is an error the provider must remedy, and the only way
 * to know is to compare the two numbers deliberately. Delivering MORE is not
 * an error — the sender got what they were told and then some.
 */
export function deliveryMatchesDisclosure(
  disclosed: { recipient_receives: number; receive_currency: string },
  delivered: { amount: number; currency: string },
): { ok: true } | { ok: false; reason: string; shortfall: number } {
  if (disclosed.receive_currency.toUpperCase() !== delivered.currency.toUpperCase()) {
    return {
      ok: false,
      reason: `Delivered in ${delivered.currency.toUpperCase()} but ${disclosed.receive_currency.toUpperCase()} was disclosed.`,
      shortfall: disclosed.recipient_receives,
    };
  }
  if (delivered.amount < disclosed.recipient_receives) {
    return {
      ok: false,
      reason: 'The recipient received less than the sender was told they would.',
      shortfall: disclosed.recipient_receives - delivered.amount,
    };
  }
  return { ok: true };
}
