/**
 * A business's public face: logo, brand colour, display name, support contact.
 *
 * TWO RULES GOVERN EVERYTHING HERE, AND BOTH ARE ABOUT NOT TRUSTING THE UPLOAD.
 *
 *  1. The file's real type is read from its first bytes, never from the
 *     Content-Type the client sent or the extension on the name. A browser
 *     will happily label anything, and "it said image/png" is how a server
 *     ends up storing and later serving something that is not a PNG.
 *
 *  2. SVG is refused. An SVG is a document, not a picture: it can carry script
 *     that runs when the file is opened in a tab. A logo is displayed in an
 *     <img>, where that script would not run — but the moment someone opens
 *     the logo URL directly, it would. Raster formats cannot do this, so the
 *     logo is raster-only and the whole class of problem is gone.
 *
 * The validators below are pure so every one of these refusals can be tested
 * with a handful of bytes and no database.
 */
import crypto from 'node:crypto';
import { Db, one, pool } from '../db.js';
import { ApiError } from '../util/common.js';

/** A logo above this is refused. Big enough for a real mark, small enough that
 *  it never becomes a way to fill the database. 1 MiB. */
export const MAX_LOGO_BYTES = 1024 * 1024;

/** The raster types we accept, mapped from their magic bytes. */
export type LogoMime = 'image/png' | 'image/jpeg' | 'image/gif' | 'image/webp';

/**
 * What kind of image is this, really? Read the signature, not the label.
 * Returns the mime, or null if the bytes are not one of the four we take.
 */
export function sniffImage(buf: Buffer): LogoMime | null {
  if (buf.length < 12) return null;
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
      buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a) {
    return 'image/png';
  }
  // JPEG: FF D8 FF
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  // GIF: "GIF87a" or "GIF89a"
  if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x38 &&
      (buf[4] === 0x37 || buf[4] === 0x39) && buf[5] === 0x61) {
    return 'image/gif';
  }
  // WEBP: "RIFF" .... "WEBP"
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
      buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50) {
    return 'image/webp';
  }
  return null;
}

/**
 * Check an uploaded logo and return its true type.
 *
 * Throws, with a message a person can act on, when the file is empty, too
 * large, or not one of the four raster types. Nothing here looks at what the
 * client claimed the file was — that is the point.
 */
export function validateLogo(buf: Buffer): { mime: LogoMime; byteLen: number } {
  if (buf.length === 0) {
    throw new ApiError(400, 'empty_file', 'The file is empty.');
  }
  if (buf.length > MAX_LOGO_BYTES) {
    throw new ApiError(413, 'file_too_large',
      `A logo must be ${Math.floor(MAX_LOGO_BYTES / 1024)} KB or smaller. This one is ${Math.ceil(buf.length / 1024)} KB.`);
  }
  const mime = sniffImage(buf);
  if (!mime) {
    throw new ApiError(400, 'unsupported_image',
      'A logo must be a PNG, JPEG, GIF or WebP image. SVG is not accepted.');
  }
  return { mime, byteLen: buf.length };
}

/**
 * Normalise a brand colour to '#rrggbb' lowercase, or throw.
 *
 * Accepts '#abc' and 'ABC123' and '#AABBCC' — anything that is unambiguously a
 * hex colour — and rejects everything else, because this value is written into
 * a style attribute and a loose one would be a way to inject CSS.
 */
export function normalizeBrandColor(raw: string): string {
  const s = raw.trim().replace(/^#/, '').toLowerCase();
  if (/^[0-9a-f]{6}$/.test(s)) return `#${s}`;
  if (/^[0-9a-f]{3}$/.test(s)) return `#${s[0]}${s[0]}${s[1]}${s[1]}${s[2]}${s[2]}`;
  throw new ApiError(400, 'invalid_color', 'A brand colour must be a hex value like #1a73e8.');
}

/** An email, loosely — enough to reject a phone number typed in the email box. */
export function normalizeEmailish(raw: string): string {
  const s = raw.trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s)) {
    throw new ApiError(400, 'invalid_email', 'That does not look like an email address.');
  }
  return s.toLowerCase();
}

export interface BrandPatch {
  display_name?: string | null;
  support_email?: string | null;
  support_phone?: string | null;
  brand_color?: string | null;
}

/**
 * Apply a partial update. A field left undefined is untouched; a field set to
 * null is cleared. The caller gets back the stored shape.
 */
export async function setBrand(merchantId: string, patch: BrandPatch, db: Db = pool) {
  const sets: string[] = [];
  const vals: unknown[] = [merchantId];

  const put = (col: string, v: unknown) => { vals.push(v); sets.push(`${col} = $${vals.length}`); };

  if (patch.display_name !== undefined) {
    put('display_name', patch.display_name === null ? null : String(patch.display_name).trim().slice(0, 120) || null);
  }
  if (patch.support_email !== undefined) {
    put('support_email', patch.support_email === null ? null : normalizeEmailish(String(patch.support_email)));
  }
  if (patch.support_phone !== undefined) {
    put('support_phone', patch.support_phone === null ? null : String(patch.support_phone).trim().slice(0, 40) || null);
  }
  if (patch.brand_color !== undefined) {
    put('brand_color', patch.brand_color === null ? null : normalizeBrandColor(String(patch.brand_color)));
  }
  if (!sets.length) return getBrand(merchantId, db);

  await db.query(`UPDATE merchants SET ${sets.join(', ')} WHERE id = $1`, vals);
  return getBrand(merchantId, db);
}

/** The brand facts, with a logo URL when one is set (cache-busted by its mtime). */
export async function getBrand(merchantId: string, db: Db = pool) {
  const m = await one<any>(db,
    `SELECT id, name, display_name, support_email, support_phone, brand_color,
            logo_mime, logo_updated_at
       FROM merchants WHERE id = $1`, [merchantId]);
  if (!m) throw new ApiError(404, 'resource_missing', 'Business not found.');
  return presentBrand(m);
}

/** Shape a merchant row into the public brand object. Pure. */
export function presentBrand(m: {
  id: string; name: string; display_name?: string | null;
  support_email?: string | null; support_phone?: string | null;
  brand_color?: string | null; logo_mime?: string | null;
  logo_updated_at?: Date | string | null;
}) {
  const stamp = m.logo_updated_at
    ? Math.floor(new Date(m.logo_updated_at).getTime() / 1000)
    : null;
  return {
    object: 'brand' as const,
    merchant_id: m.id,
    name: m.name,
    display_name: m.display_name ?? null,
    support_email: m.support_email ?? null,
    support_phone: m.support_phone ?? null,
    brand_color: m.brand_color ?? null,
    has_logo: Boolean(m.logo_mime),
    // Only present when a logo exists; the stamp makes a changed logo a new URL.
    logo_url: m.logo_mime ? `/v1/public/brand/${m.id}/logo?v=${stamp}` : null,
  };
}

/** Store (or replace) the logo. Validates first, so a bad file changes nothing. */
export async function setLogo(merchantId: string, buf: Buffer, db: Db = pool) {
  const { mime, byteLen } = validateLogo(buf);
  await db.query(
    `INSERT INTO merchant_logos (merchant_id, mime, bytes, byte_len, updated_at)
       VALUES ($1,$2,$3,$4, now())
     ON CONFLICT (merchant_id)
       DO UPDATE SET mime = EXCLUDED.mime, bytes = EXCLUDED.bytes,
                     byte_len = EXCLUDED.byte_len, updated_at = now()`,
    [merchantId, mime, buf, byteLen]);
  await db.query(
    `UPDATE merchants SET logo_mime = $2, logo_updated_at = now() WHERE id = $1`,
    [merchantId, mime]);
  return getBrand(merchantId, db);
}

/** Remove the logo. Idempotent — removing a logo that isn't there is fine. */
export async function deleteLogo(merchantId: string, db: Db = pool) {
  await db.query('DELETE FROM merchant_logos WHERE merchant_id = $1', [merchantId]);
  await db.query('UPDATE merchants SET logo_mime = NULL, logo_updated_at = NULL WHERE id = $1', [merchantId]);
  return getBrand(merchantId, db);
}

/** The bytes, for serving. Returns null when there is no logo. */
export async function getLogo(merchantId: string, db: Db = pool):
  Promise<{ mime: string; bytes: Buffer; etag: string } | null> {
  const row = await one<any>(db,
    'SELECT mime, bytes, updated_at FROM merchant_logos WHERE merchant_id = $1', [merchantId]);
  if (!row) return null;
  const bytes: Buffer = row.bytes;
  const etag = '"' + crypto.createHash('sha256').update(bytes).digest('hex').slice(0, 32) + '"';
  return { mime: row.mime, bytes, etag };
}
