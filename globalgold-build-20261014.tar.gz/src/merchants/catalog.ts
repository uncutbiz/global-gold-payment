/**
 * A merchant's catalogue (items) and the orders placed against it.
 *
 * The heart of this file is `computeOrder`, and it is pure on purpose. Working
 * out what an order costs — line totals, a discount, the grand total — is
 * exactly the kind of arithmetic that must never disagree with the money that
 * is later charged. A pure function can be tested against every rounding and
 * overflow edge with no database, and the same function produces the number
 * shown to the buyer and the number sent to the payment intent.
 */
import { Db, one, pool, tx } from '../db.js';
import { ApiError, newId, SUPPORTED_CURRENCIES } from '../util/common.js';

/** No single amount may exceed this — the same ceiling the payment API uses,
 *  so any order total can become a payment intent. */
export const MAX_MINOR = 99_999_999;
/** A quantity ceiling, so a typo cannot overflow a line into nonsense. */
export const MAX_QTY = 100_000;

export interface OrderLineInput {
  item_id?: string | null;
  name: string;
  unit_price: number;
  quantity: number;
}

export interface ComputedLine extends OrderLineInput {
  line_total: number;
}

export interface ComputedOrder {
  currency: string;
  subtotal: number;
  discount: number;
  total: number;
  lines: ComputedLine[];
}

/**
 * Price an order. Pure: the same lines and discount always give the same
 * totals, and every way the numbers could be wrong is refused here rather than
 * reaching the ledger.
 */
export function computeOrder(currencyRaw: string, lines: OrderLineInput[], discount = 0): ComputedOrder {
  const currency = currencyRaw.toLowerCase();
  if (!SUPPORTED_CURRENCIES.includes(currency as any)) {
    throw new ApiError(400, 'unsupported_currency', `${currencyRaw} is not a supported currency.`);
  }
  if (!Array.isArray(lines) || lines.length === 0) {
    throw new ApiError(400, 'empty_order', 'An order needs at least one line.');
  }
  if (lines.length > 500) {
    throw new ApiError(400, 'too_many_lines', 'An order cannot have more than 500 lines.');
  }

  const computed: ComputedLine[] = [];
  let subtotal = 0;
  for (const l of lines) {
    if (!l.name || !String(l.name).trim()) {
      throw new ApiError(400, 'line_name_required', 'Every line needs a name.');
    }
    if (!Number.isInteger(l.unit_price) || l.unit_price < 0 || l.unit_price > MAX_MINOR) {
      throw new ApiError(400, 'invalid_price', `“${l.name}” has an invalid price.`);
    }
    if (!Number.isInteger(l.quantity) || l.quantity <= 0 || l.quantity > MAX_QTY) {
      throw new ApiError(400, 'invalid_quantity', `“${l.name}” has an invalid quantity.`);
    }
    const line_total = l.unit_price * l.quantity;
    subtotal += line_total;
    if (subtotal > MAX_MINOR) {
      throw new ApiError(400, 'order_too_large', 'This order exceeds the maximum amount.');
    }
    computed.push({ item_id: l.item_id ?? null, name: String(l.name).trim(), unit_price: l.unit_price, quantity: l.quantity, line_total });
  }

  if (!Number.isInteger(discount) || discount < 0) {
    throw new ApiError(400, 'invalid_discount', 'A discount must be a whole number of minor units, zero or more.');
  }
  if (discount > subtotal) {
    throw new ApiError(400, 'discount_too_large', 'A discount cannot be larger than the order subtotal.');
  }

  return { currency, subtotal, discount, total: subtotal - discount, lines: computed };
}

// ───────────────────────────────────────────── items (catalogue)
export function presentItem(r: any) {
  return {
    object: 'item', id: r.id, name: r.name, description: r.description ?? null,
    price: r.price, currency: r.currency, sku: r.sku ?? null,
    image_url: r.image_url ?? null, active: r.active,
    created_at: r.created_at, updated_at: r.updated_at,
  };
}

export async function createItem(merchantId: string, input: {
  name: string; price: number; currency: string;
  description?: string | null; sku?: string | null; image_url?: string | null;
}, db: Db = pool) {
  const currency = input.currency.toLowerCase();
  if (!SUPPORTED_CURRENCIES.includes(currency as any)) {
    throw new ApiError(400, 'unsupported_currency', `${input.currency} is not a supported currency.`);
  }
  if (!Number.isInteger(input.price) || input.price < 0 || input.price > MAX_MINOR) {
    throw new ApiError(400, 'invalid_price', 'A price must be a whole number of minor units, zero or more.');
  }
  if (!input.name?.trim()) throw new ApiError(400, 'name_required', 'An item needs a name.');
  try {
    const r = await one(db,
      `INSERT INTO items (id, merchant_id, name, description, price, currency, sku, image_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [newId('item'), merchantId, input.name.trim(), input.description?.trim() || null,
       input.price, currency, input.sku?.trim() || null, input.image_url?.trim() || null]);
    return presentItem(r);
  } catch (e: any) {
    if (e?.code === '23505') throw new ApiError(409, 'sku_taken', 'You already have an item with that SKU.');
    throw e;
  }
}

export async function updateItem(merchantId: string, id: string, patch: {
  name?: string; description?: string | null; price?: number; sku?: string | null;
  image_url?: string | null; active?: boolean;
}, db: Db = pool) {
  const sets: string[] = []; const vals: unknown[] = [id, merchantId];
  const put = (col: string, v: unknown) => { vals.push(v); sets.push(`${col} = $${vals.length}`); };
  if (patch.name !== undefined) { if (!patch.name.trim()) throw new ApiError(400, 'name_required', 'An item needs a name.'); put('name', patch.name.trim()); }
  if (patch.description !== undefined) put('description', patch.description?.trim() || null);
  if (patch.price !== undefined) {
    if (!Number.isInteger(patch.price) || patch.price < 0 || patch.price > MAX_MINOR) throw new ApiError(400, 'invalid_price', 'A price must be a whole number of minor units, zero or more.');
    put('price', patch.price);
  }
  if (patch.sku !== undefined) put('sku', patch.sku?.trim() || null);
  if (patch.image_url !== undefined) put('image_url', patch.image_url?.trim() || null);
  if (patch.active !== undefined) put('active', patch.active);
  if (!sets.length) return getItem(merchantId, id, db);
  sets.push('updated_at = now()');
  try {
    const r = await one(db, `UPDATE items SET ${sets.join(', ')} WHERE id = $1 AND merchant_id = $2 RETURNING *`, vals);
    if (!r) throw new ApiError(404, 'resource_missing', 'Item not found.');
    return presentItem(r);
  } catch (e: any) {
    if (e?.code === '23505') throw new ApiError(409, 'sku_taken', 'You already have an item with that SKU.');
    throw e;
  }
}

export async function getItem(merchantId: string, id: string, db: Db = pool) {
  const r = await one(db, 'SELECT * FROM items WHERE id = $1 AND merchant_id = $2', [id, merchantId]);
  if (!r) throw new ApiError(404, 'resource_missing', 'Item not found.');
  return presentItem(r);
}

export async function listItems(merchantId: string, opts: { active?: boolean } = {}, db: Db = pool) {
  const where = ['merchant_id = $1']; const vals: unknown[] = [merchantId];
  if (opts.active !== undefined) { vals.push(opts.active); where.push(`active = $${vals.length}`); }
  const r = await db.query(`SELECT * FROM items WHERE ${where.join(' AND ')} ORDER BY created_at DESC LIMIT 500`, vals);
  return r.rows.map(presentItem);
}

// ───────────────────────────────────────────── orders
export function presentOrder(o: any, lines: any[] = []) {
  return {
    object: 'order', id: o.id, merchant_id: o.merchant_id, customer_id: o.customer_id ?? null,
    currency: o.currency, subtotal: o.subtotal, discount: o.discount, total: o.total,
    status: o.status, payment_intent_id: o.payment_intent_id ?? null, note: o.note ?? null,
    created_at: o.created_at, updated_at: o.updated_at,
    lines: lines.map((l) => ({
      id: l.id, item_id: l.item_id ?? null, name: l.name,
      unit_price: l.unit_price, quantity: l.quantity, line_total: l.line_total,
    })),
  };
}

export interface CreateOrderInput {
  customer_id?: string | null;
  discount?: number;
  note?: string | null;
  /** Catalogue items by id + quantity; priced from the catalogue at order time. */
  items?: { item_id: string; quantity: number }[];
  /** Ad-hoc lines not in the catalogue, priced inline. */
  lines?: OrderLineInput[];
}

/**
 * Create an order. Catalogue items are priced from the catalogue NOW and
 * snapshotted; ad-hoc lines are taken as given. Everything is checked to belong
 * to this merchant and share one currency before any row is written.
 */
export async function createOrder(merchantId: string, input: CreateOrderInput) {
  return tx(async (c) => {
    const resolved: OrderLineInput[] = [];
    let currency: string | undefined;

    for (const ref of input.items ?? []) {
      const it = await one<any>(c, 'SELECT * FROM items WHERE id = $1 AND merchant_id = $2', [ref.item_id, merchantId]);
      if (!it) throw new ApiError(404, 'resource_missing', `Item ${ref.item_id} not found.`);
      if (!it.active) throw new ApiError(400, 'item_inactive', `“${it.name}” is not available.`);
      currency ??= it.currency;
      if (it.currency !== currency) throw new ApiError(400, 'mixed_currency', 'Every item in an order must share one currency.');
      resolved.push({ item_id: it.id, name: it.name, unit_price: it.price, quantity: ref.quantity });
    }

    for (const l of input.lines ?? []) {
      resolved.push(l);
    }
    // Ad-hoc lines carry no currency of their own; they adopt the order's.
    // If there were no catalogue items, the first currency must come from the
    // caller — refuse rather than guess.
    if (currency === undefined) {
      throw new ApiError(400, 'currency_required',
        'An order of ad-hoc lines only must be created through the catalogue, or priced items must set the currency.');
    }

    if (input.customer_id) {
      const cust = await one(c, 'SELECT 1 FROM customers WHERE id = $1 AND merchant_id = $2', [input.customer_id, merchantId]);
      if (!cust) throw new ApiError(404, 'resource_missing', 'Customer not found.');
    }

    const computed = computeOrder(currency, resolved, input.discount ?? 0);
    const orderId = newId('ord');
    const o = await one<any>(c,
      `INSERT INTO orders (id, merchant_id, customer_id, currency, subtotal, discount, total, status, note)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'open',$8) RETURNING *`,
      [orderId, merchantId, input.customer_id ?? null, computed.currency,
       computed.subtotal, computed.discount, computed.total, input.note?.trim() || null]);

    const stored: any[] = [];
    for (const l of computed.lines) {
      stored.push(await one(c,
        `INSERT INTO order_items (id, order_id, item_id, name, unit_price, quantity, line_total)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
        [newId('oli'), orderId, l.item_id ?? null, l.name, l.unit_price, l.quantity, l.line_total]));
    }
    return presentOrder(o, stored);
  });
}

export async function getOrder(merchantId: string, id: string, db: Db = pool) {
  const o = await one<any>(db, 'SELECT * FROM orders WHERE id = $1 AND merchant_id = $2', [id, merchantId]);
  if (!o) throw new ApiError(404, 'resource_missing', 'Order not found.');
  const lines = (await db.query('SELECT * FROM order_items WHERE order_id = $1 ORDER BY id', [id])).rows;
  return presentOrder(o, lines);
}

export async function listOrders(merchantId: string, opts: { status?: string; limit?: number } = {}, db: Db = pool) {
  const where = ['merchant_id = $1']; const vals: unknown[] = [merchantId];
  if (opts.status) { vals.push(opts.status); where.push(`status = $${vals.length}`); }
  vals.push(Math.min(opts.limit ?? 50, 200));
  const rows = (await db.query(
    `SELECT * FROM orders WHERE ${where.join(' AND ')} ORDER BY created_at DESC LIMIT $${vals.length}`, vals)).rows;
  return rows.map((o) => presentOrder(o, []));
}

/** The legal status moves. Paid and refunded are set by payment events, not by
 *  hand; a merchant may mark an order fulfilled or cancel one that is unpaid. */
const ALLOWED: Record<string, string[]> = {
  open:      ['fulfilled', 'canceled', 'paid'],
  paid:      ['fulfilled', 'refunded'],
  fulfilled: ['refunded'],
  canceled:  [],
  refunded:  [],
};

export async function setOrderStatus(merchantId: string, id: string, next: string, db: Db = pool) {
  const o = await one<any>(db, 'SELECT * FROM orders WHERE id = $1 AND merchant_id = $2', [id, merchantId]);
  if (!o) throw new ApiError(404, 'resource_missing', 'Order not found.');
  if (o.status === next) return getOrder(merchantId, id, db);
  if (!ALLOWED[o.status]?.includes(next)) {
    throw new ApiError(409, 'invalid_transition', `An order that is ${o.status} cannot become ${next}.`);
  }
  await db.query('UPDATE orders SET status = $3, updated_at = now() WHERE id = $1 AND merchant_id = $2', [id, merchantId, next]);
  return getOrder(merchantId, id, db);
}

/** Attach a payment intent to an order (set once payment is being collected). */
export async function attachPaymentIntent(merchantId: string, id: string, piId: string, db: Db = pool) {
  const r = await db.query('UPDATE orders SET payment_intent_id = $3, updated_at = now() WHERE id = $1 AND merchant_id = $2', [id, merchantId, piId]);
  if (!r.rowCount) throw new ApiError(404, 'resource_missing', 'Order not found.');
  return getOrder(merchantId, id, db);
}
