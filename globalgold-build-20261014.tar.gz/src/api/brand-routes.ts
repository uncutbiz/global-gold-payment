/**
 * Brand & public profile endpoints.
 *
 * This is its own router, mounted BEFORE the app's JSON parser, for one
 * reason: a logo is binary, and the global `express.json()` would try to parse
 * the image bytes as JSON and reject them. So the upload route asks for a raw
 * body itself, the JSON routes ask for JSON themselves, and anything this
 * router does not match falls straight through to the rest of the app.
 *
 *   Dashboard / API (secret key or ggm_ session):
 *     GET    /v1/brand            read your brand
 *     PATCH  /v1/brand            change name / colour / support contact
 *     POST   /v1/brand/logo       upload a logo (raw image bytes)
 *     DELETE /v1/brand/logo       remove it
 *
 *   Public (no auth — these are what a checkout page and a receipt read):
 *     GET    /v1/public/brand/:id        the brand, minus anything private
 *     GET    /v1/public/brand/:id/logo   the image itself
 */
import { Router, json, raw } from 'express';
import { z } from 'zod';
import { requireKey } from './middleware.js';
import { deleteLogo, getBrand, getLogo, setBrand, setLogo, MAX_LOGO_BYTES } from '../merchants/brand.js';

export const brandApi = Router();

const sk = requireKey('secret');
const asJson = json({ limit: '10kb' });
// A little headroom over the byte cap the validator enforces, so an oversized
// upload reaches our own clear 413 rather than Express's generic one.
const asImage = raw({ type: () => true, limit: MAX_LOGO_BYTES + 64 * 1024 });

brandApi.get('/v1/brand', sk, async (req, res) => {
  res.json(await getBrand(req.merchant!.id));
});

brandApi.patch('/v1/brand', sk, asJson, async (req, res) => {
  const body = z.object({
    display_name: z.string().max(120).nullable().optional(),
    support_email: z.string().max(200).nullable().optional(),
    support_phone: z.string().max(40).nullable().optional(),
    brand_color: z.string().max(40).nullable().optional(),
  }).parse(req.body ?? {});
  res.json(await setBrand(req.merchant!.id, body));
});

brandApi.post('/v1/brand/logo', sk, asImage, async (req, res) => {
  const buf = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
  res.status(201).json(await setLogo(req.merchant!.id, buf));
});

brandApi.delete('/v1/brand/logo', sk, async (req, res) => {
  res.json(await deleteLogo(req.merchant!.id));
});

// ───────────────────────────────────────────── public
brandApi.get('/v1/public/brand/:id', async (req, res) => {
  const b = await getBrand(req.params.id as string);
  // The public view drops nothing sensitive today, but routing it through its
  // own shape means a later private field cannot leak here by accident.
  res.json({
    object: 'brand', merchant_id: b.merchant_id,
    name: b.display_name || b.name,
    brand_color: b.brand_color, has_logo: b.has_logo, logo_url: b.logo_url,
    support_email: b.support_email, support_phone: b.support_phone,
  });
});

brandApi.get('/v1/public/brand/:id/logo', async (req, res) => {
  const logo = await getLogo(req.params.id as string);
  if (!logo) { res.status(404).json({ error: { type: 'invalid_request_error', code: 'no_logo', message: 'This business has no logo.' } }); return; }
  if (req.header('if-none-match') === logo.etag) { res.status(304).end(); return; }
  res.setHeader('Content-Type', logo.mime);
  res.setHeader('ETag', logo.etag);
  // The URL is cache-busted by ?v=<mtime>, so the bytes at a given URL never
  // change — a day's cache is safe and takes the image off the hot path.
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.send(logo.bytes);
});
