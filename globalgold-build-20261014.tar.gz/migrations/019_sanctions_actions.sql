-- What happens AFTER a sanctions match is confirmed.
--
-- Screening finds the name. This table is the part with legal deadlines
-- attached, and it exists because "we blocked it" is only half of what the
-- rules require — the other half is a report, filed within a fixed window, by
-- a specific party.
--
-- BLOCKING IS NOT REJECTING, AND THE DIFFERENCE IS NOT COSMETIC
--
--   BLOCK   there is a blockable interest (an SDN, or an entity an SDN owns
--           50% or more of). The funds must be FROZEN and held — placed in an
--           interest-bearing account with an audit trail good enough to
--           unblock them with interest later. They are not returned.
--
--   REJECT  the transaction is prohibited but no blockable interest exists.
--           It is simply not processed and is returned to the originator.
--           Holding a non-SDN's money here is itself a liability.
--
-- Getting these the wrong way round is a real error in both directions:
-- returning funds that should have been frozen, or freezing funds that should
-- have been returned. So the action is recorded explicitly rather than
-- inferred, and the reviewer has to choose it.
--
-- THE CLOCK
--
-- Individual blocked and rejected transactions are reportable within 10
-- BUSINESS days of the action (31 C.F.R. 501.603 and 501.604), and blocked
-- property is additionally reported annually by 30 September. report_due_by is
-- therefore computed at insert and is not decoration: it is the date a
-- regulator measures against.
--
-- WHO ACTUALLY FILES
--
-- This is the question that decides whether this table is a worklist or an
-- archive, and it depends entirely on the structure:
--
--   processor  Card payments on Square's or Stripe's rails: THEY are the
--              financial institution for that transaction and they file. We
--              record what we saw and escalate. This is the current state.
--   principal  Operating as an appointed agent of a licensed partner: the
--              partner holds the obligation; we must escalate to them inside
--              their own, shorter, contractual window.
--   self       We are the registered financial institution. We file.
--
-- Nothing here ever transmits anything to a government. A report to OFAC is
-- signed by a named compliance officer who has read the file; a payments
-- startup auto-filing regulatory reports is an incident, not a feature. This
-- table produces the record, the deadline and the queue — a person files.

CREATE TABLE sanctions_actions (
  id                  TEXT PRIMARY KEY,
  screening_check_id  TEXT REFERENCES screening_checks(id),

  action              TEXT NOT NULL CHECK (action IN ('blocked','rejected')),

  subject_type        TEXT NOT NULL,
  subject_id          TEXT,
  name_matched        TEXT NOT NULL,

  -- Null when the action was on an onboarding attempt rather than a payment:
  -- refusing to open an account is reportable differently from stopping money.
  amount              BIGINT,
  currency            TEXT,
  counterparty        TEXT,
  -- The original transfer instructions have to accompany the report, so
  -- whatever we had is kept rather than summarised away.
  transaction_detail  JSONB NOT NULL DEFAULT '{}',

  -- Who holds the filing obligation for this one. Captured per action, not
  -- read from config at report time, because the structure changes and a
  -- record written under one arrangement must stay true to it.
  responsibility      TEXT NOT NULL CHECK (responsibility IN ('processor','principal','self')),

  -- 10 business days from the action. Computed on insert.
  report_due_by       DATE NOT NULL,

  -- Escalation, when somebody else files: when we told them, and what they
  -- said back.
  escalated_at        TIMESTAMPTZ,
  escalated_to        TEXT,
  escalation_ref      TEXT,

  -- Filing, when we file: who, when, and the reference OFAC gave back.
  reported_at         TIMESTAMPTZ,
  reported_by         TEXT,
  report_reference    TEXT,

  -- Blocked funds are held, and a holding has to be reconcilable to a ledger
  -- account. Null for rejections, which hold nothing.
  held_account        TEXT,
  released_at         TIMESTAMPTZ,
  release_reason      TEXT,

  note                TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- The worklist: what is not yet filed or escalated, soonest deadline first.
CREATE INDEX sanctions_actions_due_idx ON sanctions_actions (report_due_by)
  WHERE reported_at IS NULL AND escalated_at IS NULL;
CREATE INDEX sanctions_actions_subject_idx ON sanctions_actions (subject_type, subject_id, created_at DESC);
-- The annual blocked-property report, due 30 September, reads this.
CREATE INDEX sanctions_actions_blocked_idx ON sanctions_actions (action, released_at)
  WHERE action = 'blocked';
