-- Loyalty: points a customer earns on what they spend, and redeems for credit.
--
-- WHY EARNING IS KEYED ON A SOURCE
--
-- `loyalty_transactions.source` is unique per account. Points are earned
-- against a specific event — an order, a payment — and the webhook that tells
-- us the payment succeeded WILL sometimes arrive twice, because processors
-- retry. Without a unique source, a retried webhook earns the points twice and
-- the customer's balance drifts up every time the network hiccups. With it,
-- the second earn for the same source is refused by the database, not by our
-- remembering to check.
--
-- Balances are stored, not summed on read. A running total is correct only if
-- every write is correct, and a stored balance updated in the same transaction
-- as the ledger row it comes from cannot disagree with its own history.

CREATE TABLE loyalty_programs (
  merchant_id            TEXT PRIMARY KEY REFERENCES merchants(id),
  enabled                BOOLEAN NOT NULL DEFAULT false,
  currency               TEXT NOT NULL,
  earn_points_per_unit   INTEGER NOT NULL DEFAULT 1 CHECK (earn_points_per_unit >= 0),  -- points per 1 whole unit spent
  redeem_minor_per_point INTEGER NOT NULL DEFAULT 1 CHECK (redeem_minor_per_point >= 0),-- minor units credited per point
  min_redeem_points      INTEGER NOT NULL DEFAULT 0 CHECK (min_redeem_points >= 0),
  created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE loyalty_accounts (
  id               TEXT PRIMARY KEY,
  merchant_id      TEXT NOT NULL REFERENCES merchants(id),
  customer_id      TEXT NOT NULL REFERENCES customers(id),
  balance          INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
  lifetime_earned  INTEGER NOT NULL DEFAULT 0 CHECK (lifetime_earned >= 0),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX loyalty_accounts_cust_idx ON loyalty_accounts (merchant_id, customer_id);

CREATE TABLE loyalty_transactions (
  id          TEXT PRIMARY KEY,
  account_id  TEXT NOT NULL REFERENCES loyalty_accounts(id) ON DELETE CASCADE,
  type        TEXT NOT NULL CHECK (type IN ('earn','redeem','adjust')),
  points      INTEGER NOT NULL,          -- signed: + earns, - redeems
  source      TEXT,                      -- the event that caused it; unique per account
  note        TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX loyalty_tx_account_idx ON loyalty_transactions (account_id, created_at DESC);
CREATE UNIQUE INDEX loyalty_tx_source_idx ON loyalty_transactions (account_id, source) WHERE source IS NOT NULL;
