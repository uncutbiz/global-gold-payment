-- Business brand & public profile.
--
-- A merchant has a name already (set at signup). This adds the things a
-- customer actually sees on a checkout or a receipt: a logo, a brand colour,
-- the public-facing display name, and where to reach support.
--
-- The logo BYTES live in their own table, not on `merchants`. A logo is tens
-- of kilobytes and is needed on exactly two code paths (serve it, replace it),
-- while `merchants` is SELECTed on nearly every authenticated request. Keeping
-- the bytes out of that row means the common path never drags an image through
-- the database driver. The small, cheap facts a page needs to KNOW a logo
-- exists — its content type and when it last changed — stay on `merchants`, so
-- a page can build the <img> URL without touching the bytes at all.

ALTER TABLE merchants ADD COLUMN display_name    TEXT;
ALTER TABLE merchants ADD COLUMN support_email   TEXT;
ALTER TABLE merchants ADD COLUMN support_phone   TEXT;
ALTER TABLE merchants ADD COLUMN brand_color     TEXT;           -- '#RRGGBB', validated in code
ALTER TABLE merchants ADD COLUMN logo_mime       TEXT;           -- NULL means no logo
ALTER TABLE merchants ADD COLUMN logo_updated_at TIMESTAMPTZ;    -- doubles as a cache-buster

CREATE TABLE merchant_logos (
  merchant_id  TEXT PRIMARY KEY REFERENCES merchants(id) ON DELETE CASCADE,
  mime         TEXT NOT NULL,
  bytes        BYTEA NOT NULL,
  byte_len     INTEGER NOT NULL,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
