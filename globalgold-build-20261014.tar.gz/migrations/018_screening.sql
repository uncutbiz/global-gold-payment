-- Sanctions and PEP screening.
--
-- Checking a name against a watchlist is the easy half. The half that matters
-- to an examiner is the RECORD: who was screened, against which list as it
-- stood on that day, what came back, who looked at it, and why they decided
-- what they decided. A system that blocks correctly but cannot show its
-- working fails an audit just as surely as one that never screened at all.
--
-- So there are two tables, and the second one is the point.
--
-- WHY THE LIST IS STORED HERE RATHER THAN QUERIED LIVE
--
-- A screening decision has to be reproducible months later. If the check calls
-- a vendor API and keeps only "clear", then when a regulator asks why a name
-- that is on today's list was let through in March, there is no answer — the
-- list has changed underneath the record. Keeping entries locally, with the
-- version of the list each check ran against, makes the decision auditable.
--
-- It also means screening keeps working when the vendor is down, which matters
-- because the alternative is either blocking every signup or waving them all
-- through, and both are wrong.

CREATE TABLE watchlist_entries (
  id              TEXT PRIMARY KEY,

  -- Where it came from: 'ofac_sdn', 'ofac_consolidated', 'eu', 'un', a vendor
  -- name, or 'manual' for an internal block.
  source          TEXT NOT NULL,
  -- The publisher's own identifier, so a refresh updates rather than duplicates.
  external_id     TEXT,

  name            TEXT NOT NULL,
  -- Lowercased, punctuation stripped, tokens sorted. The column the match
  -- actually runs against, so the normalisation lives in one place rather than
  -- being reapplied at every call site.
  normalized_name TEXT NOT NULL,

  entity_type     TEXT NOT NULL DEFAULT 'unknown'
                    CHECK (entity_type IN ('individual','entity','vessel','aircraft','unknown')),
  -- 'SDN', 'PEP', 'NS-PLC' — which programme the listing is under.
  program         TEXT,
  country         TEXT,
  -- Narrows a false positive on a common name: a date of birth that does not
  -- match is strong evidence it is a different person.
  date_of_birth   DATE,
  remarks         TEXT,

  -- The list version this row belongs to, so a check can say which snapshot it
  -- saw. Bumped whenever a source is reloaded.
  list_version    TEXT NOT NULL,
  loaded_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX watchlist_source_idx ON watchlist_entries (source, external_id)
  WHERE external_id IS NOT NULL;
-- The exact-hit path.
CREATE INDEX watchlist_normalized_idx ON watchlist_entries (normalized_name);
-- Fuzzy matching runs in application code over an in-memory index, not in SQL.
--
-- The OFAC SDN list is on the order of tens of thousands of names, which fits
-- in memory comfortably and is refreshed daily at most. Doing it here instead
-- of with pg_trgm buys two things that matter more than the query speed: the
-- scoring becomes a pure function that can be tested against known names
-- without a database, and the system gains no dependency on an extension that
-- a managed or locked-down cluster might not grant.

/*
 * Every screening decision, kept forever.
 *
 * Rows are never updated away: a review decision adds to the row, it does not
 * replace the finding. Deleting a potential match because it turned out to be
 * somebody else is destroying the evidence that you looked.
 */
CREATE TABLE screening_checks (
  id              TEXT PRIMARY KEY,

  -- What was screened. Deliberately not a foreign key: a beneficial owner is
  -- screened before any row exists for them, and a payout counterparty may
  -- never become a record at all.
  subject_type    TEXT NOT NULL
                    CHECK (subject_type IN ('user','merchant','beneficial_owner','payout_counterparty')),
  subject_id      TEXT,
  name_checked    TEXT NOT NULL,
  country         TEXT,
  date_of_birth   DATE,

  --   clear            nothing above the threshold
  --   potential_match  something scored high enough to need a human
  --   confirmed_match  a reviewer said it is them
  --   false_positive   a reviewer said it is not
  --
  -- There is no 'blocked' status, on purpose: blocking is what the application
  -- does with a confirmed_match, and conflating the finding with the action
  -- makes it impossible to see how often reviewers overturn the machine.
  status          TEXT NOT NULL
                    CHECK (status IN ('clear','potential_match','confirmed_match','false_positive')),

  -- 0..100. Stored even when clear, because a run of 60s on one name is a
  -- signal even though none of them tripped the threshold.
  top_score       INTEGER NOT NULL DEFAULT 0,
  matches         JSONB NOT NULL DEFAULT '[]',

  -- Which snapshot of which lists this ran against. Without these two the row
  -- cannot be reproduced.
  sources_checked TEXT[] NOT NULL DEFAULT '{}',
  list_version    TEXT,

  reviewed_by     TEXT,
  reviewed_at     TIMESTAMPTZ,
  review_note     TEXT,

  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX screening_subject_idx ON screening_checks (subject_type, subject_id, created_at DESC);
-- The review queue: what a human still has to look at, oldest first.
CREATE INDEX screening_queue_idx ON screening_checks (created_at)
  WHERE status = 'potential_match';
