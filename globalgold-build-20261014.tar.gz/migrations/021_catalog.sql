-- Items & orders: a merchant's product catalogue, and the orders placed
-- against it.
--
-- WHY AN ORDER SNAPSHOTS THE PRICE IT WAS PLACED AT
--
-- An order line copies the item's name and price at the moment the order is
-- created, rather than pointing at the item and reading today's price. A
-- catalogue price changes; an order does not. If a line read the live price, a
-- merchant who raised a price after a sale would see last week's receipts
-- silently rewrite themselves, and the total on the order would stop matching
-- the money that was taken. The item link is kept too, for "how many of these
-- did we sell", but the money is the snapshot.

CREATE TABLE items (
  id           TEXT PRIMARY KEY,
  merchant_id  TEXT NOT NULL REFERENCES merchants(id),
  name         TEXT NOT NULL,
  description  TEXT,
  price        INTEGER NOT NULL CHECK (price >= 0),   -- minor units
  currency     TEXT NOT NULL,
  sku          TEXT,
  image_url    TEXT,
  active       BOOLEAN NOT NULL DEFAULT true,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX items_merchant_idx ON items (merchant_id, created_at DESC);
-- A SKU is unique within a merchant when present, so "SKU-100" means one thing.
CREATE UNIQUE INDEX items_merchant_sku_idx
  ON items (merchant_id, sku) WHERE sku IS NOT NULL;

CREATE TABLE orders (
  id                 TEXT PRIMARY KEY,
  merchant_id        TEXT NOT NULL REFERENCES merchants(id),
  customer_id        TEXT REFERENCES customers(id),
  currency           TEXT NOT NULL,
  subtotal           INTEGER NOT NULL CHECK (subtotal >= 0),
  discount           INTEGER NOT NULL DEFAULT 0 CHECK (discount >= 0),
  total              INTEGER NOT NULL CHECK (total >= 0),
  status             TEXT NOT NULL DEFAULT 'open'
                       CHECK (status IN ('open','paid','fulfilled','canceled','refunded')),
  payment_intent_id  TEXT REFERENCES payment_intents(id),
  note               TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX orders_merchant_idx ON orders (merchant_id, created_at DESC);
CREATE INDEX orders_customer_idx ON orders (customer_id) WHERE customer_id IS NOT NULL;

CREATE TABLE order_items (
  id          TEXT PRIMARY KEY,
  order_id    TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  item_id     TEXT REFERENCES items(id),   -- NULL for an ad-hoc line
  name        TEXT NOT NULL,               -- snapshot
  unit_price  INTEGER NOT NULL CHECK (unit_price >= 0),  -- snapshot, minor units
  quantity    INTEGER NOT NULL CHECK (quantity > 0),
  line_total  INTEGER NOT NULL CHECK (line_total >= 0)
);

CREATE INDEX order_items_order_idx ON order_items (order_id);
CREATE INDEX order_items_item_idx ON order_items (item_id) WHERE item_id IS NOT NULL;
