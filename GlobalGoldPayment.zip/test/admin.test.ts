/**
 * Admin panel: staff roles, KYC review, transaction monitoring, account freezes, audit trail.
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.CARD_RATE_LIMIT = '1000';
process.env.AUTH_RATE_LIMIT = '1000';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { createApp } = await import('../src/server.js');

let base = '';
let server: http.Server;
const PNG = 'data:image/png;base64,' + Buffer.concat([Buffer.from('89504e470d0a1a0a', 'hex'), crypto.randomBytes(300)]).toString('base64');
const staff: Record<string, string> = {};

async function call(method: string, path: string, key: string | null, body?: unknown) {
  const res = await fetch(base + path, {
    method,
    headers: { ...(key ? { authorization: `Bearer ${key}` } : {}), 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed: any = text;
  try { parsed = JSON.parse(text); } catch { /* binary */ }
  return { status: res.status, body: parsed, headers: res.headers };
}

async function user(name: string, country: string) {
  const email = `${name.toLowerCase().replace(/\s/g, '')}.${crypto.randomBytes(3).toString('hex')}@example.com`;
  const r = await call('POST', '/v1/wallet/signup', null, { email, name, password: 'correct horse battery', country });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return { token: r.body.token as string, email, ...r.body.user };
}

function kycBody(u: { name: string; country: string }, idNumber: string, extra: Record<string, unknown> = {}) {
  return {
    legal_name: u.name, date_of_birth: '1988-02-03', address_line: '12 Harbour Rd', city: 'Lagos', postal_code: '100001',
    country: u.country, id_type: 'passport', id_number: idNumber, document: PNG, ...extra,
  };
}

async function fund(u: { token: string }, amount: number) {
  const card = await call('POST', '/v1/wallet/cards', u.token, { card: { number: '4242424242424242', exp_month: 12, exp_year: 2040, cvc: '123' } });
  return call('POST', '/v1/wallet/top_ups', u.token, { amount, card: card.body.id });
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  for (const role of ['compliance', 'support', 'viewer']) {
    const email = `${role}@globalgold.test`;
    const c = await call('POST', '/v1/admin/staff', 'test-admin', { email, name: `${role} person`, password: 'staff-password-123', role });
    assert.equal(c.status, 201, JSON.stringify(c.body));
    const l = await call('POST', '/v1/admin/login', null, { email, password: 'staff-password-123' });
    assert.equal(l.status, 200, JSON.stringify(l.body));
    staff[role] = l.body.token;
  }
});

after(async () => {
  server.close();
  await pool.end();
});

describe('staff access', () => {
  it('rejects bad logins and enforces roles', async () => {
    assert.equal((await call('POST', '/v1/admin/login', null, { email: 'compliance@globalgold.test', password: 'nope' })).status, 401);
    assert.equal((await call('GET', '/v1/admin/overview', null)).status, 401);
    assert.equal((await call('GET', '/v1/admin/overview', staff.viewer)).status, 200);
    assert.equal((await call('GET', '/v1/admin/users', staff.viewer)).status, 403);
    assert.equal((await call('GET', '/v1/admin/users', staff.support)).status, 200);
    assert.equal((await call('POST', '/v1/admin/staff', staff.compliance, { email: 'x@y.co', name: 'X', password: 'long-password-123', role: 'owner' })).status, 403);
    const me = await call('GET', '/v1/admin/me', staff.compliance);
    assert.equal(me.body.role, 'compliance');
  });

  it('cuts off a disabled staff member immediately', async () => {
    const c = await call('POST', '/v1/admin/staff', 'test-admin', { email: 'temp@globalgold.test', name: 'Temp', password: 'staff-password-123', role: 'viewer' });
    const l = await call('POST', '/v1/admin/login', null, { email: 'temp@globalgold.test', password: 'staff-password-123' });
    assert.equal((await call('GET', '/v1/admin/overview', l.body.token)).status, 200);
    await call('POST', `/v1/admin/staff/${c.body.id}/disable`, 'test-admin', {});
    assert.equal((await call('GET', '/v1/admin/overview', l.body.token)).status, 401);
  });
});

describe('KYC review', () => {
  it('limits unverified users, then unlocks them after approval', async () => {
    const us = await user('Tobi Adeyemi', 'US');
    const ng = await user('Ngozi Eze', 'NG');

    // Unverified limits.
    assert.equal((await fund(us, 60000)).status, 403);      // > $500 top-up
    assert.equal((await fund(us, 40000)).status, 201);
    const intl = await call('POST', '/v1/wallet/transfers', us.token, { to: ng.email, amount: 1000 });
    assert.equal(intl.status, 403);
    assert.equal(intl.body.error.code, 'kyc_required');
    assert.equal((await call('POST', '/v1/wallet/withdrawals', us.token, { amount: 1000 })).status, 403);

    // Validation.
    const young = await call('POST', '/v1/wallet/kyc', us.token, kycBody(us, 'A1234567', { date_of_birth: '2015-01-01' }));
    assert.equal(young.body.error.code, 'age_requirement');
    const badDoc = await call('POST', '/v1/wallet/kyc', us.token, kycBody(us, 'A1234567', { document: 'data:text/html;base64,PGgxPg==' }));
    assert.equal(badDoc.status, 400);

    // Submit → pending, cannot resubmit while pending.
    const sub = await call('POST', '/v1/wallet/kyc', us.token, kycBody(us, 'A1234567'));
    assert.equal(sub.status, 201, JSON.stringify(sub.body));
    assert.equal((await call('POST', '/v1/wallet/kyc', us.token, kycBody(us, 'A1234567'))).body.error.code, 'kyc_pending');
    assert.equal((await call('GET', '/v1/wallet', us.token)).body.kyc.status, 'pending');

    // Queue shows it with automatic checks.
    const q = await call('GET', '/v1/admin/kyc', staff.support);
    const item = q.body.data.find((k: any) => k.id === sub.body.id);
    assert.ok(item);
    assert.equal(item.checks.name_matches_account, true);
    assert.equal(item.checks.duplicate_identity, false);
    assert.equal(item.id_number_last4, '4567');
    assert.equal(JSON.stringify(q.body).includes('A1234567'), false);   // full ID number never exposed

    // Support can look but not decide or open documents.
    assert.equal((await call('POST', `/v1/admin/kyc/${sub.body.id}/approve`, staff.support, {})).status, 403);
    assert.equal((await call('GET', `/v1/admin/kyc/${sub.body.id}/document`, staff.support)).status, 403);
    const doc = await call('GET', `/v1/admin/kyc/${sub.body.id}/document`, staff.compliance);
    assert.equal(doc.status, 200);
    assert.equal(doc.headers.get('content-type'), 'image/png');

    // Reject needs a reason, which the customer sees.
    assert.equal((await call('POST', `/v1/admin/kyc/${sub.body.id}/reject`, staff.compliance, {})).status, 400);
    const rej = await call('POST', `/v1/admin/kyc/${sub.body.id}/reject`, staff.compliance, { note: 'The photo is blurry. Upload a clearer picture.' });
    assert.equal(rej.body.status, 'rejected');
    const w = (await call('GET', '/v1/wallet', us.token)).body;
    assert.equal(w.kyc.status, 'rejected');
    assert.match(w.kyc.rejection_reason, /blurry/);

    // Resubmit and approve.
    const sub2 = await call('POST', '/v1/wallet/kyc', us.token, kycBody(us, 'A1234567'));
    assert.equal(sub2.status, 201);
    const ok = await call('POST', `/v1/admin/kyc/${sub2.body.id}/approve`, staff.compliance, { note: 'Clear document' });
    assert.equal(ok.body.status, 'approved');
    assert.equal((await call('POST', `/v1/admin/kyc/${sub2.body.id}/approve`, staff.compliance, {})).status, 400);

    const sent = await call('POST', '/v1/wallet/transfers', us.token, { to: ng.email, amount: 1000 });
    assert.equal(sent.status, 201, JSON.stringify(sent.body));
    assert.equal((await call('POST', '/v1/wallet/withdrawals', us.token, { amount: 500 })).status, 201);
  });

  it('flags the same ID document used on two accounts', async () => {
    const a = await user('Musa Bello', 'NG');
    const b = await user('Musa Bello Two', 'NG');
    await call('POST', '/v1/wallet/kyc', a.token, kycBody(a, 'B7654321'));
    const s2 = await call('POST', '/v1/wallet/kyc', b.token, kycBody(b, 'b7654321', { legal_name: 'Musa Bello' }));   // same number, different case
    const alerts = await call('GET', '/v1/admin/alerts?status=open', staff.viewer);
    const dup = alerts.body.data.find((x: any) => x.rule === 'duplicate_identity' && x.subject_id === s2.body.id);
    assert.ok(dup, 'duplicate identity alert');
    assert.equal(dup.severity, 'high');
    const q = await call('GET', '/v1/admin/kyc', staff.compliance);
    assert.equal(q.body.data.find((k: any) => k.id === s2.body.id).checks.duplicate_identity, true);
    assert.equal(q.body.data.find((k: any) => k.id === s2.body.id).checks.name_matches_account, false);
  });
});

describe('transaction monitoring', () => {
  it('raises alerts for large and rapid transfers, and lets compliance resolve them', async () => {
    const a = await user('Big Sender', 'US');
    const b = await user('Receiver', 'US');
    const s = await call('POST', '/v1/wallet/kyc', a.token, kycBody(a, 'C1112223'));
    await call('POST', `/v1/admin/kyc/${s.body.id}/approve`, staff.compliance, {});
    await fund(a, 200000);
    await fund(a, 200000);

    const big = await call('POST', '/v1/wallet/transfers', a.token, { to: b.email, amount: 300000, note: 'Car' });
    assert.equal(big.status, 201, JSON.stringify(big.body));
    for (let i = 0; i < 4; i++) await call('POST', '/v1/wallet/transfers', a.token, { to: b.email, amount: 1000 });

    const open = (await call('GET', '/v1/admin/alerts?status=open', staff.compliance)).body.data.filter((x: any) => x.user_id === a.id);
    const rules = open.map((x: any) => x.rule).sort();
    assert.deepEqual(rules, ['large_transfer', 'new_account_large_send', 'velocity']);

    // Flagged filter + detail view with ledger lines.
    const flagged = await call('GET', `/v1/admin/transactions?flagged=true&user=${a.id}`, staff.support);
    assert.deepEqual(flagged.body.data.map((t: any) => t.id), [big.body.id]);
    const detail = await call('GET', `/v1/admin/transactions/${big.body.id}`, staff.viewer);
    assert.equal(detail.body.summary.kind, 'transfer');
    assert.equal(detail.body.alerts.length, 2);
    const debits = detail.body.ledger.reduce((s: number, l: any) => s + l.debit, 0);
    const credits = detail.body.ledger.reduce((s: number, l: any) => s + l.credit, 0);
    assert.equal(debits, credits);

    const large = open.find((x: any) => x.rule === 'large_transfer');
    assert.equal((await call('POST', `/v1/admin/alerts/${large.id}/resolve`, staff.viewer, { resolution: 'resolved' })).status, 403);
    const r = await call('POST', `/v1/admin/alerts/${large.id}/resolve`, staff.compliance, { resolution: 'resolved', note: 'Customer bought a car; invoice on file' });
    assert.equal(r.body.status, 'resolved');
    assert.equal((await call('POST', `/v1/admin/alerts/${large.id}/resolve`, staff.compliance, { resolution: 'dismissed' })).status, 400);
  });

  it('freezes an account: sessions end and sign-in is blocked until unfrozen', async () => {
    const u = await user('Frozen Fred', 'GB');
    assert.equal((await call('POST', `/v1/admin/users/${u.id}/freeze`, staff.compliance, {})).status, 400);   // reason required
    const f = await call('POST', `/v1/admin/users/${u.id}/freeze`, staff.compliance, { reason: 'Suspected account takeover' });
    assert.equal(f.body.status, 'locked');
    assert.equal((await call('GET', '/v1/wallet', u.token)).status, 401);
    const login = await call('POST', '/v1/wallet/login', null, { email: u.email, password: 'correct horse battery' });
    assert.equal(login.status, 403);
    assert.equal(login.body.error.code, 'account_locked');

    const detail = await call('GET', `/v1/admin/users/${u.id}`, staff.support);
    assert.equal(detail.body.user.locked_reason, 'Suspected account takeover');

    await call('POST', `/v1/admin/users/${u.id}/unfreeze`, staff.compliance, {});
    assert.equal((await call('POST', '/v1/wallet/login', null, { email: u.email, password: 'correct horse battery' })).status, 200);
  });

  it('shows every kind of transaction in one list and an overview', async () => {
    const m = (await call('POST', '/v1/admin/merchants', 'test-admin', { name: 'Accra Market', email: 'm@example.com' })).body;
    const tok = (await call('POST', '/v1/tokens', m.api_keys.publishable, { card: { number: '4242424242424242', exp_month: 1, exp_year: 2041, cvc: '123' } })).body.id;
    const pi = (await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 2500, currency: 'usd', payment_token: tok, confirm: true, description: 'Kente cloth' })).body;
    await call('POST', '/v1/refunds', m.api_keys.secret, { payment_intent: pi.id, amount: 500 });

    const list = await call('GET', '/v1/admin/transactions?limit=200', staff.viewer);
    const kinds = new Set(list.body.data.map((t: any) => t.kind));
    for (const k of ['payment', 'refund', 'transfer', 'international_transfer', 'top_up', 'withdrawal']) assert.ok(kinds.has(k), `missing ${k}`);
    const row = list.body.data.find((t: any) => t.id === pi.id);
    assert.equal(row.from_label, 'Visa •••• 4242');
    assert.equal(row.to_label, 'Accra Market');

    const search = await call('GET', '/v1/admin/transactions?q=kente', staff.viewer);
    assert.deepEqual(search.body.data.map((t: any) => t.id), [pi.id]);

    // Suspending a merchant stops new payments.
    await call('POST', `/v1/admin/merchants/${m.id}/status`, staff.compliance, { status: 'suspended', reason: 'Excessive chargebacks' });
    assert.equal((await call('POST', '/v1/payment_intents', m.api_keys.secret, { amount: 2500, currency: 'usd' })).status, 403);

    const o = await call('GET', '/v1/admin/overview', staff.viewer);
    assert.equal(o.status, 200, JSON.stringify(o.body));
    assert.equal(o.body.ledger.balanced, true);
    assert.ok(o.body.users.total >= 7);
    assert.ok(o.body.volume_24h.transfers_usd > 0);
    assert.ok(o.body.revenue.fees_usd > 0);
    assert.equal(o.body.daily_volume_usd.length, 7);
  });

  it('records staff actions in an append-only audit log', async () => {
    assert.equal((await call('GET', '/v1/admin/audit', staff.compliance)).status, 403);
    const log = await call('GET', '/v1/admin/audit', 'test-admin');
    const actions = new Set(log.body.data.map((a: any) => a.action));
    for (const a of ['staff.create', 'kyc.reject', 'kyc.approve', 'kyc.view_document', 'alert.resolved', 'user.freeze', 'user.unfreeze', 'merchant.suspended']) {
      assert.ok(actions.has(a), `missing ${a}`);
    }
    await assert.rejects(pool.query('DELETE FROM audit_log'), /append-only/);
  });
});
