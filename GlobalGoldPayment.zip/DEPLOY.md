# Deploying Global Gold Payment

> **Test mode only until you are licensed.** The card network connection is simulated. Real card payments and customer balances need a sponsor bank, PCI DSS certification and money-transmitter licensing. The blueprint explains all three.

## Which platform

| Platform | Use it for | Why |
|---|---|---|
| **AWS (ECS Fargate + RDS)** | Production | Everything in `infra/aws`: encrypted database, private network, firewall, secrets, audit logs. AWS is a PCI DSS Level 1 service provider, which your auditor will need. |
| **Render** | Staging / demos | One-click from `render.yaml`. Online in minutes, small monthly cost. |
| **Fly.io** | Staging, or apps close to users in many regions | `fly.toml` included. |
| **Any server with Docker** | Cheapest self-hosting | `docker-compose.prod.yml` (app + Postgres). Put Caddy, Nginx or Cloudflare in front for HTTPS. |
| Google Cloud Run + Cloud SQL, or Azure Container Apps | AWS alternatives | The same Docker image runs there. Both clouds also offer PCI-attested services. |

AWS App Runner is not an option: it [stopped taking new customers on 30 April 2026](https://encore.dev/articles/end-of-app-runner). AWS points new users to ECS, which is what this setup uses.

Recommended path: **staging on Render (or AWS staging) → production on AWS.**

---

## Before any deploy: check it works

```bash
npm ci
npm run typecheck
TEST_DATABASE_URL=postgres://... npm test        # API, wallet, admin, full journey: 39 checks
npx playwright install chromium
TEST_DATABASE_URL=postgres://... npm run test:ui # clicks every button on every page
```

After every deploy, run the smoke test against the live site. It uses test accounts and never deletes data:

```bash
BASE_URL=https://your-domain ADMIN_TOKEN=... npm run smoke            # 16 checks
BASE_URL=https://your-domain ADMIN_TOKEN=... SMOKE_SETTLE=1 npm run smoke   # also settles and pays out
```

---

## Option A: AWS — one command

Everything below is automated. `scripts/deploy-aws.sh` runs nine steps in order, stops at the
first problem, and can be re-run safely — finished one-time steps are skipped, so a re-run
carries on from where it stopped.

```bash
cp infra/aws/terraform.tfvars.example infra/aws/terraform.tfvars   # domain, zone id, GitHub repo, alarm email
$EDITOR infra/aws/terraform.tfvars

make deploy-dry     # print every command it would run; changes nothing
make deploy         # do it (asks once before it changes AWS)
```

First run takes 20–30 minutes; the certificate and the Multi-AZ database are the slow parts.
It finishes by printing your live URLs and a signed-in admin password.

| # | Step | What it does |
|---|---|---|
| 0 | `preflight` | Checks the AWS CLI, Terraform, Docker, Node and jq; that AWS is signed in; that `domain_name` really sits inside `route53_zone_id`; then type-checks and (with `TEST_DATABASE_URL`) runs the tests. Fails in seconds rather than half-way through. |
| 1 | `state-backend` | Creates an encrypted, versioned, private, HTTPS-only S3 bucket and writes `infra/aws/backend.tf`. The state holds the generated database password and card-vault key, so it must not sit on a laptop. |
| 2 | `terraform-init` | Downloads the provider, connects the backend (migrating local state if there is any), and validates the configuration. |
| 3 | `registry` | Creates the ECR repository on its own — ECS cannot start a service whose image does not exist yet. |
| 4 | `build-push` | Fetches Amazon's RDS certificate bundle, builds the image for `linux/amd64` (so it works from an Apple Silicon Mac), and pushes it tagged with the git commit. Skips the build if that tag is already in the registry. |
| 5 | `infrastructure` | Applies everything else: VPC, NAT, RDS, Secrets Manager, ALB, ACM, WAF, ECS service, autoscaling, alarms, GitHub deploy role. Shows the plan summary and warns you by name about anything it would destroy. |
| 6 | `release` | Registers a task-definition revision for the new image and rolls it out, waiting for the service to stabilise. ECS rolls back automatically if the new containers fail their health check. On a first deploy step 5 already did this, and the step notices. |
| 7 | `first-admin` | Reads the bootstrap `ADMIN_TOKEN` from Secrets Manager and creates your real owner login. Skipped if staff accounts already exist. |
| 8 | `verify` | DNS, certificate, HTTP→HTTPS redirect, `/health`, every page, the 404 and 401 responses, ECS running count, load-balancer target health — then the full end-to-end smoke test against the live site. |

Useful variations:

```bash
./scripts/deploy-aws.sh --list                 # the steps
./scripts/deploy-aws.sh --dry-run              # print, change nothing
./scripts/deploy-aws.sh --from build-push      # resume after fixing something
./scripts/deploy-aws.sh --only verify          # just re-check the live site
./scripts/deploy-aws.sh --yes --skip-tests     # unattended (CI)
./scripts/deploy-aws.sh --fresh                # forget which steps finished
./scripts/deploy-aws.sh --local-state          # skip the S3 bucket (not for production)
```

Everyday commands:

```bash
ADMIN_EMAIL=you@company.com ADMIN_NAME="Your Name" make first-admin
make release     # ship a code change: build, push, roll out
make verify      # re-run the live checks and smoke test
make outputs     # URLs, cluster, secret ARN
make logs        # tail the container logs
make plan        # Terraform plan only
make destroy     # delete the deployment (asks you to type the environment name)
make help        # everything
```

Every run is written to `.deploy-logs/`. Exit codes: `0` success, `1` a step failed,
`2` bad usage, `3` you declined a prompt.

What gets created (`infra/aws`):

- **Network:** a private network (VPC) across 2 availability zones. Public subnets hold only the load balancer, app subnets have no public IPs, and database subnets have no internet route. VPC flow logs are on.
- **Web traffic:** an Application Load Balancer that serves HTTPS only (TLS 1.2/1.3, certificate from ACM) and redirects HTTP to HTTPS.
- **Firewall:** AWS WAF with a per-IP rate limit plus AWS managed rules for common attacks and known bad inputs.
- **App:** ECS Fargate running 2–6 containers with CPU-based autoscaling, a read-only filesystem, and automatic rollback if a deploy fails.
- **Database:** RDS PostgreSQL 16, encrypted with your own KMS key and TLS-only. It is Multi-AZ by default, with 14 days of backups and Performance Insights.
- **Secrets:** Secrets Manager holds the database password, admin token, card-vault key and fingerprint key. Containers read them at start; they are never kept in code or the image.
- **Monitoring:** ECR image scanning, CloudWatch logs kept for a year, and alarms (5xx errors, unhealthy containers, database CPU and storage) sent to your email.
- **Deploys:** a GitHub OIDC role, so GitHub Actions deploys without stored AWS keys.

### 1. Prerequisites

- An AWS account, with the AWS CLI signed in as an administrator
- A domain in Route 53 (or move its DNS there)
- Terraform 1.10+ (or OpenTofu) for S3 state locking — 1.6 works without it — plus Docker, Node 22 and `jq`
- The code in a GitHub repository (e.g. `uncutbiz/global-gold-payment`)

`make deploy` checks all of this for you and says exactly what is missing.

### 2. Create the infrastructure

`make deploy` does all of this. The commands below are the same thing by hand, for when
you want to run a single stage yourself or something in the script needs debugging.

```bash
cd infra/aws
cp terraform.tfvars.example terraform.tfvars   # set domain, zone id, GitHub repo, alarm email
terraform init
terraform apply -target=aws_ecr_repository.app    # the image registry first
```

Push a first image (tags are immutable; use the git commit):

```bash
REPO=$(terraform output -raw ecr_repository_url)
TAG=$(git rev-parse --short HEAD)
aws ecr get-login-password | docker login --username AWS --password-stdin "${REPO%/*}"
docker build --platform linux/amd64 -t "$REPO:$TAG" ../..
docker push "$REPO:$TAG"
```

Create everything else, pointing at that image:

```bash
terraform apply -var "image_tag=$TAG"     # ~15–20 minutes (database + certificate)
terraform output
```

Keep Terraform state in an encrypted S3 bucket (see the commented `backend "s3"` block in `main.tf`). The state contains the generated secrets.

### 3. Create your first admin

Read the bootstrap token from Secrets Manager:

```bash
aws secretsmanager get-secret-value --secret-id "$(terraform output -raw app_secret_arn)" \
  --query SecretString --output text | jq -r .ADMIN_TOKEN
```

Then create your staff account through the API:

```bash
curl -X POST https://pay.example.com/v1/admin/staff \
  -H "Authorization: Bearer <ADMIN_TOKEN>" -H 'content-type: application/json' \
  -d '{"email":"you@company.com","name":"Your Name","password":"a-long-unique-password","role":"owner"}'
```

Sign in at `https://pay.example.com/admin`.

### 4. Turn on automatic deploys

In GitHub, open **Settings → Secrets and variables → Actions → Variables** and add the values from `terraform output`:

| Variable | From |
|---|---|
| `AWS_REGION` | your region |
| `AWS_DEPLOY_ROLE_ARN` | `github_deploy_role_arn` |
| `ECR_REPOSITORY_URL` | `ecr_repository_url` |
| `ECS_CLUSTER` | `ecs_cluster` |
| `ECS_SERVICE` | `ecs_service` |
| `TASK_DEFINITION_FAMILY` | `task_definition_family` |
| `APP_URL` | `app_url` |
| `RUN_SMOKE_TEST` | `true` (optional) |

Also add the secret `SMOKE_ADMIN_TOKEN` (the admin token) if you enabled the smoke test, and create a GitHub environment named `production`. Add required reviewers to it if you want a manual approval before each deploy.

From then on, every push to `main` goes through three steps:

1. **CI** (`.github/workflows/ci.yml`): type checks, all API tests, and the browser tests.
2. **Deploy** (`.github/workflows/deploy-aws.yml`): builds the image, pushes it to ECR, and rolls it out to ECS. It rolls back automatically if the new version fails health checks.
3. **Smoke test:** runs against the live site.

### 5. Before real money (production checklist)

- [ ] `environment = "production"` in tfvars. This turns on deletion protection and final snapshots.
- [ ] `single_nat_gateway = false` and a larger `db_instance_class`.
- [ ] Remove or rotate `ADMIN_TOKEN` once staff accounts exist.
- [ ] Move the card vault key from Secrets Manager to KMS/CloudHSM envelope encryption, or use a PCI-certified token vault provider.
- [ ] Put staff sign-in behind SSO with MFA, and restrict `/admin` by IP. You can do this with a WAF rule scoped to `/admin` and `/v1/admin`.
- [ ] Turn on AWS Security Hub with the PCI DSS standard, GuardDuty and CloudTrail across the organization.
- [ ] Replace the simulated card network in `src/acquirer/connector.ts` with your sponsor bank's connection. Connect a live exchange-rate feed in `src/wallet/fx.ts`.
- [ ] Get a QSA to scope and assess the environment.

### Costs

The biggest line items are the Multi-AZ database, the NAT gateway(s), the load balancer and WAF, and the Fargate containers. Price your exact settings in the [AWS Pricing Calculator](https://calculator.aws). For a cheaper staging environment, set `db_multi_az = false`, `app_desired_count = 1`, and use a smaller database class.

---

## Option B: Render (staging in minutes)

1. Push the repo to GitHub.
2. In Render, choose **New → Blueprint** and select the repo. Render reads `render.yaml`.
3. Set `VAULT_KEY` and `FINGERPRINT_KEY` (`openssl rand -base64 32`, one for each) and `PUBLIC_URL`.
4. Deploy. Render generates `ADMIN_TOKEN`; copy it from the Environment tab to create your first staff account (step 3 above).
5. Run `BASE_URL=https://<your>.onrender.com ADMIN_TOKEN=... npm run smoke`.

## Option C: Fly.io

Follow the commands at the top of `fly.toml`, then run the smoke test.

## Option D: your own server

```bash
cp .env.example .env.production     # set ADMIN_TOKEN, VAULT_KEY, FINGERPRINT_KEY, NODE_ENV=production
export POSTGRES_PASSWORD=$(openssl rand -hex 24)
docker compose -f docker-compose.prod.yml up -d --build
```

Point a reverse proxy with HTTPS at `127.0.0.1:8080`.

---

## Operating it

- **Health check:** `GET /health` returns `{"ok":true}` when the app can reach the database.
- **Logs:** one JSON line per request (method, path, status, time, IP). Bodies and query strings are never logged, so no card numbers or client secrets end up in logs.
- **Migrations:** run automatically on start. A database lock makes sure only one container runs them.
- **Shutdown:** containers finish in-flight requests on SIGTERM, so rolling deploys drop no requests.
- **Daily settlement:** click **Run daily settlement** in the admin panel. To automate it, schedule `POST /v1/admin/settlements/run` with EventBridge Scheduler, or with a cron on your server.
- **Rate limits:** the app's own limits are per container. On AWS, the WAF rate rule protects the whole service.

---

## Verifying the build yourself

**The image**

```bash
npm run fetch-rds-ca                 # only needed for AWS
docker build -t global-gold-payment .
docker run --rm -p 8080:8080 \
  -e DATABASE_URL=postgres://user:pass@host:5432/globalgold -e DATABASE_SSL=off \
  -e ADMIN_TOKEN=$(openssl rand -hex 32) \
  -e VAULT_KEY=$(openssl rand -base64 32) -e FINGERPRINT_KEY=$(openssl rand -base64 32) \
  global-gold-payment
```

Behind a company proxy that inspects TLS, `npm ci` inside the build needs your proxy's
certificate. Put it in the build context and add two lines to the build stage:

```dockerfile
COPY your-proxy-ca.crt /tmp/ca.crt
ENV NODE_EXTRA_CA_CERTS=/tmp/ca.crt
```

**The AWS files**

```bash
cd infra/aws && terraform init && terraform validate && terraform plan
```

Without AWS credentials you can still check every resource type and argument against the
published provider schema (no AWS account, no Terraform registry access needed):

```bash
mkdir -p /tmp/tfcheck && cd /tmp/tfcheck && npm init -y && npm i --legacy-peer-deps @cdktf/provider-aws@21
python3 /path/to/repo/scripts/check-terraform-schema.py /path/to/repo/infra/aws
```
