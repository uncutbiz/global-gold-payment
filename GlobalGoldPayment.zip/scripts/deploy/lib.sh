# Shared helpers for the deployment steps. Sourced, never run directly.
# shellcheck shell=bash

set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TF_DIR="$REPO_ROOT/infra/aws"
STATE_FILE="$TF_DIR/.deploy-state"
# shellcheck disable=SC2034  # used by scripts/deploy-aws.sh, which sources this file
LOG_DIR="$REPO_ROOT/.deploy-logs"

DRY_RUN="${DRY_RUN:-0}"
ASSUME_YES="${ASSUME_YES:-0}"

if [ -t 1 ] && [ "${NO_COLOR:-}" = "" ]; then
  C_DIM=$'\033[2m'; C_RED=$'\033[31m'; C_GRN=$'\033[32m'; C_YEL=$'\033[33m'
  C_BLU=$'\033[36m'; C_BLD=$'\033[1m'; C_OFF=$'\033[0m'
else
  C_DIM=''; C_RED=''; C_GRN=''; C_YEL=''; C_BLU=''; C_BLD=''; C_OFF=''
fi

log()   { printf '%s\n' "${C_BLU}▸${C_OFF} $*"; }
ok()    { printf '%s\n' "${C_GRN}✓${C_OFF} $*"; }
warn()  { printf '%s\n' "${C_YEL}!${C_OFF} $*" >&2; }
info()  { printf '%s\n' "  ${C_DIM}$*${C_OFF}"; }
die()   { printf '%s\n' "${C_RED}✗ $*${C_OFF}" >&2; exit 1; }

heading() {
  printf '\n%s\n' "${C_BLD}── $* ${C_OFF}"
}

# run <cmd...> — echoes the command; skips it when DRY_RUN=1.
run() {
  if [ "$DRY_RUN" = "1" ]; then
    printf '%s\n' "  ${C_DIM}would run: $*${C_OFF}"
    return 0
  fi
  printf '%s\n' "  ${C_DIM}\$ $*${C_OFF}"
  "$@"
}

need() {
  command -v "$1" >/dev/null 2>&1 || die "$1 is not installed. $2"
}

confirm() {
  [ "$ASSUME_YES" = "1" ] && return 0
  [ "$DRY_RUN" = "1" ] && return 0
  printf '%s' "${C_YEL}?${C_OFF} $1 [y/N] "
  local answer=''
  # Read from the terminal when there is one, otherwise from stdin.
  { read -r answer <&9; } 2>/dev/null 9</dev/tty || read -r answer || answer=''
  case "$answer" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

# ---- step bookkeeping -------------------------------------------------------

step_done() {
  [ "$DRY_RUN" = "1" ] && return 0
  mkdir -p "$(dirname "$STATE_FILE")"
  touch "$STATE_FILE"
  grep -v "^$1=" "$STATE_FILE" >"$STATE_FILE.tmp" 2>/dev/null || true
  printf '%s=done %s\n' "$1" "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >>"$STATE_FILE.tmp"
  mv "$STATE_FILE.tmp" "$STATE_FILE"
}

step_is_done() {
  [ -f "$STATE_FILE" ] && grep -q "^$1=done" "$STATE_FILE"
}

# ---- terraform / config -----------------------------------------------------

TFVARS="$TF_DIR/terraform.tfvars"

# tfvar <name> [default] — reads a top-level string/number from terraform.tfvars.
tfvar() {
  local name="$1" default="${2:-}" value=''
  if [ -f "$TFVARS" ]; then
    value="$(sed -n "s/^[[:space:]]*${name}[[:space:]]*=[[:space:]]*\"\{0,1\}\([^\"#]*\)\"\{0,1\}.*/\1/p" "$TFVARS" | head -1)"
    value="${value%"${value##*[![:space:]]}"}"
  fi
  printf '%s' "${value:-$default}"
}

# tf_out <name> — a terraform output, or empty if the state has none yet.
tf_out() {
  ( cd "$TF_DIR" && terraform output -raw "$1" 2>/dev/null ) || printf ''
}

aws_region() {
  printf '%s' "${AWS_REGION:-$(tfvar region us-east-1)}"
}

image_tag() {
  if [ -n "${IMAGE_TAG:-}" ]; then printf '%s' "$IMAGE_TAG"; return; fi
  if git -C "$REPO_ROOT" rev-parse --short HEAD >/dev/null 2>&1; then
    local sha dirty=''
    sha="$(git -C "$REPO_ROOT" rev-parse --short=12 HEAD)"
    git -C "$REPO_ROOT" diff --quiet 2>/dev/null || dirty="-dirty$(date -u '+%Y%m%d%H%M%S')"
    printf '%s' "$sha$dirty"
  else
    printf 'v%s' "$(date -u '+%Y%m%d-%H%M%S')"
  fi
}

# Terraform wrapper: passes -var image_tag and auto-approves when ASSUME_YES=1.
tf() {
  ( cd "$TF_DIR" && run terraform "$@" )
}

secret_field() {
  # secret_field <secret-arn> <json key>
  aws secretsmanager get-secret-value --secret-id "$1" --region "$(aws_region)" \
    --query SecretString --output text 2>/dev/null \
    | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{process.stdout.write(String(JSON.parse(s)[process.argv[1]]??""))}catch{process.stdout.write("")}})' "$2"
}
