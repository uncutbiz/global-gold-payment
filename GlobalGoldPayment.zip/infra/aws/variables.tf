variable "region" {
  description = "AWS region, e.g. us-east-1"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name: staging or production"
  type        = string
  default     = "staging"
}

variable "domain_name" {
  description = "Public hostname for the app, e.g. pay.globalgold.com"
  type        = string
}

variable "route53_zone_id" {
  description = "Route 53 hosted zone that contains domain_name (used for the certificate and DNS record)"
  type        = string
}

variable "vpc_cidr" {
  type    = string
  default = "10.20.0.0/16"
}

variable "single_nat_gateway" {
  description = "One NAT gateway (cheaper) instead of one per availability zone (more resilient)"
  type        = bool
  default     = true
}

variable "db_instance_class" {
  type    = string
  default = "db.t4g.medium"
}

variable "db_allocated_storage" {
  type    = number
  default = 50
}

variable "db_multi_az" {
  description = "Standby database in a second availability zone (recommended for production)"
  type        = bool
  default     = true
}

variable "app_cpu" {
  type    = number
  default = 512
}

variable "app_memory" {
  type    = number
  default = 1024
}

variable "app_desired_count" {
  type    = number
  default = 2
}

variable "app_max_count" {
  type    = number
  default = 6
}

variable "image_tag" {
  description = "Initial image tag in ECR. CI deploys new tags after this."
  type        = string
  default     = "latest"
}

variable "github_repository" {
  description = "GitHub repo allowed to deploy, as owner/name (e.g. uncutbiz/global-gold-payment). Empty to skip."
  type        = string
  default     = ""
}

variable "create_github_oidc_provider" {
  description = "Create the GitHub OIDC identity provider (only one can exist per AWS account)"
  type        = bool
  default     = true
}

variable "waf_rate_limit" {
  description = "Maximum requests per IP per 5 minutes before WAF blocks"
  type        = number
  default     = 2000
}

variable "alarm_email" {
  description = "Email for CloudWatch alarms (leave empty to skip)"
  type        = string
  default     = ""
}
