import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { one, pool } from '../db.js';
import {
  cancelPaymentIntent, capturePaymentIntent, confirmPaymentIntent, createPaymentIntent,
  createRefund, getPaymentIntent, listPaymentIntents,
} from '../payments/service.js';
import { createPayout, getBalance } from '../settlement/settlement.js';
import { ApiError, SUPPORTED_CURRENCIES } from '../util/common.js';
import { tokenize } from '../vault/vault.js';
import { idempotency, rateLimit, requireKey } from './middleware.js';
import { businessLogIn, businessLogOut, businessSignUp, keyPrefixes, payoutWallet, rollKeys, setPayoutDestination } from '../merchants/accounts.js';
import { COUNTRIES } from '../wallet/fx.js';

export const api = Router();

const cardRateLimit = rateLimit(Number(process.env.CARD_RATE_LIMIT ?? 30), 60_000);

const currency = z.string().toLowerCase().pipe(z.enum(SUPPORTED_CURRENCIES));
const minorUnits = z.number().int().positive().max(99_999_999);

// ---------------------------------------------------------------- hosted checkout
// Authenticated by the PaymentIntent's client_secret instead of an API key.
async function checkoutIntent(id: string, secret: unknown) {
  const row = await one(pool,
    `SELECT pi.id, pi.merchant_id, pi.amount, pi.currency, pi.status, pi.description, pi.client_secret, m.name AS merchant_name
       FROM payment_intents pi JOIN merchants m ON m.id = pi.merchant_id WHERE pi.id = $1`, [id]);
  const ok = row && typeof secret === 'string' && secret.length === row.client_secret.length &&
    crypto.timingSafeEqual(Buffer.from(secret), Buffer.from(row.client_secret));
  if (!ok) throw new ApiError(404, 'resource_missing', 'This checkout link is not valid.');
  return row;
}

api.get('/v1/checkout/:id', async (req, res) => {
  const r = await checkoutIntent(req.params.id as string, req.query.client_secret);
  res.json({ id: r.id, merchant: r.merchant_name, amount: r.amount, currency: r.currency, status: r.status, description: r.description });
});

api.post('/v1/checkout/:id/pay', cardRateLimit, async (req, res) => {
  const body = z.object({
    client_secret: z.string(),
    card: z.object({ number: z.string().min(12).max(23), exp_month: z.coerce.number().int(), exp_year: z.coerce.number().int(), cvc: z.string() }),
  }).parse(req.body);
  const r = await checkoutIntent(req.params.id as string, body.client_secret);
  const merchant = await one(pool, 'SELECT * FROM merchants WHERE id=$1', [r.merchant_id]);
  const t = await tokenize(pool, { merchantId: merchant.id }, body.card);
  const pi = await confirmPaymentIntent(merchant, r.id, t.id);
  res.json({ id: pi.id, status: pi.status, amount: pi.amount, currency: pi.currency, last_payment_error: pi.last_payment_error, payment_method: pi.payment_method });
});

// ---------------------------------------------------------------- merchant
// ---------------------------------------------------------------- business accounts
const businessAuthLimit = rateLimit(Number(process.env.AUTH_RATE_LIMIT ?? 20), 60_000);

api.post('/v1/business/signup', businessAuthLimit, async (req, res) => {
  const body = z.object({
    business_name: z.string().trim().min(2).max(120),
    name: z.string().trim().min(1).max(100),
    email: z.email(),
    password: z.string().min(10, 'Use at least 10 characters for your password.').max(200),
    country: z.string().length(2),
    business_type: z.enum(['individual', 'company', 'nonprofit']),
    website: z.url().optional(),
    description: z.string().max(500).optional(),
  }).parse(req.body);
  res.status(201).json(await businessSignUp(body));
});

api.post('/v1/business/login', businessAuthLimit, async (req, res) => {
  const body = z.object({ email: z.string(), password: z.string() }).parse(req.body);
  res.json(await businessLogIn(body.email, body.password));
});

api.post('/v1/business/logout', async (req, res) => {
  const t = req.header('authorization')?.slice(7) ?? '';
  if (t.startsWith('ggm_')) await businessLogOut(t);
  res.json({ ok: true });
});

api.get('/v1/account', requireKey('secret'), async (req, res) => {
  const m = req.merchant as any;
  res.json({
    object: 'account', ...m,
    country_name: COUNTRIES[m.country]?.name,
    api_keys: await keyPrefixes(m.id),
    payout_wallet: await payoutWallet(m.id),
  });
});

api.post('/v1/account', requireKey('secret'), async (req, res) => {
  const body = z.object({
    webhook_url: z.url().nullable().optional(),
    payout_method: z.enum(['bank', 'wallet']).optional(),
    payout_wallet_email: z.email().optional(),
  }).parse(req.body);
  const out: Record<string, unknown> = { object: 'account', id: req.merchant!.id };
  if (body.webhook_url !== undefined) {
    const m = await one(pool, 'UPDATE merchants SET webhook_url=$2 WHERE id=$1 RETURNING webhook_url', [req.merchant!.id, body.webhook_url]);
    out.webhook_url = m.webhook_url;
  }
  if (body.payout_method) Object.assign(out, await setPayoutDestination(req.merchant!.id, body.payout_method, body.payout_wallet_email));
  res.json(out);
});

// Revokes the current keys and returns new ones. The secret key is shown only here.
api.post('/v1/account/keys/roll', requireKey('secret'), async (req, res) => {
  res.status(201).json({ object: 'api_keys', ...(await rollKeys(req.merchant!.id)) });
});

// Tokenization: called from the browser with a publishable key.
api.post('/v1/tokens', cardRateLimit, requireKey('publishable', 'secret'), async (req, res) => {
  const body = z.object({
    card: z.object({
      number: z.string().min(12).max(23),
      exp_month: z.coerce.number().int(),
      exp_year: z.coerce.number().int(),
      cvc: z.string(),
    }),
  }).parse(req.body);
  const t = await tokenize(pool, { merchantId: req.merchant!.id }, body.card);
  res.status(201).json({ object: 'token', id: t.id, card: { brand: t.brand, last4: t.last4, exp_month: t.exp_month, exp_year: t.exp_year } });
});

const sk = requireKey('secret');

api.post('/v1/payment_intents', sk, idempotency, async (req, res) => {
  const body = z.object({
    amount: minorUnits.min(50, 'Amount must be at least 50 minor units.'),
    currency,
    capture_method: z.enum(['automatic', 'manual']).optional(),
    description: z.string().max(500).optional(),
    metadata: z.record(z.string(), z.string().max(500)).optional(),
    payment_token: z.string().optional(),
    confirm: z.boolean().optional(),
  }).parse(req.body);
  let pi = await createPaymentIntent(req.merchant!, body);
  if (body.confirm) {
    if (!body.payment_token) throw new ApiError(400, 'parameter_missing', 'payment_token is required when confirm is true.');
    pi = await confirmPaymentIntent(req.merchant!, pi.id, body.payment_token);
  }
  res.status(201).json(pi);
});

api.get('/v1/payment_intents', sk, async (req, res) => {
  const limit = z.coerce.number().int().min(1).max(100).default(25).parse(req.query.limit);
  res.json({ object: 'list', data: await listPaymentIntents(req.merchant!.id, limit) });
});

api.get('/v1/payment_intents/:id', requireKey('secret', 'publishable'), async (req, res) => {
  const pi = await getPaymentIntent(req.merchant!.id, req.params.id as string);
  if (req.keyKind === 'publishable') {
    // Publishable keys may read an intent only with its client secret, and see a reduced view.
    if (req.query.client_secret !== pi.client_secret) throw new ApiError(404, 'resource_missing', 'No such payment_intent.');
    const { id, amount, currency: cur, status, last_payment_error, payment_method, description } = pi;
    return res.json({ id, object: 'payment_intent', amount, currency: cur, status, last_payment_error, payment_method, description });
  }
  res.json(pi);
});

// Confirm: server-side with a secret key, or from the browser with publishable key + client_secret.
api.post('/v1/payment_intents/:id/confirm', requireKey('secret', 'publishable'), idempotency, async (req, res) => {
  const body = z.object({ payment_token: z.string(), client_secret: z.string().optional() }).parse(req.body);
  const id = req.params.id as string;
  if (req.keyKind === 'publishable') {
    const row = await one(pool, 'SELECT client_secret FROM payment_intents WHERE id=$1 AND merchant_id=$2', [id, req.merchant!.id]);
    const ok = row && body.client_secret &&
      row.client_secret.length === body.client_secret.length &&
      crypto.timingSafeEqual(Buffer.from(row.client_secret), Buffer.from(body.client_secret));
    if (!ok) throw new ApiError(404, 'resource_missing', 'No such payment_intent.');
  }
  const pi = await confirmPaymentIntent(req.merchant!, id, body.payment_token);
  if (req.keyKind === 'publishable') {
    return res.json({ id: pi.id, object: 'payment_intent', status: pi.status, amount: pi.amount, currency: pi.currency, last_payment_error: pi.last_payment_error, payment_method: pi.payment_method });
  }
  res.json(pi);
});

api.post('/v1/payment_intents/:id/capture', sk, idempotency, async (req, res) => {
  const body = z.object({ amount_to_capture: minorUnits.optional() }).parse(req.body ?? {});
  res.json(await capturePaymentIntent(req.merchant!, req.params.id as string, body.amount_to_capture));
});

api.post('/v1/payment_intents/:id/cancel', sk, idempotency, async (req, res) => {
  res.json(await cancelPaymentIntent(req.merchant!, req.params.id as string));
});

api.post('/v1/refunds', sk, idempotency, async (req, res) => {
  const body = z.object({ payment_intent: z.string(), amount: minorUnits.optional() }).parse(req.body);
  res.status(201).json(await createRefund(req.merchant!, body.payment_intent, body.amount));
});

api.get('/v1/balance', sk, async (req, res) => {
  res.json(await getBalance(req.merchant!.id));
});

api.post('/v1/payouts', sk, idempotency, async (req, res) => {
  const body = z.object({ currency, amount: minorUnits.optional() }).parse(req.body);
  res.status(201).json(await createPayout(req.merchant!, body.currency, body.amount));
});

api.get('/v1/payouts', sk, async (req, res) => {
  const r = await pool.query('SELECT * FROM payouts WHERE merchant_id=$1 ORDER BY created_at DESC LIMIT 50', [req.merchant!.id]);
  res.json({ object: 'list', data: r.rows });
});

api.get('/v1/events', sk, async (req, res) => {
  const limit = z.coerce.number().int().min(1).max(100).default(25).parse(req.query.limit);
  const r = await pool.query(
    'SELECT id, type, data, created_at FROM events WHERE merchant_id=$1 ORDER BY created_at DESC LIMIT $2',
    [req.merchant!.id, limit]);
  res.json({ object: 'list', data: r.rows });
});
