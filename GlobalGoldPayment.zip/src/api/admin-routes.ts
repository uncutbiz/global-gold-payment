import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { one, pool, tx } from '../db.js';
import { trialBalance } from '../ledger/ledger.js';
import { runSettlement } from '../settlement/settlement.js';
import { newId, sha256 } from '../util/common.js';
import { rateLimit } from './middleware.js';
import { ALL_ROLES, audit, createStaff, listStaff, requireStaff, setStaffDisabled, staffLogin, staffLogout } from '../admin/staff.js';
import {
  auditLog, decideKyc, kycDocument, kycQueue, listAlerts, listMerchants, listTransactions, listUsers,
  overview, resolveAlert, setMerchantStatus, setUserLocked, transactionDetail, userDetail,
} from '../admin/service.js';

export const adminApi = Router();

const anyStaff = requireStaff(...ALL_ROLES);
const compliance = requireStaff('compliance');
const investigators = requireStaff('compliance', 'support');
const ownerOnly = requireStaff();
const loginLimit = rateLimit(Number(process.env.AUTH_RATE_LIMIT ?? 20), 60_000);

// ------------------------------------------------------------------ session
adminApi.post('/v1/admin/login', loginLimit, async (req, res) => {
  const body = z.object({ email: z.string(), password: z.string() }).parse(req.body);
  res.json(await staffLogin(body.email, body.password));
});
adminApi.post('/v1/admin/logout', anyStaff, async (req, res) => {
  await staffLogout(req.header('authorization')!.slice(7));
  res.json({ ok: true });
});
adminApi.get('/v1/admin/me', anyStaff, (req, res) => res.json(req.staff));

// ------------------------------------------------------------------ staff (owner)
adminApi.get('/v1/admin/staff', ownerOnly, async (_req, res) => res.json({ object: 'list', data: await listStaff() }));
adminApi.post('/v1/admin/staff', ownerOnly, async (req, res) => {
  const body = z.object({
    email: z.email(), name: z.string().min(1).max(100),
    password: z.string().min(12, 'Staff passwords need at least 12 characters.'),
    role: z.enum(['owner', 'compliance', 'support', 'viewer']),
  }).parse(req.body);
  const s = await createStaff(body);
  await audit(pool, req.staff!, 'staff.create', 'admin_user', s.id, { email: s.email, role: s.role });
  res.status(201).json(s);
});
adminApi.post('/v1/admin/staff/:id/:action', ownerOnly, async (req, res) => {
  const action = z.enum(['disable', 'enable']).parse(req.params.action);
  const s = await setStaffDisabled(req.params.id as string, action === 'disable');
  await audit(pool, req.staff!, `staff.${action}`, 'admin_user', s.id);
  res.json(s);
});

// ------------------------------------------------------------------ monitoring
adminApi.get('/v1/admin/overview', anyStaff, async (_req, res) => res.json(await overview()));

adminApi.get('/v1/admin/transactions', anyStaff, async (req, res) => {
  const q = z.object({
    kind: z.string().optional(), status: z.string().optional(), q: z.string().max(100).optional(),
    currency: z.string().optional(), flagged: z.enum(['true', 'false']).optional(),
    user: z.string().optional(), merchant: z.string().optional(), before: z.string().optional(),
    limit: z.coerce.number().int().min(1).max(200).optional(),
  }).parse(req.query);
  res.json(await listTransactions({ ...q, flagged: q.flagged === 'true' }));
});
adminApi.get('/v1/admin/transactions/:id', anyStaff, async (req, res) => res.json(await transactionDetail(req.params.id as string)));

adminApi.get('/v1/admin/alerts', anyStaff, async (req, res) => {
  const q = z.object({ status: z.enum(['open', 'resolved', 'dismissed']).optional(), severity: z.enum(['low', 'medium', 'high']).optional() }).parse(req.query);
  res.json(await listAlerts(q));
});
adminApi.post('/v1/admin/alerts/:id/resolve', compliance, async (req, res) => {
  const body = z.object({ resolution: z.enum(['resolved', 'dismissed']), note: z.string().max(1000).optional() }).parse(req.body);
  res.json(await resolveAlert(req.staff!, req.params.id as string, body.resolution, body.note));
});

// ------------------------------------------------------------------ customers & KYC
adminApi.get('/v1/admin/users', investigators, async (req, res) => {
  const q = z.object({
    q: z.string().max(100).optional(), kyc: z.enum(['unverified', 'pending', 'approved', 'rejected']).optional(),
    status: z.enum(['active', 'locked']).optional(),
  }).parse(req.query);
  res.json(await listUsers(q));
});
adminApi.get('/v1/admin/users/:id', investigators, async (req, res) => res.json(await userDetail(req.params.id as string)));
adminApi.post('/v1/admin/users/:id/freeze', compliance, async (req, res) => {
  const body = z.object({ reason: z.string().min(3, 'Give a reason for freezing the account.').max(500) }).parse(req.body);
  res.json(await setUserLocked(req.staff!, req.params.id as string, true, body.reason));
});
adminApi.post('/v1/admin/users/:id/unfreeze', compliance, async (req, res) => {
  res.json(await setUserLocked(req.staff!, req.params.id as string, false));
});

adminApi.get('/v1/admin/kyc', investigators, async (req, res) => {
  const status = z.enum(['pending', 'approved', 'rejected']).default('pending').parse(req.query.status);
  res.json(await kycQueue(status));
});
adminApi.get('/v1/admin/kyc/:id/document', compliance, async (req, res) => {
  const doc = await kycDocument(req.params.id as string);
  await audit(pool, req.staff!, 'kyc.view_document', 'kyc_submission', req.params.id as string);
  res.setHeader('Content-Type', doc.document_mime);
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Disposition', 'inline');
  res.send(doc.document);
});
adminApi.post('/v1/admin/kyc/:id/:decision', compliance, async (req, res) => {
  const decision = z.enum(['approve', 'reject']).parse(req.params.decision);
  const body = z.object({ note: z.string().max(500).optional() }).parse(req.body ?? {});
  res.json(await decideKyc(req.staff!, req.params.id as string, decision, body.note));
});

// ------------------------------------------------------------------ merchants
adminApi.get('/v1/admin/merchants', investigators, async (_req, res) => res.json(await listMerchants()));

adminApi.post('/v1/admin/merchants', ownerOnly, async (req, res) => {
  const body = z.object({
    name: z.string().min(1).max(200),
    email: z.email(),
    fee_bps: z.number().int().min(0).max(2000).optional(),
    fee_fixed: z.number().int().min(0).max(1000).optional(),
    max_amount: z.number().int().positive().max(99_999_999).optional(),
    webhook_url: z.url().optional(),
    status: z.enum(['pending_review', 'active']).optional(),
  }).parse(req.body);

  const result = await tx(async (c) => {
    const id = newId('acct', 9);
    const m = await one(c,
      `INSERT INTO merchants (id, name, email, fee_bps, fee_fixed, max_amount, webhook_url, webhook_secret, status)
       VALUES ($1,$2,$3,COALESCE($4,290),COALESCE($5,30),COALESCE($6,1000000),$7,$8,$9) RETURNING *`,
      [id, body.name, body.email, body.fee_bps ?? null, body.fee_fixed ?? null, body.max_amount ?? null,
       body.webhook_url ?? null, 'whsec_' + crypto.randomBytes(24).toString('base64url'), body.status ?? 'active']);
    const keys: Record<string, string> = {};
    for (const kind of ['secret', 'publishable'] as const) {
      const raw = `${kind === 'secret' ? 'sk' : 'pk'}_test_${crypto.randomBytes(24).toString('base64url')}`;
      await c.query('INSERT INTO api_keys (id, merchant_id, kind, key_hash, prefix) VALUES ($1,$2,$3,$4,$5)',
        [newId('key'), id, kind, sha256(raw), raw.slice(0, 12)]);
      keys[kind] = raw;
    }
    await audit(c, req.staff!, 'merchant.create', 'merchant', id, { name: body.name });
    return { merchant: m, keys };
  });
  res.status(201).json({ ...result.merchant, object: 'merchant', api_keys: result.keys });
});

adminApi.post('/v1/admin/merchants/:id/status', compliance, async (req, res) => {
  const body = z.object({ status: z.enum(['pending_review', 'active', 'suspended']), reason: z.string().max(500).optional() }).parse(req.body);
  res.json(await setMerchantStatus(req.staff!, req.params.id as string, body.status, body.reason));
});

// ------------------------------------------------------------------ finance
adminApi.post('/v1/admin/settlements/run', ownerOnly, async (req, res) => {
  const data = await runSettlement();
  await audit(pool, req.staff!, 'settlement.run', 'clearing_batch', data.map((d) => d.id).join(',') || 'none', { batches: data.length });
  res.json({ object: 'list', data });
});
adminApi.get('/v1/admin/ledger/trial-balance', anyStaff, async (_req, res) => {
  const rows = await trialBalance(pool);
  res.json({ balanced: rows.every((r) => Number(r.debits) === Number(r.credits)), currencies: rows });
});
adminApi.get('/v1/admin/audit', ownerOnly, async (_req, res) => res.json(await auditLog()));
