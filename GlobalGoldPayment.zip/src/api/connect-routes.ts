/**
 * Connecting a merchant's processor account, and receiving processor webhooks.
 *
 * More than one processor can be enabled, so every URL carries the processor's
 * name. These are the values you paste into each provider's console:
 *
 *   Square   OAuth redirect  {PUBLIC_URL}/v1/connect/square/callback
 *            Webhook         {PUBLIC_URL}/v1/webhooks/square
 *   Stripe   OAuth redirect  {PUBLIC_URL}/v1/connect/stripe/callback
 *            Webhook         {PUBLIC_URL}/v1/webhooks/stripe
 *
 * GET /v1/connect/config prints them for every enabled provider, so nothing is
 * guessed or mistyped.
 */
import { Router, json, raw } from 'express';
import { z } from 'zod';
import { config } from '../config.js';
import { requireKey } from './middleware.js';
import { isEnabled, providerNamed, providers, providersForCountry } from '../providers/index.js';
import {
  completeConnect, connectionStatus, disconnect, recordProviderEvent,
  redirectUri, startConnect, webhookUrl,
} from '../merchants/connect.js';

export const connectApi = Router();

const sk = requireKey('secret');

/**
 * This router is mounted before the app's JSON parser, so that the webhook route
 * below still sees the raw bytes its signature covers. The consequence is that
 * req.body is empty here unless a route asks for it, so the routes that take one
 * parse it themselves.
 */
const body = json({ limit: '10kb' });

/** Exactly what to paste into each provider's console. */
connectApi.get('/v1/connect/config', (_req, res) => {
  res.json({
    object: 'connect_config',
    providers: providers.map((p) => ({
      provider: p.name,
      environment: p.name === 'square' ? config.square.env
        : p.name === 'stripe' ? (config.stripe.secretKey.startsWith('sk_live_') ? 'production' : 'test')
        : 'simulated',
      oauth_redirect_url: redirectUri(p.name),
      webhook_url: webhookUrl(p.name),
      merchant_countries: p.merchantCountries,
      tokenizes_in_browser: p.tokenizesInBrowser,
    })),
    platform_fee: { bps: config.platformFeeBps, fixed: config.platformFeeFixed },
  });
});

/** Which processors can serve a country, without needing an account first. */
connectApi.get('/v1/connect/providers', (req, res) => {
  const country = String(req.query.country ?? '').toUpperCase();
  const list = country ? providersForCountry(country) : providers;
  res.json({
    object: 'list',
    country: country || null,
    data: list.map((p) => ({ provider: p.name, merchant_countries: p.merchantCountries })),
  });
});

/** Has this business connected a processor account, and which ones can it use? */
connectApi.get('/v1/connect/status', sk, async (req, res) => {
  res.json(await connectionStatus(req.merchant!.id));
});

/**
 * Start the connection. Returns a URL to send the merchant to.
 * `?provider=stripe` picks one explicitly; otherwise the merchant keeps the
 * processor they already use, or gets the best one for their country.
 */
connectApi.post('/v1/connect/start', body, sk, async (req, res) => {
  const want = z.string().optional().parse(req.query.provider ?? (req.body as any)?.provider ?? undefined);
  const r = await startConnect(req.merchant!.id, want);
  res.json({ object: 'connect_link', url: r.url, provider: r.provider, expires_in_minutes: 15 });
});

connectApi.post('/v1/connect/disconnect', body, sk, async (req, res) => {
  res.json(await disconnect(req.merchant!.id));
});

/**
 * Where a provider sends the merchant back. This is a browser redirect, not an
 * API call, so it answers with a small page rather than JSON.
 */
connectApi.get('/v1/connect/:provider/callback', async (req, res) => {
  const page = (title: string, body: string, ok: boolean) => res.status(ok ? 200 : 400).type('html').send(
    `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
     <title>${title}</title>
     <link rel="stylesheet" href="/static/theme.css">
     <div style="max-width:32rem;margin:12vh auto;padding:0 20px;text-align:center">
       <a class="logo" href="/">Global <span>Gold</span></a>
       <h1 style="font-size:1.6rem;margin:22px 0 10px">${title}</h1>
       <p class="muted">${body}</p>
       <p style="margin-top:22px"><a class="btn primary" href="/dashboard">Back to my dashboard</a></p>
     </div>`);

  const name = String(req.params.provider);
  if (!isEnabled(name)) return page('Unknown processor', 'That connection link is not for this platform.', false);
  const label = name.charAt(0).toUpperCase() + name.slice(1);

  // The merchant declined on the provider's screen.
  if (typeof req.query.error === 'string') {
    return page('Connection cancelled',
      'Nothing was changed. You can start again from your dashboard whenever you are ready.', false);
  }

  const parsed = z.object({ code: z.string().min(4), state: z.string().min(4) }).safeParse(req.query);
  if (!parsed.success) return page('Something is missing', 'That link is incomplete. Start again from your dashboard.', false);

  try {
    const r = await completeConnect(name, parsed.data.state, parsed.data.code);
    return page(`${label} connected`,
      `${r.business_name ?? 'Your account'} is linked. You can take payments now, and our fee is shown on every one.`, true);
  } catch (e: any) {
    return page('Could not connect', e?.message ?? 'The processor refused the connection.', false);
  }
});

/**
 * Provider webhooks.
 *
 * The signature covers the raw bytes, so this route parses the body itself
 * rather than reusing the JSON parser — a re-serialised body would not match.
 * An unverified notification is discarded without being looked at.
 */
connectApi.post('/v1/webhooks/:provider',
  raw({ type: '*/*', limit: '1mb' }),
  async (req, res) => {
    const name = String(req.params.provider);
    if (!isEnabled(name)) return res.status(404).json({ received: false });

    const provider = providerNamed(name);
    if (!provider.verifyWebhook) return res.status(404).json({ received: false });

    const rawBody = Buffer.isBuffer(req.body) ? req.body.toString('utf8') : String(req.body ?? '');
    const headers: Record<string, string | undefined> = {};
    for (const [k, v] of Object.entries(req.headers)) headers[k.toLowerCase()] = Array.isArray(v) ? v[0] : v;

    if (!provider.verifyWebhook(rawBody, headers, webhookUrl(name))) {
      // Never say more than this: a detailed error helps an attacker tune a forgery.
      return res.status(401).json({ received: false });
    }

    let body: any;
    try { body = JSON.parse(rawBody); } catch { return res.status(400).json({ received: false }); }

    // Square calls it event_id; Stripe calls it id. The connected account is
    // merchant_id on Square and the top-level `account` on a Stripe Connect event.
    const eventId = String(body?.event_id ?? body?.id ?? '');
    const type = String(body?.type ?? 'unknown');
    const accountId = body?.merchant_id ?? body?.account ?? null;
    if (!eventId) return res.status(400).json({ received: false });

    const isNew = await recordProviderEvent({ provider: name, eventId, type, accountId, payload: body });

    // Always 200 once verified: a non-2xx makes the provider retry, and we have
    // already stored it. Duplicates are answered the same way.
    res.json({ received: true, duplicate: !isNew });
  });
