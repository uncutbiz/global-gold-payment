import type { NextFunction, Request, Response } from 'express';
import crypto from 'node:crypto';
import { ZodError } from 'zod';
import { one, pool } from '../db.js';
import type { Merchant } from '../payments/service.js';
import { ApiError, sha256 } from '../util/common.js';
import { merchantForSession } from '../merchants/accounts.js';

declare global {
  namespace Express {
    interface Request { merchant?: Merchant; keyKind?: 'secret' | 'publishable' }
  }
}

function bearer(req: Request): string | undefined {
  const h = req.header('authorization');
  return h?.startsWith('Bearer ') ? h.slice(7).trim() : undefined;
}

export function requireKey(...kinds: ('secret' | 'publishable')[]) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    const key = bearer(req);
    if (!key) throw new ApiError(401, 'unauthorized', 'Provide your API key as "Authorization: Bearer <key>".');
    if (key.startsWith('ggm_')) {
      // Dashboard session: acts with the business's secret-key permissions.
      const m = await merchantForSession(key);
      if (!m) throw new ApiError(401, 'session_expired', 'Your session has expired. Sign in again.');
      if (!kinds.includes('secret')) throw new ApiError(403, 'wrong_key_type', 'This endpoint needs a publishable key.');
      const { session_user_id, session_user_name, session_user_email, ...merchant } = m;
      req.merchant = merchant;
      req.keyKind = 'secret';
      return next();
    }
    const row = await one(pool,
      `SELECT m.*, k.kind FROM api_keys k JOIN merchants m ON m.id = k.merchant_id
        WHERE k.key_hash = $1 AND k.revoked_at IS NULL`, [sha256(key)]);
    if (!row) throw new ApiError(401, 'invalid_api_key', 'The API key is not valid.');
    if (!kinds.includes(row.kind)) {
      throw new ApiError(403, 'wrong_key_type', `This endpoint needs a ${kinds.join(' or ')} key.`);
    }
    const { kind, ...merchant } = row;
    req.merchant = merchant;
    req.keyKind = kind;
    next();
  };
}

/**
 * Idempotency-Key support for POSTs: the first response for a key is stored and
 * replayed for retries; reusing a key with a different body returns 422.
 */
export async function idempotency(req: Request, res: Response, next: NextFunction) {
  const key = req.header('idempotency-key');
  if (req.method !== 'POST' || !key || !req.merchant) return next();
  if (key.length > 255) throw new ApiError(400, 'idempotency_key_invalid', 'Idempotency-Key must be 255 characters or fewer.');
  const hash = sha256(req.method + req.originalUrl + JSON.stringify(req.body ?? {}));

  const inserted = await pool.query(
    `INSERT INTO idempotency_keys (merchant_id, key, request_hash) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
    [req.merchant.id, key, hash]);
  if (!inserted.rowCount) {
    const prev = await one(pool, 'SELECT * FROM idempotency_keys WHERE merchant_id=$1 AND key=$2', [req.merchant.id, key]);
    if (prev.request_hash !== hash) throw new ApiError(422, 'idempotency_key_reused', 'This Idempotency-Key was used with different request parameters.');
    if (prev.response_status == null) throw new ApiError(409, 'idempotency_in_progress', 'A request with this Idempotency-Key is still in progress.');
    res.setHeader('Idempotent-Replayed', 'true');
    return res.status(prev.response_status).json(prev.response_body);
  }

  const merchantId = req.merchant.id;
  const origJson = res.json.bind(res);
  res.json = (body: any) => {
    // Server errors are not cached so the client can retry safely.
    const q = res.statusCode >= 500
      ? pool.query('DELETE FROM idempotency_keys WHERE merchant_id=$1 AND key=$2', [merchantId, key])
      : pool.query('UPDATE idempotency_keys SET response_status=$3, response_body=$4 WHERE merchant_id=$1 AND key=$2',
          [merchantId, key, res.statusCode, JSON.stringify(body)]);
    q.catch((e) => console.error('idempotency store failed', e)).finally(() => origJson(body));
    return res;
  };
  next();
}

/**
 * Fixed-window per-IP rate limit (in memory, single instance). Public card
 * endpoints are the main target of card-testing attacks; use Redis in production.
 */
export function rateLimit(max: number, windowMs: number) {
  const hits = new Map<string, { n: number; reset: number }>();
  return (req: Request, res: Response, next: NextFunction) => {
    const now = Date.now();
    const k = req.ip ?? 'unknown';
    let h = hits.get(k);
    if (!h || h.reset < now) { h = { n: 0, reset: now + windowMs }; hits.set(k, h); }
    if (hits.size > 50_000) hits.clear();
    if (++h.n > max) {
      res.setHeader('Retry-After', Math.ceil((h.reset - now) / 1000));
      throw new ApiError(429, 'rate_limited', 'Too many requests. Try again shortly.');
    }
    next();
  };
}

export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ApiError) {
    return res.status(err.status).json({ error: { type: err.status === 402 ? 'card_error' : 'invalid_request_error', code: err.code, message: err.message, ...err.extra } });
  }
  if (err instanceof ZodError) {
    const i = err.issues[0];
    const param = i.path.join('.');
    const field = param ? param.replace(/_/g, ' ').replace(/\./g, ' → ') : 'request';
    const detail = i.code === 'invalid_type' && /undefined/.test(i.message) ? 'is required' : i.message.replace(/^Invalid input: /, '').toLowerCase();
    return res.status(400).json({ error: { type: 'invalid_request_error', code: 'parameter_invalid', param, message: /\.$/.test(i.message) ? i.message : `Check the ${field}: ${detail}.` } });
  }
  if (err?.type === 'entity.parse.failed') {
    return res.status(400).json({ error: { type: 'invalid_request_error', code: 'invalid_json', message: 'Request body is not valid JSON.' } });
  }
  console.error(err);
  res.status(500).json({ error: { type: 'api_error', code: 'internal_error', message: 'Something went wrong on our side. It is safe to retry with the same Idempotency-Key.' } });
}
