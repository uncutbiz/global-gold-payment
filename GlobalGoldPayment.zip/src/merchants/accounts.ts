/**
 * Self-serve business accounts (the Stripe/PayPal Business side).
 *
 *   sign up ──▶ pending_review ──(staff approve in admin panel)──▶ active ──▶ take payments
 *
 * People sign in to the dashboard with email + password. The dashboard session
 * token (ggm_…) works like a secret key for that business, so the dashboard uses
 * the same API as merchants' own servers.
 */
import crypto from 'node:crypto';
import { one, pool, tx } from '../db.js';
import { ApiError, newId, sha256 } from '../util/common.js';
import { checkPassword, dummyHash, hashPassword } from '../util/passwords.js';
import { COUNTRIES } from '../wallet/fx.js';
import { raiseAlert } from '../admin/monitoring.js';
import type { PoolClient } from 'pg';

const SESSION_HOURS = 12;

async function issueKeys(c: PoolClient, merchantId: string) {
  await c.query('UPDATE api_keys SET revoked_at = now() WHERE merchant_id = $1 AND revoked_at IS NULL', [merchantId]);
  const keys: Record<'secret' | 'publishable', string> = { secret: '', publishable: '' };
  for (const kind of ['secret', 'publishable'] as const) {
    const raw = `${kind === 'secret' ? 'sk' : 'pk'}_test_${crypto.randomBytes(24).toString('base64url')}`;
    await c.query('INSERT INTO api_keys (id, merchant_id, kind, key_hash, prefix) VALUES ($1,$2,$3,$4,$5)',
      [newId('key'), merchantId, kind, sha256(raw), raw.slice(0, 12)]);
    keys[kind] = raw;
  }
  return keys;
}

async function newSession(userId: string) {
  const token = 'ggm_' + crypto.randomBytes(32).toString('base64url');
  await pool.query(
    `INSERT INTO merchant_sessions (token_hash, merchant_user_id, expires_at) VALUES ($1,$2, now() + make_interval(hours => $3))`,
    [sha256(token), userId, SESSION_HOURS]);
  return token;
}

export async function businessSignUp(input: {
  business_name: string; name: string; email: string; password: string; country: string;
  website?: string; business_type: string; description?: string;
}) {
  const country = input.country.toUpperCase();
  if (!COUNTRIES[country]) throw new ApiError(400, 'country_not_supported', 'Global Gold is not available for businesses in this country yet.');
  const email = input.email.trim().toLowerCase();
  const hash = await hashPassword(input.password);
  const { user, merchantId } = await tx(async (c) => {
    const exists = await one(c, 'SELECT 1 FROM merchant_users WHERE email = $1', [email]);
    if (exists) throw new ApiError(409, 'email_taken', 'A business account with this email already exists. Sign in instead.');
    const merchantId = newId('acct', 9);
    await c.query(
      `INSERT INTO merchants (id, name, email, status, webhook_secret, country, website, business_type, description)
       VALUES ($1,$2,$3,'pending_review',$4,$5,$6,$7,$8)`,
      [merchantId, input.business_name.trim(), email, 'whsec_' + crypto.randomBytes(24).toString('base64url'),
       country, input.website ?? null, input.business_type, input.description ?? null]);
    const user = await one(c,
      `INSERT INTO merchant_users (id, merchant_id, email, name, password_hash) VALUES ($1,$2,$3,$4,$5) RETURNING id, email, name`,
      [newId('mu'), merchantId, email, input.name.trim(), hash]);
    await issueKeys(c, merchantId);
    await raiseAlert(c, { severity: 'low', rule: 'business_review', message: `New business “${input.business_name.trim()}” is waiting for approval`,
      subjectType: 'merchant', subjectId: merchantId, merchantId });
    return { user, merchantId };
  });
  return { token: await newSession(user.id), user, merchant_id: merchantId };
}

export async function businessLogIn(emailRaw: string, password: string) {
  const u = await one(pool, 'SELECT * FROM merchant_users WHERE email = $1', [emailRaw.trim().toLowerCase()]);
  const ok = await checkPassword(password, u?.password_hash ?? await dummyHash());
  if (!u || !ok) throw new ApiError(401, 'invalid_login', 'Email or password is incorrect.');
  return { token: await newSession(u.id), user: { id: u.id, email: u.email, name: u.name }, merchant_id: u.merchant_id };
}

export async function businessLogOut(token: string) {
  await pool.query('DELETE FROM merchant_sessions WHERE token_hash = $1', [sha256(token)]);
}

/** Resolves a dashboard session to its merchant (used by requireKey). */
export async function merchantForSession(token: string) {
  return one(pool,
    `SELECT m.*, u.id AS session_user_id, u.name AS session_user_name, u.email AS session_user_email
       FROM merchant_sessions s JOIN merchant_users u ON u.id = s.merchant_user_id JOIN merchants m ON m.id = u.merchant_id
      WHERE s.token_hash = $1 AND s.expires_at > now()`, [sha256(token)]);
}

export async function rollKeys(merchantId: string) {
  return tx((c) => issueKeys(c, merchantId));
}

export async function keyPrefixes(merchantId: string) {
  const r = await pool.query(`SELECT kind, prefix, created_at FROM api_keys WHERE merchant_id = $1 AND revoked_at IS NULL`, [merchantId]);
  return r.rows;
}

export async function setPayoutDestination(merchantId: string, method: 'bank' | 'wallet', walletEmail?: string) {
  let walletUserId: string | null = null;
  let walletName: string | null = null;
  if (method === 'wallet') {
    if (!walletEmail) throw new ApiError(400, 'parameter_missing', 'Enter the email of the Global Gold wallet that should receive payouts.');
    const u = await one(pool, `SELECT id, name, status, kyc_status FROM users WHERE email = $1`, [walletEmail.trim().toLowerCase()]);
    if (!u || u.status !== 'active') throw new ApiError(404, 'wallet_not_found', 'No active Global Gold wallet uses this email.');
    if (u.kyc_status !== 'approved') throw new ApiError(400, 'wallet_not_verified', 'Payouts can only go to a wallet with a verified identity.');
    walletUserId = u.id; walletName = u.name;
  }
  await pool.query('UPDATE merchants SET payout_method = $2, payout_wallet_user_id = $3 WHERE id = $1', [merchantId, method, walletUserId]);
  return { payout_method: method, payout_wallet: walletName ? { name: walletName, email: walletEmail!.trim().toLowerCase() } : null };
}

export async function payoutWallet(merchantId: string) {
  return one(pool,
    `SELECT u.name, u.email FROM merchants m JOIN users u ON u.id = m.payout_wallet_user_id WHERE m.id = $1`, [merchantId]);
}
