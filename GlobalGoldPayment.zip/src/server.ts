import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config, isProduction } from './config.js';
import { pool } from './db.js';
import { migrate } from './migrate.js';
import { api } from './api/routes.js';
import { walletApi } from './api/wallet-routes.js';
import { adminApi } from './api/admin-routes.js';
import { connectApi } from './api/connect-routes.js';
import { errorHandler } from './api/middleware.js';
import { startWebhookWorker } from './webhooks/webhooks.js';

const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);
  if (process.env.LOG_REQUESTS !== 'off') app.use((req, res, next) => {
    const start = process.hrtime.bigint();
    res.on('finish', () => {
      if (req.path === '/health' || req.path.startsWith('/static/')) return;
      // Never log bodies or query strings: they can contain card numbers or client secrets.
      console.log(JSON.stringify({ level: 'info', msg: 'request', method: req.method, path: req.path, status: res.statusCode,
        ms: Math.round(Number(process.hrtime.bigint() - start) / 1e4) / 100, ip: req.ip }));
    });
    next();
  });
  // Provider webhooks verify a signature over the raw bytes, so this router is
  // mounted before any body parser can consume and re-serialise them.
  app.use(connectApi);

  // ID documents are uploaded as base64 JSON; every other route keeps a small body limit.
  app.use('/v1/wallet/kyc', express.json({ limit: '8mb' }));
  app.use(express.json({ limit: '100kb' }));
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    if (isProduction) res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    next();
  });
  app.get('/health', async (_req, res) => {
    try {
      await pool.query('SELECT 1');
      res.json({ ok: true });
    } catch {
      res.status(503).json({ ok: false });
    }
  });
  app.use(adminApi);
  app.use(walletApi);
  app.use(api);
  app.get('/checkout/:id', (_req, res) => res.sendFile(path.join(publicDir, 'checkout.html')));
  app.get(['/favicon.ico', '/favicon.svg'], (_req, res) => {
    res.type('image/svg+xml').setHeader('Cache-Control', 'public, max-age=86400');
    res.sendFile(path.join(publicDir, 'favicon.svg'));
  });
  app.get('/', (_req, res) => res.sendFile(path.join(publicDir, 'index.html')));
  app.get('/admin', (_req, res) => res.sendFile(path.join(publicDir, 'admin.html')));
  app.get('/wallet', (_req, res) => res.sendFile(path.join(publicDir, 'wallet.html')));
  app.get('/dashboard', (_req, res) => res.sendFile(path.join(publicDir, 'dashboard.html')));
  app.use('/static', express.static(publicDir));
  app.use((_req, res) => res.status(404).json({ error: { type: 'invalid_request_error', code: 'not_found', message: 'Unknown endpoint.' } }));
  app.use(errorHandler);
  return app;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  await migrate();
  const app = createApp();
  const server = app.listen(config.port, () => {
    console.log(`Global Gold Payment listening on ${config.publicUrl}`);
    console.log(`  home:               ${config.publicUrl}/`);
    console.log(`  business dashboard: ${config.publicUrl}/dashboard`);
    console.log(`  customer wallet:    ${config.publicUrl}/wallet`);
    console.log(`  admin panel:        ${config.publicUrl}/admin`);
  });
  const stopWorker = config.webhookWorker ? startWebhookWorker() : () => {};

  // Graceful shutdown: containers get SIGTERM before being stopped.
  let closing = false;
  const shutdown = (signal: string) => {
    if (closing) return;
    closing = true;
    console.log(JSON.stringify({ level: 'info', msg: `received ${signal}, shutting down` }));
    stopWorker();
    server.close(() => pool.end().finally(() => process.exit(0)));
    setTimeout(() => process.exit(1), 25_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}
