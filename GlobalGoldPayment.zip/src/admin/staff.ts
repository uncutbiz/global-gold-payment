/**
 * Staff accounts for the admin panel, with roles and an audit trail.
 *
 *   owner       everything, including staff management, merchant approval and settlement
 *   compliance  KYC decisions, alerts, freezing accounts, merchant status
 *   support     read customers and transactions
 *   viewer      read-only dashboards
 *
 * The ADMIN_TOKEN env var acts as a bootstrap owner (to create the first staff
 * account). Production: remove it after setup, and require SSO + hardware-key MFA
 * and IP allow-listing for staff.
 */
import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { config } from '../config.js';
import { Db, one, pool } from '../db.js';
import { ApiError, newId, sha256 } from '../util/common.js';
import { checkPassword, dummyHash, hashPassword } from '../util/passwords.js';

export type Role = 'owner' | 'compliance' | 'support' | 'viewer';
export interface Staff { id: string | null; email: string; name: string; role: Role }

declare global {
  namespace Express { interface Request { staff?: Staff } }
}

const SESSION_HOURS = 8;

export async function createStaff(input: { email: string; name: string; password: string; role: Role }) {
  const row = await one(pool,
    `INSERT INTO admin_users (id, email, name, password_hash, role) VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (email) DO NOTHING RETURNING id, email, name, role, created_at`,
    [newId('adm'), input.email.trim().toLowerCase(), input.name.trim(), await hashPassword(input.password), input.role]);
  if (!row) throw new ApiError(409, 'email_taken', 'A staff account with this email already exists.');
  return row;
}

export async function listStaff() {
  const r = await pool.query('SELECT id, email, name, role, disabled_at, created_at FROM admin_users ORDER BY created_at');
  return r.rows;
}

export async function setStaffDisabled(id: string, disabled: boolean) {
  const row = await one(pool, 'UPDATE admin_users SET disabled_at = $2 WHERE id = $1 RETURNING id, email, role, disabled_at', [id, disabled ? new Date() : null]);
  if (!row) throw new ApiError(404, 'resource_missing', 'Staff account not found.');
  if (disabled) await pool.query('DELETE FROM admin_sessions WHERE admin_id = $1', [id]);
  return row;
}

export async function staffLogin(email: string, password: string) {
  const u = await one(pool, 'SELECT * FROM admin_users WHERE email = $1', [email.trim().toLowerCase()]);
  const ok = await checkPassword(password, u?.password_hash ?? await dummyHash());
  if (!u || !ok || u.disabled_at) throw new ApiError(401, 'invalid_login', 'Email or password is incorrect.');
  const token = 'gga_' + crypto.randomBytes(32).toString('base64url');
  await pool.query(
    `INSERT INTO admin_sessions (token_hash, admin_id, expires_at) VALUES ($1,$2, now() + make_interval(hours => $3))`,
    [sha256(token), u.id, SESSION_HOURS]);
  return { token, staff: { id: u.id, email: u.email, name: u.name, role: u.role } };
}

export async function staffLogout(token: string) {
  await pool.query('DELETE FROM admin_sessions WHERE token_hash = $1', [sha256(token)]);
}

function isBootstrapToken(t: string) {
  const a = Buffer.from(sha256(t)), b = Buffer.from(sha256(config.adminToken));
  return crypto.timingSafeEqual(a, b);
}

/** Allows the listed roles. Owners are always allowed. */
export function requireStaff(...roles: Role[]) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    const h = req.header('authorization') ?? '';
    const token = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
    let staff: Staff | undefined;
    if (token.startsWith('gga_')) {
      staff = await one<Staff>(pool,
        `SELECT a.id, a.email, a.name, a.role FROM admin_sessions s JOIN admin_users a ON a.id = s.admin_id
          WHERE s.token_hash = $1 AND s.expires_at > now() AND a.disabled_at IS NULL`, [sha256(token)]);
      if (!staff) throw new ApiError(401, 'session_expired', 'Your admin session has expired. Sign in again.');
    } else if (token && isBootstrapToken(token)) {
      staff = { id: null, email: 'bootstrap', name: 'Bootstrap token', role: 'owner' };
    }
    if (!staff) throw new ApiError(401, 'unauthorized', 'Sign in to the admin panel.');
    if (staff.role !== 'owner' && !roles.includes(staff.role)) {
      throw new ApiError(403, 'forbidden', `Your role (${staff.role}) cannot do this.`);
    }
    req.staff = staff;
    next();
  };
}

export const ALL_ROLES: Role[] = ['owner', 'compliance', 'support', 'viewer'];

export async function audit(db: Db, staff: Staff, action: string, targetType: string, targetId: string, details: Record<string, unknown> = {}) {
  await db.query(
    `INSERT INTO audit_log (admin_id, admin_label, action, target_type, target_id, details) VALUES ($1,$2,$3,$4,$5,$6)`,
    [staff.id, `${staff.name} (${staff.email})`, action, targetType, targetId, JSON.stringify(details)]);
}
