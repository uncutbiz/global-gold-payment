import 'dotenv/config';

function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var ${name} (see .env.example)`);
  return v;
}

/**
 * DATABASE_URL, or the pieces separately (how ECS injects RDS credentials from
 * Secrets Manager): DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD.
 */
function databaseUrl(): string {
  if (process.env.DATABASE_URL) return process.env.DATABASE_URL;
  const { DB_HOST, DB_PORT = '5432', DB_NAME = 'globalgold', DB_USER, DB_PASSWORD } = process.env;
  if (DB_HOST && DB_USER && DB_PASSWORD) {
    return `postgres://${encodeURIComponent(DB_USER)}:${encodeURIComponent(DB_PASSWORD)}@${DB_HOST}:${DB_PORT}/${DB_NAME}`;
  }
  return required('DATABASE_URL');
}

export const isProduction = process.env.NODE_ENV === 'production';

export const config = {
  port: Number(process.env.PORT ?? 4000),
  databaseUrl: databaseUrl(),
  // off | require (TLS + verify the certificate; needs DATABASE_CA_FILE on RDS) | no-verify (TLS only)
  databaseSsl: process.env.DATABASE_SSL ?? (isProduction ? 'require' : 'off'),
  databaseCaFile: process.env.DATABASE_CA_FILE,
  // Number of reverse proxies in front of the app (e.g. 1 for an AWS load balancer), for correct client IPs.
  trustProxy: Number(process.env.TRUST_PROXY ?? (isProduction ? 1 : 0)),
  publicUrl: process.env.PUBLIC_URL ?? `http://localhost:${process.env.PORT ?? 4000}`,
  adminToken: required('ADMIN_TOKEN'),
  // 32-byte keys, base64. In production these come from an HSM / cloud KMS, never env vars.
  vaultKeyId: process.env.VAULT_KEY_ID ?? 'k1',
  vaultKey: Buffer.from(required('VAULT_KEY'), 'base64'),
  fingerprintKey: Buffer.from(required('FINGERPRINT_KEY'), 'base64'),
  // Acquirer identifiers sent in ISO 8583 fields 41/42.
  terminalId: process.env.TERMINAL_ID ?? 'GGPAY001',
  acceptorId: process.env.ACCEPTOR_ID ?? 'GLOBALGOLD00001',
  webhookWorker: process.env.WEBHOOK_WORKER !== 'off',

  // ---------------------------------------------------------------- platform
  // Which processors do the regulated work underneath us. Several can be on at
  // once; each merchant is routed to one that serves their country.
  //   simulated — the built-in ISO 8583 test network (development and tests)
  //   square    — Square Payments API with app_fee_money
  //   stripe    — Stripe Connect direct charges with application_fee_amount
  // PAYMENT_PROVIDERS=square,stripe   (PAYMENT_PROVIDER is still accepted)
  paymentProviders: ((process.env.PAYMENT_PROVIDERS ?? process.env.PAYMENT_PROVIDER ?? 'simulated')
    .split(',').map((s) => s.trim()).filter(Boolean)) as Array<'simulated' | 'square' | 'stripe'>,
  // Our cut of each payment, in basis points. 50 bps = 0.5%.
  platformFeeBps: Number(process.env.PLATFORM_FEE_BPS ?? 50),
  // A fixed amount on top, in minor units. 0 by default.
  platformFeeFixed: Number(process.env.PLATFORM_FEE_FIXED ?? 0),

  // How much of the customer wallet is switched on.
  //
  //   off           — no stored value at all. Customers pay by card at checkout.
  //                   This is the only setting that needs no money-transmitter
  //                   licence, and the only one Square's terms clearly allow.
  //   platform_only — customers may hold a balance and spend it with merchants
  //                   on this platform, but cannot send it to another person.
  //                   Multi-merchant stored value; get legal advice first.
  //   full          — balances plus person-to-person and international transfers.
  //                   This is money transmission: it needs licensing, or a
  //                   licensed partner acting as principal with you as agent.
  //                   Square and Stripe both prohibit P2P on their own rails.
  //
  // Defaults to `full` on the simulated provider (development and tests) and
  // `off` on a real provider, so nothing regulated can be switched on by accident.
  walletMode: (process.env.WALLET_MODE
    ?? ((process.env.PAYMENT_PROVIDERS ?? process.env.PAYMENT_PROVIDER ?? 'simulated') === 'simulated' ? 'full' : 'off')
  ) as 'off' | 'platform_only' | 'full',

  square: {
    env: (process.env.SQUARE_ENV ?? 'sandbox') as 'sandbox' | 'production',
    appId: process.env.SQUARE_APP_ID ?? '',
    appSecret: process.env.SQUARE_APP_SECRET ?? '',
    webhookSignatureKey: process.env.SQUARE_WEBHOOK_SIGNATURE_KEY,
    platformAccessToken: process.env.SQUARE_ACCESS_TOKEN,
  },

  stripe: {
    secretKey: process.env.STRIPE_SECRET_KEY ?? '',
    clientId: process.env.STRIPE_CLIENT_ID ?? '',
    webhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
  },
};

/** The first enabled provider — what a single-provider deployment means. */
export const primaryProvider = config.paymentProviders[0] ?? 'simulated';

if (isProduction && config.adminToken.length < 32) throw new Error('ADMIN_TOKEN must be at least 32 characters in production');
if (config.vaultKey.length !== 32) throw new Error('VAULT_KEY must be 32 bytes, base64-encoded');
if (config.fingerprintKey.length !== 32) throw new Error('FINGERPRINT_KEY must be 32 bytes, base64-encoded');
if (!Number.isFinite(config.platformFeeBps) || config.platformFeeBps < 0 || config.platformFeeBps > 10_000) {
  throw new Error('PLATFORM_FEE_BPS must be between 0 and 10000 (10000 = 100%)');
}
if (!config.paymentProviders.length) throw new Error('PAYMENT_PROVIDERS must name at least one processor.');
for (const p of config.paymentProviders) {
  if (!['simulated', 'square', 'stripe'].includes(p)) {
    throw new Error(`Unknown payment provider "${p}". Use simulated, square or stripe.`);
  }
}
if (config.paymentProviders.includes('square') && (!config.square.appId || !config.square.appSecret)) {
  throw new Error('Square is enabled but SQUARE_APP_ID / SQUARE_APP_SECRET are missing. See src/providers/square.ts.');
}
if (config.paymentProviders.includes('stripe') && (!config.stripe.secretKey || !config.stripe.clientId)) {
  throw new Error('Stripe is enabled but STRIPE_SECRET_KEY / STRIPE_CLIENT_ID are missing. See src/providers/stripe.ts.');
}
if (isProduction && config.paymentProviders.includes('square') && config.square.env !== 'production') {
  throw new Error('NODE_ENV=production with SQUARE_ENV=sandbox would take fake payments. Set SQUARE_ENV=production.');
}
if (isProduction && config.paymentProviders.includes('stripe') && !config.stripe.secretKey.startsWith('sk_live_')) {
  throw new Error('NODE_ENV=production with a Stripe test key would take fake payments. Use your sk_live_ key.');
}
if (!['off', 'platform_only', 'full'].includes(config.walletMode)) {
  throw new Error(`WALLET_MODE must be off, platform_only or full (got ${config.walletMode})`);
}
if (isProduction && config.walletMode === 'full') {
  // Holding balances and moving money between people is money transmission.
  // Set WALLET_MONEY_TRANSMITTER_LICENSED=yes once you hold the licences, or are
  // an appointed agent of a licensed principal, to acknowledge this deliberately.
  if (process.env.WALLET_MONEY_TRANSMITTER_LICENSED !== 'yes') {
    throw new Error(
      'WALLET_MODE=full in production means person-to-person money transmission, which requires ' +
      'money-transmitter licensing (or acting as an agent of a licensed principal) and is prohibited ' +
      'on Square and Stripe. Set WALLET_MODE=off, or set WALLET_MONEY_TRANSMITTER_LICENSED=yes if you ' +
      'genuinely hold that permission.');
  }
}
