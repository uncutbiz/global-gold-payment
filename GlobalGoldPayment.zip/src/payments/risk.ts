/**
 * Rule-based pre-authorization risk checks. Production systems add ML scoring,
 * device fingerprinting, 3-D Secure step-up, and BIN/IP/country mismatch rules.
 */
import { Db } from '../db.js';
import type { CardToken } from '../vault/vault.js';

export interface RiskDecision { score: number; action: 'allow' | 'block'; reasons: string[] }

export async function assessRisk(
  db: Db, p: { amount: number; maxAmount: number; card: CardToken },
): Promise<RiskDecision> {
  const reasons: string[] = [];
  let score = 5;

  if (p.amount > p.maxAmount) { score += 80; reasons.push('amount_over_merchant_limit'); }
  if (p.amount >= 500_00) { score += 10; reasons.push('high_amount'); }
  if (p.card.brand === 'unknown') { score += 15; reasons.push('unknown_brand'); }

  // Velocity: attempts with the same card across ALL merchants in the last hour.
  const v = await db.query(
    `SELECT COUNT(*)::int AS n,
            COUNT(*) FILTER (WHERE outcome IN ('declined','blocked'))::int AS failed
       FROM payment_attempts
      WHERE fingerprint = $1 AND created_at > now() - interval '1 hour'`,
    [p.card.fingerprint]);
  const { n, failed } = v.rows[0];
  if (n >= 10) { score += 80; reasons.push('card_velocity'); }
  if (failed >= 3) { score += 80; reasons.push('repeated_declines'); }

  score = Math.min(score, 100);
  return { score, action: score >= 75 ? 'block' : 'allow', reasons };
}
