/**
 * PaymentIntent state machine.
 *
 *   requires_payment_method ──confirm──▶ processing ──approved──▶ requires_capture ──capture──▶ succeeded
 *            ▲                               │          (manual)          │
 *            └──────── declined / blocked ───┘                            └──cancel──▶ canceled
 *                                                  approved (automatic) ─────────────▶ succeeded
 *
 * Network calls happen OUTSIDE database transactions: we move the intent to
 * `processing` (a lock by state), call the acquirer, then finalize. A crash in
 * between leaves the intent in `processing`; a reconciliation job must match it
 * against the processor's records (see README "Production gaps").
 */
import type { PoolClient } from 'pg';
import { one, pool, tx } from '../db.js';
import { connector } from '../acquirer/connector.js';
import { acct, postJournal } from '../ledger/ledger.js';
import { ApiError, computeFee, newId } from '../util/common.js';
import { detokenize, getToken } from '../vault/vault.js';
import { emitEvent } from '../webhooks/webhooks.js';
import { assessRisk } from './risk.js';
import { raiseAlert } from '../admin/monitoring.js';

export interface Merchant {
  id: string; name: string; email: string; status: string;
  fee_bps: number; fee_fixed: number; max_amount: number;
  webhook_url: string | null; webhook_secret: string;
  payout_method?: 'bank' | 'wallet'; payout_wallet_user_id?: string | null;
}

export function present(pi: any, card?: any) {
  return {
    id: pi.id,
    object: 'payment_intent',
    amount: pi.amount,
    currency: pi.currency,
    status: pi.status,
    capture_method: pi.capture_method,
    amount_capturable: pi.status === 'requires_capture' ? pi.amount : 0,
    amount_captured: pi.amount_captured,
    amount_refunded: pi.amount_refunded,
    fee: pi.fee,
    client_secret: pi.client_secret,
    description: pi.description,
    metadata: pi.metadata,
    payment_method: pi.wallet_user_id ? { type: 'global_gold_wallet' } : card ? { token: card.id, brand: card.brand, last4: card.last4, exp_month: card.exp_month, exp_year: card.exp_year } : pi.token_id,
    network: pi.auth_code ? { auth_code: pi.auth_code, rrn: pi.network_ref } : null,
    last_payment_error: pi.decline_code ? { code: pi.decline_code, message: pi.decline_message } : null,
    risk_score: pi.risk_score,
    created: pi.created_at,
  };
}

async function load(c: PoolClient | typeof pool, merchantId: string, id: string, lock = false) {
  const pi = await one(c, `SELECT * FROM payment_intents WHERE id = $1 AND merchant_id = $2 ${lock ? 'FOR UPDATE' : ''}`, [id, merchantId]);
  if (!pi) throw new ApiError(404, 'resource_missing', `No such payment_intent: ${id}`);
  return pi;
}

export async function getPaymentIntent(merchantId: string, id: string) {
  const pi = await load(pool, merchantId, id);
  const card = pi.token_id ? await getToken(pool, pi.token_id, merchantId) : undefined;
  return present(pi, card);
}

export async function listPaymentIntents(merchantId: string, limit = 25) {
  const r = await pool.query(
    `SELECT pi.*, t.brand, t.last4, t.exp_month, t.exp_year
       FROM payment_intents pi LEFT JOIN card_tokens t ON t.id = pi.token_id
      WHERE pi.merchant_id = $1 ORDER BY pi.created_at DESC LIMIT $2`, [merchantId, limit]);
  return r.rows.map((row) => present(row, row.token_id ? { id: row.token_id, brand: row.brand, last4: row.last4, exp_month: row.exp_month, exp_year: row.exp_year } : undefined));
}

export async function createPaymentIntent(m: Merchant, input: {
  amount: number; currency: string; capture_method?: 'automatic' | 'manual';
  description?: string; metadata?: Record<string, string>;
}) {
  if (m.status !== 'active') throw new ApiError(403, 'account_inactive', 'This account cannot accept payments yet.');
  return tx(async (c) => {
    const pi = await one(c,
      `INSERT INTO payment_intents (id, merchant_id, amount, currency, status, capture_method, client_secret, description, metadata)
       VALUES ($1,$2,$3,$4,'requires_payment_method',$5,$6,$7,$8) RETURNING *`,
      [newId('pi'), m.id, input.amount, input.currency, input.capture_method ?? 'automatic',
       newId('secret', 18), input.description ?? null, JSON.stringify(input.metadata ?? {})]);
    await emitEvent(c, m.id, 'payment_intent.created', present(pi));
    return present(pi);
  });
}

async function postCapture(c: PoolClient, m: Merchant, pi: any, amount: number) {
  const fee = computeFee(amount, m.fee_bps, m.fee_fixed);
  await postJournal(c, pi.currency, { type: 'payment_intent', id: pi.id }, `capture ${pi.id}`, [
    { account: acct.receivable, debit: amount },
    { account: acct.pending(m.id), credit: amount - fee },
    { account: acct.fees, credit: fee },
  ]);
  return fee;
}

export async function confirmPaymentIntent(m: Merchant, id: string, tokenId: string) {
  // Phase 1: claim the intent.
  const { pi, card } = await tx(async (c) => {
    const pi = await load(c, m.id, id, true);
    if (pi.status !== 'requires_payment_method') {
      throw new ApiError(400, 'payment_intent_unexpected_state', `This PaymentIntent is ${pi.status} and cannot be confirmed.`);
    }
    const card = await getToken(c, tokenId, m.id);
    if (!card) throw new ApiError(400, 'invalid_payment_method', 'Unknown payment token for this account.');
    await c.query(`UPDATE payment_intents SET status='processing', token_id=$2, decline_code=NULL, decline_message=NULL, updated_at=now() WHERE id=$1`, [id, tokenId]);
    return { pi, card };
  });

  const fail = async (outcome: 'declined' | 'blocked' | 'error', code: string, message: string, responseCode: string | null, score: number | null) =>
    tx(async (c) => {
      const row = await one(c,
        `UPDATE payment_intents SET status='requires_payment_method', decline_code=$2, decline_message=$3, risk_score=$4, updated_at=now()
          WHERE id=$1 RETURNING *`, [id, code, message, score]);
      await c.query(`INSERT INTO payment_attempts (payment_intent_id, token_id, fingerprint, outcome, response_code, risk_score) VALUES ($1,$2,$3,$4,$5,$6)`,
        [id, tokenId, card.fingerprint, outcome, responseCode, score]);
      if (outcome === 'blocked') {
        await raiseAlert(c, { severity: 'low', rule: 'risk_block', message: `Card payment blocked by risk rules at ${m.name}: ${message}`,
          subjectType: 'payment_intent', subjectId: id, merchantId: m.id, amount: pi.amount, currency: pi.currency });
      }
      await emitEvent(c, m.id, 'payment_intent.payment_failed', present(row, card));
      return present(row, card);
    });

  // Phase 2: risk.
  const risk = await assessRisk(pool, { amount: pi.amount, maxAmount: m.max_amount, card });
  if (risk.action === 'block') return fail('blocked', 'risk_blocked', `Blocked by risk rules: ${risk.reasons.join(', ')}`, null, risk.score);

  // Phase 3: authorize with the network.
  const secret = await detokenize(pool, tokenId);
  const authReq = { ...secret, amount: pi.amount, currency: pi.currency };
  let result;
  try {
    result = await connector.authorize(authReq);
  } catch (e) {
    // Timeout/transport error: outcome unknown. Real systems send a reversal (0400)
    // with the same RRN so the issuer releases any hold it may have placed.
    return fail('error', 'processing_error', 'The payment network did not respond. Try again.', null, risk.score);
  }
  if (!result.approved) return fail('declined', result.declineCode!, result.declineMessage!, result.responseCode, risk.score);

  // Phase 4: finalize.
  return tx(async (c) => {
    await c.query(`INSERT INTO payment_attempts (payment_intent_id, token_id, fingerprint, outcome, response_code, risk_score) VALUES ($1,$2,$3,'approved','00',$4)`,
      [id, tokenId, card.fingerprint, risk.score]);
    let row;
    if (pi.capture_method === 'automatic') {
      const fee = await postCapture(c, m, pi, pi.amount);
      row = await one(c,
        `UPDATE payment_intents SET status='succeeded', amount_captured=amount, fee=$2, auth_code=$3, network_ref=$4, risk_score=$5, updated_at=now()
          WHERE id=$1 RETURNING *`, [id, fee, result.authCode, result.rrn, risk.score]);
      await emitEvent(c, m.id, 'payment_intent.succeeded', present(row, card));
    } else {
      row = await one(c,
        `UPDATE payment_intents SET status='requires_capture', auth_code=$2, network_ref=$3, risk_score=$4, updated_at=now()
          WHERE id=$1 RETURNING *`, [id, result.authCode, result.rrn, risk.score]);
      await emitEvent(c, m.id, 'payment_intent.amount_capturable_updated', present(row, card));
    }
    return present(row, card);
  });
}

export async function capturePaymentIntent(m: Merchant, id: string, amountToCapture?: number) {
  return tx(async (c) => {
    const pi = await load(c, m.id, id, true);
    if (pi.status !== 'requires_capture') throw new ApiError(400, 'payment_intent_unexpected_state', `This PaymentIntent is ${pi.status} and cannot be captured.`);
    const amount = amountToCapture ?? pi.amount;
    if (amount <= 0 || amount > pi.amount) throw new ApiError(400, 'amount_too_large', `Capture amount must be between 1 and ${pi.amount}.`);
    // Any uncaptured remainder is released. The captured amount goes to the clearing file.
    const fee = await postCapture(c, m, pi, amount);
    const row = await one(c,
      `UPDATE payment_intents SET status='succeeded', amount_captured=$2, fee=$3, updated_at=now() WHERE id=$1 RETURNING *`,
      [id, amount, fee]);
    const card = await getToken(c, pi.token_id, m.id);
    await emitEvent(c, m.id, 'payment_intent.succeeded', present(row, card));
    return present(row, card);
  });
}

export async function cancelPaymentIntent(m: Merchant, id: string) {
  const pi = await tx(async (c) => {
    const pi = await load(c, m.id, id, true);
    if (!['requires_payment_method', 'requires_capture'].includes(pi.status)) {
      throw new ApiError(400, 'payment_intent_unexpected_state', `This PaymentIntent is ${pi.status} and cannot be canceled.`);
    }
    if (pi.status === 'requires_capture') {
      await c.query(`UPDATE payment_intents SET status='processing', updated_at=now() WHERE id=$1`, [id]);
    }
    return pi;
  });

  if (pi.status === 'requires_capture') {
    const secret = await detokenize(pool, pi.token_id);
    try {
      await connector.reverse({ ...secret, amount: pi.amount, currency: pi.currency, originalRrn: pi.network_ref });
    } catch {
      // Authorization will simply expire at the issuer. Record the cancel anyway.
    }
  }

  return tx(async (c) => {
    const row = await one(c, `UPDATE payment_intents SET status='canceled', updated_at=now() WHERE id=$1 RETURNING *`, [id]);
    await emitEvent(c, m.id, 'payment_intent.canceled', present(row));
    return present(row);
  });
}

export async function createRefund(m: Merchant, paymentIntentId: string, amount?: number) {
  // Reserve the refund amount first so concurrent refunds cannot exceed the captured amount.
  const { pi, refundAmount } = await tx(async (c) => {
    const pi = await load(c, m.id, paymentIntentId, true);
    if (pi.status !== 'succeeded') throw new ApiError(400, 'charge_not_refundable', 'Only succeeded payments can be refunded.');
    const remaining = pi.amount_captured - pi.amount_refunded;
    const refundAmount = amount ?? remaining;
    if (refundAmount <= 0 || refundAmount > remaining) {
      throw new ApiError(400, 'amount_too_large', `Refund amount must be between 1 and ${remaining}.`);
    }
    await c.query('UPDATE payment_intents SET amount_refunded = amount_refunded + $2, updated_at=now() WHERE id=$1', [pi.id, refundAmount]);
    return { pi, refundAmount };
  });

  if (pi.wallet_user_id) {
    // Wallet-funded payment: no card network, the money goes straight back to the wallet.
    return tx(async (c) => {
      const id = newId('re');
      await postJournal(c, pi.currency, { type: 'refund', id }, `wallet refund ${id} for ${pi.id}`, [
        { account: acct.pending(m.id), debit: refundAmount },
        { account: acct.wallet(pi.wallet_user_id), credit: refundAmount },
      ]);
      await c.query(
        `INSERT INTO wallet_transactions (id, user_id, type, amount, currency, counterparty, note, payment_intent_id)
         VALUES ($1,$2,'refund',$3,$4,$5,$6,$7)`,
        [newId('wtx'), pi.wallet_user_id, refundAmount, pi.currency, m.name, pi.description, pi.id]);
      const re = await one(c,
        `INSERT INTO refunds (id, merchant_id, payment_intent_id, amount, status) VALUES ($1,$2,$3,$4,'succeeded') RETURNING *`,
        [id, m.id, pi.id, refundAmount]);
      await emitEvent(c, m.id, 'refund.succeeded', re);
      return { object: 'refund', ...re };
    });
  }

  const secret = await detokenize(pool, pi.token_id);
  let result;
  try {
    result = await connector.refund({ ...secret, amount: refundAmount, currency: pi.currency });
  } catch {
    result = { approved: false, responseCode: '96', rrn: null as any };
  }

  if (!result.approved) {
    const re = await tx(async (c) => {
      await c.query('UPDATE payment_intents SET amount_refunded = amount_refunded - $2, updated_at=now() WHERE id=$1', [pi.id, refundAmount]);
      const re = await one(c,
        `INSERT INTO refunds (id, merchant_id, payment_intent_id, amount, status) VALUES ($1,$2,$3,$4,'failed') RETURNING *`,
        [newId('re'), m.id, pi.id, refundAmount]);
      await emitEvent(c, m.id, 'refund.failed', re);
      return re;
    });
    throw new ApiError(502, 'refund_failed', 'The network rejected the refund. Try again later.', { refund: re });
  }

  return tx(async (c) => {
    const id = newId('re');
    // Processing fee is not returned on refunds (common industry practice; configurable).
    await postJournal(c, pi.currency, { type: 'refund', id }, `refund ${id} for ${pi.id}`, [
      { account: acct.pending(m.id), debit: refundAmount },
      { account: acct.receivable, credit: refundAmount },
    ]);
    const re = await one(c,
      `INSERT INTO refunds (id, merchant_id, payment_intent_id, amount, status, network_ref) VALUES ($1,$2,$3,$4,'succeeded',$5) RETURNING *`,
      [id, m.id, pi.id, refundAmount, result.rrn]);
    await emitEvent(c, m.id, 'refund.succeeded', re);
    return { object: 'refund', ...re };
  });
}
