/**
 * Square provider.
 *
 * Square is the acquirer; we are the platform. Each payment is created with the
 * seller's own OAuth access token and carries `app_fee_money` — our cut, which
 * Square deposits into our account and the rest into the seller's.
 *
 * Setup (Square Developer Console → your application):
 *   1. OAuth → set the redirect URL to  {PUBLIC_URL}/v1/connect/square/callback
 *   2. Note the Application ID and Application Secret
 *   3. Request the `PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS` permission — app fees
 *      need it and it is not granted by default
 *   4. Webhooks → subscribe to payment.updated, refund.updated, oauth.authorization.revoked
 *      and copy the signature key
 *
 *   SQUARE_ENV=sandbox|production
 *   SQUARE_APP_ID=...
 *   SQUARE_APP_SECRET=...
 *   SQUARE_WEBHOOK_SIGNATURE_KEY=...
 *
 * Limits worth remembering: app fees work only where the seller and the platform
 * are in the SAME country and currency, in US, CA, GB, AU, the eurozone and JP.
 * A seller outside those needs a different provider.
 */
import crypto from 'node:crypto';
import {
  CaptureRequest, ChargeRequest, OnboardingResult, OnboardingStart,
  PaymentProvider, ProviderError, ProviderResult, RefundRequest,
} from './provider.js';

/** Pinned so a Square API change can never silently alter behaviour. */
const SQUARE_VERSION = '2026-09-16';

const HOSTS = {
  sandbox: { api: 'https://connect.squareupsandbox.com', web: 'https://squareupsandbox.com' },
  production: { api: 'https://connect.squareup.com', web: 'https://squareup.com' },
} as const;

/** Permissions we need: take payments for the seller, and keep our app fee. */
const SCOPES = [
  'MERCHANT_PROFILE_READ',
  'PAYMENTS_READ',
  'PAYMENTS_WRITE',
  'PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS',
  'ORDERS_READ',
  'ORDERS_WRITE',
];

/** Square decline codes → a short sentence a shopper can act on. */
const DECLINES: Record<string, string> = {
  CARD_DECLINED: 'The card was declined. Try another card.',
  INSUFFICIENT_FUNDS: 'The card has insufficient funds.',
  CVV_FAILURE: 'The security code is incorrect.',
  ADDRESS_VERIFICATION_FAILURE: 'The postal code does not match the card.',
  EXPIRED_CARD: 'The card has expired.',
  CARD_EXPIRED: 'The card has expired.',
  INVALID_EXPIRATION: 'The expiry date is not valid.',
  GENERIC_DECLINE: 'The card was declined.',
  CARD_NOT_SUPPORTED: 'The card does not support this type of payment.',
  INVALID_CARD: 'The card details are not valid.',
  PAN_FAILURE: 'The card number is not valid.',
  CARD_DECLINED_CALL_ISSUER: 'The card was declined. Ask the cardholder to call their bank.',
  CARD_DECLINED_VERIFICATION_REQUIRED: 'The card needs verification before it can be used.',
  TRANSACTION_LIMIT: 'The amount is over the card limit.',
  VOICE_FAILURE: 'The card was declined.',
  ALLOWABLE_PIN_TRIES_EXCEEDED: 'Too many PIN attempts.',
};

interface SquareMoney { amount: number; currency: string }

export interface SquareConfig {
  env: 'sandbox' | 'production';
  appId: string;
  appSecret: string;
  webhookSignatureKey?: string;
  /** Our own access token, used where no seller context applies. */
  platformAccessToken?: string;
  /** Injected in tests. Defaults to global fetch. */
  fetchImpl?: typeof fetch;
  /** Request timeout in ms. */
  timeoutMs?: number;
}

export class SquareProvider implements PaymentProvider {
  readonly name = 'square' as const;
  /** Card data is tokenised by the Web Payments SDK. We never see a PAN. */
  readonly tokenizesInBrowser = true;
  /** Where Square can onboard sellers AND app fees are supported. */
  readonly merchantCountries = ['US', 'CA', 'GB', 'AU', 'IE', 'FR', 'ES', 'JP', 'DE', 'NL', 'IT'] as const;

  private readonly host: string;
  private readonly web: string;
  private readonly doFetch: typeof fetch;
  private readonly timeoutMs: number;

  constructor(private readonly cfg: SquareConfig) {
    if (!cfg.appId || !cfg.appSecret) {
      throw new Error('Square needs SQUARE_APP_ID and SQUARE_APP_SECRET. See src/providers/square.ts.');
    }
    this.host = HOSTS[cfg.env].api;
    this.web = HOSTS[cfg.env].web;
    this.doFetch = cfg.fetchImpl ?? fetch;
    this.timeoutMs = cfg.timeoutMs ?? 20_000;
  }

  // ------------------------------------------------------------------ plumbing

  private async call<T = any>(
    path: string,
    init: { method: string; token?: string | null; body?: unknown; idempotencyKey?: string },
  ): Promise<T> {
    const headers: Record<string, string> = {
      'Square-Version': SQUARE_VERSION,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
    if (init.token) headers.Authorization = `Bearer ${init.token}`;

    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), this.timeoutMs);
    let res: Response;
    try {
      res = await this.doFetch(this.host + path, {
        method: init.method,
        headers,
        body: init.body === undefined ? undefined : JSON.stringify(init.body),
        signal: ac.signal,
      });
    } catch (e: any) {
      // A network failure is retryable: the payment may or may not exist, and the
      // idempotency key makes a retry safe.
      throw new ProviderError(
        e?.name === 'AbortError' ? 'Square did not respond in time.' : 'Could not reach Square.',
        'provider_unreachable', true, e?.message);
    } finally {
      clearTimeout(timer);
    }

    const text = await res.text();
    let json: any;
    try { json = text ? JSON.parse(text) : {}; } catch { json = { raw: text }; }

    if (!res.ok) {
      const err = json?.errors?.[0] ?? {};
      throw new ProviderError(
        err.detail || `Square returned ${res.status}.`,
        String(err.code || `http_${res.status}`),
        res.status >= 500 || res.status === 429,
        json?.errors,
      );
    }
    return json as T;
  }

  /** Square wants whole minor units and an uppercase ISO currency. */
  private money(amount: number, currency: string): SquareMoney {
    return { amount: Math.round(amount), currency: currency.toUpperCase() };
  }

  /** Square idempotency keys are 1–45 characters. */
  private key(raw: string): string {
    return raw.length <= 45 ? raw : crypto.createHash('sha256').update(raw).digest('base64url').slice(0, 45);
  }

  private sellerToken(merchant: { accessToken?: string | null; id: string }): string {
    const token = merchant.accessToken || this.cfg.platformAccessToken;
    if (!token) {
      throw new ProviderError(
        `Merchant ${merchant.id} has not connected a Square account yet.`,
        'merchant_not_connected');
    }
    return token;
  }

  private result(payment: any, fallbackRef: string): ProviderResult {
    const approved = payment?.status === 'COMPLETED' || payment?.status === 'APPROVED';
    const declineCode = payment?.card_details?.errors?.[0]?.code
      ?? (payment?.status === 'FAILED' ? 'GENERIC_DECLINE' : undefined);
    return {
      approved,
      providerPaymentId: payment?.id,
      authCode: payment?.card_details?.auth_result_code,
      networkRef: payment?.id ?? fallbackRef,
      status: payment?.status,
      declineCode,
      declineMessage: declineCode ? (DECLINES[declineCode] ?? DECLINES.GENERIC_DECLINE) : undefined,
      platformFee: payment?.app_fee_money?.amount,
      providerFee: Array.isArray(payment?.processing_fee)
        ? payment.processing_fee.reduce((t: number, f: any) => t + (f?.amount_money?.amount ?? 0), 0)
        : undefined,
    };
  }

  // -------------------------------------------------------------------- charge

  async charge(req: ChargeRequest): Promise<ProviderResult> {
    if (req.source.kind !== 'provider_token') {
      // Square must never be handed a card number: the browser tokenises it.
      throw new ProviderError(
        'Square payments need a token from the Web Payments SDK, not a card number.',
        'raw_card_not_accepted');
    }
    const body: Record<string, unknown> = {
      source_id: req.source.token,
      idempotency_key: this.key(req.idempotencyKey),
      amount_money: this.money(req.amount, req.currency),
      autocomplete: req.capture,
    };
    if (req.platformFee && req.platformFee > 0) body.app_fee_money = this.money(req.platformFee, req.currency);
    if (req.merchant.locationId) body.location_id = req.merchant.locationId;
    if (req.reference) body.reference_id = req.reference.slice(0, 40);
    if (req.note) body.note = req.note.slice(0, 500);
    if (req.buyerEmail) body.buyer_email_address = req.buyerEmail;
    if (req.source.verificationToken) body.verification_token = req.source.verificationToken;

    try {
      const out = await this.call('/v2/payments', {
        method: 'POST', token: this.sellerToken(req.merchant), body,
      });
      return this.result(out.payment, req.idempotencyKey);
    } catch (e) {
      // A decline arrives as a 4xx with a card error, not as a payment object.
      if (e instanceof ProviderError && !e.retryable && DECLINES[e.code]) {
        return {
          approved: false,
          networkRef: req.idempotencyKey,
          declineCode: e.code,
          declineMessage: DECLINES[e.code],
        };
      }
      throw e;
    }
  }

  async capture(req: CaptureRequest): Promise<ProviderResult> {
    const out = await this.call(`/v2/payments/${encodeURIComponent(req.providerPaymentId)}/complete`, {
      method: 'POST', token: this.sellerToken(req.merchant), body: {},
    });
    return this.result(out.payment, req.providerPaymentId);
  }

  async void(req: CaptureRequest): Promise<ProviderResult> {
    const out = await this.call(`/v2/payments/${encodeURIComponent(req.providerPaymentId)}/cancel`, {
      method: 'POST', token: this.sellerToken(req.merchant), body: {},
    });
    return this.result(out.payment, req.providerPaymentId);
  }

  async refund(req: RefundRequest): Promise<ProviderResult> {
    const body: Record<string, unknown> = {
      idempotency_key: this.key(req.idempotencyKey),
      payment_id: req.providerPaymentId,
      amount_money: this.money(req.amount, req.currency),
    };
    // Give back our fee in proportion, or the seller absorbs our cut on refunds.
    if (req.platformFeeRefund && req.platformFeeRefund > 0) {
      body.app_fee_money = this.money(req.platformFeeRefund, req.currency);
    }
    if (req.reason) body.reason = req.reason.slice(0, 192);

    const out = await this.call('/v2/refunds', {
      method: 'POST', token: this.sellerToken(req.merchant), body,
    });
    const refund = out.refund ?? {};
    const ok = refund.status === 'COMPLETED' || refund.status === 'PENDING';
    return {
      approved: ok,
      providerPaymentId: refund.id,
      networkRef: refund.id ?? req.idempotencyKey,
      status: refund.status,
      platformFee: refund.app_fee_money?.amount,
      declineCode: ok ? undefined : String(refund.status ?? 'refund_failed'),
      declineMessage: ok ? undefined : 'Square did not accept the refund.',
    };
  }

  // ---------------------------------------------------------------- onboarding

  startOnboarding(merchantId: string, redirectUri: string): OnboardingStart {
    // `state` ties the callback back to this merchant and blocks CSRF.
    const nonce = crypto.randomBytes(16).toString('base64url');
    const state = `${merchantId}.${nonce}`;
    const q = new URLSearchParams({
      client_id: this.cfg.appId,
      scope: SCOPES.join(' '),
      session: 'false',
      state,
      redirect_uri: redirectUri,
    });
    return { url: `${this.web}/oauth2/authorize?${q}`, state };
  }

  async completeOnboarding(code: string, redirectUri: string): Promise<OnboardingResult> {
    const token = await this.call('/oauth2/token', {
      method: 'POST',
      body: {
        client_id: this.cfg.appId,
        client_secret: this.cfg.appSecret,
        code,
        grant_type: 'authorization_code',
        redirect_uri: redirectUri,
      },
    });
    return this.describeSeller(token);
  }

  async refreshAccess(refreshToken: string): Promise<OnboardingResult> {
    const token = await this.call('/oauth2/token', {
      method: 'POST',
      body: {
        client_id: this.cfg.appId,
        client_secret: this.cfg.appSecret,
        refresh_token: refreshToken,
        grant_type: 'refresh_token',
      },
    });
    return this.describeSeller(token);
  }

  /** Turn an OAuth response into the seller's account, name and first location. */
  private async describeSeller(token: any): Promise<OnboardingResult> {
    if (!token?.access_token) throw new ProviderError('Square did not return an access token.', 'oauth_failed');
    const base: OnboardingResult = {
      accountId: token.merchant_id,
      accessToken: token.access_token,
      refreshToken: token.refresh_token,
      expiresAt: token.expires_at ? new Date(token.expires_at) : undefined,
    };
    // Best effort: a missing location only means we send payments without one.
    try {
      const locs = await this.call('/v2/locations', { method: 'GET', token: token.access_token });
      const active = (locs.locations ?? []).find((l: any) => l.status === 'ACTIVE') ?? locs.locations?.[0];
      if (active) {
        base.locationId = active.id;
        base.businessName = active.business_name || active.name;
        base.currency = (active.currency || '').toLowerCase() || undefined;
        base.country = active.country || undefined;
      }
    } catch { /* keep the tokens; the location can be filled in later */ }
    return base;
  }

  // ------------------------------------------------------------------- webhook

  /**
   * HMAC-SHA256 over (notification URL + raw body), keyed with the webhook
   * signature key, base64, compared in constant time.
   */
  verifyWebhook(rawBody: string, headers: Record<string, string | undefined>, notificationUrl: string): boolean {
    const key = this.cfg.webhookSignatureKey;
    const given = headers['x-square-hmacsha256-signature'] ?? headers['X-Square-HmacSha256-Signature'];
    if (!key || !given) return false;
    const expected = crypto.createHmac('sha256', key).update(notificationUrl + rawBody).digest('base64');
    const a = Buffer.from(expected), b = Buffer.from(given);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
}
