/**
 * Stripe Connect provider.
 *
 * Stripe is the acquirer; we are the platform. Payments are created *on the
 * connected account* (a direct charge) with `application_fee_amount` — our cut,
 * which Stripe moves to our balance while the rest settles to the merchant.
 *
 * One important difference from Square: Stripe has deprecated the per-merchant
 * OAuth access token. Requests are made with OUR platform secret key plus a
 * `Stripe-Account: acct_…` header, so the only thing we store per merchant is
 * the account id — nothing secret. That makes a leaked merchant row far less
 * dangerous here than on Square, and it is why `accessToken` is unused below.
 *
 * Setup (Stripe Dashboard → Connect → Settings → OAuth):
 *   Redirect URI   {PUBLIC_URL}/v1/connect/stripe/callback
 *   Webhook        {PUBLIC_URL}/v1/webhooks/stripe  (listen to "Connect" events)
 *
 *   STRIPE_SECRET_KEY=sk_live_…      (or sk_test_… )
 *   STRIPE_CLIENT_ID=ca_…
 *   STRIPE_WEBHOOK_SECRET=whsec_…
 *
 * Stripe reaches far more countries than Square, which is why it exists here:
 * Nigeria, Kenya, India, Brazil, Mexico and more are Stripe-only.
 */
import crypto from 'node:crypto';
import {
  CaptureRequest, ChargeRequest, OnboardingResult, OnboardingStart,
  PaymentProvider, ProviderError, ProviderResult, RefundRequest,
} from './provider.js';

/** Pinned, so a Stripe API change can never silently alter behaviour. */
const STRIPE_VERSION = '2026-08-27.basil';
const API = 'https://api.stripe.com';
const CONNECT = 'https://connect.stripe.com';

/** How far out of date a webhook timestamp may be, in seconds. */
const WEBHOOK_TOLERANCE = 300;

/** Stripe decline codes → a sentence a shopper can act on. */
const DECLINES: Record<string, string> = {
  card_declined: 'The card was declined.',
  insufficient_funds: 'The card has insufficient funds.',
  incorrect_cvc: 'The security code is incorrect.',
  incorrect_number: 'The card number is not valid.',
  incorrect_zip: 'The postal code does not match the card.',
  expired_card: 'The card has expired.',
  invalid_expiry_month: 'The expiry month is not valid.',
  invalid_expiry_year: 'The expiry year is not valid.',
  processing_error: 'The card could not be processed. Try again.',
  lost_card: 'The card was declined.',
  stolen_card: 'The card was declined.',
  pickup_card: 'The card was declined.',
  call_issuer: 'The card was declined. Ask the cardholder to call their bank.',
  do_not_honor: 'The card was declined.',
  generic_decline: 'The card was declined.',
  fraudulent: 'The card was declined.',
  authentication_required: 'The bank needs the cardholder to authenticate this payment.',
  currency_not_supported: 'This card does not support that currency.',
};

export interface StripeConfig {
  secretKey: string;
  clientId: string;
  webhookSecret?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

export class StripeProvider implements PaymentProvider {
  readonly name = 'stripe' as const;
  /** Cards are tokenised by Stripe.js / Elements. We never see a PAN. */
  readonly tokenizesInBrowser = true;
  /**
   * Countries where Stripe onboards businesses. Deliberately includes the ones
   * Square cannot serve — that is the reason this provider exists.
   */
  readonly merchantCountries = [
    'US', 'CA', 'GB', 'AU', 'NZ', 'IE', 'FR', 'ES', 'IT', 'DE', 'NL', 'BE', 'AT',
    'PT', 'FI', 'SE', 'NO', 'DK', 'PL', 'CZ', 'CH', 'JP', 'SG', 'HK', 'MY', 'TH',
    'IN', 'MX', 'BR', 'NG', 'KE', 'GH', 'ZA', 'AE',
  ] as const;

  private readonly doFetch: typeof fetch;
  private readonly timeoutMs: number;

  constructor(private readonly cfg: StripeConfig) {
    if (!cfg.secretKey || !cfg.clientId) {
      throw new Error('Stripe needs STRIPE_SECRET_KEY and STRIPE_CLIENT_ID. See src/providers/stripe.ts.');
    }
    this.doFetch = cfg.fetchImpl ?? fetch;
    this.timeoutMs = cfg.timeoutMs ?? 20_000;
  }

  // ------------------------------------------------------------------ plumbing

  /** Stripe takes form-encoded bodies, with bracket notation for nesting. */
  private form(obj: Record<string, unknown>, prefix = ''): string[] {
    const out: string[] = [];
    for (const [k, v] of Object.entries(obj)) {
      if (v === undefined || v === null) continue;
      const key = prefix ? `${prefix}[${k}]` : k;
      if (typeof v === 'object' && !Array.isArray(v)) out.push(...this.form(v as Record<string, unknown>, key));
      else out.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(v))}`);
    }
    return out;
  }

  private async call<T = any>(
    base: string, path: string,
    init: { method: string; body?: Record<string, unknown>; account?: string | null; idempotencyKey?: string; auth?: string },
  ): Promise<T> {
    const headers: Record<string, string> = {
      Authorization: `Bearer ${init.auth ?? this.cfg.secretKey}`,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Stripe-Version': STRIPE_VERSION,
    };
    // Act on the merchant's account rather than our own.
    if (init.account) headers['Stripe-Account'] = init.account;
    if (init.idempotencyKey) headers['Idempotency-Key'] = init.idempotencyKey;

    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), this.timeoutMs);
    let res: Response;
    try {
      res = await this.doFetch(base + path, {
        method: init.method,
        headers,
        body: init.body ? this.form(init.body).join('&') : undefined,
        signal: ac.signal,
      });
    } catch (e: any) {
      throw new ProviderError(
        e?.name === 'AbortError' ? 'Stripe did not respond in time.' : 'Could not reach Stripe.',
        'provider_unreachable', true, e?.message);
    } finally {
      clearTimeout(timer);
    }

    const text = await res.text();
    let json: any;
    try { json = text ? JSON.parse(text) : {}; } catch { json = { raw: text }; }

    if (!res.ok) {
      const err = json?.error ?? {};
      throw new ProviderError(
        err.message || err.error_description || `Stripe returned ${res.status}.`,
        String(err.decline_code || err.code || err.error || `http_${res.status}`),
        res.status >= 500 || res.status === 429,
        json?.error,
      );
    }
    return json as T;
  }

  private account(merchant: { accountId?: string | null; id: string }): string {
    if (!merchant.accountId) {
      throw new ProviderError(
        `Merchant ${merchant.id} has not connected a Stripe account yet.`,
        'merchant_not_connected');
    }
    return merchant.accountId;
  }

  /** Stripe idempotency keys are free-form but capped; keep them short. */
  private key(raw: string): string {
    return raw.length <= 255 ? raw : crypto.createHash('sha256').update(raw).digest('hex');
  }

  private result(pi: any, fallbackRef: string): ProviderResult {
    const charge = pi?.latest_charge && typeof pi.latest_charge === 'object' ? pi.latest_charge : undefined;
    const approved = pi?.status === 'succeeded' || pi?.status === 'requires_capture';
    const err = pi?.last_payment_error;
    const declineCode = err?.decline_code || err?.code;
    return {
      approved,
      providerPaymentId: pi?.id,
      authCode: charge?.payment_method_details?.card?.authorization_code,
      networkRef: pi?.id ?? fallbackRef,
      status: pi?.status,
      declineCode: approved ? undefined : declineCode,
      declineMessage: approved ? undefined
        : (DECLINES[declineCode] ?? err?.message ?? (pi?.status ? `Payment ${pi.status}.` : undefined)),
      platformFee: pi?.application_fee_amount ?? charge?.application_fee_amount,
      providerFee: charge?.balance_transaction?.fee,
    };
  }

  // -------------------------------------------------------------------- charge

  async charge(req: ChargeRequest): Promise<ProviderResult> {
    if (req.source.kind !== 'provider_token') {
      throw new ProviderError(
        'Stripe payments need a PaymentMethod from Stripe.js, not a card number.',
        'raw_card_not_accepted');
    }
    const body: Record<string, unknown> = {
      amount: Math.round(req.amount),
      currency: req.currency.toLowerCase(),
      payment_method: req.source.token,
      confirm: 'true',
      // Never bounce the shopper to a 3DS page from a server-side confirm; a
      // payment that needs authentication comes back as requires_action instead.
      'automatic_payment_methods[enabled]': 'true',
      'automatic_payment_methods[allow_redirects]': 'never',
      capture_method: req.capture ? 'automatic' : 'manual',
      expand: 'latest_charge',
    };
    if (req.platformFee && req.platformFee > 0) body.application_fee_amount = Math.round(req.platformFee);
    if (req.reference) body.metadata = { global_gold_id: req.reference };
    if (req.note) body.description = req.note.slice(0, 350);
    if (req.buyerEmail) body.receipt_email = req.buyerEmail;

    try {
      const pi = await this.call(API, '/v1/payment_intents', {
        method: 'POST', body, account: this.account(req.merchant),
        idempotencyKey: this.key(req.idempotencyKey),
      });
      return this.result(pi, req.idempotencyKey);
    } catch (e) {
      // A decline is a 402 with a decline code, not an exception worth throwing.
      if (e instanceof ProviderError && !e.retryable && (DECLINES[e.code] || e.code === 'card_declined')) {
        return {
          approved: false,
          networkRef: req.idempotencyKey,
          declineCode: e.code,
          declineMessage: DECLINES[e.code] ?? e.message,
        };
      }
      throw e;
    }
  }

  async capture(req: CaptureRequest): Promise<ProviderResult> {
    const body: Record<string, unknown> = { expand: 'latest_charge' };
    // Capturing less than was authorised releases the rest.
    if (req.amount) body.amount_to_capture = Math.round(req.amount);
    const pi = await this.call(API, `/v1/payment_intents/${encodeURIComponent(req.providerPaymentId)}/capture`, {
      method: 'POST', body, account: this.account(req.merchant),
      idempotencyKey: this.key(req.idempotencyKey),
    });
    return this.result(pi, req.providerPaymentId);
  }

  async void(req: CaptureRequest): Promise<ProviderResult> {
    const pi = await this.call(API, `/v1/payment_intents/${encodeURIComponent(req.providerPaymentId)}/cancel`, {
      method: 'POST', body: {}, account: this.account(req.merchant),
      idempotencyKey: this.key(req.idempotencyKey),
    });
    return { ...this.result(pi, req.providerPaymentId), approved: false, status: pi?.status ?? 'canceled' };
  }

  async refund(req: RefundRequest): Promise<ProviderResult> {
    const body: Record<string, unknown> = {
      payment_intent: req.providerPaymentId,
      amount: Math.round(req.amount),
    };
    // Hand our fee back in proportion, or the merchant absorbs our cut.
    if (req.platformFeeRefund && req.platformFeeRefund > 0) body.refund_application_fee = 'true';
    if (req.reason) body.metadata = { reason: req.reason.slice(0, 500) };

    const refund = await this.call(API, '/v1/refunds', {
      method: 'POST', body, account: this.account(req.merchant),
      idempotencyKey: this.key(req.idempotencyKey),
    });
    const ok = refund?.status === 'succeeded' || refund?.status === 'pending';
    return {
      approved: ok,
      providerPaymentId: refund?.id,
      networkRef: refund?.id ?? req.idempotencyKey,
      status: refund?.status,
      declineCode: ok ? undefined : String(refund?.failure_reason ?? 'refund_failed'),
      declineMessage: ok ? undefined : 'Stripe did not accept the refund.',
    };
  }

  // ---------------------------------------------------------------- onboarding

  startOnboarding(merchantId: string, redirectUri: string): OnboardingStart {
    const nonce = crypto.randomBytes(16).toString('base64url');
    const state = `${merchantId}.${nonce}`;
    const q = new URLSearchParams({
      response_type: 'code',
      client_id: this.cfg.clientId,
      scope: 'read_write',
      redirect_uri: redirectUri,
      state,
    });
    return { url: `${CONNECT}/oauth/authorize?${q}`, state };
  }

  async completeOnboarding(code: string, _redirectUri: string): Promise<OnboardingResult> {
    const token = await this.call(CONNECT, '/oauth/token', {
      method: 'POST',
      body: { grant_type: 'authorization_code', code },
    });
    if (!token?.stripe_user_id) throw new ProviderError('Stripe did not return an account id.', 'oauth_failed');

    const result: OnboardingResult = {
      accountId: token.stripe_user_id,
      // Stripe deprecated per-merchant tokens: we call with our platform key and
      // a Stripe-Account header, so there is no secret to keep for this merchant.
      accessToken: '',
      refreshToken: token.refresh_token,
    };
    // Best effort: the account's display name, country and currency.
    try {
      const acct = await this.call(API, `/v1/accounts/${encodeURIComponent(token.stripe_user_id)}`, { method: 'GET' });
      result.businessName = acct?.business_profile?.name || acct?.settings?.dashboard?.display_name || undefined;
      result.country = acct?.country || undefined;
      result.currency = acct?.default_currency || undefined;
    } catch { /* the account id is the part we actually need */ }
    return result;
  }

  /** Kept for the interface; Stripe access tokens are no longer used. */
  async refreshAccess(refreshToken: string): Promise<OnboardingResult> {
    const token = await this.call(CONNECT, '/oauth/token', {
      method: 'POST', body: { grant_type: 'refresh_token', refresh_token: refreshToken },
    });
    return { accountId: token.stripe_user_id, accessToken: '', refreshToken: token.refresh_token };
  }

  // ------------------------------------------------------------------- webhook

  /**
   * Stripe-Signature is `t=<unix>,v1=<hex hmac>`, where the HMAC covers
   * `<t>.<raw body>`. The timestamp is checked too: without that, a captured
   * notification could be replayed at any point in the future.
   */
  verifyWebhook(rawBody: string, headers: Record<string, string | undefined>, _url: string): boolean {
    const secret = this.cfg.webhookSecret;
    const header = headers['stripe-signature'] ?? headers['Stripe-Signature'];
    if (!secret || !header) return false;

    let timestamp = '';
    const signatures: string[] = [];
    for (const part of header.split(',')) {
      const [k, v] = part.split('=', 2);
      if (k?.trim() === 't') timestamp = (v ?? '').trim();
      else if (k?.trim() === 'v1' && v) signatures.push(v.trim());
    }
    if (!timestamp || !signatures.length) return false;

    const age = Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp));
    if (!Number.isFinite(age) || age > WEBHOOK_TOLERANCE) return false;

    const expected = crypto.createHmac('sha256', secret).update(`${timestamp}.${rawBody}`).digest('hex');
    const a = Buffer.from(expected);
    // Stripe may send several v1 signatures during a secret rotation.
    return signatures.some((s) => {
      const b = Buffer.from(s);
      return a.length === b.length && crypto.timingSafeEqual(a, b);
    });
  }
}
