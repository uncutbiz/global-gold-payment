/**
 * Simulated provider: the built-in ISO 8583 test network.
 *
 * This is what runs in development and in the test suite, so nothing depends on
 * a Square sandbox being reachable. It is the only provider that accepts a raw
 * card number, because it is the only one where the "network" is in-process.
 *
 * It also models the platform fee, so fee arithmetic is exercised by the tests
 * exactly as it will be against Square.
 */
import { connector } from '../acquirer/connector.js';
import {
  CaptureRequest, ChargeRequest, PaymentProvider, ProviderError, ProviderResult, RefundRequest,
} from './provider.js';

export class SimulatedProvider implements PaymentProvider {
  readonly name = 'simulated' as const;
  readonly tokenizesInBrowser = false;
  /** Every country, because nothing here is real. */
  readonly merchantCountries = [
    'US', 'GB', 'CA', 'AU', 'DE', 'FR', 'ES', 'IT', 'NL', 'IE',
    'MX', 'BR', 'NG', 'GH', 'KE', 'ZA', 'IN', 'PH',
  ] as const;

  private card(req: ChargeRequest | RefundRequest | CaptureRequest) {
    const source = 'source' in req ? req.source : undefined;
    if (!source || source.kind !== 'pan') {
      throw new ProviderError(
        'The simulated network needs a card from the vault.', 'card_required');
    }
    return source;
  }

  async charge(req: ChargeRequest): Promise<ProviderResult> {
    const card = this.card(req);
    const r = await connector.authorize({
      pan: card.pan, exp_month: card.exp_month, exp_year: card.exp_year,
      amount: req.amount, currency: req.currency,
    });
    return {
      approved: r.approved,
      providerPaymentId: r.rrn,
      authCode: r.authCode,
      networkRef: r.rrn,
      declineCode: r.declineCode,
      declineMessage: r.declineMessage,
      platformFee: r.approved ? req.platformFee : undefined,
      status: r.approved ? (req.capture ? 'COMPLETED' : 'APPROVED') : 'FAILED',
    };
  }

  /** The simulator authorises and clears in one step, so a capture is a no-op. */
  async capture(req: CaptureRequest): Promise<ProviderResult> {
    return { approved: true, providerPaymentId: req.providerPaymentId, networkRef: req.providerPaymentId, status: 'COMPLETED' };
  }

  async void(req: CaptureRequest & { source?: never }): Promise<ProviderResult> {
    return { approved: true, providerPaymentId: req.providerPaymentId, networkRef: req.providerPaymentId, status: 'CANCELED' };
  }

  async refund(req: RefundRequest & { source?: { kind: 'pan'; pan: string; exp_month: number; exp_year: number } }): Promise<ProviderResult> {
    if (!req.source) throw new ProviderError('The simulated network needs a card from the vault.', 'card_required');
    const r = await connector.refund({
      pan: req.source.pan, exp_month: req.source.exp_month, exp_year: req.source.exp_year,
      amount: req.amount, currency: req.currency,
    });
    return {
      approved: r.approved,
      providerPaymentId: r.rrn,
      networkRef: r.rrn,
      declineCode: r.declineCode,
      declineMessage: r.declineMessage,
      platformFee: r.approved ? req.platformFeeRefund : undefined,
      status: r.approved ? 'COMPLETED' : 'FAILED',
    };
  }
}
