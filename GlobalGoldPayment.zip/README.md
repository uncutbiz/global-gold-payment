# Global Gold Payment

A payment platform with two sides, written in Node.js (TypeScript) with PostgreSQL:

- **Global Gold for business (Stripe-style):** merchants accept cards and wallet payments through an API, a hosted checkout and a dashboard. It includes a token vault, an ISO 8583 card network connector, PaymentIntents, clearing and settlement, payouts and signed webhooks.
- **Global Gold wallet (PayPal-style):** customers in 18 countries hold balances in 13 currencies. They can add money from a card, send money at home or abroad with a locked exchange-rate quote, convert currencies, withdraw to a bank, share a "pay me" link, and pay merchants with *Pay with Global Gold*.

- **Admin panel (for your staff):** monitor every transaction, review and approve identity checks (KYC), work alerts from automatic monitoring rules, freeze customer accounts, suspend merchants, and manage staff roles. Every staff action is written to an append-only audit log.

Every money movement goes through one double-entry ledger that the database itself keeps balanced.

> **Test mode only.** This codebase is not PCI DSS compliant. Never send real card numbers to it. The acquirer is simulated until you connect it to a sponsor bank's processor. See *Production gaps* below.

## Quick start

```bash
docker compose up -d                 # PostgreSQL 16 on :5432
cp .env.example .env                 # then fill in the keys:
#   ADMIN_TOKEN=$(openssl rand -hex 32)
#   VAULT_KEY=$(openssl rand -base64 32)
#   FINGERPRINT_KEY=$(openssl rand -base64 32)
npm install
npm run dev                          # runs migrations, serves http://localhost:4000
npm run seed                         # demo admin, merchant and customers (in a second terminal)
npm run create-admin -- --email you@company.com --name "Your Name" --role owner
```

- Business dashboard: `http://localhost:4000/dashboard` (paste the secret key, create a checkout link, pay it)
- Customer wallet: `http://localhost:4000/wallet` (create two accounts in different countries and send money between them)
- Admin panel: `http://localhost:4000/admin` (sign in with the staff account printed by `seed` or `create-admin`)

Run the tests (they **wipe** the target database):

```bash
TEST_DATABASE_URL=postgres://globalgold:globalgold@localhost:5432/globalgold_test npm test   # 39 API checks
npx playwright install chromium
TEST_DATABASE_URL=postgres://globalgold:globalgold@localhost:5432/globalgold_test npm run test:ui   # clicks every button
BASE_URL=https://your-deployment ADMIN_TOKEN=... npm run smoke   # after each deploy
```

The Docker Compose database is named `globalgold`; create the test database first: `docker compose exec db createdb -U globalgold globalgold_test`.

## Deploying

One command builds and deploys the whole stack to AWS, step after step:

```bash
cp infra/aws/terraform.tfvars.example infra/aws/terraform.tfvars   # domain, Route 53 zone, alarm email
make deploy-dry     # show every command, change nothing
make deploy         # preflight → state bucket → ECR → image → infrastructure → release → admin → verify
```

Later, `make release` ships a code change and `make verify` re-runs the live checks and the
end-to-end smoke test. `make help` lists everything.

See [DEPLOY.md](DEPLOY.md) for what each step creates, for Render, Fly.io and self-hosting,
and for the production checklist (sponsor bank, PCI DSS, licensing).

## Test cards

Use any future expiry date and any CVC.

| Card | Result |
|---|---|
| 4242 4242 4242 4242 | Approved (Visa) |
| 5555 5555 5555 4444 | Approved (Mastercard) |
| 4000 0000 0000 0002 | `do_not_honor` (05) |
| 4000 0000 0000 9995 | `insufficient_funds` (51) |
| 4000 0000 0000 0069 | `expired_card` (54) |
| 4100 0000 0000 0019 | `suspected_fraud` (59) |
| 4000 0000 0000 0119 | `processing_error` (96) |

Any amount ending in `51` cents is declined with `insufficient_funds`.

## API

Authenticate with `Authorization: Bearer <key>`. POSTs accept an `Idempotency-Key` header. Amounts are in minor units (cents).

| Method & path | Key | Purpose |
|---|---|---|
| `POST /v1/admin/merchants` | admin | Create a merchant and return its keys (shown once) |
| `POST /v1/admin/settlements/run` | admin | Build the clearing file, fund the batch, settle pending → available |
| `GET  /v1/admin/ledger/trial-balance` | admin | Check that debits equal credits |
| `POST /v1/tokens` | pk / sk | Tokenize a card: `{card:{number,exp_month,exp_year,cvc}}` |
| `POST /v1/payment_intents` | sk | `{amount, currency, capture_method?, description?, metadata?, payment_token?, confirm?}` |
| `GET  /v1/payment_intents[/:id]` | sk (pk + `client_secret`) | List or retrieve payments |
| `POST /v1/payment_intents/:id/confirm` | sk (pk + `client_secret`) | `{payment_token}` authorizes the payment |
| `POST /v1/payment_intents/:id/capture` | sk | `{amount_to_capture?}` (partial capture releases the rest) |
| `POST /v1/payment_intents/:id/cancel` | sk | Cancel; sends a reversal if the payment was authorized |
| `POST /v1/refunds` | sk | `{payment_intent, amount?}` |
| `GET  /v1/balance` | sk | Pending and available balances per currency |
| `POST /v1/payouts` | sk | `{currency, amount?}` |
| `GET  /v1/events` | sk | Event log |
| `GET/POST /v1/account` | sk | View the account; set `webhook_url` |
| `GET  /v1/checkout/:id`, `POST /v1/checkout/:id/pay` | client_secret | Hosted checkout |

Example:

```bash
curl localhost:4000/v1/tokens -H "Authorization: Bearer $PK" -H 'content-type: application/json' \
  -d '{"card":{"number":"4242424242424242","exp_month":12,"exp_year":2030,"cvc":"123"}}'
curl localhost:4000/v1/payment_intents -H "Authorization: Bearer $SK" -H 'Idempotency-Key: order-1001' \
  -H 'content-type: application/json' -d '{"amount":4900,"currency":"usd","payment_token":"tok_…","confirm":true}'
```

### Wallet API

Sign in with `POST /v1/wallet/login`, then send `Authorization: Bearer ggs_…`. Amounts are in minor units.

| Method & path | Purpose |
|---|---|
| `GET  /v1/wallet/supported` | Countries and currencies (public) |
| `GET  /v1/wallet/recipients?email=` | Look up who you're paying (public, rate-limited) |
| `POST /v1/wallet/signup` / `login` / `logout` | `{email, name, password, country}`; home currency follows the country |
| `GET  /v1/wallet` / `GET /v1/wallet/activity` | Balances per currency, linked cards, limits / activity feed |
| `POST /v1/wallet/cards`, `DELETE /v1/wallet/cards/:id` | Link or remove a card |
| `POST /v1/wallet/top_ups` | `{amount, card}` charges the card and adds money in the home currency |
| `POST /v1/wallet/transfer_quotes` | `{to, amount, currency?}` returns the fee, rate and what the recipient gets (locked for 10 minutes) |
| `POST /v1/wallet/transfers` | `{to, amount, currency?, note?, quote?}` |
| `POST /v1/wallet/conversion_quotes`, `/conversions` | `{from, to, amount, quote?}` |
| `POST /v1/wallet/withdrawals` | `{amount, currency?}` |
| `GET  /v1/checkout/:id/wallet_preview`, `POST /v1/checkout/:id/pay_with_wallet` | Pay with Global Gold (needs the `client_secret`) |

### Admin panel

| Role | Can |
|---|---|
| `owner` | Everything, including staff accounts, the audit log, creating merchants and running settlement |
| `compliance` | Approve or reject identity checks, view ID documents, resolve alerts, freeze accounts, change merchant status |
| `support` | Read customers, transactions, the identity queue (no documents) and merchants |
| `viewer` | Overview, transactions and alerts, read-only |

**Identity checks (KYC).** Unverified customers can add up to $500 and send up to $250 at a time within their country. International transfers and withdrawals need an approved check. Customers submit their legal name, date of birth, address, ID type and number, and a photo of the ID. Only the last 4 digits of the ID number are shown, plus a keyed hash used to catch the same ID on several accounts. Staff see automatic checks (does the name match the account, is the ID used elsewhere, age), open the document, then approve or reject. A rejection reason is shown to the customer, who can resubmit.

**Monitoring rules** (in `src/admin/monitoring.ts`) open alerts for:

- transfers of $3,000 or more
- international transfers of $1,000 or more
- 5 transfers from one customer within an hour
- a new account (under 24 hours) sending $500 or more
- 3 declined card top-ups within an hour
- the same ID document used on several accounts
- card payments blocked by risk rules

Staff resolve or dismiss each alert with a note.

**Admin API.** Staff sign in with `POST /v1/admin/login`, then send `Authorization: Bearer gga_…`. The `ADMIN_TOKEN` env var works as a bootstrap owner, for creating the first staff account. Remove it in production.

| Method & path | Role |
|---|---|
| `GET /v1/admin/overview`, `/transactions`, `/transactions/:id`, `/alerts` | any staff |
| `GET /v1/admin/users`, `/users/:id`, `/kyc?status=`, `/merchants` | support, compliance |
| `GET /v1/admin/kyc/:id/document`, `POST /v1/admin/kyc/:id/approve`, `POST /v1/admin/kyc/:id/reject` | compliance |
| `POST /v1/admin/users/:id/freeze`, `/unfreeze`, `POST /v1/admin/alerts/:id/resolve`, `POST /v1/admin/merchants/:id/status` | compliance |
| `GET/POST /v1/admin/staff`, `POST /v1/admin/staff/:id/disable`, `GET /v1/admin/audit`, `POST /v1/admin/merchants`, `POST /v1/admin/settlements/run` | owner |

### Pricing (defaults, all configurable)

| What | Price |
|---|---|
| Merchant card or wallet payment | 2.9% + 30¢ (per merchant: `fee_bps`, `fee_fixed`) |
| Domestic wallet transfer | Free |
| International wallet transfer | 1% (min $0.99, max $4.99), set with `INTL_FEE_PCT` |
| Currency conversion | 1.5% margin over the mid-market rate (`FX_SPREAD` in `src/wallet/fx.ts`) |
| Adding money by card | Free to the customer; you pay the card network's interchange |

The exchange rates in `src/wallet/fx.ts` are **sample values**. Connect a live rate provider before real use.

### Webhooks

Each delivery carries `GlobalGold-Signature: t=<unix>,v1=<hex>`, where `v1 = HMAC-SHA256(webhook_secret, "<t>.<raw body>")`. You can verify it with `verify()` from `src/webhooks/webhooks.ts`. Failed deliveries are retried with exponential backoff, up to 8 attempts.

## How it fits together

```
src/
  wallet/wallet.ts          accounts, sessions, top-ups, transfers, conversions, withdrawals, Pay with Global Gold
  wallet/fx.ts              currencies, countries, quotes, cross-currency ledger postings
  wallet/kyc.ts             identity submissions and unverified-account limits
  admin/staff.ts            staff accounts, roles, sessions, audit log
  admin/service.ts          overview, unified transaction list, customers, KYC queue, alerts, merchants
  admin/monitoring.ts       transaction-monitoring rules
  vault/vault.ts            AES-256-GCM token vault (PAN never leaves it except to the connector)
  acquirer/iso8583.ts       ISO 8583 codec (MTI, bitmap, fields), PAN redaction, response codes
  acquirer/connector.ts     auth (0100), reversal (0400), refund (0200); simulator + TCP/TLS transport
  payments/service.ts       PaymentIntent state machine
  payments/risk.ts          pre-auth rules: merchant limit, card velocity, repeated declines
  ledger/ledger.ts          double-entry journals; DB triggers enforce balance and append-only
  settlement/settlement.ts  clearing file, sponsor funding, merchant settlement, payouts
  webhooks/webhooks.ts      transactional outbox + signed delivery worker
  api/                      Express routes, key auth, idempotency, rate limiting, errors
public/                     hosted checkout, merchant dashboard, customer wallet, admin panel
```

On capture, a $100.00 payment at 2.9% + 30¢ posts: Dr `platform:settlement_receivable` 100.00, Cr `merchant:<id>:pending` 96.80, Cr `platform:fee_revenue` 3.20.

## Production gaps (in rough priority order)

1. **Card data environment.** Move the vault and connector into a separate PCI-scoped service, network and database. Use HSM/KMS envelope encryption with key rotation, and serve card fields from an iframe on the vault domain. Then a QSA audit and Report on Compliance.
2. **Real acquirer link.** Implement your sponsor processor's message spec: its field set, headers, 0800 network management, STAN multiplexing, timeout reversals and stand-in processing. Then certify.
3. **3-D Secure 2.** Integrate a certified 3DS server and handle `requires_action`.
4. **Reconciliation.** Match processor clearing and funding files against the ledger. Resolve intents stuck in `processing`. Post interchange and scheme fees.
5. **Disputes.** Ingest chargebacks, move funds to a dispute account, handle evidence submission and network deadlines.
6. **Merchant onboarding.** KYB, OFAC and MATCH screening, underwriting, rolling reserves, T+N payout schedules, and ACH/RTP bank rails through the sponsor bank.
7. **Wallet and cross-border money transmission.** Holding customer balances and sending money abroad needs FinCEN MSB registration and state money transmitter licenses in the US, plus licenses or licensed partners in every destination country. It also needs customer KYC (identity checks), sanctions screening of every sender and recipient, transaction monitoring and reporting, customer funds held in safeguarded bank accounts, live FX rates with hedging, and local payout partners (bank transfer, mobile money such as M-Pesa, cash pickup). Add 2FA and device checks for wallet logins.
8. **Admin hardening.** Put staff sign-in behind SSO with hardware-key MFA and an IP allow-list. Keep KYC documents in encrypted object storage with a retention policy, and use an identity-verification provider for document authenticity, liveness checks and sanctions/PEP screening. Add case management and SAR filing on top of alerts.
9. **Platform.** Live and test key separation, key rotation, dashboard user accounts with MFA and RBAC, Redis rate limiting, a queue for webhooks, audit logs, observability, multi-region Postgres.
