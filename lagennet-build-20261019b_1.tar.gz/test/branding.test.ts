/**
 * The company is Lagennet.
 *
 * Two jobs here, and the second is the one that matters operationally.
 *
 * 1. No page, message or script still says the old name. A rename that is 95%
 *    done is worse than one not started: the stray 5% turns up on a checkout
 *    page or a receipt in front of a customer.
 *
 * 2. The INFRASTRUCTURE identifiers must NOT have been renamed. The database,
 *    the docker image, the systemd unit, the `ggp` CLI and the update scripts
 *    are all named `globalgold` in lowercase, and a running server depends on
 *    every one of them. Renaming those alongside the brand would have taken
 *    the deployment down — the database would not be found, the image would
 *    not exist, the service would not start. So this test asserts they are
 *    still there, which is the opposite of what a careless find-and-replace
 *    would have left behind.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'i18n-sheets']);
const TEXT_EXT = new Set([
  '.html', '.css', '.svg', '.ts', '.js', '.json', '.md', '.sql',
  '.sh', '.cmd', '.ps1', '.yml', '.yaml', '.tf', '.hcl', '.service', '.txt',
]);
const EXTRA_FILES = new Set(['ggp', 'Caddyfile', 'Dockerfile', 'Makefile']);

async function walk(dir: string, out: string[] = []): Promise<string[]> {
  for (const e of await fs.readdir(dir, { withFileTypes: true })) {
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(e.name)) continue;
      await walk(path.join(dir, e.name), out);
    } else if (TEXT_EXT.has(path.extname(e.name)) || EXTRA_FILES.has(e.name)
               || e.name.startsWith('globalgold-')) {
      out.push(path.join(dir, e.name));
    }
  }
  return out;
}

describe('the product is named Lagennet', () => {
  it('nothing anywhere still shows the old company name', async () => {
    const files = await walk(root);
    assert.ok(files.length > 50, 'the walk should have found the project');

    const offenders: string[] = [];
    for (const f of files) {
      const text = await fs.readFile(f, 'utf8');
      // The user-facing form: capitalised and spaced.
      if (/Global\s+Gold/.test(text)) offenders.push(path.relative(root, f));
    }
    assert.deepEqual(offenders, [], `these still say the old name:\n  ${offenders.join('\n  ')}`);
  });

  it('the public pages are branded Lagennet', async () => {
    for (const page of ['index.html', 'dashboard.html', 'wallet.html', 'admin.html', 'checkout.html']) {
      const html = await fs.readFile(path.join(root, 'public', page), 'utf8');
      assert.match(html, /Lagennet|Lagen<span/, `${page} carries no brand`);
    }
  });

  it('the brand in the logo is not sent to the translators', async () => {
    // A company name is the same in every language. Leaving a data-i18n on it
    // invites a translator to "translate" it.
    const html = await fs.readFile(path.join(root, 'public', 'index.html'), 'utf8');
    const logo = html.match(/<a class="logo"[^>]*>([\s\S]{0,80}?)<\/a>/)?.[1] ?? '';
    assert.ok(logo.includes('Lagen'), `logo markup unexpected: ${logo}`);
    assert.ok(!/data-i18n/.test(logo), 'the company name must not be a translatable string');
  });
});

describe('the infrastructure identifiers were NOT renamed', () => {
  // Each of these is load-bearing on the running server.
  const required: Array<[string, RegExp, string]> = [
    ['infra/ami/files/ggp', /\/opt\/globalgold\/compose\.yml/, 'the compose file path the CLI drives'],
    ['infra/ami/quickstart.sh', /globalgold:local/, 'the docker image tag the service runs'],
    ['docker-compose.prod.yml', /globalgold/, 'the database user and name'],
    ['.env.example', /postgres:\/\/globalgold/, 'the database connection string'],
  ];

  for (const [file, pattern, why] of required) {
    it(`${file} still uses the globalgold identifier — ${why}`, async () => {
      const text = await fs.readFile(path.join(root, file), 'utf8');
      assert.match(text, pattern,
        `${file} lost its globalgold identifier; renaming it breaks the deployment`);
    });
  }

  it('the update script is still called globalgold-update', async () => {
    // `sudo globalgold-update` is how the server is deployed. Renaming the
    // file would strand every machine already running.
    await fs.access(path.join(root, 'infra/ami/files/scripts/globalgold-update'));
  });
});
