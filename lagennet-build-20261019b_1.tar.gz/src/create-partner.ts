/**
 * Creates a partner — another platform that operates Lagennet wallets for
 * its own users (KobPaw is the first).
 *
 *   sudo ggp create-partner "KobPaw"
 *   npm run create-partner -- --name "KobPaw"
 *
 * The key is printed ONCE and only its hash is stored. If it is lost, issue a
 * new one and revoke the old; it cannot be recovered.
 */
import { parseArgs } from 'node:util';
import { pool } from './db.js';
import { migrate } from './migrate.js';
import { createPartner } from './partners/partners.js';

const { values, positionals } = parseArgs({
  allowPositionals: true,
  options: { name: { type: 'string' } },
});
const name = values.name ?? positionals[0];
if (!name) {
  console.error('Usage: ggp create-partner "Partner Name"');
  process.exit(1);
}

await migrate();
const { partner, key } = await createPartner(name);

console.log(`\n  Partner created: ${partner.name}`);
console.log(`  id:  ${partner.id}`);
console.log(`\n  Partner key (shown once — store it in the partner's secrets now):`);
console.log(`\n    ${key.key}\n`);
console.log('  The partner authenticates with:  Authorization: Bearer <that key>');
console.log('  It can create wallets and send transfers only for wallets IT creates.');
console.log('  Revoke it any time from the admin panel, or issue a second key and');
console.log('  retire this one.\n');

await pool.end();
