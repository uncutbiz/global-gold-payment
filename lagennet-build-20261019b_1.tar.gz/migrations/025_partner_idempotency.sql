-- Idempotency for the partner API.
--
-- THE BUG THIS PREVENTS, STATED PLAINLY
--
-- `POST /v1/partner/transfers` moves money. Every HTTP client in the world
-- retries on a timeout, and a timeout is exactly the case where the caller
-- does not know whether the first attempt landed. Without a key to recognise
-- the retry by, the second attempt sends the money a second time. The partner
-- did nothing wrong; the network hiccuped and their customer paid twice.
--
-- The merchant API has had this since the beginning. The partner API shipped
-- without it, which made it unsafe for anyone to integrate against — so this
-- closes that before another company is invited to.
--
-- WHY A SEPARATE TABLE FROM THE MERCHANT ONE
--
-- `idempotency_keys` is keyed (merchant_id, key) with a NOT NULL foreign key
-- to merchants, and nineteen merchant routes depend on it. Relaxing that
-- column to also hold partner ids would mean dropping a NOT NULL and a
-- foreign key on a table in live use, to save one table. Not worth it: the
-- shape is identical and the two owners stay independently constrained.

CREATE TABLE partner_idempotency_keys (
  partner_id       TEXT NOT NULL REFERENCES partners(id),
  key              TEXT NOT NULL,
  -- The hash of method + path + body. A key reused with DIFFERENT parameters
  -- is a bug in the caller, not a retry, and is refused rather than silently
  -- replaying an answer to a different question.
  request_hash     TEXT NOT NULL,
  -- NULL while the first attempt is still running: a concurrent retry gets
  -- told it is in progress instead of starting a second transfer.
  response_status  INTEGER,
  response_body    JSONB,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (partner_id, key)
);

CREATE INDEX partner_idempotency_created_idx ON partner_idempotency_keys (created_at);
