-- Partners: another platform operating wallets for its own users.
--
-- KobPaw is the case this exists for. It is a separate product with its own
-- users, and it wants Lagennet to be the rails underneath its cross-border
-- person-to-person transfers. The wallet API already does exactly that, but
-- every endpoint authenticates an END USER's session, so KobPaw could only use
-- it by making each of its users separately sign in here. That is not a
-- product flow. A partner credential lets KobPaw act for its users
-- server-to-server.
--
-- THE ONE RULE THAT MATTERS
--
-- A partner key can move other people's money. So a partner may only ever
-- touch a wallet IT created. `users.partner_id` records who owns the
-- relationship and every partner endpoint resolves users through it — if the
-- row is not yours, it does not exist as far as you are concerned. Without
-- that scoping a single partner key would be a key to every wallet on the
-- platform, including wallets belonging to real customers who signed up
-- directly and never heard of KobPaw.
--
-- `partner_ref` is the partner's OWN id for that user, so KobPaw addresses
-- wallets by the id it already has instead of storing ours. Unique per
-- partner, which also makes creation idempotent: the same ref twice returns
-- the same wallet rather than a second one.

CREATE TABLE partners (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Keys are stored hashed, exactly like merchant API keys: a leaked database
-- must not hand over working credentials. The last four characters are kept so
-- a person can tell which key a log line is about.
CREATE TABLE partner_keys (
  id          TEXT PRIMARY KEY,
  partner_id  TEXT NOT NULL REFERENCES partners(id),
  key_hash    TEXT NOT NULL UNIQUE,
  last_four   TEXT NOT NULL,
  label       TEXT,
  revoked_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX partner_keys_partner_idx ON partner_keys (partner_id) WHERE revoked_at IS NULL;

-- Which partner, if any, operates this wallet. NULL means the person signed up
-- directly and no partner may act for them.
ALTER TABLE users ADD COLUMN partner_id  TEXT REFERENCES partners(id);
ALTER TABLE users ADD COLUMN partner_ref TEXT;

CREATE UNIQUE INDEX users_partner_ref_idx ON users (partner_id, partner_ref)
  WHERE partner_id IS NOT NULL AND partner_ref IS NOT NULL;
CREATE INDEX users_partner_idx ON users (partner_id) WHERE partner_id IS NOT NULL;

-- Every action a partner takes, kept whether it succeeded or not. A credential
-- that can move money needs a record that is not the application's own logs.
CREATE TABLE partner_actions (
  id          BIGSERIAL PRIMARY KEY,
  partner_id  TEXT NOT NULL REFERENCES partners(id),
  key_id      TEXT REFERENCES partner_keys(id),
  action      TEXT NOT NULL,
  subject_ref TEXT,
  ok          BOOLEAN NOT NULL,
  detail      JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX partner_actions_partner_idx ON partner_actions (partner_id, created_at DESC);
