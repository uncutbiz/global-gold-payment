import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { one, pool } from '../db.js';
import {
  cancelPaymentIntent, capturePaymentIntent, confirmPaymentIntent, createPaymentIntent,
  createRefund, getPaymentIntent, listPaymentIntents, type ConfirmSource,
} from '../payments/service.js';
import { createLink, getLink, intentForLink, listLinks, resolveLink, setLinkActive } from '../payments/links.js';
import { createCustomer, getCustomer, listCustomers, updateCustomer } from '../merchants/customers.js';
import { daily, dailyCsv, periodFrom, series, summary, topLinks } from '../merchants/reports.js';
import { acceptDispute, getDispute, listDisputes, submitEvidence } from '../payments/disputes.js';
import {
  addLine, createInvoice, getInvoice, listInvoices, overdueInvoices,
  removeLine, sendInvoice, voidInvoice,
} from '../payments/invoices.js';
import {
  createSubscription, getSubscription, listPaymentMethods, listSubscriptions,
  saveCardForCustomer, setSubscriptionStatus,
} from '../payments/subscriptions.js';
import { checkoutConfig } from '../merchants/connect.js';
import { createPayout, getBalance } from '../settlement/settlement.js';
import { ApiError, SUPPORTED_CURRENCIES } from '../util/common.js';
import { tokenize } from '../vault/vault.js';
import { idempotency, rateLimit, requireKey } from './middleware.js';
import { businessLogIn, businessLogOut, businessSignUp, changeBusinessPassword, keyPrefixes, payoutWallet, rollKeys, setPayoutDestination } from '../merchants/accounts.js';
import { COUNTRIES } from '../wallet/fx.js';
import {
  confirmPhoneVerification, finishPasswordReset, startPasswordReset,
  startPhoneVerification, verifyResetCode,
} from '../auth/reset.js';

export const api = Router();

const cardRateLimit = rateLimit(Number(process.env.CARD_RATE_LIMIT ?? 30), 60_000);

const currency = z.string().toLowerCase().pipe(z.enum(SUPPORTED_CURRENCIES));
const minorUnits = z.number().int().positive().max(99_999_999);

// ---------------------------------------------------------------- hosted checkout
// Authenticated by the PaymentIntent's client_secret instead of an API key.
async function checkoutIntent(id: string, secret: unknown) {
  const row = await one(pool,
    `SELECT pi.id, pi.merchant_id, pi.amount, pi.currency, pi.status, pi.description, pi.client_secret, m.name AS merchant_name
       FROM payment_intents pi JOIN merchants m ON m.id = pi.merchant_id WHERE pi.id = $1`, [id]);
  const ok = row && typeof secret === 'string' && secret.length === row.client_secret.length &&
    crypto.timingSafeEqual(Buffer.from(secret), Buffer.from(row.client_secret));
  if (!ok) throw new ApiError(404, 'resource_missing', 'This checkout link is not valid.');
  return row;
}

api.get('/v1/checkout/:id', async (req, res) => {
  const r = await checkoutIntent(req.params.id as string, req.query.client_secret);
  res.json({ id: r.id, merchant: r.merchant_name, amount: r.amount, currency: r.currency, status: r.status, description: r.description });
});

/**
 * What the page needs to collect a card: which processor, and its public keys.
 * The checkout page asks for this before drawing anything, because a Square
 * merchant and a simulated one need completely different card fields.
 */
api.get('/v1/checkout/:id/payment_config', async (req, res) => {
  const r = await checkoutIntent(req.params.id as string, req.query.client_secret);
  res.json(await checkoutConfig(r.merchant_id));
});

/**
 * Pay a hosted checkout.
 *
 * Two shapes, and which one is allowed depends on the merchant's processor:
 *   provider_token  a single-use token the processor's SDK made in the browser.
 *                   The card number never reaches this server.
 *   card            a raw card, which only the simulated network accepts.
 *                   confirmPaymentIntent refuses it for any other processor.
 */
api.post('/v1/checkout/:id/pay', cardRateLimit, async (req, res) => {
  const body = z.object({
    client_secret: z.string(),
    card: z.object({ number: z.string().min(12).max(23), exp_month: z.coerce.number().int(), exp_year: z.coerce.number().int(), cvc: z.string() }).optional(),
    provider_token: z.string().min(4).max(4096).optional(),
    verification_token: z.string().min(4).max(4096).optional(),
  }).refine((b) => Boolean(b.card) !== Boolean(b.provider_token), {
    message: 'Send either card or provider_token, not both and not neither.',
  }).parse(req.body);
  const r = await checkoutIntent(req.params.id as string, body.client_secret);
  const merchant = await one(pool, 'SELECT * FROM merchants WHERE id=$1', [r.merchant_id]);

  let source: ConfirmSource;
  if (body.provider_token) {
    source = { kind: 'provider_token', token: body.provider_token, verificationToken: body.verification_token };
  } else {
    // Check the processor BEFORE the vault. confirmPaymentIntent would refuse a
    // raw card for Square or Stripe anyway, but by then the number would
    // already be encrypted and stored — a PAN kept in our vault for a payment
    // that was never going to happen. Cheaper never to accept it.
    const cfg = await checkoutConfig(merchant.id) as { provider: string; tokenizes_in_browser: boolean };
    if (cfg.tokenizes_in_browser) {
      throw new ApiError(400, 'raw_card_not_accepted',
        `This business takes payments through ${cfg.provider}, which requires the card to be tokenised in your browser. `
        + 'Reload the checkout page so it can load the right card form.');
    }
    source = { kind: 'vault_token', tokenId: (await tokenize(pool, { merchantId: merchant.id }, body.card!)).id };
  }

  const pi = await confirmPaymentIntent(merchant, r.id, source);
  res.json({ id: pi.id, status: pi.status, amount: pi.amount, currency: pi.currency, last_payment_error: pi.last_payment_error, payment_method: pi.payment_method });
});

// ---------------------------------------------------------------- merchant
// ---------------------------------------------------------------- business accounts
const businessAuthLimit = rateLimit(Number(process.env.AUTH_RATE_LIMIT ?? 20), 60_000);

api.post('/v1/business/signup', businessAuthLimit, async (req, res) => {
  const body = z.object({
    business_name: z.string().trim().min(2).max(120),
    name: z.string().trim().min(1).max(100),
    email: z.email(),
    password: z.string().min(10, 'Use at least 10 characters for your password.').max(200),
    country: z.string().length(2),
    business_type: z.enum(['individual', 'company', 'nonprofit']),
    website: z.url().optional(),
    description: z.string().max(500).optional(),
  }).parse(req.body);
  res.status(201).json(await businessSignUp(body));
});

api.post('/v1/business/login', businessAuthLimit, async (req, res) => {
  const body = z.object({ email: z.string(), password: z.string() }).parse(req.body);
  res.json(await businessLogIn(body.email, body.password));
});

api.post('/v1/business/logout', async (req, res) => {
  const t = req.header('authorization')?.slice(7) ?? '';
  if (t.startsWith('ggm_')) await businessLogOut(t);
  res.json({ ok: true });
});

api.get('/v1/account', requireKey('secret'), async (req, res) => {
  const m = req.merchant as any;
  /*
   * The phone belongs to the signed-in PERSON, not the business, so it is
   * read from merchant_users rather than merchants. An API key is not a
   * person and has no phone — that case returns null rather than pretending.
   *
   * Masked, never returned whole. The dashboard only needs to say whether a
   * number is there and verified; printing it in full would put it in every
   * screenshot and browser cache for no benefit.
   */
  let phone: { masked: string; verified: boolean } | null = null;
  if (req.sessionUserId) {
    const u = await pool.query(
      `SELECT phone, phone_verified_at FROM merchant_users WHERE id = $1`, [req.sessionUserId]);
    const row = u.rows[0];
    if (row?.phone) {
      phone = {
        masked: `••• ••• ${String(row.phone).slice(-4)}`,
        verified: row.phone_verified_at !== null,
      };
    }
  }
  res.json({
    object: 'account', ...m,
    country_name: COUNTRIES[m.country]?.name,
    api_keys: await keyPrefixes(m.id),
    payout_wallet: await payoutWallet(m.id),
    phone,
  });
});

api.post('/v1/account', requireKey('secret'), async (req, res) => {
  const body = z.object({
    webhook_url: z.url().nullable().optional(),
    payout_method: z.enum(['bank', 'wallet']).optional(),
    payout_wallet_email: z.email().optional(),
  }).parse(req.body);
  const out: Record<string, unknown> = { object: 'account', id: req.merchant!.id };
  if (body.webhook_url !== undefined) {
    const m = await one(pool, 'UPDATE merchants SET webhook_url=$2 WHERE id=$1 RETURNING webhook_url', [req.merchant!.id, body.webhook_url]);
    out.webhook_url = m.webhook_url;
  }
  if (body.payout_method) Object.assign(out, await setPayoutDestination(req.merchant!.id, body.payout_method, body.payout_wallet_email));
  res.json(out);
});

// Revokes the current keys and returns new ones. The secret key is shown only here.
// ------------------------------------------------------- phone and recovery
// The reset endpoints take no key: someone who has forgotten their password
// cannot present one. They are rate limited hard for that reason.
const resetLimit = rateLimit(Number(process.env.RESET_RATE_LIMIT ?? 10), 60_000);

/** Attach a number to the signed-in business account and send it a code. */
api.post('/v1/account/phone', requireKey('secret'), async (req, res) => {
  const body = z.object({ phone: z.string().min(5).max(30) }).parse(req.body);
  const userId = req.sessionUserId;
  if (!userId) {
    throw new ApiError(400, 'api_key_session',
      'Sign in with your email to add a phone number; an API key is not a person.');
  }
  res.json(await startPhoneVerification('merchant_user', userId, body.phone, req.ip));
});

api.post('/v1/account/phone/verify', requireKey('secret'), async (req, res) => {
  const body = z.object({ code: z.string().min(4).max(10) }).parse(req.body);
  const userId = req.sessionUserId;
  if (!userId) throw new ApiError(400, 'api_key_session', 'Sign in with your email first.');
  res.json(await confirmPhoneVerification('merchant_user', userId, body.code));
});

/** Step 1 of "I forgot my password". Always answers the same way. */
api.post('/v1/business/forgot_password', resetLimit, async (req, res) => {
  const body = z.object({ phone: z.string().min(5).max(30) }).parse(req.body);
  res.json(await startPasswordReset('merchant_user', body.phone, req.ip));
});

/** Step 2. A correct code becomes a short-lived ticket. */
api.post('/v1/business/forgot_password/verify', resetLimit, async (req, res) => {
  const body = z.object({
    phone: z.string().min(5).max(30),
    code: z.string().min(4).max(10),
  }).parse(req.body);
  res.json(await verifyResetCode('merchant_user', body.phone, body.code));
});

/** Step 3. The ticket plus a new password. */
api.post('/v1/business/forgot_password/reset', resetLimit, async (req, res) => {
  const body = z.object({
    ticket: z.string().min(10).max(200),
    new_password: z.string().min(10, 'Use at least 10 characters.').max(200),
  }).parse(req.body);
  res.json(await finishPasswordReset('merchant_user', body.ticket, body.new_password, 10));
});

/** A business owner changes their own dashboard password. */
api.post('/v1/account/password', requireKey('secret'), async (req, res) => {
  const body = z.object({
    current_password: z.string().min(1),
    new_password: z.string().min(10, 'Use at least 10 characters.').max(200),
  }).parse(req.body);
  const userId = req.sessionUserId;
  if (!userId) {
    throw new ApiError(400, 'api_key_session',
      'You are signed in with an API key, which has no password. Sign in with your email to change it.');
  }
  res.json(await changeBusinessPassword(userId, body.current_password, body.new_password));
});

api.post('/v1/account/keys/roll', requireKey('secret'), async (req, res) => {
  res.status(201).json({ object: 'api_keys', ...(await rollKeys(req.merchant!.id)) });
});

// Tokenization: called from the browser with a publishable key.
api.post('/v1/tokens', cardRateLimit, requireKey('publishable', 'secret'), async (req, res) => {
  const body = z.object({
    card: z.object({
      number: z.string().min(12).max(23),
      exp_month: z.coerce.number().int(),
      exp_year: z.coerce.number().int(),
      cvc: z.string(),
    }),
  }).parse(req.body);
  const t = await tokenize(pool, { merchantId: req.merchant!.id }, body.card);
  res.status(201).json({ object: 'token', id: t.id, card: { brand: t.brand, last4: t.last4, exp_month: t.exp_month, exp_year: t.exp_year } });
});

const sk = requireKey('secret');

api.post('/v1/payment_intents', sk, idempotency, async (req, res) => {
  const body = z.object({
    amount: minorUnits.min(50, 'Amount must be at least 50 minor units.'),
    currency,
    capture_method: z.enum(['automatic', 'manual']).optional(),
    description: z.string().max(500).optional(),
    metadata: z.record(z.string(), z.string().max(500)).optional(),
    payment_token: z.string().optional(),
    provider_token: z.string().min(4).max(4096).optional(),
    verification_token: z.string().min(4).max(4096).optional(),
    confirm: z.boolean().optional(),
  }).parse(req.body);
  let pi = await createPaymentIntent(req.merchant!, body);
  if (body.confirm) {
    if (!body.payment_token && !body.provider_token) {
      throw new ApiError(400, 'parameter_missing', 'payment_token or provider_token is required when confirm is true.');
    }
    if (body.payment_token && body.provider_token) {
      throw new ApiError(400, 'parameter_invalid', 'Send either payment_token or provider_token, not both.');
    }
    pi = await confirmPaymentIntent(req.merchant!, pi.id, confirmSource(body));
  }
  res.status(201).json(pi);
});

api.get('/v1/payment_intents', sk, async (req, res) => {
  const limit = z.coerce.number().int().min(1).max(100).default(25).parse(req.query.limit);
  res.json({ object: 'list', data: await listPaymentIntents(req.merchant!.id, limit) });
});

api.get('/v1/payment_intents/:id', requireKey('secret', 'publishable'), async (req, res) => {
  const pi = await getPaymentIntent(req.merchant!.id, req.params.id as string);
  if (req.keyKind === 'publishable') {
    // Publishable keys may read an intent only with its client secret, and see a reduced view.
    if (req.query.client_secret !== pi.client_secret) throw new ApiError(404, 'resource_missing', 'No such payment_intent.');
    const { id, amount, currency: cur, status, last_payment_error, payment_method, description } = pi;
    return res.json({ id, object: 'payment_intent', amount, currency: cur, status, last_payment_error, payment_method, description });
  }
  res.json(pi);
});

/**
 * Confirm: server-side with a secret key, or from the browser with a
 * publishable key plus the client secret.
 *
 * `payment_token` is a token from our card vault and works only on the
 * simulated network. `provider_token` is a single-use token from the
 * processor's own SDK and is what Square and Stripe merchants use — the card
 * number never reaches this server. Exactly one of the two.
 */
const confirmBody = z.object({
  payment_token: z.string().optional(),
  provider_token: z.string().min(4).max(4096).optional(),
  verification_token: z.string().min(4).max(4096).optional(),
  client_secret: z.string().optional(),
}).refine((b) => Boolean(b.payment_token) !== Boolean(b.provider_token), {
  message: 'Send either payment_token or provider_token, not both and not neither.',
});

function confirmSource(b: { payment_token?: string; provider_token?: string; verification_token?: string }): ConfirmSource {
  return b.provider_token
    ? { kind: 'provider_token', token: b.provider_token, verificationToken: b.verification_token }
    : { kind: 'vault_token', tokenId: b.payment_token! };
}

api.post('/v1/payment_intents/:id/confirm', requireKey('secret', 'publishable'), idempotency, async (req, res) => {
  const body = confirmBody.parse(req.body);
  const id = req.params.id as string;
  if (req.keyKind === 'publishable') {
    const row = await one(pool, 'SELECT client_secret FROM payment_intents WHERE id=$1 AND merchant_id=$2', [id, req.merchant!.id]);
    const ok = row && body.client_secret &&
      row.client_secret.length === body.client_secret.length &&
      crypto.timingSafeEqual(Buffer.from(row.client_secret), Buffer.from(body.client_secret));
    if (!ok) throw new ApiError(404, 'resource_missing', 'No such payment_intent.');
  }
  const pi = await confirmPaymentIntent(req.merchant!, id, confirmSource(body));
  if (req.keyKind === 'publishable') {
    return res.json({ id: pi.id, object: 'payment_intent', status: pi.status, amount: pi.amount, currency: pi.currency, last_payment_error: pi.last_payment_error, payment_method: pi.payment_method });
  }
  res.json(pi);
});

api.post('/v1/payment_intents/:id/capture', sk, idempotency, async (req, res) => {
  const body = z.object({ amount_to_capture: minorUnits.optional() }).parse(req.body ?? {});
  res.json(await capturePaymentIntent(req.merchant!, req.params.id as string, body.amount_to_capture));
});

api.post('/v1/payment_intents/:id/cancel', sk, idempotency, async (req, res) => {
  res.json(await cancelPaymentIntent(req.merchant!, req.params.id as string));
});

// ---------------------------------------------------------------- payment links
// A shareable URL that takes a payment. The merchant side is an ordinary
// secret-key API; the two public endpoints below it are what a stranger with
// the link can reach, and they are deliberately the only ones.

api.post('/v1/payment_links', sk, idempotency, async (req, res) => {
  const body = z.object({
    title: z.string().min(1).max(120),
    currency,
    amount: minorUnits.min(50).optional(),
    min_amount: minorUnits.min(50).optional(),
    max_amount: minorUnits.optional(),
    description: z.string().max(500).optional(),
    expires_at: z.coerce.date().optional(),
    max_uses: z.number().int().positive().max(1_000_000).optional(),
    metadata: z.record(z.string(), z.string().max(500)).optional(),
  }).parse(req.body);
  res.status(201).json(await createLink(req.merchant!, body));
});

api.get('/v1/payment_links', sk, async (req, res) => {
  res.json({ object: 'list', data: await listLinks(req.merchant!) });
});

api.get('/v1/payment_links/:id', sk, async (req, res) => {
  res.json(await getLink(req.merchant!, req.params.id as string));
});

api.post('/v1/payment_links/:id/:action', sk, async (req, res) => {
  const action = req.params.action;
  if (action !== 'activate' && action !== 'deactivate') {
    throw new ApiError(404, 'resource_missing', 'Unknown action.');
  }
  res.json(await setLinkActive(req.merchant!, req.params.id as string, action === 'activate'));
});

/**
 * What the public pay page shows. No API key: the code in the URL is the
 * credential, which is why it is 50 bits of randomness and why a wrong code
 * and a switched-off link return the same shape of error.
 */
api.get('/v1/pay/:code', async (req, res) => {
  res.json(await resolveLink(req.params.code as string));
});

/**
 * Turn the link into a payment the buyer can complete.
 *
 * Rate-limited with the card limiter: this endpoint creates database rows for
 * anyone who can reach it, so it is the natural thing to hammer.
 */
api.post('/v1/pay/:code/intent', cardRateLimit, async (req, res) => {
  const body = z.object({ amount: minorUnits.optional() }).parse(req.body ?? {});
  const { intentId, clientSecret } = await intentForLink(req.params.code as string, body.amount);
  res.status(201).json({ payment_intent: intentId, client_secret: clientSecret });
});

// ------------------------------------------------------------------ customers
api.post('/v1/customers', sk, idempotency, async (req, res) => {
  const body = z.object({
    email: z.string().email().max(254).optional(),
    name: z.string().max(200).optional(),
    phone: z.string().max(40).optional(),
    metadata: z.record(z.string(), z.string().max(500)).optional(),
  }).parse(req.body ?? {});
  res.status(201).json(await createCustomer(req.merchant!, body));
});

api.get('/v1/customers', sk, async (req, res) => {
  const q = z.object({ query: z.string().max(200).optional(), limit: z.coerce.number().int().positive().optional() })
    .parse(req.query ?? {});
  res.json({ object: 'list', data: await listCustomers(req.merchant!, q) });
});

api.get('/v1/customers/:id', sk, async (req, res) => {
  res.json(await getCustomer(req.merchant!, req.params.id as string));
});

api.post('/v1/customers/:id', sk, async (req, res) => {
  const body = z.object({
    email: z.string().email().max(254).optional(),
    name: z.string().max(200).optional(),
    phone: z.string().max(40).optional(),
  }).parse(req.body ?? {});
  res.json(await updateCustomer(req.merchant!, req.params.id as string, body));
});

// -------------------------------------------------------------- subscriptions
api.post('/v1/customers/:id/payment_methods', sk, idempotency, async (req, res) => {
  const body = z.object({
    provider_token: z.string().min(4).max(4096).optional(),
    verification_token: z.string().min(4).max(4096).optional(),
    payment_token: z.string().optional(),
  }).parse(req.body ?? {});
  res.status(201).json(await saveCardForCustomer(req.merchant!, {
    customerId: req.params.id as string,
    providerToken: body.provider_token,
    verificationToken: body.verification_token,
    vaultTokenId: body.payment_token,
  }));
});

api.get('/v1/customers/:id/payment_methods', sk, async (req, res) => {
  res.json({ object: 'list', data: await listPaymentMethods(req.merchant!, req.params.id as string) });
});

api.post('/v1/subscriptions', sk, idempotency, async (req, res) => {
  const body = z.object({
    customer: z.string(),
    payment_method: z.string(),
    amount: minorUnits.min(50),
    currency,
    interval: z.enum(['day', 'week', 'month', 'year']),
    interval_count: z.number().int().positive().max(52).optional(),
    description: z.string().max(500).optional(),
    max_cycles: z.number().int().positive().max(1000).optional(),
    start_at: z.coerce.date().optional(),
    charge_now: z.boolean().optional(),
  }).parse(req.body);
  res.status(201).json(await createSubscription(req.merchant!, body));
});

api.get('/v1/subscriptions', sk, async (req, res) => {
  const q = z.object({ customer: z.string().optional() }).parse(req.query ?? {});
  res.json({ object: 'list', data: await listSubscriptions(req.merchant!, q.customer) });
});

api.get('/v1/subscriptions/:id', sk, async (req, res) => {
  res.json(await getSubscription(req.merchant!, req.params.id as string));
});

api.post('/v1/subscriptions/:id/:action', sk, async (req, res) => {
  const action = req.params.action;
  if (action !== 'pause' && action !== 'resume' && action !== 'cancel') {
    throw new ApiError(404, 'resource_missing', 'Unknown action.');
  }
  res.json(await setSubscriptionStatus(req.merchant!, req.params.id as string, action));
});

// ------------------------------------------------------------------- invoices
const lineBody = z.object({
  description: z.string().min(1).max(300),
  quantity: z.number().positive().max(1_000_000).optional(),
  unit_amount: z.number().int().nonnegative().max(99_999_999),
  tax_bps: z.number().int().min(0).max(10_000).optional(),
});

api.post('/v1/invoices', sk, idempotency, async (req, res) => {
  const body = z.object({
    customer: z.string(),
    currency,
    title: z.string().max(200).optional(),
    note: z.string().max(2000).optional(),
    due_at: z.coerce.date().optional(),
    lines: z.array(lineBody).max(200).optional(),
    metadata: z.record(z.string(), z.string().max(500)).optional(),
  }).parse(req.body);
  res.status(201).json(await createInvoice(req.merchant!, body));
});

api.get('/v1/invoices', sk, async (req, res) => {
  const q = z.object({
    status: z.enum(['draft','open','paid','void','uncollectible']).optional(),
    customer: z.string().optional(),
  }).parse(req.query ?? {});
  res.json({ object: 'list', data: await listInvoices(req.merchant!, q) });
});

api.get('/v1/invoices/overdue', sk, async (req, res) => {
  res.json({ object: 'list', data: await overdueInvoices(req.merchant!) });
});

api.get('/v1/invoices/:id', sk, async (req, res) => {
  res.json(await getInvoice(req.merchant!, req.params.id as string));
});

api.post('/v1/invoices/:id/lines', sk, async (req, res) => {
  res.json(await addLine(req.merchant!, req.params.id as string, lineBody.parse(req.body)));
});

api.delete('/v1/invoices/:id/lines/:lineId', sk, async (req, res) => {
  res.json(await removeLine(req.merchant!, req.params.id as string, req.params.lineId as string));
});

api.post('/v1/invoices/:id/send', sk, async (req, res) => {
  res.json(await sendInvoice(req.merchant!, req.params.id as string));
});

api.post('/v1/invoices/:id/void', sk, async (req, res) => {
  res.json(await voidInvoice(req.merchant!, req.params.id as string));
});

// ------------------------------------------------------------------- disputes
// A merchant cannot open a dispute — the cardholder's bank does that, and we
// hear about it by webhook. What they can do is answer one, or give up on it.

api.get('/v1/disputes', sk, async (req, res) => {
  const q = z.object({ status: z.enum(['needs_response','under_review','won','lost','accepted']).optional() })
    .parse(req.query ?? {});
  res.json({ object: 'list', data: await listDisputes(req.merchant!, q.status) });
});

api.get('/v1/disputes/:id', sk, async (req, res) => {
  res.json(await getDispute(req.merchant!, req.params.id as string));
});

api.post('/v1/disputes/:id/evidence', sk, async (req, res) => {
  const body = z.record(z.string(), z.string().max(20_000)).parse(req.body ?? {});
  res.json(await submitEvidence(req.merchant!, req.params.id as string, body));
});

api.post('/v1/disputes/:id/accept', sk, async (req, res) => {
  res.json(await acceptDispute(req.merchant!, req.params.id as string));
});

// -------------------------------------------------------------------- reports
const reportRange = z.object({ from: z.string().optional(), to: z.string().optional() });

api.get('/v1/reports/summary', sk, async (req, res) => {
  const p = periodFrom(reportRange.parse(req.query ?? {}));
  res.json({ from: p.from, to: p.to, data: await summary(req.merchant!, p) });
});

api.get('/v1/reports/daily', sk, async (req, res) => {
  const p = periodFrom(reportRange.parse(req.query ?? {}));
  res.json({ from: p.from, to: p.to, data: await daily(req.merchant!, p) });
});

api.get('/v1/reports/series', sk, async (req, res) => {
  const q = z.object({ days: z.coerce.number().int().min(1).max(90).optional() }).parse(req.query ?? {});
  res.json({ object: 'list', data: await series(req.merchant!, q.days ?? 7) });
});

api.get('/v1/reports/top_links', sk, async (req, res) => {
  const p = periodFrom(reportRange.parse(req.query ?? {}));
  res.json({ object: 'list', data: await topLinks(req.merchant!, p) });
});

api.get('/v1/reports/daily.csv', sk, async (req, res) => {
  const p = periodFrom(reportRange.parse(req.query ?? {}));
  const name = `globalgold-${p.from.toISOString().slice(0, 10)}-to-${p.to.toISOString().slice(0, 10)}.csv`;
  res.type('text/csv').set('content-disposition', `attachment; filename="${name}"`);
  res.send(await dailyCsv(req.merchant!, p));
});

api.post('/v1/refunds', sk, idempotency, async (req, res) => {
  const body = z.object({ payment_intent: z.string(), amount: minorUnits.optional() }).parse(req.body);
  res.status(201).json(await createRefund(req.merchant!, body.payment_intent, body.amount));
});

api.get('/v1/balance', sk, async (req, res) => {
  res.json(await getBalance(req.merchant!.id));
});

api.post('/v1/payouts', sk, idempotency, async (req, res) => {
  const body = z.object({ currency, amount: minorUnits.optional() }).parse(req.body);
  res.status(201).json(await createPayout(req.merchant!, body.currency, body.amount));
});

api.get('/v1/payouts', sk, async (req, res) => {
  const r = await pool.query('SELECT * FROM payouts WHERE merchant_id=$1 ORDER BY created_at DESC LIMIT 50', [req.merchant!.id]);
  res.json({ object: 'list', data: r.rows });
});

api.get('/v1/events', sk, async (req, res) => {
  const limit = z.coerce.number().int().min(1).max(100).default(25).parse(req.query.limit);
  const r = await pool.query(
    'SELECT id, type, data, created_at FROM events WHERE merchant_id=$1 ORDER BY created_at DESC LIMIT $2',
    [req.merchant!.id, limit]);
  res.json({ object: 'list', data: r.rows });
});
