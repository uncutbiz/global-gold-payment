import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { config } from '../config.js';
import { one, pool } from '../db.js';
import { ApiError, SUPPORTED_CURRENCIES } from '../util/common.js';
import { rateLimit } from './middleware.js';
import {
  convertBalance, getActivity, getWallet, linkCard, listSupported, logIn, logOut, lookupRecipient,
  payWithWallet, quoteConversion, quoteTransfer, requireUser, sendMoney, signUp, topUp, unlinkCard,
  walletPaymentPreview, withdraw,
} from '../wallet/wallet.js';
import { latestKyc, submitKyc } from '../wallet/kyc.js';
import {
  activateCard, cardOrder, createVirtualCard, listCards, orderPhysicalCard,
  revealCard, setCardControls, setCardStatus,
} from '../cards/cards.js';
import { listAuthorizations } from '../cards/authorize.js';

export const walletApi = Router();

const authLimit = rateLimit(Number(process.env.AUTH_RATE_LIMIT ?? 20), 60_000);

/**
 * Wallet features are gated by config.walletMode, because holding balances and
 * moving money between people is regulated activity. The gate lives here, in
 * front of the routes, so a feature can never be reached by a client that has
 * simply guessed the URL.
 *
 *   needsWallet  — any stored value at all (top-ups, balances, paying merchants)
 *   needsP2P     — sending money to another person, and cashing out to a bank
 */
function needsWallet(_req: any, res: any, next: any) {
  if (config.walletMode === 'off') {
    return res.status(403).json({ error: {
      type: 'invalid_request_error', code: 'wallet_disabled',
      message: 'Wallet balances are not available. Pay by card at checkout instead.',
    }});
  }
  next();
}

function needsP2P(_req: any, res: any, next: any) {
  if (config.walletMode !== 'full') {
    return res.status(403).json({ error: {
      type: 'invalid_request_error', code: 'transfers_disabled',
      message: 'Sending money to other people is not available on this platform yet.',
    }});
  }
  next();
}
const currency = z.string().toLowerCase().pipe(z.enum(SUPPORTED_CURRENCIES));
const cents = z.number().int().positive().max(1_000_000_000_00);
const password = z.string().min(10, 'Use at least 10 characters for your password.').max(200);
const card = z.object({ number: z.string().min(12).max(23), exp_month: z.coerce.number().int(), exp_year: z.coerce.number().int(), cvc: z.string() });

// ------------------------------------------------------------------ public
/**
 * What this deployment can actually do. The landing page and checkout read this
 * so the marketing copy can never promise a feature that is switched off.
 */
walletApi.get('/v1/platform', (_req, res) => {
  res.json({
    object: 'platform',
    providers: config.paymentProviders,
    provider: config.paymentProviders[0],
    live: !config.paymentProviders.includes('simulated')
      && (!config.paymentProviders.includes('square') || config.square.env === 'production')
      && (!config.paymentProviders.includes('stripe') || config.stripe.secretKey.startsWith('sk_live_')),
    wallet_mode: config.walletMode,
    features: {
      card_payments: true,
      wallet_balances: config.walletMode !== 'off',
      pay_with_wallet: config.walletMode !== 'off',
      person_to_person: config.walletMode === 'full',
      international_transfers: config.walletMode === 'full',
      withdrawals: config.walletMode === 'full',
    },
    platform_fee: { bps: config.platformFeeBps, fixed: config.platformFeeFixed },
  });
});

walletApi.get('/v1/wallet/supported', (_req, res) => res.json(listSupported()));

walletApi.get('/v1/wallet/recipients', needsP2P, authLimit, async (req, res) => {
  const email = z.email().parse(req.query.email);
  res.json(await lookupRecipient(email));
});

walletApi.post('/v1/wallet/signup', authLimit, async (req, res) => {
  const body = z.object({ email: z.email(), name: z.string().trim().min(1).max(100), password, country: z.string().length(2) }).parse(req.body);
  const r = await signUp(body);
  res.status(201).json({ object: 'session', token: r.session, user: r.user });
});

walletApi.post('/v1/wallet/login', authLimit, async (req, res) => {
  const body = z.object({ email: z.string(), password: z.string() }).parse(req.body);
  const r = await logIn(body.email, body.password);
  res.json({ object: 'session', token: r.session, user: r.user });
});

// ------------------------------------------------------------------ signed in
walletApi.post('/v1/wallet/logout', requireUser, async (req, res) => {
  await logOut(req.header('authorization')!.slice(7));
  res.json({ ok: true });
});

walletApi.get('/v1/wallet', requireUser, async (req, res) => res.json(await getWallet(req.user!)));
walletApi.get('/v1/wallet/activity', requireUser, async (req, res) => res.json(await getActivity(req.user!.id)));

walletApi.post('/v1/wallet/cards', authLimit, requireUser, async (req, res) => {
  const body = z.object({ card }).parse(req.body);
  res.status(201).json(await linkCard(req.user!.id, body.card));
});

walletApi.delete('/v1/wallet/cards/:id', requireUser, async (req, res) => {
  res.json(await unlinkCard(req.user!.id, req.params.id as string));
});

walletApi.get('/v1/wallet/kyc', requireUser, async (req, res) => {
  res.json({ status: req.user!.kyc_status, latest: await latestKyc(req.user!.id) });
});

walletApi.post('/v1/wallet/kyc', authLimit, requireUser, async (req, res) => {
  const body = z.object({
    legal_name: z.string().trim().min(2).max(150),
    date_of_birth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use the format YYYY-MM-DD.'),
    address_line: z.string().trim().min(3).max(200),
    city: z.string().trim().min(1).max(100),
    postal_code: z.string().trim().min(1).max(20),
    country: z.string().length(2),
    id_type: z.enum(['passport', 'national_id', 'drivers_license']),
    id_number: z.string().min(5).max(30),
    document: z.string().max(8 * 1024 * 1024),
  }).parse(req.body);
  res.status(201).json(await submitKyc(req.user!.id, body));
});

walletApi.post('/v1/wallet/top_ups', needsWallet, requireUser, async (req, res) => {
  const body = z.object({ amount: cents, card: z.string() }).parse(req.body);
  res.status(201).json(await topUp(req.user!, body.amount, body.card));
});

walletApi.post('/v1/wallet/transfer_quotes', needsP2P, requireUser, async (req, res) => {
  const body = z.object({ to: z.email(), amount: cents, currency: currency.optional() }).parse(req.body);
  res.json(await quoteTransfer(req.user!, body));
});

walletApi.post('/v1/wallet/transfers', needsP2P, requireUser, async (req, res) => {
  const body = z.object({
    to: z.email(), amount: cents, currency: currency.optional(),
    note: z.string().max(140).optional(), quote: z.string().optional(),
  }).parse(req.body);
  res.status(201).json(await sendMoney(req.user!, body));
});

walletApi.post('/v1/wallet/conversion_quotes', needsWallet, requireUser, async (req, res) => {
  const body = z.object({ from: currency, to: currency, amount: cents }).parse(req.body);
  res.json(await quoteConversion(req.user!, body.from, body.to, body.amount));
});

walletApi.post('/v1/wallet/conversions', needsWallet, requireUser, async (req, res) => {
  const body = z.object({ from: currency, to: currency, amount: cents, quote: z.string().optional() }).parse(req.body);
  res.status(201).json(await convertBalance(req.user!, body));
});

walletApi.post('/v1/wallet/withdrawals', needsP2P, requireUser, async (req, res) => {
  const body = z.object({ amount: cents, currency: currency.optional() }).parse(req.body);
  res.status(201).json(await withdraw(req.user!, body.amount, body.currency));
});

// ------------------------------------------------------------------ "Pay with Global Gold" at checkout
async function checkoutPi(id: string, secret: unknown) {
  const pi = await one(pool, 'SELECT id, amount, currency, status, client_secret FROM payment_intents WHERE id = $1', [id]);
  const ok = pi && typeof secret === 'string' && secret.length === pi.client_secret.length &&
    crypto.timingSafeEqual(Buffer.from(secret), Buffer.from(pi.client_secret));
  if (!ok) throw new ApiError(404, 'resource_missing', 'This checkout link is not valid.');
  return pi;
}

walletApi.get('/v1/checkout/:id/wallet_preview', needsWallet, requireUser, async (req, res) => {
  const pi = await checkoutPi(req.params.id as string, req.query.client_secret);
  res.json(await walletPaymentPreview(req.user!, pi));
});

walletApi.post('/v1/checkout/:id/pay_with_wallet', needsWallet, requireUser, async (req, res) => {
  const body = z.object({ client_secret: z.string() }).parse(req.body);
  await checkoutPi(req.params.id as string, body.client_secret);
  const r = await payWithWallet(req.user!, req.params.id as string);
  res.json({ id: r.id, status: r.status, amount: r.amount, currency: r.currency, paid_from: r.paid_from, payment_method: { type: 'global_gold_wallet' } });
});

// ─────────────────────────────────────────────────────── issued cards
/*
 * Cards we issue, as distinct from /v1/wallet/cards, which is a card the
 * customer already owns and links as a funding source. Two very different
 * things that both call themselves "card", so they get different paths.
 *
 * Gated on needsWallet: a card that spends a balance is only meaningful where
 * balances exist at all.
 */
const mccList = z.array(z.string().regex(/^\d{4}$/, 'An MCC is four digits.')).max(50);
const limitField = z.number().int().min(0).max(1_000_000_000_00).nullable();
const controls = {
  per_auth_limit: limitField.optional(),
  daily_limit: limitField.optional(),
  monthly_limit: limitField.optional(),
  allowed_mcc: mccList.nullable().optional(),
  blocked_mcc: mccList.nullable().optional(),
};

walletApi.get('/v1/cards', needsWallet, requireUser, async (req, res) => {
  res.json({ object: 'list', data: await listCards(req.user!) });
});

walletApi.post('/v1/cards', needsWallet, requireUser, async (req, res) => {
  const body = z.object({
    currency, nickname: z.string().max(60).optional(),
    single_use: z.boolean().optional(), ...controls,
  }).parse(req.body ?? {});
  res.status(201).json(await createVirtualCard(req.user!, body));
});

walletApi.post('/v1/cards/order', needsWallet, requireUser, async (req, res) => {
  const body = z.object({
    currency, nickname: z.string().max(60).optional(),
    address: z.object({
      name: z.string().min(1).max(120), line1: z.string().min(1).max(200),
      line2: z.string().max(200).optional(), city: z.string().min(1).max(120),
      region: z.string().max(120).optional(), postalCode: z.string().min(1).max(20),
      country: z.string().length(2),
    }),
    ...controls,
  }).parse(req.body ?? {});
  res.status(201).json(await orderPhysicalCard(req.user!, body));
});

walletApi.get('/v1/cards/:id/order', needsWallet, requireUser, async (req, res) => {
  res.json(await cardOrder(req.user!, req.params.id as string));
});

/** The digits. Its own call, so asking for a PAN is visible in the access log. */
walletApi.post('/v1/cards/:id/reveal', needsWallet, requireUser, async (req, res) => {
  res.json(await revealCard(req.user!, req.params.id as string));
});

walletApi.post('/v1/cards/:id/activate', needsWallet, requireUser, async (req, res) => {
  res.json(await activateCard(req.user!, req.params.id as string));
});

/*
 * The action is validated here rather than in the path. Express 5's router
 * rejects an inline regex in a parameter outright — `:action(freeze|cancel)`
 * throws at startup, taking the whole server with it — so the allowed set is
 * a lookup, exactly as the payment-link and subscription routes do it.
 */
walletApi.post('/v1/cards/:id/:action', needsWallet, requireUser, async (req, res) => {
  const want: Record<string, 'frozen' | 'active' | 'canceled'> =
    { freeze: 'frozen', unfreeze: 'active', cancel: 'canceled' };
  const next = want[req.params.action as string];
  if (!next) {
    throw new ApiError(404, 'resource_missing',
      `Unknown action '${req.params.action}'. Use freeze, unfreeze or cancel.`);
  }
  res.json(await setCardStatus(req.user!, req.params.id as string, next));
});

walletApi.post('/v1/cards/:id/controls', needsWallet, requireUser, async (req, res) => {
  const body = z.object(controls).parse(req.body ?? {});
  res.json(await setCardControls(req.user!, req.params.id as string, body));
});

walletApi.get('/v1/card_authorizations', needsWallet, requireUser, async (req, res) => {
  const q = z.object({ card: z.string().optional() }).parse(req.query ?? {});
  res.json({ object: 'list', data: await listAuthorizations(req.user!.id, q.card) });
});
