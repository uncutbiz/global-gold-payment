/**
 * The authorization decision — the "programmable" half of a card programme.
 *
 * A real issuer-processor holds the network connection and, when someone taps
 * the card, calls us with "£12.40 at SAINSBURYS, MCC 5411 — yes or no?" and
 * roughly two seconds to answer. This is that answer.
 *
 * Two things shape everything here.
 *
 * ONE: money must be held, not just checked. Checking the balance and then
 * letting the money be spent elsewhere before the capture arrives is how a
 * prepaid card goes negative. So an approval posts a ledger hold immediately,
 * moving funds out of the spendable balance into a hold account. Capture and
 * reversal both work against that hold.
 *
 * TWO: the check and the hold must be one atomic act. Two taps at the same
 * instant, each seeing the same balance, is the classic double-spend — the
 * same shape of bug as the monthly fee cap, and closed the same way: the
 * wallet row is locked for the duration of the decision.
 *
 * Declines are recorded with a reason. "Why was my card declined" is the most
 * common support question any card programme gets, and a decline that leaves
 * no row makes it unanswerable.
 */
import { one, pool, tx } from '../db.js';
import { ApiError, newId } from '../util/common.js';
import { acct, balance, postJournal } from '../ledger/ledger.js';

/** Where held funds sit between approval and capture. */
const heldAccount = (userId: string) => `wallet:${userId}:card_hold`;

export interface AuthorizationRequest {
  cardId: string;
  amount: number;
  currency: string;
  merchantName?: string;
  mcc?: string;
}

export type DeclineReason =
  | 'card_not_active' | 'card_canceled' | 'card_frozen' | 'card_not_issued'
  | 'single_use_spent' | 'wrong_currency' | 'over_per_auth_limit'
  | 'over_daily_limit' | 'over_monthly_limit' | 'category_blocked'
  | 'insufficient_funds';

/** Said to the cardholder, not to the terminal. Plain, and never guessy. */
const REASON_TEXT: Record<DeclineReason, string> = {
  card_not_active: 'This card is not active.',
  card_canceled: 'This card was cancelled.',
  card_frozen: 'This card is frozen. Unfreeze it to use it.',
  card_not_issued: 'This card has not been made yet.',
  single_use_spent: 'This was a single-use card and has already been used.',
  wrong_currency: 'This card cannot be used in that currency.',
  over_per_auth_limit: 'This is more than the single-payment limit on this card.',
  over_daily_limit: 'This would go over the daily limit on this card.',
  over_monthly_limit: 'This would go over the monthly limit on this card.',
  category_blocked: 'This card is not allowed at this type of business.',
  insufficient_funds: 'There is not enough in the wallet for this payment.',
};

/**
 * Spend already committed this period.
 *
 * Counts approved and captured authorizations and leaves out reversals and
 * declines — a refused tap must not eat into a limit, or a card that declines
 * once for the wrong reason starts declining for every reason.
 */
async function spentSince(c: any, cardId: string, since: Date): Promise<number> {
  const r = await c.query(
    `SELECT coalesce(sum(CASE WHEN status='captured' THEN greatest(captured_amount, 0) ELSE amount END), 0)::bigint AS s
       FROM card_authorizations
      WHERE card_id = $1 AND status IN ('approved','captured') AND decided_at >= $2`,
    [cardId, since]);
  return Number(r.rows[0].s);
}

const startOfDay = () => { const d = new Date(); d.setUTCHours(0, 0, 0, 0); return d; };
const startOfMonth = () => { const d = new Date(); d.setUTCDate(1); d.setUTCHours(0, 0, 0, 0); return d; };

/**
 * Decide, and if approved, hold the money.
 *
 * Returns the authorization either way. A decline is a recorded outcome, not
 * an error — the network asked a question and got an answer.
 */
export async function authorize(req: AuthorizationRequest) {
  if (!Number.isInteger(req.amount) || req.amount <= 0) {
    throw new ApiError(400, 'parameter_invalid', 'amount must be a positive whole number of minor units.');
  }

  return tx(async (c) => {
    const card = await one(c, `SELECT * FROM issued_cards WHERE id = $1 FOR UPDATE`, [req.cardId]);
    if (!card) throw new ApiError(404, 'resource_missing', 'No such card.');

    const id = newId('cauth');
    const decline = async (reason: DeclineReason) => {
      const row = await one(c,
        `INSERT INTO card_authorizations
           (id, card_id, user_id, amount, currency, merchant_name, mcc, status, decline_reason, decided_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,'declined',$8, now()) RETURNING *`,
        [id, card.id, card.user_id, req.amount, req.currency.toLowerCase(),
         req.merchantName ?? null, req.mcc ?? null, reason]);
      return present(row);
    };

    // ── the card itself ──────────────────────────────────────────────────
    if (card.status === 'canceled') return decline('card_canceled');
    if (card.status === 'frozen') return decline('card_frozen');
    if (card.status === 'ordered' || !card.vault_token_id) return decline('card_not_issued');
    if (card.status !== 'active') return decline('card_not_active');

    if (card.single_use) {
      const used = await one(c,
        `SELECT 1 FROM card_authorizations WHERE card_id=$1 AND status IN ('approved','captured') LIMIT 1`,
        [card.id]);
      if (used) return decline('single_use_spent');
    }

    // A card denominated in one currency does not decide foreign exchange on
    // its own. Converting silently at a rate nobody agreed to is worse than
    // a decline the cardholder can act on.
    if (req.currency.toLowerCase() !== card.currency) return decline('wrong_currency');

    // ── merchant category ────────────────────────────────────────────────
    // An allow list is absolute: with one set, anything not named is refused,
    // and the block list is not consulted. That ordering matters for a card
    // handed to a child or an employee — "only these" must not be weakened by
    // a forgotten entry in "not these".
    const mcc = req.mcc ?? null;
    if (card.allowed_mcc?.length) {
      if (!mcc || !card.allowed_mcc.includes(mcc)) return decline('category_blocked');
    } else if (card.blocked_mcc?.length && mcc && card.blocked_mcc.includes(mcc)) {
      return decline('category_blocked');
    }

    // ── limits ───────────────────────────────────────────────────────────
    if (card.per_auth_limit !== null && req.amount > Number(card.per_auth_limit)) {
      return decline('over_per_auth_limit');
    }
    if (card.daily_limit !== null) {
      const spent = await spentSince(c, card.id, startOfDay());
      if (spent + req.amount > Number(card.daily_limit)) return decline('over_daily_limit');
    }
    if (card.monthly_limit !== null) {
      const spent = await spentSince(c, card.id, startOfMonth());
      if (spent + req.amount > Number(card.monthly_limit)) return decline('over_monthly_limit');
    }

    // ── the money ────────────────────────────────────────────────────────
    // Read inside the same transaction that holds the card row, so two taps
    // cannot both see the same balance.
    const available = await balance(c, acct.wallet(card.user_id), card.currency);
    if (available < req.amount) return decline('insufficient_funds');

    const row = await one(c,
      `INSERT INTO card_authorizations
         (id, card_id, user_id, amount, currency, merchant_name, mcc, status, network_ref, decided_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'approved',$8, now()) RETURNING *`,
      [id, card.id, card.user_id, req.amount, req.currency.toLowerCase(),
       req.merchantName ?? null, req.mcc ?? null, `sim_${id}`]);

    // The hold. Out of spendable, into held — the balance a cardholder sees
    // drops the moment the card is tapped, which is what they expect.
    await postJournal(c, card.currency, { type: 'card_authorization', id },
      `card authorization ${id}${req.merchantName ? ` at ${req.merchantName}` : ''}`, [
        { account: acct.wallet(card.user_id), debit: req.amount },
        { account: heldAccount(card.user_id), credit: req.amount },
      ]);

    return present(row);
  });
}

/**
 * The merchant takes the money.
 *
 * Capture may be for less than was authorized — a restaurant authorizes with a
 * tip allowance, a fuel pump authorizes a round number — so the difference is
 * released back to the cardholder rather than quietly kept.
 */
export async function captureAuthorization(authId: string, amount?: number) {
  return tx(async (c) => {
    const a = await one(c, `SELECT * FROM card_authorizations WHERE id=$1 FOR UPDATE`, [authId]);
    if (!a) throw new ApiError(404, 'resource_missing', 'No such authorization.');
    if (a.status !== 'approved') {
      throw new ApiError(400, 'authorization_unexpected_state', `This authorization is ${a.status}.`);
    }
    const take = amount ?? Number(a.amount);
    if (!Number.isInteger(take) || take <= 0 || take > Number(a.amount)) {
      throw new ApiError(400, 'parameter_invalid', 'A capture cannot be for more than was authorized.');
    }

    const lines = [
      { account: heldAccount(a.user_id), debit: take },
      { account: acct.bankCash, credit: take },
    ];
    // Anything authorized and not taken goes straight back to spendable.
    const released = Number(a.amount) - take;
    if (released > 0) {
      lines.push({ account: heldAccount(a.user_id), debit: released });
      lines.push({ account: acct.wallet(a.user_id), credit: released });
    }
    await postJournal(c, a.currency, { type: 'card_capture', id: a.id },
      `card capture ${a.id}`, lines);

    const row = await one(c,
      `UPDATE card_authorizations SET status='captured', captured_amount=$2, captured_at=now()
        WHERE id=$1 RETURNING *`, [authId, take]);

    // A single-use card is spent. Closing it here rather than at approval
    // means an authorization that was never captured does not burn the card.
    await c.query(
      `UPDATE issued_cards SET status='canceled', canceled_at=now(), updated_at=now()
        WHERE id=$1 AND single_use = true AND status <> 'canceled'`, [a.card_id]);

    return present(row);
  });
}

/** The merchant never took it, or the network timed it out. Money goes back. */
export async function reverseAuthorization(authId: string) {
  return tx(async (c) => {
    const a = await one(c, `SELECT * FROM card_authorizations WHERE id=$1 FOR UPDATE`, [authId]);
    if (!a) throw new ApiError(404, 'resource_missing', 'No such authorization.');
    if (a.status !== 'approved') {
      throw new ApiError(400, 'authorization_unexpected_state', `This authorization is ${a.status}.`);
    }
    await postJournal(c, a.currency, { type: 'card_reversal', id: a.id },
      `card authorization ${a.id} reversed`, [
        { account: heldAccount(a.user_id), debit: Number(a.amount) },
        { account: acct.wallet(a.user_id), credit: Number(a.amount) },
      ]);
    const row = await one(c,
      `UPDATE card_authorizations SET status='reversed', reversed_at=now() WHERE id=$1 RETURNING *`,
      [authId]);
    return present(row);
  });
}

export function present(a: any) {
  return {
    id: a.id,
    object: 'card_authorization',
    card: a.card_id,
    amount: Number(a.amount),
    currency: a.currency,
    merchant_name: a.merchant_name,
    mcc: a.mcc,
    status: a.status,
    decline_reason: a.decline_reason,
    decline_message: a.decline_reason ? REASON_TEXT[a.decline_reason as DeclineReason] : null,
    captured_amount: Number(a.captured_amount ?? 0),
    created_at: a.created_at,
  };
}

export async function listAuthorizations(userId: string, cardId?: string, limit = 50) {
  const r = await pool.query(
    `SELECT * FROM card_authorizations
      WHERE user_id = $1 ${cardId ? 'AND card_id = $3' : ''}
      ORDER BY created_at DESC LIMIT $2`,
    cardId ? [userId, Math.min(limit, 100), cardId] : [userId, Math.min(limit, 100)]);
  return r.rows.map(present);
}

/** What a cardholder has authorized but not yet had taken. */
export async function heldTotal(userId: string, currency: string): Promise<number> {
  return balance(pool, heldAccount(userId), currency);
}
