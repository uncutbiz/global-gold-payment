/**
 * Browser test: clicks through every page of the real app (home, business
 * dashboard, hosted checkout, wallet, admin panel) against a real server and
 * database, and checks that each button does what it says.
 *
 *   npx playwright install chromium   # once
 *   npm run test:ui
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { chromium, type Browser, type Page } from 'playwright';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5433/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.CARD_RATE_LIMIT = '1000';
process.env.AUTH_RATE_LIMIT = '1000';

const { pool } = await import('../../src/db.js');
const { migrate } = await import('../../src/migrate.js');
const { createApp } = await import('../../src/server.js');

let base = '';
let server: http.Server;
let browser: Browser;
const errors: string[] = [];
const PW = 'correct horse battery';

async function page(): Promise<Page> {
  const p = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  p.on('pageerror', (e) => errors.push(`${p.url()}: ${e.message}`));
  p.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_TUNNEL|Failed to load resource/.test(m.text())) errors.push(`${p.url()}: ${m.text()}`); });
  return p;
}
const toast = async (p: Page, text: RegExp) => { await p.locator('#toast', { hasText: text }).waitFor({ timeout: 5000 }); };

/*
 * The business dashboard is tabbed: Home, Payments, Invoices, Customers,
 * Subscriptions, Payment links, Disputes, Reports, Settings. A control only
 * exists on its own section, and a reload lands back on Home — so anything
 * below that touches a form has to open its section first.
 */
const sec = async (p: Page, name: string) => {
  await p.click(`#sections button[data-sec="${name}"]`);
  await p.locator(`[data-section="${name}"]`).first().waitFor({ state: 'visible' });
};

async function api(method: string, path: string, key: string | null, body?: unknown) {
  const r = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(key ? { authorization: `Bearer ${key}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const b: any = await r.json();
  if (!r.ok) throw new Error(`${path}: ${b.error?.message}`);
  return b;
}

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  await api('POST', '/v1/admin/staff', 'test-admin', { email: 'boss@gg.test', name: 'Boss', password: 'staff-password-123', role: 'owner' });
});

after(async () => {
  await browser?.close();
  server.close();
  await pool.end();
});

describe('every page, every button', { concurrency: false }, () => {
  let checkoutUrl = '';

  it('landing page: calculator, sign-in links, and both sign-up forms work', async () => {
    const p = await page();
    await p.goto(base + '/');

    // Sign-in routes for each audience.
    for (const [name, path] of [['Customer sign in', '/wallet'], ['Business sign in', '/dashboard'], ['Staff sign in', '/admin']]) {
      assert.equal(await p.getByRole('link', { name }).first().getAttribute('href'), path, `${name} link`);
    }

    // The country list comes from the API, not a hard-coded copy.
    const supported = await (await fetch(base + '/v1/wallet/supported')).json();
    await p.waitForFunction(
      (n) => document.querySelectorAll('#to option').length === n, supported.countries.length, { timeout: 5000 });

    // Fee rules: free at home, 1% abroad, clamped to $0.99–$4.99.
    await p.fill('#amt', '250');
    await p.selectOption('#from', 'US');
    await p.selectOption('#to', 'US');
    assert.equal(await p.textContent('#fee'), 'Free', 'domestic transfers are free');
    await p.selectOption('#to', 'NG');
    assert.equal(await p.textContent('#fee'), '$2.50', '1% of $250');
    await p.fill('#amt', '10');
    assert.equal(await p.textContent('#fee'), '$0.99', 'minimum fee');
    await p.fill('#amt', '5000');
    assert.equal(await p.textContent('#fee'), '$4.99', 'maximum fee');
    assert.match(await p.textContent('#got') ?? '', /₦[\d,]+/, 'recipient amount in naira');

    // A customer can open a wallet from the landing page and land signed in.
    const who = Date.now().toString(36);
    await p.fill('#formP input[name=name]', 'Landing Customer');
    await p.selectOption('#formP select[name=country]', 'NG');
    await p.fill('#formP input[name=email]', `landing-${who}@test.com`);
    await p.fill('#formP input[name=password]', 'a-long-password-123');
    await p.click('#formP button[type=submit]');
    await p.waitForURL('**/wallet', { timeout: 10_000 });
    assert.ok(await p.evaluate(() => sessionStorage.getItem('ggp_wallet')), 'wallet session stored');

    // And a business can too, landing on its dashboard.
    await p.goto(base + '/');
    await p.click('#tabB');
    await p.fill('#formB input[name=business_name]', 'Landing Coffee');
    await p.fill('#formB input[name=name]', 'Landing Owner');
    await p.fill('#formB input[name=email]', `landing-biz-${who}@test.com`);
    await p.fill('#formB input[name=password]', 'a-long-password-123');
    await p.click('#formB button[type=submit]');
    await p.waitForURL('**/dashboard', { timeout: 10_000 });
    const key = await p.evaluate(() => sessionStorage.getItem('ggp_business'));
    assert.ok(key?.startsWith('ggm_'), 'business session stored');

    // A duplicate email is reported, not swallowed.
    await p.goto(base + '/');
    await p.fill('#formP input[name=name]', 'Duplicate');
    await p.fill('#formP input[name=email]', `landing-${who}@test.com`);
    await p.fill('#formP input[name=password]', 'a-long-password-123');
    await p.click('#formP button[type=submit]');
    await p.waitForSelector('#msgP .error', { timeout: 5000 });
    assert.match(await p.textContent('#msgP') ?? '', /already exists/i);

    await p.close();
  });

  it('business: sign up, wait for approval, get approved, create a checkout link', async () => {
    const p = await page();
    await p.goto(base + '/dashboard?signup');
    await p.fill('#bName', 'Lagos Juice Bar');
    await p.selectOption('#bCountry', 'NG');
    await p.fill('#bDesc', 'Fresh juice');
    await p.fill('#uName', 'Tunde');
    await p.fill('#uEmail', 'tunde@juice.test');
    await p.fill('#uPassword', 'business password');
    await p.click('#authBtn');
    await p.locator('#statusBanner', { hasText: 'reviewing' }).waitFor();
    assert.equal(await p.isDisabled('#createBtn'), true, 'cannot take payments before approval');

    // Staff approve in the admin panel.
    const a = await page();
    await a.goto(base + '/admin');
    await a.fill('#lEmail', 'boss@gg.test'); await a.fill('#lPassword', 'staff-password-123'); await a.click('#loginForm button');
    // At least one business is waiting — other tests may have created some too,
    // so assert "not zero" rather than an exact count.
    await a.waitForFunction(() => Number(document.getElementById('cBiz')?.textContent ?? 0) > 0, null, { timeout: 15_000 });
    await a.click('a[data-nav="merchants"]');
    await a.locator('.kyc', { hasText: 'Lagos Juice Bar' }).getByRole('button', { name: 'Approve' }).click();
    await toast(a, /can now take payments/);
    await a.close();

    await p.reload();
    // The sidebar shows status on every section, so this does not depend on
    // which tab happens to be open.
    await p.locator('#railStatus', { hasText: 'Active' }).waitFor();
    await sec(p, 'payments');
    assert.equal(await p.isDisabled('#createBtn'), false);
    await p.fill('#amount', '12.50');
    await p.selectOption('#currency', 'usd');
    await p.fill('#description', 'Mango smoothie');
    await p.click('#createBtn');
    const link = p.locator('#checkoutLink a');
    await link.waitFor();
    checkoutUrl = (await link.getAttribute('href'))!;
    assert.match(checkoutUrl, /\/checkout\/pi_/);

    // Developer keys and webhook settings.
    await sec(p, 'settings');
    await p.click('#rollKeys');
    await p.locator('#newKeys', { hasText: 'sk_test_' }).waitFor();
    await p.fill('#webhookUrl', 'https://example.com/hooks');
    await p.click('#saveWebhook');
    await toast(p, /Webhook endpoint saved/);
    await p.close();
  });

  it('wallet: sign up, get blocked abroad, verify identity, add money, send, convert, withdraw', async () => {
    // Recipient in Kenya.
    await api('POST', '/v1/wallet/signup', null, { email: 'wanjiru@ke.test', name: 'Wanjiru', password: PW, country: 'KE' });

    const p = await page();
    await p.goto(base + '/wallet');
    await p.click('#modeSignup');
    await p.fill('#name', 'Ada Lovelace'); await p.fill('#email', 'ada@us.test'); await p.fill('#password', PW);
    await p.selectOption('#country', 'US');
    await p.click('#authBtn');
    await p.locator('#kycBar', { hasText: 'Verify your identity' }).waitFor();

    // Link a card and add money.
    await p.click('[data-tab="add"]');
    await p.fill('#cardNumber', '4242424242424242'); await p.fill('#cardExp', '1230'); await p.fill('#cardCvc', '123');
    await p.click('#cardForm button[type=submit]');
    await toast(p, /Card linked/);
    await p.fill('#topupAmount', '400');
    await p.click('#topupForm button[type=submit]');
    await toast(p, /Added \$400\.00/);
    await p.locator('#homeBalance', { hasText: '$400.00' }).waitFor();

    // Send is always clickable: empty form explains what's missing.
    await p.click('[data-tab="send"]');
    assert.equal(await p.isDisabled('#sendBtn'), false);
    await p.click('#sendBtn');
    await p.locator('#sendError', { hasText: 'email' }).waitFor();

    // International send is blocked until verified.
    await p.fill('#sendTo', 'wanjiru@ke.test'); await p.fill('#sendAmount', '50');
    await p.click('#sendBtn');
    await p.locator('#sendError', { hasText: 'verified account' }).waitFor();

    // Verify identity.
    await p.click('#kycBar button');
    await p.fill('#kName', 'Ada Lovelace'); await p.fill('#kDob', '1990-12-10');
    await p.fill('#kAddr', '1 Main St'); await p.fill('#kCity', 'Boston'); await p.fill('#kPostal', '02110');
    await p.fill('#kNum', 'P1234567');
    await p.setInputFiles('#kDoc', { name: 'passport.png', mimeType: 'image/png', buffer: Buffer.concat([Buffer.from('89504e470d0a1a0a', 'hex'), crypto.randomBytes(500)]) });
    await p.click('#kBtn');
    await toast(p, /Submitted/);
    await p.locator('#kycBar', { hasText: 'under review' }).waitFor();

    // Staff approve it and view the document.
    const a = await page();
    await a.goto(base + '/admin');
    await a.fill('#lEmail', 'boss@gg.test'); await a.fill('#lPassword', 'staff-password-123'); await a.click('#loginForm button');
    await a.click('a[data-nav="kyc"]');
    const card = a.locator('.kyc', { hasText: 'Ada Lovelace' });
    await card.getByRole('button', { name: 'View document' }).click();
    await card.locator('img').waitFor();
    await card.getByRole('button', { name: 'Approve' }).click();
    await toast(a, /approved/);
    await a.close();

    await p.reload();
    await p.locator('#homeLabel', { hasText: 'Verified' }).waitFor();

    // Two-step international send: review, then confirm.
    await p.fill('#sendTo', 'wanjiru@ke.test'); await p.dispatchEvent('#sendTo', 'change');
    await p.locator('#recipientCard', { hasText: 'Kenya' }).waitFor();
    await p.fill('#sendAmount', '50'); await p.fill('#sendNote', 'Rent');
    await p.click('#sendBtn');
    await p.locator('#quoteBox', { hasText: 'Wanjiru gets' }).waitFor();
    await p.locator('#sendBtn', { hasText: 'Confirm and send $50.99' }).waitFor();
    await p.click('#sendBtn');
    await toast(p, /Sent\. They received KSh/);
    await p.locator('#homeBalance', { hasText: '$349.01' }).waitFor();
    await p.locator('#activity li', { hasText: 'Sent to Wanjiru' }).waitFor();

    // Convert.
    await p.click('[data-tab="convert"]');
    await p.fill('#convAmount', '20'); await p.selectOption('#convTo', 'eur');
    await p.click('#convBtn');
    await p.locator('#convQuote', { hasText: 'You get' }).waitFor();
    await p.click('#convBtn');
    await toast(p, /Converted to €/);
    await p.locator('#otherBalances', { hasText: 'EUR' }).waitFor();

    // Withdraw.
    await p.click('[data-tab="withdraw"]');
    await p.fill('#wdAmount', '10');
    await p.click('#withdrawForm button[type=submit]');
    await toast(p, /Withdrawal of \$10\.00/);

    // Get paid link.
    await p.click('[data-tab="request"]');
    assert.match(await p.textContent('#payLink') ?? '', /send_to=ada%40us\.test/);
    await p.close();
  });

  it('checkout: pay with the wallet, then refund and pay out from the dashboard', async () => {
    const p = await page();
    await p.goto(checkoutUrl);
    await p.locator('#amount', { hasText: '$12.50' }).waitFor();
    await p.click('#walletBtn');
    await p.fill('#wEmail', 'ada@us.test'); await p.fill('#wPassword', PW);
    await p.click('#wLoginBtn');
    await p.locator('#walletConfirm button', { hasText: 'Pay' }).click();
    await p.locator('#done', { hasText: 'Payment complete' }).waitFor();
    await p.close();

    // A second checkout paid by card, including a decline first.
    const b = await page();
    await b.goto(base + '/dashboard');
    await b.fill('#uEmail', 'tunde@juice.test'); await b.fill('#uPassword', 'business password'); await b.click('#authBtn');
    await sec(b, 'payments');
    await b.locator('#payments tr', { hasText: 'Global Gold wallet' }).waitFor();
    await b.fill('#amount', '30'); await b.fill('#description', 'Party pack'); await b.click('#createBtn');
    const url = (await b.locator('#checkoutLink a').getAttribute('href'))!;
    const c = await page();
    await c.goto(url);
    await c.fill('#number', '4000000000009995'); await c.fill('#exp', '1230'); await c.fill('#cvc', '123');
    await c.click('#payBtn');
    await c.locator('#error', { hasText: 'insufficient funds' }).waitFor();
    await c.fill('#number', '4242424242424242');
    await c.click('#payBtn');
    await c.locator('#done', { hasText: 'Payment complete' }).waitFor();
    await c.close();

    // Refund the wallet payment from the dashboard.
    await b.reload();
    await sec(b, 'payments');
    await b.locator('#payments tr', { hasText: 'Mango smoothie' }).getByRole('button', { name: 'Refund' }).click();
    await toast(b, /wallet/);

    // Payouts go to Ada's wallet.
    await sec(b, 'settings');
    await b.selectOption('#payoutMethod', 'wallet');
    await b.fill('#payoutWallet', 'ada@us.test');
    await b.click('#payoutForm button[type=submit]');
    await toast(b, /Payout settings saved/);
    await sec(b, 'home');
    await b.click('#payoutBtn');
    await toast(b, /Nothing available/);   // not settled yet

    // Staff run settlement.
    const a = await page();
    await a.goto(base + '/admin');
    await a.fill('#lEmail', 'boss@gg.test'); await a.fill('#lPassword', 'staff-password-123'); await a.click('#loginForm button');
    await a.getByRole('button', { name: 'Run daily settlement' }).click();
    await toast(a, /Settled/);

    await b.reload();
    await b.locator('#balances', { hasText: '$28.17' }).waitFor();   // $30 - $1.17 fee, minus the smoothie's $0.66 fee (fees aren't returned on refunds)
    await b.click('#payoutBtn');
    await toast(b, /Global Gold wallet/);
    await b.locator('#payouts', { hasText: 'Global Gold wallet' }).waitFor();
    await b.close();

    // Admin: transactions, drawer, alerts, customers, freeze, audit log.
    await a.click('a[data-nav="transactions"]');
    await a.locator('tbody tr', { hasText: 'Merchant payout' }).first().click();
    await a.locator('.drawer', { hasText: 'Ledger entries' }).waitFor();
    await a.click('.drawer header button');
    await a.fill('#tQ', 'Party pack');
    await a.locator('tbody tr', { hasText: 'Party pack' }).waitFor();
    await a.click('a[data-nav="customers"]');
    await a.locator('tbody tr', { hasText: 'Wanjiru' }).click();
    await a.getByRole('button', { name: 'Freeze account' }).click();
    await a.fill('textarea', 'Testing freeze');
    await a.getByRole('button', { name: 'Confirm' }).click();
    await toast(a, /Account frozen/);
    await a.getByRole('button', { name: 'Unfreeze account' }).click();
    await toast(a, /unfrozen/);
    await a.click('.drawer header button');
    await a.click('a[data-nav="staff"]');
    await a.locator('tbody tr', { hasText: 'user.freeze' }).waitFor();
    await a.locator('tbody tr', { hasText: 'kyc.approve' }).waitFor();
    await a.click('a[data-nav="overview"]');
    await a.locator('.pill', { hasText: 'balanced' }).waitFor();
    await a.close();

    // Ada sees the refund and the payout in her wallet.
    const w = await page();
    await w.goto(base + '/wallet');
    await w.fill('#email', 'ada@us.test'); await w.fill('#password', PW); await w.click('#authBtn');
    await w.locator('#activity li', { hasText: 'Business payout from Lagos Juice Bar' }).waitFor();
    await w.locator('#activity li', { hasText: 'Refund from Lagos Juice Bar' }).waitFor();
    await w.close();
  });

  it('no page threw a script error', () => {
    assert.deepEqual(errors, []);
  });
});
