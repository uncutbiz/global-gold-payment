/**
 * Issued cards: the authorization decision, the money it holds, and the
 * controls a cardholder sets.
 *
 * What is worth testing here is not that a good payment works — it is that
 * every way of spending money that should not be spendable is refused, and
 * that an approval and its hold are one atomic act. A prepaid card that can be
 * taken negative is the failure that ends a card programme.
 *
 * WARNING: wipes the target database's public schema.
 */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/globalgold_test';
process.env.ADMIN_TOKEN = 'test-admin-cards';
process.env.VAULT_KEY = crypto.randomBytes(32).toString('base64');
process.env.FINGERPRINT_KEY = crypto.randomBytes(32).toString('base64');
process.env.WEBHOOK_WORKER = 'off';
process.env.LOG_REQUESTS = 'off';
process.env.WALLET_MODE = 'full';

const { pool } = await import('../src/db.js');
const { migrate } = await import('../src/migrate.js');
const { acct, postJournal, balance } = await import('../src/ledger/ledger.js');
const { createVirtualCard, orderPhysicalCard, producePhysicalCard, activateCard,
        setCardStatus, setCardControls, revealCard, listCards, cardOrder } = await import('../src/cards/cards.js');
const { authorize, captureAuthorization, reverseAuthorization, heldTotal } = await import('../src/cards/authorize.js');
const { hashPassword } = await import('../src/util/passwords.js');

let n = 0;

/** A wallet holder with money in it, funded straight through the ledger. */
async function holder(fundMinor = 100_00, currency = 'usd') {
  const id = `usr_card_${n++}_${crypto.randomBytes(3).toString('hex')}`;
  await pool.query(
    `INSERT INTO users (id, email, name, password_hash) VALUES ($1,$2,'Card Tester',$3)`,
    [id, `${id}@test.local`, await hashPassword('a-long-password-123')]);
  if (fundMinor > 0) {
    const c = await pool.connect();
    try {
      await c.query('BEGIN');
      await postJournal(c as any, currency, { type: 'test_fund', id }, 'test funding', [
        { account: acct.bankCash, debit: fundMinor },
        { account: acct.wallet(id), credit: fundMinor },
      ]);
      await c.query('COMMIT');
    } finally { c.release(); }
  }
  return { id, name: 'Card Tester' };
}

const ADDRESS = {
  name: 'Card Tester', line1: '1 Test Street', city: 'Columbus',
  region: 'OH', postalCode: '43004', country: 'US',
};

before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
});
after(async () => { await pool.end(); });

describe('issuing cards', () => {
  it('makes a virtual card that is usable at once, and never returns the number by accident', async () => {
    const u = await holder();
    const card = await createVirtualCard(u, { currency: 'usd', nickname: 'Groceries' });
    assert.equal(card.status, 'active');
    assert.equal(card.kind, 'virtual');
    assert.match(card.last4, /^\d{4}$/);
    assert.equal((card as any).number, undefined, 'a card listing must never carry a PAN');
    assert.equal((card as any).pan, undefined);

    // The number comes back only when explicitly asked for.
    const shown = await revealCard(u, card.id);
    assert.match(shown.number, /^\d{16}$/);
    assert.ok(shown.number.startsWith('400000'),
      'a simulated card must sit in the non-routable test range, never a live BIN');
    assert.ok(shown.number.endsWith(card.last4));
  });

  it('orders a physical card with no number until it is produced', async () => {
    const u = await holder();
    const card = await orderPhysicalCard(u, { currency: 'usd', address: ADDRESS });
    assert.equal(card.status, 'ordered');
    assert.equal(card.last4, null, 'an unmade card has no number');

    // It cannot be spent while it is in the post.
    const refused = await authorize({ cardId: card.id, amount: 5_00, currency: 'usd' });
    assert.equal(refused.status, 'declined');
    assert.equal(refused.decline_reason, 'card_not_issued');

    await assert.rejects(() => revealCard(u, card.id), /not been made/);

    const made = await producePhysicalCard(card.id);
    assert.equal(made.status, 'shipped');
    assert.match(made.last4!, /^\d{4}$/);

    // Shipped is still not spendable: a card live in transit is spendable by
    // whoever opens the envelope.
    const inTransit = await authorize({ cardId: card.id, amount: 5_00, currency: 'usd' });
    assert.equal(inTransit.decline_reason, 'card_not_active');

    const live = await activateCard(u, card.id);
    assert.equal(live.status, 'active');
    const ok = await authorize({ cardId: card.id, amount: 5_00, currency: 'usd' });
    assert.equal(ok.status, 'approved');

    const order = await cardOrder(u, card.id);
    assert.equal(order.status, 'shipped');
    assert.equal(order.to.postal_code, '43004');
  });

  it('refuses an order with no address to send it to', async () => {
    const u = await holder();
    await assert.rejects(
      () => orderPhysicalCard(u, { currency: 'usd', address: { ...ADDRESS, line1: '' } }),
      /line1/);
  });

  it('shows one cardholder nothing of another’s cards', async () => {
    const a = await holder();
    const b = await holder();
    const card = await createVirtualCard(a, { currency: 'usd' });
    assert.equal((await listCards(b)).length, 0);
    await assert.rejects(() => revealCard(b, card.id), /No such card/);
    await assert.rejects(() => setCardStatus(b, card.id, 'canceled'), /No such card/);
  });
});

describe('authorization decisions', () => {
  it('holds the money, so the balance drops the moment the card is tapped', async () => {
    const u = await holder(100_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    assert.equal(await balance(pool, acct.wallet(u.id), 'usd'), 100_00);

    const auth = await authorize({ cardId: card.id, amount: 30_00, currency: 'usd', merchantName: 'Cafe' });
    assert.equal(auth.status, 'approved');
    assert.equal(await balance(pool, acct.wallet(u.id), 'usd'), 70_00, 'spendable drops at authorization');
    assert.equal(await heldTotal(u.id, 'usd'), 30_00);
  });

  it('cannot be double-spent by two taps at the same instant', async () => {
    const u = await holder(50_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    // Ten simultaneous taps of $10 against $50. Naively each sees $50 and
    // approves; only five may.
    const results = await Promise.all(
      Array.from({ length: 10 }, () => authorize({ cardId: card.id, amount: 10_00, currency: 'usd' })));
    const approved = results.filter((r) => r.status === 'approved');
    assert.equal(approved.length, 5, `${approved.length} approvals against a $50 balance`);
    assert.equal(await balance(pool, acct.wallet(u.id), 'usd'), 0);
    assert.ok(await balance(pool, acct.wallet(u.id), 'usd') >= 0, 'a prepaid card must never go negative');
    for (const r of results.filter((x) => x.status === 'declined')) {
      assert.equal(r.decline_reason, 'insufficient_funds');
    }
  });

  it('declines for a reason the cardholder can act on', async () => {
    const u = await holder(10_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    const r = await authorize({ cardId: card.id, amount: 50_00, currency: 'usd' });
    assert.equal(r.decline_reason, 'insufficient_funds');
    assert.match(r.decline_message!, /not enough/i);
    // And it is on the record, because "why was I declined" is unanswerable
    // without it.
    const rows = await pool.query(`SELECT * FROM card_authorizations WHERE id=$1`, [r.id]);
    assert.equal(rows.rows[0].status, 'declined');
  });

  it('honours freeze, unfreeze and cancel', async () => {
    const u = await holder();
    const card = await createVirtualCard(u, { currency: 'usd' });
    await setCardStatus(u, card.id, 'frozen');
    assert.equal((await authorize({ cardId: card.id, amount: 1_00, currency: 'usd' })).decline_reason, 'card_frozen');
    await setCardStatus(u, card.id, 'active');
    assert.equal((await authorize({ cardId: card.id, amount: 1_00, currency: 'usd' })).status, 'approved');
    await setCardStatus(u, card.id, 'canceled');
    assert.equal((await authorize({ cardId: card.id, amount: 1_00, currency: 'usd' })).decline_reason, 'card_canceled');
    // Cancelling is final.
    await assert.rejects(() => setCardStatus(u, card.id, 'active'), /cancelled/);
  });

  it('enforces the per-payment limit', async () => {
    const u = await holder();
    const card = await createVirtualCard(u, { currency: 'usd', per_auth_limit: 20_00 });
    assert.equal((await authorize({ cardId: card.id, amount: 20_01, currency: 'usd' })).decline_reason, 'over_per_auth_limit');
    assert.equal((await authorize({ cardId: card.id, amount: 20_00, currency: 'usd' })).status, 'approved');
  });

  it('enforces a daily limit across several payments, and a decline does not eat into it', async () => {
    const u = await holder(500_00);
    const card = await createVirtualCard(u, { currency: 'usd', daily_limit: 50_00 });
    assert.equal((await authorize({ cardId: card.id, amount: 30_00, currency: 'usd' })).status, 'approved');
    // Over the remaining 20, refused.
    assert.equal((await authorize({ cardId: card.id, amount: 25_00, currency: 'usd' })).decline_reason, 'over_daily_limit');
    // That refusal must not have consumed anything: exactly 20 is still fine.
    assert.equal((await authorize({ cardId: card.id, amount: 20_00, currency: 'usd' })).status, 'approved');
    assert.equal((await authorize({ cardId: card.id, amount: 1, currency: 'usd' })).decline_reason, 'over_daily_limit');
  });

  it('gives the daily limit back when an authorization is reversed', async () => {
    const u = await holder(500_00);
    const card = await createVirtualCard(u, { currency: 'usd', daily_limit: 50_00 });
    const a = await authorize({ cardId: card.id, amount: 50_00, currency: 'usd' });
    assert.equal((await authorize({ cardId: card.id, amount: 1_00, currency: 'usd' })).decline_reason, 'over_daily_limit');
    await reverseAuthorization(a.id);
    assert.equal((await authorize({ cardId: card.id, amount: 50_00, currency: 'usd' })).status, 'approved',
      'a reversed payment must not keep eating the limit');
  });

  it('treats an allow list as absolute and a block list as a veto', async () => {
    const u = await holder(500_00);
    const only = await createVirtualCard(u, { currency: 'usd', allowed_mcc: ['5411'] });
    assert.equal((await authorize({ cardId: only.id, amount: 5_00, currency: 'usd', mcc: '5411' })).status, 'approved');
    assert.equal((await authorize({ cardId: only.id, amount: 5_00, currency: 'usd', mcc: '5813' })).decline_reason, 'category_blocked');
    // Unknown category against an allow list is refused, not waved through.
    assert.equal((await authorize({ cardId: only.id, amount: 5_00, currency: 'usd' })).decline_reason, 'category_blocked');

    const not = await createVirtualCard(u, { currency: 'usd', blocked_mcc: ['7995'] });
    assert.equal((await authorize({ cardId: not.id, amount: 5_00, currency: 'usd', mcc: '7995' })).decline_reason, 'category_blocked');
    assert.equal((await authorize({ cardId: not.id, amount: 5_00, currency: 'usd', mcc: '5411' })).status, 'approved');
    // No category given and only a block list: allowed.
    assert.equal((await authorize({ cardId: not.id, amount: 5_00, currency: 'usd' })).status, 'approved');
  });

  it('will not convert currency on its own', async () => {
    const u = await holder(500_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    assert.equal((await authorize({ cardId: card.id, amount: 5_00, currency: 'eur' })).decline_reason, 'wrong_currency');
  });

  it('spends a single-use card once, and only after it is captured', async () => {
    const u = await holder(500_00);
    const card = await createVirtualCard(u, { currency: 'usd', single_use: true });
    const a = await authorize({ cardId: card.id, amount: 10_00, currency: 'usd' });
    assert.equal(a.status, 'approved');
    assert.equal((await authorize({ cardId: card.id, amount: 1_00, currency: 'usd' })).decline_reason, 'single_use_spent');
    await captureAuthorization(a.id);
    const after = await pool.query(`SELECT status FROM issued_cards WHERE id=$1`, [card.id]);
    assert.equal(after.rows[0].status, 'canceled', 'a used single-use card closes itself');
  });

  it('does not burn a single-use card on an authorization that was reversed', async () => {
    const u = await holder(500_00);
    const card = await createVirtualCard(u, { currency: 'usd', single_use: true });
    const a = await authorize({ cardId: card.id, amount: 10_00, currency: 'usd' });
    await reverseAuthorization(a.id);
    assert.equal((await authorize({ cardId: card.id, amount: 10_00, currency: 'usd' })).status, 'approved',
      'a payment that never completed must not consume the card');
  });
});

describe('capture and reversal', () => {
  it('returns the difference when less is taken than was authorized', async () => {
    const u = await holder(100_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    // A restaurant authorizes with room for a tip, then takes less.
    const a = await authorize({ cardId: card.id, amount: 60_00, currency: 'usd', merchantName: 'Restaurant' });
    assert.equal(await balance(pool, acct.wallet(u.id), 'usd'), 40_00);
    await captureAuthorization(a.id, 45_00);
    assert.equal(await balance(pool, acct.wallet(u.id), 'usd'), 55_00, 'the unused $15 comes back');
    assert.equal(await heldTotal(u.id, 'usd'), 0, 'nothing is left held');
  });

  it('puts everything back on a reversal', async () => {
    const u = await holder(100_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    const a = await authorize({ cardId: card.id, amount: 25_00, currency: 'usd' });
    await reverseAuthorization(a.id);
    assert.equal(await balance(pool, acct.wallet(u.id), 'usd'), 100_00);
    assert.equal(await heldTotal(u.id, 'usd'), 0);
  });

  it('refuses to capture more than was authorized, or to capture twice', async () => {
    const u = await holder(100_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    const a = await authorize({ cardId: card.id, amount: 20_00, currency: 'usd' });
    await assert.rejects(() => captureAuthorization(a.id, 20_01), /more than was authorized/);
    await captureAuthorization(a.id);
    await assert.rejects(() => captureAuthorization(a.id), /captured/);
    await assert.rejects(() => reverseAuthorization(a.id), /captured/);
  });

  it('leaves the ledger balanced through the whole life of a card payment', async () => {
    const u = await holder(200_00);
    const card = await createVirtualCard(u, { currency: 'usd' });
    const a = await authorize({ cardId: card.id, amount: 80_00, currency: 'usd' });
    await captureAuthorization(a.id, 70_00);
    const b = await authorize({ cardId: card.id, amount: 40_00, currency: 'usd' });
    await reverseAuthorization(b.id);

    const r = await pool.query(
      `SELECT coalesce(sum(debit),0)::bigint AS d, coalesce(sum(credit),0)::bigint AS c FROM ledger_lines`);
    assert.equal(Number(r.rows[0].d), Number(r.rows[0].c), 'debits and credits must agree');
    assert.equal(await balance(pool, acct.wallet(u.id), 'usd'), 130_00);
    assert.equal(await heldTotal(u.id, 'usd'), 0);
  });
});

describe('controls can be changed', () => {
  it('updates only the fields sent', async () => {
    const u = await holder(500_00);
    const card = await createVirtualCard(u, { currency: 'usd', per_auth_limit: 10_00, daily_limit: 20_00 });
    const after = await setCardControls(u, card.id, { per_auth_limit: 50_00 });
    assert.equal(after.controls.per_auth_limit, 50_00);
    assert.equal(after.controls.daily_limit, 20_00, 'a field not sent is left alone');
    const cleared = await setCardControls(u, card.id, { daily_limit: null });
    assert.equal(cleared.controls.daily_limit, null, 'null removes a limit');
    assert.equal(cleared.controls.per_auth_limit, 50_00);
  });

  it('refuses a nonsense limit', async () => {
    const u = await holder();
    const card = await createVirtualCard(u, { currency: 'usd' });
    await assert.rejects(() => setCardControls(u, card.id, { daily_limit: -5 as any }), /whole number/);
  });

  it('treats a zero limit as "nothing", not as "no limit"', async () => {
    const u = await holder(500_00);
    const card = await createVirtualCard(u, { currency: 'usd', per_auth_limit: 0 });
    assert.equal((await authorize({ cardId: card.id, amount: 1, currency: 'usd' })).decline_reason, 'over_per_auth_limit');
  });
});
